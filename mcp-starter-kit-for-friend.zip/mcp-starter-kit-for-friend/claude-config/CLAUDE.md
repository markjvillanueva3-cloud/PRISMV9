<!-- rtk-instructions v2 (PRISM-customized) -->
# RTK — Use for HIGH-VOLUME commands only

RTK compresses CLI output. Use `rtk` prefix ONLY for these commands where savings are proven:

```bash
# Tests (99% savings — ALWAYS use rtk for tests)
rtk vitest run              # 2.17M chars → 5K chars
rtk npx vitest run          # Same
rtk vitest run <file>       # Per-file too

# npm operations (70-90% savings)
rtk npm install             # Compact install output
rtk npm list                # Compact dependency tree
rtk pnpm install            # Same

# Analytics
rtk gain                    # View session savings stats
```

## Do NOT use rtk for:
- `ls` — RTK adds timestamps/sizes, INCREASES output
- `npx tsc --noEmit` — Already compact, RTK adds formatting overhead
- `git` commands — PRISM is not a git repo
- Any command producing <500 chars output — overhead exceeds savings

## Rule: If output will be SHORT, skip rtk. If output will be LONG (tests, installs), use rtk.
<!-- /rtk-instructions -->
