# Setup Guide — Installing the Claude Code Config

This guide walks you through installing the Claude Code harness from this starter kit onto your own machine so the slash commands, agents, skills, and autofire hooks actually fire. After this, your Claude Code will behave like Mark's — with `/rgs`, `/forge-audit`, `/boot`, `/handoff`, token budgeting, duplication guards, the whole kit.

> **Audience:** a developer who is already using Claude Code CLI and wants to adopt this config to help build their own MCP server.

---

## 0. Prerequisites

- Claude Code CLI installed (`claude` command works)
- A shell you know (bash via Git Bash on Windows is fine)
- Node.js 18+ (for `.mjs` hooks) and PowerShell 7+ (for `.ps1` hooks — Windows) OR adapt the `.ps1` scripts to bash on macOS/Linux
- A directory for your own MCP server project (we'll call this `~/your-mcp/`)

Your Claude config lives at:
- **Windows:** `C:\Users\<you>\.claude\`
- **macOS/Linux:** `~/.claude/`

Throughout this guide, `$CLAUDE_HOME` means that directory.

---

## 1. Back up your existing Claude config

> **Do not skip this.** If you already have a `~/.claude/` you care about, back it up first.

```bash
# macOS / Linux
cp -r ~/.claude ~/.claude.backup-$(date +%Y%m%d)

# Windows (bash)
cp -r "/c/Users/$USER/.claude" "/c/Users/$USER/.claude.backup-$(date +%Y%m%d)"
```

---

## 2. Install the slash commands

Slash commands are markdown files in `$CLAUDE_HOME/commands/`. Each `.md` file becomes a `/filename` slash command in Claude Code.

```bash
# macOS / Linux
mkdir -p ~/.claude/commands
cp slash-commands/*.md ~/.claude/commands/

# Windows (bash)
mkdir -p "/c/Users/$USER/.claude/commands"
cp slash-commands/*.md "/c/Users/$USER/.claude/commands/"
```

**Cherry-pick if you want.** There are 189 commands and most of the machining-specific ones (`/lathe-ai`, `/wedm-*`, `/okuma-macro`, `/hypermill-*`, `/vam-analyze`, etc.) won't apply to your MCP. Safe infrastructure commands to keep:

```
boot.md                  context.md              context-audit.md
context-integrity.md     context-map.md          handoff.md
health.md                status.md               system-audit.md
scope.md                 snapshot.md             sync.md
audit-task.md            scrutinize.md           findings.md
remember.md              replay.md               quick-ref.md
rgs.md                   scout.md                navigate.md
code-index.md            engine-browse.md        registry-browse.md
forge.md                 forge-audit.md          forge-engines.md
forge-wiring.md          forge-hooks.md          forge-skills.md
forge-tests.md           forge-types.md          forge-metrics.md
forge-perf.md            forge-drift.md          forge-docs.md
forge-deps.md            forge-cleanup.md        forge-safety.md
hook-browse.md           hook-profile.md         hook-stats.md
hook-status.md           process-health.md       quality-dashboard.md
quality-gate.md          quality-check.md        token-budget.md
token-ledger.md          checkpoint.md           release-ready.md
verify-loop.md           plan-build.md           read-plan.md
roadmap-quality-check.md milestone.md            ship.md
smart.md                 smart-route.md          auto-commit.md
update-all-docs.md       stop-check.md
```

Delete the rest from `~/.claude/commands/` if you don't want them.

---

## 3. Install the agents

Subagents live at `$CLAUDE_HOME/agents/`.

```bash
mkdir -p ~/.claude/agents
cp -r claude-config/agents/. ~/.claude/agents/
```

Included agents (all domain-agnostic — keep them all):
- `build-doctor.md` — diagnoses TypeScript build errors
- `catalog-enricher.md` — fills gaps in data catalogs
- `code-archaeologist.md` — deep read-only codebase exploration
- `dispatcher-wirer.md` — wires engines to dispatchers
- `doc-generator.md` — batch JSDoc generation
- `physics-review-agent.md` / `physics-reviewer.md` — formula correctness review
- `regression-hunter.md` — test-failure root cause analysis
- `test-review-agent.md` / `test-runner.md` — test coverage + execution
- `wiring-review-agent.md` — dispatcher wiring audit
- `teams/` — multi-agent team definitions

Rename references to "PRISM" in these files if you want them tailored to your domain, otherwise they work as-is.

---

## 4. Install the skills

Skills auto-load based on user intent. Install them at `$CLAUDE_HOME/skills/`.

```bash
mkdir -p ~/.claude/skills
cp -r claude-config/skills/. ~/.claude/skills/
```

Included skills (all domain-agnostic):
`activate-features`, `adaptive-optimize`, `batch-ops`, `bot-launch`, `checkpoint`, `codebase-memory-*` (4 variants), `context-budget`, `coordination-dashboard`, `cowork-*`, `cron-bootstrap`, `cron-manage`, `dispatch-format`, `dispatcher-profile`, `feature-matrix`, `memory-prune`, `model-router`, `notify`, `prism-review` (rename to your-project-review), `remediation-scorecard`, `security-audit`, `self-heal`, `session-persist`, `skill-modernize`, `smart`, `smart-apply`, `system-health`, `team-budget`, `team-dispatch`.

The `skill-classification.json` file drives the skill router — keep it.

---

## 5. Install the autofire hooks

This is the **single biggest token-savings mechanism** in the whole kit. Autofire hooks live at the root of `$CLAUDE_HOME/` as `hookify.autofire-<name>.local.md` files. They fire slash commands automatically when user input matches a pattern — so you don't burn tokens teaching Claude to route requests.

```bash
# macOS / Linux
cp claude-config/hookify-autofire/*.md ~/.claude/

# Windows (bash)
cp claude-config/hookify-autofire/*.md "/c/Users/$USER/.claude/"
```

134 autofire files installed. Open a few to see the pattern:

```markdown
---
trigger: <regex on user input>
action: <slash command to fire>
---
```

---

## 6. Wire up `settings.json`

`settings.json` is where Claude Code's hooks, permissions, and env vars live. **Review this file before copying — it references paths from Mark's machine.**

```bash
cp claude-config/settings.json ~/.claude/settings.json
```

Then edit it:
1. Replace any absolute paths (`H:\prism\...`, `C:\Users\Mark Villanueva\...`) with your own.
2. Remove PRISM-specific hook references you don't want (e.g., `engine-duplication-blocker.mjs` only matters if you have engines).
3. Keep these general-purpose hooks:
   - `pre-edit-safety-gate.ps1` — blocks risky writes
   - `code-integrity-prewrite.mjs` — pre-write integrity
   - `cross-session-duplication-guard.mjs` — duplication guard
   - `post-build-verify.ps1` — post-build verification

Point each hook entry at the file under your `hooks-reference/` install (see step 8).

---

## 7. Install global `CLAUDE.md`

The global `CLAUDE.md` contains user instructions Claude loads on every session (RTK rules, memory-system pointers, etc.).

```bash
# Review it first — it contains PRISM-specific references
cat claude-config/CLAUDE.md

# If happy, copy it
cp claude-config/CLAUDE.md ~/.claude/CLAUDE.md
```

Edit the copied file:
- Remove the PRISM memory path references unless you also set up the auto-memory system.
- Keep the **RTK** section — it's a token-savings tool (`rtk vitest run` → 99% output compression for test runs).
- Keep `currentDate` / `userEmail` if you want Claude to know those.

---

## 8. Install the hooks themselves

The hooks referenced in `settings.json` live in the `hooks-reference/` folder of this kit. Put them somewhere stable:

```bash
mkdir -p ~/your-mcp/scripts/hooks
cp hooks-reference/*.mjs hooks-reference/*.ps1 ~/your-mcp/scripts/hooks/
```

Then update `settings.json` paths to point at `~/your-mcp/scripts/hooks/<hook>.{mjs,ps1}`.

Read `hooks-reference/README-setup.md` for wiring specifics.

---

## 9. Install keybindings (optional)

```bash
cp claude-config/keybindings.json ~/.claude/keybindings.json
```

Only keep the bindings you actually want — delete the rest.

---

## 10. Verify the install

Restart Claude Code, then try these in order:

```
/commands             # lists every slash command Claude Code sees
/health               # system health check
/hook-status          # shows which hooks are registered
/context              # context-budget report
/rgs <query>          # resource graph search
/forge-audit          # audit your (currently empty) engine set
```

If `/commands` lists your imports and `/health` returns something, the install worked.

---

## 11. Build out your MCP

Now that the harness is live:

1. Follow `roadmaps/MCP-FULL-AUTOMATION-BLUEPRINT.md` to scaffold the server.
2. Use `/forge-engines` to create new engines (read `forge-engine.md` slash command for the template).
3. As you add engines, port `TokenEconomyEngine`, `ContextCompactionEngine`, `SessionHandoffV2Engine` from `engines-reference/`.
4. Run `/token-budget` and `/token-ledger` periodically to confirm you're staying under budget.
5. When a session gets long, run `/handoff` — it will produce a compacted doc you can feed into the next session.

---

## Troubleshooting

- **Slash commands don't appear** → check that files are at `~/.claude/commands/*.md` (not in a subdir).
- **Hooks don't fire** → check `settings.json` hook paths are absolute and the scripts are executable.
- **`.ps1` hooks fail on macOS/Linux** → install PowerShell (`brew install powershell` / `apt install powershell`) or port to bash.
- **Skills not auto-loading** → check `~/.claude/skills/skill-classification.json` is present and well-formed.
- **Autofire doesn't trigger** → the filenames must start with `hookify.autofire-` and end with `.local.md`.

---

## Philosophy

This config was built under a single constraint: **don't waste tokens.** Every piece of it exists because a vanilla Claude Code session burned tokens on something that could be automated, cached, or blocked upfront.

- Slash commands > re-prompting
- Autofire > Claude routing
- Hooks > Claude remembering
- Skills > Claude re-deriving
- Compaction engines > re-loading context
- Session handoff docs > re-explaining next session

When in doubt about whether to add something, ask: *would this save tokens over the next 100 sessions?* If yes, codify it. If no, leave it as ad-hoc prompting.

Happy building.
