# MCP Server Starter Kit — Token Savings, Compaction, Session Handoff & Slash Commands

Curated reference material from the PRISM MCP server **plus** the full Claude Code configuration that drives it (slash commands, agents, skills, autofire hooks). Hand this whole folder to a friend building their own MCP — it's a working blueprint for a token-efficient, long-running MCP *and* the Claude Code harness that makes it productive.

Author: Mark Villanueva (markjvillanueva3@gmail.com)
Source project: `H:\prism\mcp-server\`
Source Claude config: `C:\Users\Mark Villanueva\.claude\`
Snapshot date: 2026-04-17

---

## Quick start for your friend

> Read this first — everything else is reference material.

**Step 1.** Read [SETUP-FOR-YOUR-CLAUDE.md](SETUP-FOR-YOUR-CLAUDE.md). It walks through installing the Claude config (slash commands, agents, skills, autofire hooks) on their machine.

**Step 2.** Read the three strategic docs in order:
1. `roadmaps/MCP-FULL-AUTOMATION-BLUEPRINT.md` — the big picture
2. `audits/U06-memory-context-token-audit.md` — where tokens bleed
3. `milestones/TOKEN-OPT-MS0.json` — the plan to fix it

**Step 3.** Copy the three core engines and adapt to their domain:
- `engines-reference/TokenEconomyEngine.ts`
- `engines-reference/ContextCompactionEngine.ts`
- `engines-reference/SessionHandoffV2Engine.ts`

**Step 4.** Pick 3–5 hooks from `hooks-reference/` that apply to their system and wire them in via `claude-config/settings.json`.

---

## Folder map

```
mcp-starter-kit-for-friend/
├── README.md                      ← you are here
├── SETUP-FOR-YOUR-CLAUDE.md       ← install guide for the Claude config
│
├── roadmaps/                      ← strategic plans (start here)
├── protocols/                     ← boot / coding / safety protocols + skill map
├── milestones/                    ← concrete JSON milestones (TOKEN-OPT etc.)
├── audits/                        ← baselines: where tokens bleed today
├── indexes/                       ← compaction snapshots + session handoff samples
│
├── engines-reference/             ← TS source for token + compaction + handoff engines
├── hooks-reference/               ← lifecycle hooks (the biggest token savings)
├── skills-reference/              ← skill-splitting + bloat-detection scripts
├── scripts-reference/             ← session preflight + token-estimate rebuilders
│
├── slash-commands/                ← 189 Claude Code slash commands (rgs, forge-audit, etc.)
└── claude-config/                 ← full Claude Code harness
    ├── CLAUDE.md                  ← global user instructions
    ├── settings.json              ← hook wiring, permissions, env vars
    ├── keybindings.json           ← keyboard shortcuts
    ├── agents/                    ← 13 specialized subagents
    ├── skills/                    ← Skill library (auto-loaded by harness)
    └── hookify-autofire/          ← 134 autofire skill-trigger files
```

---

## `roadmaps/` — Strategic plans

- **MCP-FULL-AUTOMATION-BLUEPRINT.md** — end-to-end automation design
- **MCP-DEVELOPMENT-AUTOMATION-ROADMAP.md** — how the MCP develops itself
- **MCP-AUTOMATION-HARDENING-ROADMAP.md** — prototype → resilient server
- **ULTIMATE-PRISM-ROADMAP-v25.md** — master roadmap
- **ROADMAP_INSTRUCTIONS.md / ROADMAP_SECTION_INDEX.md / ROADMAP_TRACKER.md** — authoring/tracking
- **SYSTEM_CONTRACT.md** — invariants every milestone must respect

## `protocols/` — Operating protocols + skill/script indexes

- **PRISM_PROTOCOLS_BOOT.md** — session-start / precompaction setup
- **PRISM_PROTOCOLS_CODING.md** — coding conventions enforced by hooks
- **PRISM_PROTOCOLS_SAFETY.md** — tool-call safety rules
- **SKILL_RELEVANCE_MAP.json** — which skills fire for which user intents
- **SCRIPT_INDEX.json** — registry of scripts Claude invokes instead of ad-hoc bash

## `milestones/`

- **TOKEN-OPT-MS0.json** — primary token-optimization milestone (study first)
- **AGENT-ROADMAP.json / APP-MS0.json / ARCH-MS0.json / ARCH-MS1.json / INFRA-MS0.json** — foundational milestones

## `audits/` — Baselines

- **U06-memory-context-token-audit.md** — where tokens bleed in a long-running MCP
- **U07-master-index-state-directory-audit.md** — state/index layout on disk
- **U08-session-checkpoint-autofire-audit.md** — auto-checkpoint triggers

## `indexes/` — Compaction & handoff samples

- **TOKEN_OPTIMIZATION_AUDIT_2026-03-24.md** — concrete findings
- **SESSION_HANDOFF.md** — handoff doc template/output
- **COMPACTION_SNAPSHOT.md** — what a compacted state looks like
- **MASTER_INDEX_COMPACT.md** — how large indexes are compacted for Claude
- **DSL_COMPACT.md** — compact DSL for state summaries
- **token-baseline.json** — frozen token counts for regression detection

## `engines-reference/` — Working TypeScript engine source

Domain-agnostic engines — drop into your MCP and adapt.
- **TokenAccountingEngine.ts** — per-action token spend
- **TokenBudgetAllocatorEngine.ts** — per-session/per-action budgets
- **TokenEconomyEngine.ts** — policy layer on accountant + allocator
- **SessionTokenLedgerEngine.ts** — persistent cross-session ledger
- **DiffTokenEstimatorEngine.ts** — cheap estimate before send
- **CompactFormatterEngine.ts** — terse output formatter
- **CompactPlannerEngine.ts** — plans keep vs. drop
- **CompactionStrategyEngine.ts** — strategy selection (LRU, relevance, …)
- **SchemaCompactEngine.ts** — compacts tool-def JSON schemas
- **ContextRetentionEngine.ts** — what survives across compaction
- **ContextCompactionEngine.ts** — compaction itself
- **SessionHandoffV2Engine.ts** — produces the handoff doc
- **ShiftHandoffEngine.ts** — shift-change pattern for long agent runs
- **compaction.ts** — tuned config knobs

## `hooks-reference/` — Lifecycle hooks (biggest token saver)

Hooks enforce rules *before* Claude wastes tokens repeating mistakes.
- **hookBridge.ts / hookRegistration.ts / index.ts** — registration plumbing
- **pre-edit-safety-gate.ps1** — blocks risky edits pre-flight
- **code-integrity-prewrite.mjs** — pre-write integrity check
- **engine-duplication-blocker.mjs** — prevents re-creating existing engines
- **cross-session-duplication-guard.mjs** — duplication guard across sessions
- **anti-regression-gate.ps1** — blocks known-bad patterns
- **teammate-quality-gate.ps1 / teammate-reassign.ps1** — multi-agent coordination
- **ai-integration-stop-check.mjs** — stop-condition for autonomous loops
- **ai-reasoning-session-start.mjs** — session-start reasoning prep
- **agent-auto-update-hook.mjs** — keeps agent memory fresh
- **post-build-verify.ps1** — post-build validation
- **pre-roadmap-execute.ts / post-roadmap-unit.ts** — per-unit roadmap hooks
- **README-setup.md** — wiring hooks into `settings.json`

## `skills-reference/` — Skill management scripts

Skills = token cost on load. Keep them small.
- **split-skill.ps1** — splits oversized skills (only needed slice loads)
- **__scan_sizes.ps1** — bloat detector
- **extract-course-skills.ps1** — mines skills from tutorial content
- **update-skill-index.ps1 / index-splits.js** — maintains the skill index

## `scripts-reference/` — Standalone token/session scripts

- **update-token-estimates.ps1** — rebuilds `token-baseline.json`
- **prism-context-only.ts** — emits minimum context block for a session
- **session_preflight.js** — session-start preflight

---

## `slash-commands/` — 189 slash commands (`/rgs`, `/forge-audit`, `/boot`, …)

The full slash-command library. Highlights:

**Token / session management**
- `/token-budget` `/token-ledger` `/context` `/context-audit` `/context-integrity` `/context-map` `/compact`-family in autofire
- `/handoff` `/snapshot` `/checkpoint` (in claude-config/skills) `/boot` `/startup`

**Forge — MCP development automation (the whole family)**
- `/forge` `/forge-audit` `/forge-engines` `/forge-wiring` `/forge-hooks` `/forge-skills`
- `/forge-debug` `/forge-deps` `/forge-docs` `/forge-drift` `/forge-metrics` `/forge-perf`
- `/forge-postflight` `/forge-safety` `/forge-schema` `/forge-tests` `/forge-types`
- `/forge-cleanup` `/forge-from-scout` `/forge-learn` `/forge-materials`
- `/forge-mcp-wire` `/forge-app-wire` `/forge-triple` `/forge-video-watchlist`

**Health / audit / status**
- `/health` `/status` `/system-audit` `/audit-task` `/scrutinize`
- `/hook-browse` `/hook-profile` `/hook-stats` `/hook-status`
- `/process-health` `/quality-dashboard` `/quality-gate` `/quality-check`

**Knowledge / navigation**
- `/rgs` (Resource Graph Search) `/scout` `/navigate` `/code-index`
- `/engine-browse` `/registry-browse` `/formula-browse`
- `/findings` `/remember` `/replay` `/quick-ref`

**Intelligence / planning**
- `/plan-build` `/playbook` `/predict` `/scope` `/ship` `/smart` `/smart-route`
- `/read-plan` `/roadmap-quality-check`

**Build / verify**
- `/release-ready` `/verify-loop` `/program-validate` `/stop-check`
- `/auto-commit` `/sync` `/milestone` `/update-all-docs`

…plus 150+ more domain commands (lathe, wire EDM, CAM, etc.) — your friend will want to cherry-pick the infrastructure ones and ignore the machining-specific commands.

## `claude-config/` — The full Claude Code harness

Everything that makes these slash commands, skills, and hooks actually fire:
- **CLAUDE.md** — global user instructions (RTK rules, memory pointers, …)
- **settings.json** — hook wiring, permissions, env vars
- **keybindings.json** — keyboard shortcuts
- **agents/** — 13 subagents (build-doctor, code-archaeologist, physics-reviewer, dispatcher-wirer, regression-hunter, test-runner, wiring-review-agent, …)
- **skills/** — auto-loaded skill library (context-budget, adaptive-optimize, prism-review, model-router, session-persist, system-health, …)
- **hookify-autofire/** — 134 autofire triggers that fire slash commands / skills in response to user input patterns. This is the *secret sauce* for token efficiency — the harness does the routing, Claude doesn't have to.

---

## What's NOT included (and why)

- `node_modules`, build output, test fixtures — ~60 GB, not useful as reference
- Domain-specific engines (machining/CNC) — PRISM-specific, won't apply elsewhere
- Resource data, PDFs, G-code archives — live in `H:\prism\resources\` and `H:\PRISM\JM DIE\`
- `settings.local.json` — machine-specific, excluded on purpose
- `history.jsonl` / `file-history/` / `cache/` — ephemeral runtime state

---

## Adapting to a different MCP

**Domain-agnostic (copy freely):** token engines, compaction engines, session handoff pattern, hook registration scaffold, skill-splitting scripts, the `/forge-*` command family, the `claude-config/` harness structure.

**PRISM-specific (ignore or replace):** machining knowledge bases, JM Die archive references, CNC controller engines, G-code post-processors, CAM integrations.

Good luck — ping Mark if you have questions about any of it.
