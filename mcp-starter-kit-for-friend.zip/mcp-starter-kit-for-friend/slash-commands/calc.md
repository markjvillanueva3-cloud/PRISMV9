# Calc — Quick CNC calculation (zero dispatcher overhead)

Run a manufacturing calculation instantly using QuickCalcEngine.

## Usage
- `/calc rpm 300 0.5` → RPM from 300 SFM, 0.5" diameter
- `/calc feed 5000 0.003 4` → Feed rate from RPM, chip load, flutes
- `/calc mrr 0.5 0.25 60` → Material removal rate
- `/calc tap 10 1.5` → Tap drill for M10x1.5
- `/calc power 5 steel` → Cutting power for 5 in³/min in steel
- `/calc scallop 3 1` → Scallop height for R3mm, 1mm stepover
- `/calc time 12 60` → Cutting time for 12" at 60 IPM

## Steps
1. Parse $ARGUMENTS to identify calculation type and parameters
2. Call the appropriate QuickCalcEngine method directly
3. Return the result in compact format (formula + answer)

No dispatcher calls needed — pure math, instant results.
