---
effort: high
maxTurns: 25
disallowedTools:
  - Write
---

# System Health Check

You are running a comprehensive health check on the PRISM MCP Server system. Check every dimension and report a clear status dashboard. Execute all checks — do not skip any.

## Args: $ARGUMENTS
- Empty: full health check
- `build`: build health only
- `drift`: roadmap drift only
- `claims`: claim status only
- `counts`: count verification only

## Check 1: Build Health
Run `npm run build` from `C:/PRISM/mcp-server/` and capture:
- Success or failure
- Number of TypeScript errors (grep for "error TS")
- Number of warnings
- Bundle size if shown

## Check 2: Test Health
Run `npm test` from `C:/PRISM/mcp-server/` and capture:
- Total tests, passed, failed, skipped
- Any test suites that error out

## Check 3: Roadmap Drift
Read `C:/PRISM/mcp-server/data/roadmap-index.json`:
- Count actual envelope files in `data/milestones/` vs `total_milestones`
- Count envelopes with `"status": "complete"` vs `completed_milestones`
- Check each index entry has a matching envelope file
- Check each envelope file has a matching index entry
- Flag any mismatches

## Check 4: Stale Claims
Scan `C:/PRISM/mcp-server/data/claims/` for claim directories:
- Check each `claim.json` timestamp
- Flag any claims older than 5 minutes without recent heartbeat
- Check if `C:/PRISM/state/ACTIVE_CLAIM.json` exists and is valid

## Check 5: Count Verification
Compare documented counts against live code:
- **Dispatchers**: count files in `src/tools/dispatchers/` matching `*Dispatcher.ts`
- **Engines**: count files in `src/engines/` matching `*.ts` (exclude index/test files)
- **Milestones**: count envelope files in `data/milestones/`
- Cross-reference against MEMORY.md verified counts and CLAUDE.md stated counts

## Check 6: CLAUDE.md Staleness
Read all CLAUDE.md files and check for outdated counts:
- `C:\PRISM\CLAUDE.md`
- `C:\PRISM\mcp-server\CLAUDE.md`
- `C:\PRISM\mcp-server\src\engines\CLAUDE.md`
- `C:\PRISM\mcp-server\src\tools\dispatchers\CLAUDE.md`
Flag any stated counts that don't match verified reality.

## Check 7: State File Integrity
Verify key state files exist and are valid JSON/MD:
- `C:/PRISM/state/CURRENT_POSITION.md`
- `C:/PRISM/mcp-server/data/roadmap-index.json`
- `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md`

## Check 8: Context & Memory Health
Quick context health scan:
1. Count MEMORY.md lines (target <200): `LEAN` (<100), `OK` (100-179), `HEAVY` (180-199), `OVER` (200+)
2. Count hookify rules: `ls ~/.claude/hookify.*.local.md | wc -l`
3. Check for stale state files in `C:/PRISM/state/` older than 7 days
4. Check HANDOFF.md age — stale if >48 hours
5. If HEAVY or OVER: suggest `/context-audit` for diagnosis, then `/slim` to trim

## Check 8B: ECC Hook Registration
Verify these ECC hooks are registered in `H:/prism/.claude/settings.json`:
- `compact-counter.mjs` — should appear in PostToolUse hooks
- `safety-gates.mjs` — should appear in PreToolUse Task hooks
- `safety-escalation.mjs` — should appear in PostToolUse Task hooks
- `directory-freeze.mjs` — should appear in PreToolUse Write/Edit hooks
- `mcp-health-recovery.mjs` — should appear in PostToolUseFailure hooks
- `pattern-extractor.mjs` — should appear in Stop hooks
Report: `ECC Hooks: [N]/6 registered ([list any missing])`

## Check 9: Dependency Security (quick)
Run `npm audit --json` from `C:/PRISM/mcp-server/` (if full mode):
- Count CRITICAL and HIGH severity vulnerabilities
- Report any with available fixes
- Skip in `build`/`drift`/`claims`/`counts` focused modes

## Check 10: Type Coverage Snapshot
Quick type health pulse from `C:/PRISM/mcp-server/src/`:
- Count files with >10 `any` types (grep -c `: any` per file)
- Report top 3 worst files
- Skip in focused modes

## Check 11: Wiring Integrity (quick)
Quick orphan check:
- Count engine files not imported by any dispatcher
- Count dispatcher files not registered in index.ts
- Skip in focused modes — use `/forge-wiring` for full analysis

## Health Report
```
PRISM HEALTH CHECK
==================
Build:      [PASS/FAIL] — [N] errors, [N] warnings
Tests:      [PASS/FAIL] — [N] passed, [N] failed, [N] skipped
Roadmap:    [CLEAN/DRIFT] — [N] milestones indexed, [N] envelopes found
Claims:     [CLEAN/STALE] — [N] active, [N] stale
Counts:     [MATCH/DRIFT] — [details of any mismatches]
CLAUDE.md:  [CURRENT/STALE] — [files with outdated counts]
State:      [OK/ISSUES] — [any missing or invalid files]
Memory:     [LEAN/OK/HEAVY/OVER] — [N]/200 lines | Hooks: [N] rules | Handoff: [age]
ECC Hooks:  [N]/6 registered — [missing list or "all present"]
Deps:       [CLEAN/N vulns] — [critical/high counts]
Types:      [CLEAN/N files with excessive any]
Wiring:     [CLEAN/N orphans]

Overall:    [HEALTHY / N ISSUES FOUND]
```

If issues are found, provide a prioritized fix list:
1. CRITICAL: Build failures, stale claims blocking work
2. MAJOR: Count drift, missing envelopes
3. MINOR: CLAUDE.md staleness, cosmetic issues

## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
