# Troubleshoot — Interactive Manufacturing Problem Solver

Walk through a structured diagnostic flow using PRISM's trouble trees, tribal knowledge, and engine calculations to diagnose and solve manufacturing problems.

## Args: $ARGUMENTS
- Empty: show available troubleshooting categories
- `[problem]`: describe the problem in natural language (e.g., "chatter during milling", "poor surface finish", "tool breaking")
- `chatter`: chatter/vibration troubleshooting
- `surface`: surface finish problems
- `tool-wear`: excessive or abnormal tool wear
- `dimensional`: dimensional accuracy issues
- `chip`: chip evacuation problems

## Phase 1: Smart Config
```
SMART CONFIG
Role:   Manufacturing Process Expert + Senior TypeScript Engineer
Model:  SONNET
Effort: MEDIUM
Reason: Domain expertise for diagnosis + code access for PRISM data
```

## Phase 2: Problem Classification
Parse the user's problem description and classify into one of:
- **Chatter/Vibration**: chatter, vibration, harmonics, noise, marks, waviness
- **Surface Finish**: rough, finish, Ra, scratches, marks, burnish, tear
- **Tool Wear**: wear, breakage, chipping, crater, flank, BUE, built-up edge
- **Dimensional**: tolerance, runout, taper, size, oversize, undersize, drift
- **Chip Evacuation**: chip, packing, birds nest, stringy, re-cutting

## Phase 3: Load Trouble Tree
1. Read the corresponding trouble tree from `C:/PRISM/cad-engine/data/shop_practices/trouble_trees/`:
   - `chatter.json` for vibration
   - `surface_finish.json` for finish
   - `tool_wear.json` for wear
   - `dimensional_accuracy.json` for dimensions
   - `chip_evacuation.json` for chips
2. Parse the decision tree structure

## Phase 4: Interactive Diagnosis
Walk through the trouble tree top-down:
1. Present the root question with options
2. Based on user's answer (or inferred from their description), follow the tree branch
3. At each node, present:
   - **Symptom check**: "Are you seeing [X]?"
   - **Possible causes**: ranked by likelihood
   - **Quick fix**: immediate action to try
4. Continue until reaching a leaf node (specific diagnosis)

## Phase 5: Solution with PRISM Data
Once diagnosed, provide a comprehensive solution:
1. **Root cause**: specific diagnosis from the tree
2. **Tribal knowledge**: search TribalKnowledgeEngine for relevant tips
   ```
   prism_knowledge action:search params:{query: "[diagnosis keywords]"}
   ```
3. **Parameter adjustment**: if cutting parameters are involved, calculate corrected values
   ```
   prism_calc action:speed_feed params:{...corrected params}
   ```
4. **Similar cases**: search for similar problems in tribal knowledge

## Phase 6: Output
```
DIAGNOSIS
=========
Problem:    [user's description]
Category:   [chatter/surface/tool-wear/dimensional/chip]
Root Cause: [specific diagnosis]
Confidence: [HIGH/MEDIUM/LOW]

SOLUTION
--------
1. [Immediate fix — what to do RIGHT NOW]
2. [Parameter adjustment — specific values]
3. [Prevention — long-term fix]

TRIBAL KNOWLEDGE
----------------
- [Relevant tip 1]
- [Relevant tip 2]

RELATED PRISM TOOLS
--------------------
- /process-calc [params] — recalculate with corrected parameters
- /quality-check [params] — verify fix effectiveness
```

## Error Handling
- If problem doesn't match any category, ask the user to clarify
- If trouble tree file missing, use general diagnostic heuristics
- If no tribal knowledge matches, skip that section
