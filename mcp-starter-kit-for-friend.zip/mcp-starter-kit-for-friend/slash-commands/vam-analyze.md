# VAM Analyze — Vibration-Assisted Machining Analysis

Analyze vibration-assisted machining parameters: force reduction, tool life improvement, critical speed ratio, and chip breaking effectiveness.

## Args: $ARGUMENTS
- Empty: defaults (ultrasonic linear, turning, steel)
- `elliptical titanium`: ultrasonic elliptical mode on titanium
- `low_freq drilling composite`: low-frequency VAM drilling composite
- `ultrasonic milling inconel 50m/min`: specific cutting speed

## Steps

1. Parse args for mode, operation, workpiece, cutting_speed_m_min
2. Call `vibrationAssistedMachiningEngine.calculate()` with parsed input
3. Display results:
   - Force reduction % and surface improvement %
   - Tool life multiplier
   - Critical speed ratio and intermittent cutting status
   - Duty cycle and chip breaking effectiveness
   - Power consumption for actuator
4. Show recommendations

## Output Format

```
VAM ANALYSIS
============
Mode: [mode] | Op: [operation] | Material: [workpiece]
Cutting Speed: [Vc] m/min | Freq: [f] Hz | Amp: [A] um

Force Reduction:    [pct]%
Surface Improvement: [pct]%
Tool Life:          [mult]x baseline

Critical Speed Ratio: [ratio] ([intermittent/continuous] cutting)
Duty Cycle:           [pct]%
Chip Breaking:        [score]/1.0

Actuator Power: [W] W

Recommendations:
- [rec1]
- [rec2]
```

## Key Physics
- Speed ratio < 1.0 = intermittent cutting (most benefit)
- Elliptical mode: ~30% better than linear for force/surface
- Titanium/Inconel: 1.5x more tool life benefit from VAM
- Higher frequency = better chip breaking
