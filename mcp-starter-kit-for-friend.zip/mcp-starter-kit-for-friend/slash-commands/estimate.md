# Estimate — Quick manufacturing cost estimate

Get a ballpark cost estimate for a machining job.

## Usage
- `/estimate 6061 15min qty=100` — 100 parts, 15 min cycle, 6061 aluminum
- `/estimate steel 60min 5axis` — 1 part, 60 min cycle, steel, 5-axis
- `/estimate titanium 30min qty=10 breaks` — with price breaks at 1/10/50/100

## Steps
1. Parse $ARGUMENTS for: material, cycle time, quantity, machine type
2. Use costEstimatorEngine.quickEstimate() for simple case
3. If "breaks" requested, use costEstimatorEngine.priceBreaks()
4. Show compact result with per-part cost and breakdown
