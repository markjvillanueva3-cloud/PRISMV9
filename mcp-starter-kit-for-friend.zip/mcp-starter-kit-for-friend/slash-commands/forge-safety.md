# Forge Safety — Safety Chain Audit + Hardening Autopilot

You are running a specialized autopilot pipeline focused on auditing the PRISM safety chain end-to-end, identifying unprotected operations, hardening weak links, and validating that all safety-critical paths are correctly enforced.

## Args: $ARGUMENTS
- Empty: full audit — analyze the entire safety chain, find gaps, harden the worst ones
- `sx`: focus on S(x) scoring paths only
- `blocks`: focus on hard-block conditions and bypass prevention
- `coolant`: focus on coolant/MQL safety validation
- `thermal`: focus on thermal safety and fire risk paths
- `[file-path]`: audit safety aspects of a specific file
- `criticals`: focus on the 5 open CRITICAL findings from QA
- `list`: just analyze and list safety gaps without fixing any

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** for safety modeling.
- Consider every reliability model, failure distribution, risk analysis method, and safety factor calculation.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing safety science coverage.
- **Completeness > Speed.** A missed safety model is a critical capability gap.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.

## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: COMPLEX (safety-critical code demands exhaustive analysis)
2. Domain: Security/Safety + Manufacturing + Systems Architecture
3. Roles: Senior Security Auditor + Manufacturing Process Expert + Principal Systems Architect
4. Model: OPUS (safety-critical — getting it wrong has high cost)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — but with safety rails at maximum strictness.
Note: YOLO mode does NOT relax safety checks. It means autonomous decisions, not reckless ones.

## Phase 3: Safety Chain Inventory

### 3A: Map the Safety Architecture
Trace the complete safety chain:

1. **SafetyEngine** (`src/engines/SafetyEngine.ts`):
   - What inputs feed S(x) scoring?
   - What thresholds trigger BLOCKED vs APPROVED?
   - Is the WARNING zone truly eliminated (binary scoring)?
   - Does missing critical data → BLOCKED (not partial credit)?

2. **SafetyDispatcher** (`src/tools/dispatchers/safetyDispatcher.ts`):
   - Does it re-throw SafetyBlockError?
   - Are all safety-relevant actions routed through the safety chain?
   - Is there any path that bypasses safety scoring?

3. **CoolantValidationEngine** (`src/engines/CoolantValidationEngine.ts`):
   - MQL unit conversion (L/min → mL/hr: flowRate * 60000)
   - Speed bracket logic (no dead branches)
   - Dry titanium/superalloy fire safety → isAdequate=false
   - Flow utilization division-by-zero guard

4. **Tool Life / Force Calculations**:
   - Do force engines feed S(x)?
   - Do tool life predictions flag cliff warnings?
   - Is missing force/tool-life data → BLOCKED?

5. **Safety Hooks** (`src/hooks/safety*.ts`):
   - Pre-operation safety gates
   - Post-operation safety validation
   - Safety logging and audit trail

### 3B: Claude Code Safety Hook Audit
Verify the ECC-layer safety hooks are registered and active in `H:/prism/.claude/settings.json`:
1. `safety-gates.mjs` in PreToolUse ^Task$ — blocks tasks touching safety-critical files without a plan
2. `safety-escalation.mjs` in PostToolUse ^Task$ — flags sessions that modified safety files without review
3. `directory-freeze.mjs` in PreToolUse ^Write/Edit$ — blocks writes to frozen directories
If any are missing, flag as CRITICAL and add to settings.json. These operate at the agent layer before any code is written.

### 3C: Check Known CRITICALs
Review the 5 open CRITICAL findings from QA:
1. **5-axis C-axis limits** — Are angular limits enforced?
2. **Post-processor tap safety** — Are tap cycles validated?
3. **Post-processor bore safety** — Are bore cycles validated?
4. **Post-processor 5-axis safety** — Are 5-axis operations validated?
5. **Bridge never wired** — Is the CAD bridge connected to the main system?

For each: check current status, verify if fixed or still open.

### 3C: Identify Safety Gaps
Scan for these patterns:

**Unprotected Operations:**
- Engine calculations that produce safety-relevant output but don't feed S(x)
- Dispatcher actions that skip safety validation
- Code paths that can bypass SafetyBlockError

**Weak Scoring:**
- S(x) inputs with partial credit for missing data (should be 0.0)
- Score thresholds that allow dangerous operations through
- Scoring functions that don't account for all risk factors

**Missing Validations:**
- Material-operation combinations without safety rules
- Machine capability limits not enforced
- Tool-material compatibility not checked
- Coolant adequacy not verified for all operation types

**Error Handling Gaps:**
- Safety errors caught and swallowed (not re-thrown)
- Try/catch blocks around safety code that default to "safe"
- Missing safety checks in error recovery paths

**Data Integrity:**
- Safety-critical constants hardcoded vs. configurable
- Safety thresholds without documented justification
- Missing unit conversions or wrong conversion factors

### 3D: Risk Assessment
For each gap found:
- **Severity**: CRITICAL / MAJOR / MINOR
- **Exploitability**: Can a normal user accidentally trigger unsafe behavior?
- **Blast Radius**: What's the worst-case outcome?
- **Fix Complexity**: How hard is it to fix?

```
SAFETY AUDIT RESULTS
====================
Total Safety Components:  [N]
Components Audited:       [N]
Findings:                 [N] total
  CRITICAL:  [N] — must fix now
  MAJOR:     [N] — should fix soon
  MINOR:     [N] — fix when convenient

Open CRITICALs from QA:
  1. [status] 5-axis C-axis limits
  2. [status] Post-proc tap safety
  3. [status] Post-proc bore safety
  4. [status] Post-proc 5-axis safety
  5. [status] Bridge never wired

New Findings:
  [SEV] [file:line] — [description]
  ...
```

If args = `list`, stop here.

## Phase 4: Harden Safety Chain
For each finding, prioritized by severity:

### 4A: CRITICAL Fixes (mandatory)
1. Read the affected file completely
2. Understand the current behavior
3. Design the fix — must not introduce new safety holes
4. Implement the fix
5. Add a test that verifies the fix
6. Verify the fix doesn't break existing safety tests

### 4B: MAJOR Fixes
1. Same protocol as CRITICAL
2. Can batch related fixes in the same file

### 4C: MINOR Fixes
1. Fix if quick (<5 min each)
2. Otherwise, log for later

### 4D: Fix Validation Rules
Every safety fix must satisfy:
- **No false negatives**: The fix must not allow unsafe operations through
- **Minimal false positives**: The fix should not block safe operations
- **No bypass paths**: The fix must not be circumventable
- **Fail-safe**: If the safety check itself errors, default to BLOCKED
- **Logged**: Safety decisions must be traceable

## Phase 5: Test Safety
After all fixes:

### 5A: Unit Tests
1. Run all existing safety-related tests
2. Run any new tests added during Phase 4
3. All must pass — zero tolerance for safety test failures

### 5B: Scenario Testing
Test critical scenarios:
- Missing material data → should BLOCK
- Missing force data → should BLOCK
- Dry machining titanium → should BLOCK or flag
- MQL flow rate edge cases → correct unit conversion
- S(x) score at boundary → correct binary decision
- SafetyBlockError propagation → not swallowed

### 5C: Bypass Testing
Attempt to bypass safety:
- Can a dispatcher action skip safety validation?
- Can an engine return unsafe values without triggering S(x)?
- Can safety hooks be disabled without detection?
- Can safety thresholds be overridden at runtime?

### 5D: Full Suite
1. Run `npm run build` — must pass
2. Run `npm test` — must pass with zero regression
3. Run CAD tests if safety-related CAD changes were made

```
SAFETY TEST RESULTS
===================
Safety Unit Tests:    [N] passing, [N] failing
Scenario Tests:       [N] passing, [N] failing
Bypass Tests:         [N] blocked (good), [N] passed through (BAD)
Full Suite:           [N] passing, [N] failing
Regressions:          NONE / [details]
```

## Phase 6: Forge Postflight (`/forge-postflight safety` protocol)
Run the shared integration protocol for safety chain modifications:
1. **Gate 1 — DSL**: RUN — verify safety-related code follows PRISM DSL (AtomicValue, action schema, safety integration)
2. **Gate 2 — Matrix**: CONDITIONAL — if new safety engines/hooks were created, register in MASTER_INDEX
3. **Gate 3 — Trace**: RUN — verify safety chain wiring: engine → SafetyEngine → S(x) scoring → hard-block enforcement
4. **Gate 4 — Sync**: RUN — verify safety component counts, update MEMORY.md if CRITICALs resolved
5. **Gate 5 — Memory**: RUN — update MEMORY.md with fixed findings (update "Open findings" count)
6. **Gate 6 — Hookify**: SKIP (safety hooks are PRISM hooks, not autofire rules)

Report the postflight results before proceeding to commit.

## Phase 7: Auto-Commit (`/auto-commit` protocol)
1. Stage all safety fixes and new tests
2. Commit: `fix(safety): harden [N] safety gaps — [summary] [FORGE-SAFETY]`
3. Report the commit

## Summary Report
```
FORGE SAFETY COMPLETE
=====================
Audited:       [N] safety components
Findings:      [N] total ([C] CRITICAL, [M] MAJOR, [m] MINOR)
Fixed:         [N] findings
  CRITICAL:    [N]/[N] fixed
  MAJOR:       [N]/[N] fixed
  MINOR:       [N]/[N] fixed
Deferred:      [N] findings for later
Tests Added:   [N] new safety tests
All Passing:   YES/NO
Committed:     [commit hash]

Safety Score: [X]/10

Open CRITICALs: [N] remaining (was [M])

Safety Chain Status:
  S(x) Scoring:        [HARDENED / GAPS REMAIN]
  Hard Blocks:         [ENFORCED / GAPS REMAIN]
  Coolant Safety:      [VERIFIED / NEEDS WORK]
  Thermal Safety:      [VERIFIED / NEEDS WORK]
  Error Propagation:   [VERIFIED / GAPS REMAIN]

Next: /forge-safety criticals for remaining CRITICALs, /forge-tests for test coverage
```

## Error Handling
- **Safety test failure**: STOP. Do not proceed. Fix the safety test before continuing.
- **Build failure**: STOP. Safety code must compile. Fix before continuing.
- **Bypass found**: Treat as CRITICAL. Fix immediately.
- **Context budget**: Complete current CRITICAL fix, commit, report remaining work.

## Safety Rails (maximum strictness)
- Never weaken existing safety checks to fix a test
- Never add bypass paths or escape hatches to safety code
- Never mark a safety finding as resolved without a test proving it
- Never skip the full test suite after safety changes
- Safety errors must always fail-safe (default to BLOCKED)
- All safety thresholds must have documented justification
- Never commit safety changes without running the full test suite
- S(x) scoring must remain binary: APPROVED or BLOCKED, no WARNING zone
