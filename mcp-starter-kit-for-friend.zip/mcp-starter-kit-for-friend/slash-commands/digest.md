# Digest — Compact file/directory summary

Generate an ultra-compact structural digest instead of reading full files.

## Usage
- `/digest src/engines/QuickCalcEngine.ts` — one file
- `/digest src/engines/` — whole directory
- `/digest file1.ts file2.ts file3.ts` — batch mode

## Steps
1. Parse $ARGUMENTS for file/directory paths
2. For files: use contextDigestEngine.digestFile() or oneLiner()
3. For directories: use contextDigestEngine.digestDirectory()
4. For multiple: use contextDigestEngine.batchDigest()
5. Output the compact digest (80-90% fewer tokens than reading full files)
