# Slim — Active Context Optimizer

You are actively trimming, compressing, and reorganizing context files to maximize token efficiency. This is the ACTION counterpart to `/context` (which only diagnoses). `/slim` makes changes.

## Args: $ARGUMENTS
- Empty: full optimization pass — MEMORY.md + CLAUDE.md + state cleanup
- `memory`: optimize MEMORY.md only
- `claude`: optimize CLAUDE.md files only
- `state`: clean stale state files only
- `dedup`: find and resolve duplicates across all context files
- `extract [section]`: extract a specific MEMORY.md section to a topic file
- `dry-run`: analyze and report what would change without modifying anything

## Step 1: Measure Baseline
Before any changes, capture current metrics:
```
BASELINE
  MEMORY.md:       [N] lines (~[N]K tokens)
  CLAUDE.md files: [N] total lines across [N] files
  Topic files:     [N] files, [N] total lines
  State dir:       [N] files, [N]MB total
```

## Step 2: MEMORY.md Optimization
Read MEMORY.md and apply these optimizations:

### 2A: Compress Verbose Entries
Find entries >120 characters and compress them:
- Remove filler words and redundant explanations
- Use abbreviations for known terms (TS, disp, eng, algo)
- Convert multi-sentence bullets to single-line format
- Use em-dash style: `**Label** — concise description`

### 2B: Deduplicate
Find facts stated in multiple sections:
- Same count stated in two different sections → keep one
- Same fix listed in both "Critical Fixes" and "SYS-MS7 results" → keep the more concise one
- Same convention stated in both MEMORY.md and a CLAUDE.md → keep in the most appropriate location

### 2C: Extract Bloated Sections
If any section exceeds 10 lines:
- Extract detail to a topic file in `~/.claude/projects/*/memory/[topic].md`
- Replace section in MEMORY.md with a 2-line summary + link
- Candidates: "PRISM Critical Fixes Applied" (10 lines), "CC-MS0 CAD/CAM Track" (8 lines), "Materials Deep Accuracy" (11 lines)

### 2D: Remove Stale Data
Identify entries that are no longer useful:
- Completed phases with excessive detail (keep summary, remove step-by-step)
- Historical journey data ("47.1% → 56.3% → 67.6%...") — only keep final result
- Obsolete notes about merged/retired hooks (keep the merge note, remove the old hook descriptions)

### 2E: Enforce Line Budget
After all optimizations, verify MEMORY.md is under 200 lines:
- If still over: prioritize extraction of the largest sections
- If well under: note room for growth

## Step 3: CLAUDE.md Optimization
For each CLAUDE.md file in the PRISM project:

### 3A: Cross-File Deduplication
- Find facts that appear in multiple CLAUDE.md files
- Move shared facts to the root CLAUDE.md only
- Keep sub-directory CLAUDE.md files focused on their specific domain

### 3B: MEMORY.md vs CLAUDE.md Dedup
- Find facts in both MEMORY.md and CLAUDE.md files
- Rule: stable facts belong in CLAUDE.md, session-observed facts in MEMORY.md
- Remove duplicates from the less appropriate location

### 3C: Compress
Apply the same compression rules as MEMORY.md:
- Remove filler, use abbreviations, one-line bullets
- Remove commented-out old instructions
- Remove TODOs that have been completed

## Step 4: State Directory Cleanup
Scan `C:/PRISM/state/` for stale files:

### 4A: Age-Based Cleanup
- Ralph loop files (`ralph_loops/*.json`) older than 7 days → archive or delete
- Externalized results (`externalized/*.json`) older than 7 days → delete
- Checkpoint files (`checkpoints/*.json`) older than 14 days → keep latest 3, delete rest
- Event logs (`events/*.jsonl`) older than 14 days → delete

### 4B: Size-Based Cleanup
- Files > 1MB that are not actively referenced → flag for review
- Accumulated JSONL logs → truncate to last 1000 lines

### 4C: Dead Reference Cleanup
- State files that reference deleted milestones or units → delete
- WIP files for completed work → delete

**Safety**: Never delete `CURRENT_POSITION.md`, `ACTIVE_CLAIM.json`, or any file that might be in active use.

## Step 5: Measure Results
```
OPTIMIZATION RESULTS
====================
MEMORY.md:
  Before:    [N] lines (~[N]K tokens)
  After:     [M] lines (~[M]K tokens)
  Saved:     [D] lines ([X]% reduction)
  Actions:   [N] compressed, [N] deduped, [N] extracted, [N] removed

CLAUDE.md files:
  Before:    [N] total lines
  After:     [M] total lines
  Saved:     [D] lines
  Actions:   [N] deduped, [N] compressed

State cleanup:
  Files removed:  [N] ([X]MB freed)
  Files kept:     [N]
  Logs truncated: [N]

Total Token Savings: ~[N]K tokens/session
```

## Dry-Run Mode (`/slim dry-run`)
Perform all analysis but make NO changes. Output the same report with "WOULD" prefixes:
```
DRY RUN — No changes made
  WOULD compress [N] MEMORY.md entries (saving [N] lines)
  WOULD extract [N] sections to topic files
  WOULD remove [N] stale state files ([X]MB)
  ...
```

## Error Handling
- **MEMORY.md parse error**: back up first, then attempt optimization
- **Topic file write failure**: report path issue, skip extraction
- **State file in use**: skip files modified in last 5 minutes
- **Over-optimization**: never reduce MEMORY.md below 30 lines — some context is essential

## Safety Rails
- Always read files before editing
- Never delete CURRENT_POSITION.md, ACTIVE_CLAIM.json, or roadmap-index.json
- Never remove entries about safety fixes or critical patterns
- Never compress entries below readability threshold
- Back up MEMORY.md to `memory/MEMORY.md.bak` before major changes
- State cleanup is conservative — flag uncertain files for manual review
- Dry-run first if unsure: `/slim dry-run`

## Chaining
- Diagnostic first: `/context-audit` → see what's heavy → `/slim` → fix it (or `/context` for legacy view)
- After bulk work: `/forge-*` session → `/slim` → clean up context bloat
- Session hygiene: `/slim memory` at end of session → keep MEMORY.md lean
- Pairs with: `/remember` (adds memories efficiently), `/handoff` (prepares for next session)
