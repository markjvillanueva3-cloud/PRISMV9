# First Part Right — Zero-Scrap First Article Pipeline

The most expensive part in any shop is the FIRST one. This command eliminates first-article scrap by front-loading every possible check before the machine starts. One scrapped aerospace part can cost $5,000-50,000 in material alone. This pays for itself on the first use.

**Value**: Prevents first-article scrap. Average shop scraps 15-30% of first articles. At $500/part average material cost, saving even 5 first articles/month = $2,500+/month saved.

## Args:
- Material + part description (e.g., "Inconel 718 turbine bracket, 5 pockets, ±0.0005 bores")
- Path to existing G-code program (e.g., "C:/programs/part123.nc")
- `dry-run`: analysis only, no program modifications

## Phase 1: Risk Assessment — What Can Go Wrong?
Before anything else, identify every failure mode:

1. **Material risk**: Is this a difficult material? Fire risk (titanium, magnesium)? Work hardening (Inconel, duplex SS)? Gummy (aluminum, copper)?
   - `/material-lookup` → get ISO group, machinability rating, known gotchas
   - Cross-reference TribalKnowledgeEngine for material-specific warnings

2. **Tolerance risk**: Which dimensions are tightest? Which are most likely to drift?
   - Rank dimensions by: tolerance band / typical process variation
   - Flag any dimension where Cpk < 1.33 is predicted
   - Identify thermal growth risk (long cycle times, tight tolerances)

3. **Tool risk**: Which tools are most likely to fail?
   - `/tool-catalog` → check tool selection appropriateness
   - `/wear-analysis` → predict which tool wears fastest
   - Flag: small tools in deep pockets, long-reach tools, single-flute operations

4. **Program risk**: What could go wrong in the G-code?
   - `/program-validate` → full verification pipeline
   - Check: rapid-into-material, missing coolant, inconsistent feeds
   - Verify: work offset assumptions, tool length assumptions

5. **Setup risk**: What's most likely to cause setup errors?
   - Workholding adequacy (clamping forces vs cutting forces)
   - Datum surface quality requirements
   - Tool stickout / holder clearance conflicts

Output:
```
RISK ASSESSMENT — [Part Name]
Risk Level: [LOW / MEDIUM / HIGH / CRITICAL]
Top 5 Risks:
  1. [risk] — [mitigation]
  2. [risk] — [mitigation]
  ...
```

## Phase 2: Parameter Optimization for First-Article Safety
Don't run aggressive parameters on the first part. Optimize for SUCCESS, not speed.

1. Run `ultimateSpeedFeedEngine.calculate()` with `optimize: "tool_life"` (conservative)
   - Reduce chip load 10-15% from optimal for safety margin
   - Use conservative depth of cut for first article
   - Ensure power/torque has 20%+ headroom

2. For each operation, calculate:
   - Expected surface finish (must beat requirement by margin)
   - Expected dimensional accuracy (thermal + deflection)
   - Tool deflection at these parameters (must be < 20% of tolerance)

3. Generate "first article parameters" vs "production parameters":
   - First article: conservative, maximizes chance of success
   - Production: balanced, optimizes cost after process is proven

## Phase 3: Pre-Flight Checklist
Generate a comprehensive pre-flight checklist the operator must verify:

### Before Setup:
- [ ] Raw material matches spec (cert on file)
- [ ] Material dimensions verified (measure 3 locations)
- [ ] All tools inspected (no chips, correct geometry)
- [ ] Tool stickout measured and matches setup sheet
- [ ] Machine warmed up (minimum 15 min spindle run)
- [ ] Coolant concentration checked (refractometer)
- [ ] Work offset verified with indicator

### Before First Cut:
- [ ] Single-block first tool approach (verify clearance)
- [ ] Feed hold ready during first contact
- [ ] Listen for chatter on first engagement
- [ ] Verify chip color and shape (not blue = overheating)

### During Machining:
- [ ] Monitor spindle load (should match predicted ±15%)
- [ ] Check coolant delivery reaching cut zone
- [ ] Watch for vibration changes (bearing frequency change)

### After First Article:
- [ ] Measure ALL critical dimensions (not just a sample)
- [ ] Check surface finish at specified locations
- [ ] Visual inspection (burrs, tool marks, discoloration)
- [ ] Compare to expected vs actual parameter table

## Phase 4: Setup Sheet Generation
1. `/setup-sheet-generate` — operator-ready documentation with:
   - Tool list with exact stickout, holder, and offset notes
   - Workholding diagram with clamping forces
   - Speed/feed table (first-article conservative values)
   - Critical dimensions highlighted with pass/fail criteria
   - Photo/diagram of expected chip types per operation

## Phase 5: Inspection Plan
1. `/quality-check` — generate inspection plan:
   - Every dimension measured on first article (100% inspection)
   - Measurement method per dimension (caliper, mic, CMM, go/no-go)
   - Required measurement resolution (must be ≤10% of tolerance)
   - Record form (AS9102 template for aerospace)

## Phase 6: Cost-of-Failure Analysis
Calculate what happens if the first article fails:
- Material cost lost: $[X]
- Machine time lost: [X] min × $[rate]/hr = $[X]
- Tool cost lost: $[X] (if tools damaged)
- Schedule impact: [X] hours delay
- **Total risk**: $[X] if first article scraps

vs. the cost of this analysis: ~5 minutes of compute time.

## Phase 7: Machine-Learned Prediction (uses learned coefficients)
If this machine has learning data from previous parts:
1. Call `prism_calc` action `learned_prediction` — machine-specific predictions
   - Params: { machineId, predictionType: "dimension", material, operation, shopTemp_C, toolWearState }
   - Accounts for: machine bias, thermal growth, coolant age, warm-up state
2. Call `prism_calc` action `upqi_calc` — Unified Process Quality Index
   - Combines force-deflection + thermal + wear into ONE capability metric
   - UPQI < 1.33 = HIGH RISK, flag immediately
3. Call `prism_calc` action `process_stability_margin` — distance from instability
   - PSM < 0.2 = CRITICAL, 0.2-0.5 = CAUTION, > 0.5 = OK
4. Call `prism_calc` action `all_dimensionless` — 8 dimensionless numbers
   - Cutting Number, Thermal Peclet, Stability Number = instant physics health check

## Phase 8: Post-Measurement Learning
After first article is measured, feed results back:
1. Call `prism_calc` action `submit_measurement` for EACH dimension
   - System LEARNS and improves predictions for next part
2. Call `prism_calc` action `compare_and_learn` — show bias shift
3. For repeat jobs: `prism_calc` action `machine_intelligence` shows accuracy trend

## Output Summary
```
FIRST PART RIGHT — [Part Name]
================================
Risk Level:     [LOW/MEDIUM/HIGH/CRITICAL]
Material:       [name] (ISO [group], machinability [X]/100)

RISK MITIGATION:
  [N] risks identified, [N] mitigations applied
  Top risk: [description] → [mitigation]

PARAMETERS (First Article — Conservative):
  Operation    | Vc      | fz      | ap     | Safety margin
  [op1]        | [X]     | [X]     | [X]    | [X]% under optimal
  ...

PARAMETERS (Production — After Process Proven):
  [same table with balanced values — X% faster]

CHECKLIST: [N] items — printed/ready for operator
SETUP SHEET: Generated — [N] tools, [N] operations
INSPECTION: 100% first article — [N] dimensions

COST OF FAILURE: $[X] if first article scraps
COST OF THIS ANALYSIS: ~$0 (5 min compute)
ROI: [X]:1 risk reduction

Files: setup-sheet.pdf, inspection-plan.pdf, checklist.pdf
```

## Key Engines Used
UltimateSpeedFeedEngine, GCodeSafetyAnalyzerEngine, AdvancedWearPhysicsEngine,
ProcessCapabilityEngine, SetupSheetFromGCodeEngine, MaterialDatabaseEngine,
TribalKnowledgeEngine, MachineGeometricAccuracyEngine
