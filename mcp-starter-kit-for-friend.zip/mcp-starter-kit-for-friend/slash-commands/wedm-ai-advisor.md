---
name: wedm-ai-advisor
description: Neural-powered Wire EDM parameter optimization
version: 1.0.0
engines:
  - WEDMNeuralTrainingEngine
  - WEDMFeedbackCalibrationEngine
  - WireEDMDeepAIHardeningEngine
  - WEDMProgramOptimizerEngine
actions:
  - wedm_neural_predict
  - wedm_optimize_params
  - wedm_submit_feedback
  - wedm_calibration_report
hooks:
  - hook_wedm_neural_sanity
  - hook_wedm_learning_trigger
triggers:
  - "wedm ai"
  - "optimize parameters"
  - "neural edm"
  - "best parameters"
---

# /wedm-ai-advisor — Neural Parameter Optimization

AI-powered Wire EDM parameter optimization:
- Neural network predictions (10 models)
- Bayesian calibration
- Uncertainty quantification
- Continuous learning from feedback

## Usage

```
/wedm-ai-advisor <goal> [options]
```

## Arguments

- `goal` — Optimization target (ra|mrr|balance|custom)
- `--material` — Workpiece material
- `--thickness` — Section thickness in mm
- `--current-params` — Current E-code or parameters
- `--constraints` — Hard constraints (e.g., "Ra<0.5")

## Neural Models (10)

| Model | Purpose | Input → Output |
|-------|---------|----------------|
| Ra Predictor | Surface finish | params → Ra µm |
| MRR Predictor | Removal rate | params → mm²/min |
| Wire Break | Break probability | params → P(break) |
| Cycle Time | Time estimation | geometry → minutes |
| Power | Energy consumption | params → kW |
| Wear | Wire wear rate | params → wear/m |
| Stability | Process stability | params → stability% |
| Corner | Corner quality | geometry → quality |
| Taper | Taper accuracy | UV params → error |
| Cost | Total cost | all → $/part |

## Optimization Goals

| Goal | Optimizes | Constraints |
|------|-----------|-------------|
| `ra` | Minimize surface roughness | MRR ≥ threshold |
| `mrr` | Maximize removal rate | Ra ≤ target |
| `balance` | Pareto optimal | Both weighted |
| `custom` | User-defined | Specified |

## Output

```json
{
  "recommended_params": {
    "ecode": "E1847",
    "on_time_us": 4.2,
    "off_time_us": 12.0,
    "peak_current_A": 180,
    "servo_voltage_V": 45,
    "wire_tension_g": 1200,
    "wire_speed_m_min": 8.5,
    "flushing_bar": 6
  },
  "predictions": {
    "ra_um": 0.72,
    "mrr_mm2_min": 48.5,
    "wire_break_prob": 0.03,
    "cycle_time_min": 42
  },
  "confidence": {
    "overall": 0.88,
    "ra": 0.92,
    "mrr": 0.85,
    "break": 0.78
  },
  "alternatives": [
    {"params": {...}, "tradeoff": "5% faster, 10% rougher"}
  ]
}
```

## Examples

```bash
# Optimize for surface finish
/wedm-ai-advisor ra --material D2 --thickness 25

# Maximize speed with Ra constraint
/wedm-ai-advisor mrr --constraints "Ra<0.8"

# Balance for production
/wedm-ai-advisor balance --material A2

# Improve current parameters
/wedm-ai-advisor ra --current-params E1234 --material M2
```

## Feedback Loop

Submit actual results to improve models:
```bash
/wedm-ai-advisor feedback --program part.nc --actual-ra 0.68 --actual-time 45
```

This triggers:
1. `hook_wedm_learning_trigger`
2. Bayesian model update
3. Knowledge base enrichment

## Safety Hooks

- `hook_wedm_neural_sanity` — Validates outputs in physical bounds
- Blocks if Ra < 0 or Ra > 20 µm

## Leverages

- `WEDMNeuralTrainingEngine` (2,436 LOC) — All 10 models
- `WEDMFeedbackCalibrationEngine` (229 LOC) — Bayesian updates
- Gaussian Process regression with RBF kernel
