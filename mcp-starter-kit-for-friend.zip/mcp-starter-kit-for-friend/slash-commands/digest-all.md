---
effort: low
maxTurns: 5
disallowedTools:
  - Edit
  - Write
  - Bash
---

# Digest All — Load Complete System Map in Minimal Tokens

Load the entire PRISM file system map in ~1500 tokens. Use this at session start instead of running Glob/Grep to explore the codebase.

## Steps

1. Read `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` — full system in ~735 tokens (shortcodes, counts, top engines, key dispatchers)
2. Read `C:/PRISM/mcp-server/data/docs/DIRECTORY_DIGEST.md` — 215 dirs with purposes + domain routing (~800 tokens)
3. Only if needed: Read `C:/PRISM/mcp-server/data/docs/DSL_COMPACT.md` — shortcode category reference (~100 tokens)

## IMPORTANT: Use Shortcodes in All Output
When referencing files, use DSL shortcodes to save tokens:
- Instead of `src/engines/CuttingForceEngine.ts` → use `E0042: CuttingForceEngine`
- Instead of `src/tools/dispatchers/calcDispatcher.ts` → use `D01: calcDispatcher`
- Resolve: `codeSystemIndexEngine.resolve('E0042')` or `/code-index E0042`
- Lookup: `codeSystemIndexEngine.lookup('src/engines/CuttingForceEngine.ts')` → `E0042`

## What You Get

After loading these files (~1535 tokens total), you know:
- Every directory and its purpose
- Domain routing (topic -> directory mapping)
- File counts per directory
- Shortcode system (E0001 = first engine, D01 = first dispatcher)
- Key files in each directory
- Cross-references between components

## When NOT to Use

- If you only need one specific file -> use `/code-index` or Grep directly
- If you already loaded MEMORY.md which has the essentials
- If you're in a token-critical session -> use `/quick-ref` instead (even more compact)

## Additional Deep Dives

If you need more detail after loading the digest:
- All 860 engines with 1-line descriptions: `data/docs/ENGINE_DIGEST.md`
- All 66 dispatchers with action counts: `data/docs/DISPATCHER_DIGEST.md`
- Full engine shortcode index: `data/docs/CODE_SYSTEM_INDEX.json`
- Complete file listing: `data/docs/MASTER_INDEX_COMPACT.md`
