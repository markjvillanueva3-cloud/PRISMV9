# Algorithm Inspect — PRISM Algorithm Explorer

You are inspecting PRISM's 51 algorithms. Each algorithm implements the `Algorithm<I,O>` interface with validate, calculate, and getMetadata methods. They span 17 domains from cutting forces to neural inference. Use this to understand available algorithms, check their metadata, find the right algorithm for a task, or audit safety classifications.

## Args: $ARGUMENTS
- Empty: list all 51 algorithms grouped by domain
- `[algorithm-name]`: inspect a specific algorithm in detail
- `domain [name]`: list algorithms in a domain (force, thermal, wear, optimization, etc.)
- `safety`: show all algorithms by safety classification (critical/standard/informational)
- `search [keyword]`: search algorithms by name, domain, or description
- `unused`: find algorithms not referenced by any dispatcher action
- `coverage`: show domain coverage map

## Algorithm Directory
All algorithms live in `C:/PRISM/mcp-server/src/algorithms/`:

### Domains (17):
- **force**: Kienzle, JohnsonCook, Merchant, OxleyForce, SpecificEnergy
- **tool_life**: Taylor, UsuiWear, BayesianWear, ToolWearPrediction
- **thermal**: ThermalPartition, ThermalFEA, JaegerTempField, CuttingTempAdvanced
- **surface**: SurfaceFinishPredictor, RoughnessModel
- **stability**: StabilityLobeDiagram, FRFStabilityLobe, SpindleVibFFT
- **dynamics**: ModalAnalysis, HarmonicResponse
- **optimization**: GeneticOptimizer, SimulatedAnnealing, ParticleSwarm, BayesianOptimizer
- **planning**: AntColonyTSP, DPMultiPass, ILPAssignment, CSPSetupPlan
- **ml**: NeuralInference, TimeSeriesPredictor, AnomalyDetector
- **signal**: FFTAnalyzer, KalmanFilter, WaveletAnalysis
- **control**: PIDController, AdaptiveController, FuzzyController
- **geometry**: MinkowskiSum, SweptVolumeCollision, ConvexHull
- **collision**: CollisionDetection, RapidMoveValidator
- **wear**: UsuiWearModel, AbrahamsonWear
- **power**: SpindlePowerModel, MotorThermalModel
- **numerical**: NewtonRaphson, RungeKutta, GaussElimination
- **material**: MaterialFlowStress, HardenabilityModel

## Step 1: Parse Query
Fuzzy-match algorithm and domain names:
- "kienzle" → KienzleForceModel
- "taylor" → TaylorModel
- "ga" or "genetic" → GeneticOptimizer
- "fft" → FFTAnalyzer

## Step 2: Execute Query

### List All (`/algorithm-inspect`)
1. Read all `.ts` files in `src/algorithms/` (exclude types.ts, index.ts, test files)
2. Group by domain
3. Present:
```
PRISM ALGORITHMS (51)
=====================
force (5):         Kienzle, JohnsonCook, Merchant, Oxley, SpecificEnergy
tool_life (4):     Taylor, UsuiWear, BayesianWear, ToolWearPrediction
thermal (4):       ThermalPartition, ThermalFEA, Jaeger, CuttingTempAdv
stability (3):     StabilityLobe, FRFStabilityLobe, SpindleVibFFT
optimization (4):  Genetic, SimAnnealing, ParticleSwarm, Bayesian
planning (4):      AntColonyTSP, DPMultiPass, ILPAssign, CSPSetup
...
```

### Inspect Specific (`/algorithm-inspect KienzleForceModel`)
1. Read the algorithm file
2. Extract: class name, domain, safety classification, input/output types
3. Extract metadata from getMetadata()
4. Present:
```
ALGORITHM: KienzleForceModel
==============================
File:     src/algorithms/KienzleForceModel.ts
Domain:   force
Safety:   critical
Lines:    [N]

Input:    { kc11, mc, h, b, ap, ae, vc, n, z }
Output:   { Fc, Ff, Fp, P, T, specific_energy }

Metadata:
  Model:     Kienzle empirical force model
  Formula:   Fc = kc1.1 × h^(1-mc) × b × ap
  Reference: Kienzle, O. (1952) "Die Bestimmung von Kräften..."
  Accuracy:  ±10% for standard steels
  Limits:    h > 0, b > 0, kc11 > 0

Used By:
  [dispatchers/actions that call this algorithm]

Test Coverage:
  [test files that test this algorithm]
```

### Safety Audit (`/algorithm-inspect safety`)
```
ALGORITHM SAFETY CLASSIFICATION
================================
CRITICAL (must never produce unsafe values):
  KienzleForceModel, MerchantForceModel, TaylorModel,
  ThermalPartitionModel, StabilityLobeDiagram, ...

STANDARD (quality-important but not safety-blocking):
  GeneticOptimizer, SimulatedAnnealing, FFTAnalyzer, ...

INFORMATIONAL (advisory/display only):
  NeuralInference, AnomalyDetector, TimeSeriesPredictor, ...

Coverage: [N] critical, [N] standard, [N] informational
All critical algorithms tested: [YES/NO]
```

### Unused (`/algorithm-inspect unused`)
Find algorithms not referenced by any dispatcher:
1. For each algorithm, grep all dispatcher files for references
2. List any with zero references
```
UNUSED ALGORITHMS
=================
[algorithm] — no dispatcher references found
[algorithm] — imported but never called
```

## Error Handling
- **Algorithm not found**: "No algorithm matching '[name]'. Available: [list by domain]"
- **Domain not found**: "Unknown domain '[name]'. Domains: force, thermal, wear, ..."
- **File missing**: "Algorithm file expected but not found."

## Chaining
- Discovery: `/algorithm-inspect` → find algo → `/algorithm-inspect [name]` → understand interface
- Development: `/algorithm-inspect unused` → find orphans → `/forge-engines` → wire them
- Safety: `/algorithm-inspect safety` → audit critical → `/forge-safety` → harden
- Validation: `/algorithm-inspect [name]` → check test coverage → `/forge-tests` → add tests
- Pairs with: `/registry-browse algorithm` (registry view), `/trace` (wiring chain), `/action-search` (find dispatcher actions)
