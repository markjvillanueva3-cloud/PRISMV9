---
effort: high
maxTurns: 25
---

# Session Startup Macro

This profile-side command is only a launcher.
The canonical PRISM `/startup` command lives in the repo at `H:/PRISM/.claude/commands/startup.md`.

## Rule

When working in `H:\PRISM`, follow the repo command exactly instead of maintaining a separate profile-side startup protocol.

## Canonical Source

- `H:/PRISM/.claude/commands/startup.md`
