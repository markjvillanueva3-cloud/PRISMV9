# Sync System State

You are synchronizing all PRISM system state to ensure consistency across the roadmap index, milestone envelopes, position tracker, and documentation. This is the "fix everything" command — it detects drift and repairs it.

## Args: $ARGUMENTS
- Empty: detect and fix all drift
- `dry-run`: detect only, report what would be fixed without changing anything
- `counts`: fix count drift only
- `index`: fix roadmap index only
- `position`: fix CURRENT_POSITION.md only

## Phase 1: Inventory
Scan the filesystem to build ground truth:

1. **Envelopes**: List all `.json` files in `C:/PRISM/mcp-server/data/milestones/`. For each, read and extract: `id`, `title`, `track`, `status`, unit count, completed unit count.

2. **Index**: Read `C:/PRISM/mcp-server/data/roadmap-index.json`. Build a map of indexed milestones.

3. **Claims**: Scan `C:/PRISM/mcp-server/data/claims/` for active claims.

## Phase 2: Detect Drift

### Index vs Envelopes
- Envelopes without index entries → "MISSING FROM INDEX"
- Index entries without envelopes → "ORPHAN INDEX ENTRY"
- Index status != envelope status → "STATUS MISMATCH"
- Index unit counts != envelope unit counts → "COUNT MISMATCH"

### Aggregate Counts
- `total_milestones` in index header vs actual count
- `completed_milestones` in index header vs actual complete count
- Track-level totals

### Position Tracker
- Read `C:/PRISM/state/CURRENT_POSITION.md`
- Compare its milestone counts against index reality
- Check if "available tracks" table is current

### CLAUDE.md Counts
- Check all CLAUDE.md files for stale counts (dispatchers, engines, actions, milestones)
- Compare against MEMORY.md verified values

## Phase 3: Report Drift
```
SYNC DRIFT REPORT
=================
Index ↔ Envelopes:
  [N] missing from index
  [N] orphan index entries
  [N] status mismatches
  [N] count mismatches

Aggregate Counts:
  total_milestones:     [index value] → [actual]  [OK/FIX]
  completed_milestones: [index value] → [actual]  [OK/FIX]

Position Tracker:
  [N] stale values detected

CLAUDE.md:
  [file]: [field] says [X], actual [Y]
```

## Phase 4: Fix (unless dry-run)
For each drift item detected:

1. **Missing from index**: Add entry with data from envelope
2. **Orphan index entry**: Warn only (do not delete — may be intentional)
3. **Status mismatch**: Update index to match envelope (envelope is source of truth)
4. **Count mismatch**: Update index counts from envelope
5. **Aggregate counts**: Recalculate and update index header
6. **Position tracker**: Regenerate milestone summary section
7. **CLAUDE.md counts**: Update stated counts to match verified reality
8. **Stale claims**: Reap claims older than 5 minutes
9. **Version bump**: Increment roadmap-index patch version

## Phase 5: Verify
After fixes:
- Re-read index and verify all counts match
- Verify `total_milestones` = envelope count
- Verify `completed_milestones` = complete envelope count
- Report: "Sync complete. [N] items fixed. System is now consistent."

## Phase 6: Update Memory
If any significant drift was fixed, update MEMORY.md with the new correct counts.
