---
effort: high
maxTurns: 30
---

# Forge — Brainstorm → Plan → Iterate Pipeline

You are running the full ideation-to-execution pipeline. This command chains `/smart`, `/rgs`, and `/ralph-loop` into a single flow that takes a rough idea and forges it into a polished, executed milestone.

## Args: $ARGUMENTS
- A brief description of what to build, fix, or improve
- Example: `/forge add 5-axis compensation to the safety chain`
- Example: `/forge optimize session startup token cost`
- Example: `/forge create a dashboard for roadmap progress`

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** before concluding any analysis or implementation.
- Consider every applicable model, formula, algorithm, and combination — including novel cross-domain approaches.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing coverage before building new.
- **Completeness > Speed.** A missed mathematical model is a permanent capability gap.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.

## Phase 1: Smart Analysis (`/smart` protocol)
Analyze the brief across complexity, domain, and effort dimensions:
1. **Complexity**: SIMPLE / MODERATE / COMPLEX
2. **Domain**: Which PRISM domains does this touch? (engines, dispatchers, safety, infrastructure, UI, etc.)
3. **Roles**: Select appropriate roles (TypeScript Engineer, Manufacturing Expert, Systems Architect, etc.)
4. **Model**: Select OPUS / SONNET / HAIKU based on complexity
5. **Effort**: HIGH / MEDIUM / LOW

Output the SMART CONFIG header, then proceed.

## Phase 2: Brainstorm (`/rgs brainstorm` protocol)
With the smart configuration active:
1. Read `C:/PRISM/state/CURRENT_POSITION.md` for current system state
2. Read `C:/PRISM/mcp-server/data/roadmap-index.json` for roadmap context
3. Explore the codebase areas relevant to the brief
4. Brainstorm the implementation approach:
   - What exists that can be leveraged?
   - What needs to be built from scratch?
   - What are the risks and dependencies?
   - How many units/sessions will this take?
5. Present 2-3 approach options with tradeoffs
6. Pick the best approach (or ask if genuinely ambiguous)

## Phase 2B: Toolkit Selection (index-driven)
After brainstorming identifies the domain and approach, pre-load relevant tools to avoid wasteful mid-execution searches.

**Lookup Protocol:**
1. **Map the brief's domain** to PRISM subsystems using keyword matching:
   - force/cutting/chip → `force` domain; thermal/heat → `thermal`; safety/S(x) → `safety`; tool/wear → `tool_life`; surface/roughness → `surface`; stability/chatter → `stability`; optimization → `optimization`; quality/SPC → `quality`; material/alloy → `material`; gcode/toolpath → `geometry`; controller → `control`

2. **Select relevant skills** (from the 54 available):
   - Always: `/test`, `/scrutinize`, `/check-dsl`
   - By domain: safety → `/safety-audit`, `/forge-safety`; engines → `/algorithm-inspect`, `/formula-browse`; dispatchers → `/action-search`; materials → `/material-lookup`; hooks → `/hook-browse`; registries → `/registry-browse`
   - By task type: creating → `/addtomatrix`, `/forge-wiring`; debugging → `/forge-debug`, `/trace`; performance → `/forge-perf`; cleanup → `/de-sloppify`; verification → `/verify-loop`

3. **Select relevant engines/algorithms** from MASTER_INDEX:
   - Read `C:/PRISM/mcp-server/MASTER_INDEX_COMPACT.md` — extract entries matching the domain
   - List the 3-8 most relevant engines/algorithms with file paths

4. **Select relevant formulas** (if domain is physics/manufacturing):
   - List formula IDs from FormulaRegistry that the implementation will need

5. **Select relevant dispatchers**:
   - Identify which dispatcher(s) own the target domain's actions

**Output a compact Toolkit Card:**
```
TOOLKIT — [forge brief summary]
================================
Skills:       /safety-audit, /algorithm-inspect, /test, /scrutinize
Engines:      [relevant engine names] ([N] relevant)
Formulas:     [relevant formula IDs] ([N] relevant)
Dispatchers:  [dispatcher names with action counts]
Scripts:      [relevant scripts or "none"]
Key Files:    [3-5 primary files to create/modify]
```

Reference this toolkit throughout Phases 3-4 to avoid re-searching for components.

## Phase 3: Generate Milestone (`/rgs generate` protocol)
Transform the brainstorm into a formal RGS milestone:
1. Create milestone envelope JSON conforming to `roadmapSchema.ts`
2. Populate all units with:
   - Clear steps with tool references
   - Entry/exit conditions
   - Deliverables
   - Dependencies
3. Write envelope to `C:/PRISM/mcp-server/data/milestones/{ID}.json`
4. Add entry to `roadmap-index.json`
5. Run scrutinization (12 checks, target >= 0.92)

## Phase 4: Execute with Ralph Loop (`/ralph-loop` protocol)
Begin executing the milestone with iterative refinement:
1. Claim the first unit via TaskClaimService
2. Execute the unit's steps
3. After each unit, run a Ralph-style quality loop:
   - **Review**: Does the output meet exit conditions?
   - **Assess**: Are there quality issues or gaps?
   - **Loop**: If issues found, fix them before proceeding
   - **Proceed**: Move to next unit only when current is solid
   - **Harden**: Run build + tests after each unit
4. Update envelope and index as units complete
5. Continue until milestone is complete or session budget is exhausted

## Progress Tracking
After each phase, report:
```
FORGE PROGRESS
==============
Phase 1 (Smart):     COMPLETE — [config summary]
Phase 2 (Brainstorm): COMPLETE — [approach selected]
Phase 3 (Generate):  COMPLETE — [milestone-id] created ([N] units)
Phase 4 (Execute):   IN PROGRESS — [X]/[Y] units done

Current Unit: [unit-id] — [title]
Ralph Iteration: [N]
Build: [PASS/FAIL]
```

## Session Budget Awareness
If you're running low on context:
1. Run `/compact quick` to save handoff state before context is lost
2. Complete the current unit cleanly (or finish current step)
3. Ship it (`/ship` protocol — includes `/remember` for key findings)
4. Report what's done and what remains
5. Next session: `/startup` → `/handoff read` → `/pick-task [next-unit-id]`

## End State
When the milestone is complete (or session ends):
```
FORGE COMPLETE
==============
Milestone: [ID] — [title]
Units:     [X]/[Y] complete
Duration:  [N] phases executed
Quality:   Scrutiny score [X.XX]
Build:     PASS
Tests:     [N] passing

Deliverables:
  - [list of what was created/modified]

Next: /forge [next idea] or /pick-task for remaining work
```
