# Test — Smart Test Runner

You are running PRISM tests with intelligent filtering, regression detection, and clean reporting. This is the standalone test command — use it anytime you need to verify code without the full `/ship` ceremony.

## Args: $ARGUMENTS
- Empty: full build + full test suite
- `smoke`: build + quick smoke tests only (health, unit tests)
- `safety`: safety-related tests only (safety-actions, safety-score-boundaries, enforcement, emergency-stop, hookengine-safety, rem-ms0-safety)
- `engines`: L2 engine tests only (l2-engines, l2-pass2, l2-infrastructure, l2-mfg-intelligence, l2-cadcam)
- `dispatchers`: L3 dispatcher tests only (l3-core, l3-specialty)
- `hooks`: L4 hook/cadence tests only (l4-hooks-cadences, l4-pass2-hooks)
- `algorithms`: algorithm tests only (algorithms, algorithm-calculate-audit, algorithm-benchmarks)
- `roadmap`: roadmap tests only (scrutinize-roadmap, roadmap-hooks, roadmap-executor, roadmap-loader)
- `integration`: integration chain + input validation tests
- `cad`: CAD bridge tests (vitest cad-bridge + pytest if Python available)
- `[pattern]`: run tests matching a vitest pattern (e.g., `test safety` → `vitest run --reporter verbose safety`)
- `build-only`: just run build, no tests
- `no-build`: skip build, tests only

## Step 1: Build Check (unless `no-build`)
Run from `C:/PRISM/mcp-server/`:
```
npm run build
```
Capture:
- Success/failure
- Count of TypeScript errors (grep for "error TS")
- If build fails: report errors and STOP (unless `no-build` was specified)

## Step 2: Determine Test Scope
Based on args, construct the vitest command:

| Arg | Filter |
|-----|--------|
| (empty) | `npx vitest run --reporter verbose` |
| smoke | `npx vitest run --reporter verbose health envParsing atomicWrite getEffort apiTimeout` |
| safety | `npx vitest run --reporter verbose safety-actions safety-score enforcement emergency hookengine rem-ms0` |
| engines | `npx vitest run --reporter verbose l2-engines l2-pass2 l2-infrastructure l2-mfg l2-cadcam` |
| dispatchers | `npx vitest run --reporter verbose l3-core l3-specialty` |
| hooks | `npx vitest run --reporter verbose l4-hooks l4-pass2` |
| algorithms | `npx vitest run --reporter verbose algorithms algorithm-calculate algorithm-benchmarks` |
| roadmap | `npx vitest run --reporter verbose scrutinize-roadmap roadmap-hooks roadmap-executor roadmap-loader` |
| integration | `npx vitest run --reporter verbose integration-chain input-validation` |
| cad | `npx vitest run --reporter verbose cad-bridge` + `python -m pytest C:/PRISM/cad/tests/ -v` |
| [pattern] | `npx vitest run --reporter verbose [pattern]` |

Run from `C:/PRISM/mcp-server/`.

## Step 3: Parse Results
From vitest output, extract:
- Total tests, passed, failed, skipped
- Failed test names and their error messages
- Duration

## Step 4: Regression Detection
Compare against known baseline from MEMORY.md:
- **Expected:** 1242 backend pass, 1 known failure (Merchant's force_ratios in Kienzle)
- **New failures:** Any test that fails AND is not in the known failure list = REGRESSION
- **Fixed tests:** Any known failure that now passes = IMPROVEMENT

## Step 5: Report
```
TEST RESULTS
============
Scope:      [what was tested]
Build:      [PASS/FAIL] — [N errors]
Tests:      [N] passed, [N] failed, [N] skipped ([duration])
Regressions: [N new failures / NONE]
Known:      [N known failures still present]
Improvements: [N previously-failing tests now pass / NONE]

[If failures exist:]
FAILURES:
  - [test name]: [short error message]
  - [test name]: [short error message]

Status: [CLEAN / N REGRESSIONS DETECTED]
```

## Error Handling
- **Build timeout:** Kill after 120s, report as build failure
- **Test timeout:** vitest has built-in timeouts, report any timeout as failure
- **Missing vitest:** Report "vitest not found — run npm install from C:/PRISM/mcp-server/"
- **Partial failures:** Always show the full report even if some tests fail

## Chaining
- After `/test`: if CLEAN → ready for `/ship` or `/auto-commit`
- After `/test`: if REGRESSIONS → fix before proceeding
- Called automatically by: `/autopilot` Phase 6, `/ship` Step 4
