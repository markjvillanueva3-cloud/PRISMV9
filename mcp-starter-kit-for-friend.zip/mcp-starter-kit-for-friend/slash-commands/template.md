# Template — Use a prompt template for common tasks

Fill and execute a pre-built prompt template.

## Usage
- `/template list` — show all available templates
- `/template engine_create name=Foo purpose="bar operations"` — fill and use a template
- `/template commit_message type=feat scope=engines summary="add X"` — generate commit message

## Steps
1. If "list" → call promptTemplateEngine.list() and display
2. Otherwise parse template ID and params from $ARGUMENTS
3. Call promptTemplateEngine.fill(id, params)
4. Display the filled template
