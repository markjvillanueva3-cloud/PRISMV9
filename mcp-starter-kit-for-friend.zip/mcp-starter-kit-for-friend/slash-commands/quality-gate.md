# Quality Gate — Full Quality Assurance Pipeline

Complete quality assurance setup for production runs. Combines process capability analysis, SPC planning, inspection point definition, program verification, operator instructions, and first-article requirements.

## Args:
- Part + tolerance description (e.g., "aerospace bracket, ±0.0005 on bore, 32 Ra finish")
- `first-article`: generate first-article inspection report template
- `spc`: focus on SPC setup for ongoing production

## Phase 1: Process Capability Analysis
1. Parse input for critical dimensions, tolerances, surface finish requirements
2. `/quality-check` — process capability prediction
   - Cp/Cpk per critical dimension (ISO 22514)
   - Machine capability vs process capability
   - Predicted scrap rate (PPM)
   - Sigma level per dimension
   - Risk ranking: which dimensions are most likely to fail

## Phase 2: Speed/Feed for Quality
1. `/process-calc` — process parameters tuned for quality
   - Surface finish prediction (Ra, Rz) per operation
   - Dimensional accuracy prediction (thermal growth, deflection)
   - Residual stress estimation
2. Run `ultimateSpeedFeedEngine.calculate()` with `optimize: "surface_finish"`
   - Parameters optimized for dimensional stability
   - Thermal error compensation recommendations
   - Tool deflection compensation values

## Phase 3: Program Verification
1. `/program-validate` — verify CNC program
   - Syntax correctness
   - No rapid-into-material violations
   - Feed rate consistency (no sudden changes)
   - Power/torque within safe limits
   - Coolant activation at correct points
2. `/auto-speed-feed` — verify speeds/feeds are quality-appropriate
   - No excessive chip loads
   - Surface speed appropriate for finish requirements
   - Dwelling where needed for bore finish

## Phase 4: SPC Plan
1. Define control chart setup per critical dimension:
   - Chart type (X-bar/R, X-bar/S, individual/MR)
   - Subgroup size and sampling frequency
   - Control limits (from capability study)
   - Out-of-control rules (Western Electric / Nelson)
2. Measurement system analysis (MSA) requirements:
   - Gage R&R study plan
   - Required measurement resolution
   - Instrument recommendations

## Phase 5: Setup Sheet with Quality Focus
1. `/setup-sheet-generate` — operator documentation
   - Critical dimensions highlighted with tolerances
   - In-process inspection points
   - Go/no-go gage list
   - Tool wear indicators to watch
   - When to measure (every Nth part, after tool change, etc.)

## Phase 6: First-Article Requirements
1. Generate first-article inspection checklist:
   - Every dimension measured and recorded
   - Surface finish measurements at specified locations
   - Material certification verification
   - Hardness test (if applicable)
   - Visual inspection criteria
   - AS9102 form template (if aerospace)

## Output Summary
```
QUALITY GATE COMPLETE — [Part Description]
============================================
Critical Dims:  [N] identified
Tolerances:     [tightest] to [loosest]

PROCESS CAPABILITY:
Dimension        | Tolerance | Cp    | Cpk   | Sigma | PPM   | Risk
[dim1]           | ±[X]      | [X]   | [X]   | [X]σ  | [X]   | [H/M/L]
[dim2]           | ±[X]      | [X]   | [X]   | [X]σ  | [X]   | [H/M/L]
...

SPC SETUP:
  Chart type:       [X-bar/R or I/MR]
  Subgroup size:    [N]
  Sample frequency: every [N] parts
  Control limits:   calculated from capability study
  OOC rules:        [list]

INSPECTION PLAN:
  First article:    [N] measurements required
  In-process:       [N] dims checked every [N] parts
  Final:            [N] dims + surface finish + visual
  Instruments:      [list with required resolution]

QUALITY PREDICTION:
  Expected Cpk:     [X] (overall)
  Predicted scrap:  [X] PPM
  Sigma level:      [X]σ
  Confidence:       [X]%

Files Generated:
  Setup sheet, SPC template, FAI checklist, inspection plan
```

## Key Engines Used
ProcessCapabilityEngine, UltimateSpeedFeedEngine, StatisticalProcessMonitoringEngine,
GCodeSafetyAnalyzerEngine, SetupSheetFromGCodeEngine, MachineGeometricAccuracyEngine
