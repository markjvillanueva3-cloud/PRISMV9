# Context — Context Budget Inspector

You are analyzing the current session's context consumption and identifying optimization opportunities. This is a quick diagnostic tool that helps manage token efficiency during long sessions.

## Args: $ARGUMENTS
- Empty: full context audit
- `memory`: check MEMORY.md size and optimization opportunities
- `hooks`: check hook output sizes and compression effectiveness
- `files`: check which files have been read this session and their sizes
- `trim`: suggest specific trimming actions to free context

## Step 1: MEMORY.md Analysis
Read `~/.claude/projects/*/memory/MEMORY.md`:
1. Count total lines (target: <200 for optimal loading)
2. Count sections and estimate tokens per section
3. Identify sections that could be compressed or moved to topic files
4. Check for stale information that should be removed

```
MEMORY.md:
  Lines:     [N] / 200 limit ([X]% used)
  Sections:  [N]
  Est tokens: ~[N]K
  Status:    [LEAN / APPROACHING LIMIT / OVER LIMIT]
```

## Step 2: CLAUDE.md Analysis
Check all CLAUDE.md files for size:
- `C:/PRISM/CLAUDE.md`
- `C:/PRISM/mcp-server/CLAUDE.md`
- `C:/PRISM/mcp-server/src/engines/CLAUDE.md`
- `C:/PRISM/mcp-server/src/tools/dispatchers/CLAUDE.md`

For each:
1. Count lines
2. Estimate tokens
3. Check for redundancy across files
4. Check for information that duplicates MEMORY.md

```
CLAUDE.md Files:
  [path]:     [N] lines (~[N]K tokens)
  [path]:     [N] lines (~[N]K tokens)
  Total:      [N] lines (~[N]K tokens)
  Redundancy: [NONE / N duplicated sections between files]
```

## Step 3: Hook Output Analysis
Check hook configurations for output efficiency:
1. Read `~/.claude/settings.json` — count hooks and their matchers
2. Check posttooluse-unified compression thresholds (5K/8K/10K/20K)
3. Estimate average hook overhead per tool call
4. Check for hooks that fire frequently but add minimal value

```
Hook Output:
  Total hooks:        [N]
  Compression rules:  [N] tiers (5K/8K/10K/20K)
  Hookify rules:      [N] (block: [N], warn: [N], autofire: [N])
  Estimated overhead: ~[N] tokens/tool-call average
```

## Step 4: Skill/Command Size Audit
Check the total size of all command files:
1. Count files in `~/.claude/commands/`
2. Sum their sizes
3. Note: command files are loaded on-demand (not all loaded at once), so this is informational

```
Commands:
  Files:      [N] command files
  Total size: [N]KB
  Largest:    [name] ([N] lines)
  Smallest:   [name] ([N] lines)
```

## Step 5: Optimization Suggestions
Based on the analysis, suggest specific actions:

### If MEMORY.md is over 200 lines:
- Identify sections to extract into topic files (e.g., `materials-notes.md`, `cad-notes.md`)
- Identify stale data to remove
- Identify verbose sections to compress

### If CLAUDE.md files are redundant:
- Identify which facts appear in multiple files
- Suggest consolidation strategy

### If hooks are heavy:
- Identify hooks with low signal-to-noise ratio
- Suggest tightening compression thresholds
- Suggest removing low-value hooks

### If context is lean:
- Report "Context budget healthy — no action needed"

## Context Report
```
CONTEXT BUDGET
==============
MEMORY.md:    [N] lines ([X]% of 200 limit) — [LEAN/WARNING/OVER]
CLAUDE.md:    [N] total lines across [N] files — [OK/HEAVY]
Hooks:        [N] scripts + [N] rules — ~[N] tokens/call
Commands:     [N] files, [N]KB total

Estimated Session Load: ~[N]K tokens (context files + hooks)
Session Target:         <30K tokens for optimal performance

Recommendations:
  [1. specific action if needed]
  [2. specific action if needed]
  [3. specific action if needed]
  [or: "Context is lean — no optimizations needed"]

Status: [HEALTHY / NEEDS ATTENTION / OPTIMIZE NOW]
```

## Error Handling
- **Can't read MEMORY.md**: "MEMORY.md not found at expected path. Check `~/.claude/projects/` structure."
- **Can't read settings.json**: "settings.json not found. Hooks may not be configured."
- **Context already lean**: Report as healthy — don't suggest unnecessary optimizations.

## Chaining
- Mid-session check: `/context` → identify bloat → trim manually or via `/forge-perf tokens`
- Session start: `/startup` → `/context memory` → quick size check
- Before compaction: `/context` → understand what's heavy before the system auto-compacts
- After heavy work: `/context trim` → specific suggestions to free context
