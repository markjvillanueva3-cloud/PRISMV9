# Forge Tests — Test Gap Discovery + Generation Autopilot

You are running a specialized autopilot pipeline focused on discovering test coverage gaps, generating comprehensive test suites, running them, and reporting coverage improvements across the PRISM system.

## Args: $ARGUMENTS
- Empty: full discovery — analyze the system, find test gaps, generate tests for the worst gaps
- `[file-path]`: generate tests for a specific file or module
- `[subsystem]`: focus on a subsystem (engines, dispatchers, algorithms, safety, cad, materials)
- `[count]`: generate up to N test files (default: 5)
- `list`: just analyze and list test gaps without generating any
- `coverage`: run existing tests and report coverage map

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when generating test cases.
- Consider every edge case, boundary condition, statistical distribution, and failure mode.
- Test every formula, algorithm, and physics model against published reference values.
- **Completeness > Speed.** An untested code path is a latent defect.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE-COMPLEX (test generation requires understanding the code under test)
2. Domain: Testing/QA + TypeScript/Python Engineering
3. Roles: Senior QA & Reliability Engineer + Senior TypeScript Engineer
4. Model: OPUS (test design requires understanding edge cases and failure modes)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Test Coverage Analysis

### 3A: Inventory Existing Tests
1. Glob `C:/PRISM/mcp-server/src/__tests__/**/*.test.ts` — count all MCP test files
2. Glob `C:/PRISM/cad-engine/tests/**/test_*.py` — count all CAD test files
3. Read test count from last known run (MEMORY.md: 1243 MCP, 60 CAD)
4. Map which source files have corresponding test files

### 3B: Identify Coverage Gaps
For each product type, check test coverage:

**Engines** (`src/engines/*.ts`):
- List all engine files
- Check which have a corresponding `__tests__/*Engine.test.ts`
- Flag engines with zero tests
- Flag engines with tests that only test the happy path (no error cases)

**Dispatchers** (`src/tools/dispatchers/*Dispatcher.ts`):
- List all dispatcher files
- Check which have corresponding test files
- Flag dispatchers with untested actions
- Check: does every action have at least one test?

**Algorithms** (`src/algorithms/*.ts`):
- List all algorithm files
- Check for test coverage
- Flag algorithms with no edge case tests (boundary values, empty inputs, NaN)

**Safety Chain** (`src/engines/Safety*.ts`, `src/hooks/safety*.ts`):
- Are S(x) scoring paths tested?
- Are hard-block conditions tested?
- Are bypass attempts tested (should fail)?

**CAD Engine** (`cad-engine/src/*.py`):
- bridge.py: JSON-RPC protocol coverage
- cad_kernel.py: geometry operation coverage
- geo_validator.py: validation check coverage
- cad_export.py: format export coverage

**Registries** (`src/registries/*.ts`):
- Data loading tests
- Lookup/query tests
- Edge cases (missing entries, malformed data)

### 3C: Rank Gaps by Risk
Score each gap:
- **Blast Radius** (HIGH/MEDIUM/LOW): If this code breaks, how much of the system fails?
- **Change Frequency** (HIGH/MEDIUM/LOW): How often is this code modified?
- **Complexity** (HIGH/MEDIUM/LOW): How complex is the code? (more complex = more likely to have bugs)
- **Safety Relevance** (HIGH/MEDIUM/LOW): Does this code affect safety scoring or critical operations?

Priority = (BlastRadius * 3 + ChangeFreq * 2 + Complexity * 2 + SafetyRelevance * 3) / 10

Present:
```
TEST GAP ANALYSIS
=================
Total Source Files:    [N]
Files with Tests:     [N] ([X]%)
Files without Tests:  [N] ([Y]%)

Critical Gaps (sorted by risk):
Rank | File                          | Type       | Blast | Freq | Safety | Score
-----|-------------------------------|------------|-------|------|--------|------
  1  | SafetyEngine.ts               | engine     | HIGH  | HIGH | HIGH   | 9.5
  2  | materialDispatcher.ts         | dispatcher | HIGH  | MED  | MED    | 7.2
  ...

Test Distribution:
  Engines:      [X]/[Y] tested ([Z]%)
  Dispatchers:  [X]/[Y] tested ([Z]%)
  Algorithms:   [X]/[Y] tested ([Z]%)
  Safety:       [X]/[Y] tested ([Z]%)
  CAD:          [X]/[Y] tested ([Z]%)
  Registries:   [X]/[Y] tested ([Z]%)
```

If args = `list` or `coverage`, stop here.

## Phase 4: Generate Tests
For each gap to fill (top N from ranking):

### 4A: Understand the Source
1. Read the source file completely
2. Identify all public functions/methods
3. Identify all code paths (branches, error handlers, edge cases)
4. Identify dependencies (what does this code call? what mocks are needed?)
5. Check existing patterns — how do neighboring test files structure their tests?

### 4B: Design Test Suite
For each source file, design tests covering:

**Happy Path:**
- Standard input → expected output
- Multiple valid input variations

**Error Cases:**
- Missing required parameters
- Invalid parameter types
- Out-of-range values
- Null/undefined inputs

**Edge Cases:**
- Boundary values (0, negative, MAX_SAFE_INTEGER)
- Empty collections
- NaN/Infinity for numeric operations
- Unicode/special characters for string operations

**Integration Points:**
- Does the unit correctly call its dependencies?
- Does it handle dependency failures gracefully?

**PRISM-Specific:**
- AtomicValue return format compliance
- Safety score integration
- Parameter normalization behavior

### 4C: Write Tests
1. Create the test file following existing conventions:
   - MCP tests: `src/__tests__/{module-name}.test.ts` using vitest
   - CAD tests: `tests/test_{module-name}.py` using pytest
2. Use existing test helpers and fixtures
3. Include descriptive `describe`/`it` blocks
4. Add comments explaining what each test validates

### 4D: Run Tests
1. Run the new test file in isolation first
2. Fix any test failures (bad assertions, missing mocks, import errors)
3. Run the full test suite to verify no regressions
4. Report results per test file

## Phase 5: Validate
For each generated test file:
1. Does it actually test the source code (not just import it)?
2. Does it cover the identified gaps?
3. Do all tests pass?
4. Does the full suite still pass?

```
TEST GENERATION RESULTS
=======================
File: {test-file}
  Tests written:  [N]
  Tests passing:  [N]
  Tests failing:  [N]
  Paths covered:  [happy] + [error] + [edge]
  Status:         PASS / NEEDS FIXES
```

## Phase 6: Forge Postflight (`/forge-postflight tests` protocol)
Run the shared integration protocol for newly created test files:
1. **Gate 1 — DSL**: SKIP (test files don't need DSL compliance)
2. **Gate 2 — Matrix**: SKIP (tests aren't registered in MASTER_INDEX)
3. **Gate 3 — Trace**: SKIP (tests don't participate in wiring chains)
4. **Gate 4 — Sync**: RUN — verify test count in MEMORY.md matches actual passing count
5. **Gate 5 — Memory**: RUN — update test suite counts (MCP + CAD totals)
6. **Gate 6 — Hookify**: SKIP (tests don't need autofire rules)

Report the postflight results before proceeding to commit.

## Phase 7: Auto-Commit (`/auto-commit` protocol)
1. Stage all new test files
2. Commit: `test(scope): add [N] test suites for [modules] [FORGE-TESTS]`
3. Report the commit

## Summary Report
```
FORGE TESTS COMPLETE
====================
Analyzed:      [N] source files
Gaps Found:    [N] files with no tests
Generated:     [N] test files ([M] total tests)
All Passing:   YES/NO
Regressions:   NONE / [details]
Committed:     [commit hash]

Coverage Before: [X]% files tested
Coverage After:  [Y]% files tested (+[Z]%)

New Test Files:
  - {test-1}.test.ts — [N] tests for [module]
  - {test-2}.test.ts — [N] tests for [module]
  ...

Test Totals: [N] MCP + [M] CAD = [T] total (was [P])

Next: /forge-tests for more tests, /forge-safety for safety audit
```

## Error Handling
- **Import errors in tests**: Check the source file's exports, fix import paths
- **Mock failures**: Study existing test patterns for mock setup
- **Flaky tests**: Add appropriate timeouts, use deterministic data
- **Build failures**: Run `npm run build` first, fix type errors before testing
- **Context budget**: Generate the highest-priority test file only, report remaining gaps

## Safety Rails
- Never modify source code to make tests pass — fix the tests instead
- Never skip running the full suite after generating new tests
- Never create tests that depend on external services or network
- Tests must be deterministic — no random data without seeds
- Test files must follow existing naming conventions
