# Registry Browse — PRISM Registry Explorer

You are exploring PRISM's 18 registries. Each registry follows a 4-layer hierarchy (CORE → ENHANCED → USER → LEARNED) with search APIs, TTL caching, and auto-reload. Use this to discover what's registered, check for gaps, or query specific entries.

## Args: $ARGUMENTS
- Empty: list all 18 registries with entry counts
- `[registry-name]`: browse a specific registry (e.g., `algorithm`, `formula`, `material`, `tool`)
- `search [registry] [query]`: search within a registry by keyword
- `stats`: show aggregate statistics across all registries
- `layers [registry]`: show entries grouped by data layer (CORE/ENHANCED/USER/LEARNED)
- `gaps`: find registries with low coverage or missing entries
- `compare [registry] [a] [b]`: compare two entries side-by-side

## Registry Directory
All registries live in `C:/PRISM/mcp-server/src/registries/`:

| Registry | File | What It Stores |
|----------|------|---------------|
| Algorithm | AlgorithmRegistry.ts | 51 physics/optimization/ML algorithms |
| Formula | FormulaRegistry.ts | 500 manufacturing formulas |
| Skill | SkillRegistry.ts | Agent skills and capabilities |
| Tool | ToolRegistry.ts | Cutting tools (inserts, endmills, drills) |
| Material | MaterialRegistry.ts | Material definitions and properties |
| Machine | MachineRegistry.ts | CNC machine configurations |
| Coolant | CoolantRegistry.ts | Coolant types and parameters |
| Coating | CoatingRegistry.ts | Tool coating specifications |
| PostProcessor | PostProcessorRegistry.ts | G-code post-processors |
| ToolpathStrategy | ToolpathStrategyRegistry.ts | Machining strategies |
| KnowledgeBase | KnowledgeBaseRegistry.ts | Domain knowledge entries |
| Alarm | AlarmRegistry.ts | Machine alarm definitions |
| Database | DatabaseRegistry.ts | Data source connections |
| Agent | AgentRegistry.ts | AI agent definitions |
| Script | ScriptRegistry.ts | Automation scripts |
| Hook | HookRegistry.ts | Event hook definitions |
| Base | BaseRegistry.ts | Abstract base class (not browsable) |
| Manager | manager.ts | Registry coordination layer |

## Step 1: Parse Query
Determine the browse mode. Registry names are fuzzy-matched:
- "algo" or "algorithm" → AlgorithmRegistry
- "formula" or "formulas" → FormulaRegistry
- "tool" or "cutting" → ToolRegistry
- "mat" or "material" → MaterialRegistry
- "machine" or "cnc" → MachineRegistry

## Step 2: Execute Query

### List All (`/registry-browse`)
1. Read each registry file
2. Count registered entries (look for CORE data arrays/maps)
3. Present:
```
PRISM REGISTRIES (18)
=====================
Registry            | Entries | Layers | Status
--------------------|---------|--------|-------
AlgorithmRegistry   |    51   | CORE   | ACTIVE
FormulaRegistry     |   500   | CORE   | ACTIVE
ToolRegistry        |   [N]   | CORE+  | ACTIVE
MaterialRegistry    |   [N]   | CORE   | ACTIVE
...
Total entries: [N] across 18 registries
```

### Browse Specific (`/registry-browse algorithm`)
1. Read the registry file
2. Extract all registered entries with metadata
3. Group by category/domain if applicable
4. Present:
```
ALGORITHM REGISTRY (51 entries)
================================
Domain: force (5)
  KienzleForceModel    — Empirical cutting force (kc1.1 + mc)
  JohnsonCookModel     — Flow stress with strain/rate/temp
  MerchantForceModel   — Analytical shear-plane forces
  ...

Domain: thermal (4)
  ThermalPartitionModel — Heat partition chip/tool/work
  JaegerTempField       — Moving heat source analytical
  ...

Domain: optimization (4)
  GeneticOptimizer      — Multi-objective GA
  SimulatedAnnealing    — SA with adaptive cooling
  ...
```

### Search (`/registry-browse search formula coolant`)
1. Grep the registry file for the keyword
2. Return matching entries with context
3. Show entry name, description, and which layer it's in

### Stats (`/registry-browse stats`)
Aggregate across all registries:
```
REGISTRY STATISTICS
===================
Total registries:   18 (16 data + 1 base + 1 manager)
Total entries:      [N]
By layer:
  CORE:      [N] entries (built-in)
  ENHANCED:  [N] entries (extended)
  USER:      [N] entries (custom)
  LEARNED:   [N] entries (auto-discovered)
Largest:     FormulaRegistry (500 entries)
Smallest:    [registry] ([N] entries)
```

### Gaps (`/registry-browse gaps`)
Find under-populated or empty registries:
```
REGISTRY GAPS
=============
[registry]: 0 entries — no data registered
[registry]: [N] entries — low coverage vs. [expected]
[registry]: missing [category] entries
```

## Error Handling
- **Registry not found**: "No registry matching '[name]'. Available: [list]"
- **Empty registry**: "Registry exists but has 0 entries. Use /forge-engines to populate."
- **File missing**: "Registry file not found at expected path."

## Chaining
- Discovery: `/registry-browse` → pick registry → `/registry-browse [name]` → dive in
- Development: `/registry-browse gaps` → find empty → `/forge-engines` → populate
- Validation: `/registry-browse [name]` → count entries → `/sync` → verify counts match docs
- Pairs with: `/action-search` (find actions that use a registry), `/trace` (trace registry → engine → dispatcher)
