# Tool Histogram — Tool Usage Distribution

Visualize which tools consume the most tokens this session.

## Steps
1. Review the conversation for tool calls made this session
2. Estimate token cost per tool call:
   - Read: ~lines * 3 tokens
   - Grep: ~matches * 20 tokens
   - Glob: ~results * 5 tokens
   - Edit: ~(old + new string) / 4 tokens
   - Write: ~content / 4 tokens
   - Bash: ~output / 4 tokens
   - Agent: ~2000-5000 tokens per call

3. Output histogram:
```
TOOL HISTOGRAM — [N] calls, ~[N]K tokens
═══════════════════════════════════════
[Tool]  [bar] [pct]% ([N]x, ~[N]K)
...

Top consumer: [tool] ([pct]%)
Optimization target: [suggestion]
```

4. Keep under 300 tokens output.
