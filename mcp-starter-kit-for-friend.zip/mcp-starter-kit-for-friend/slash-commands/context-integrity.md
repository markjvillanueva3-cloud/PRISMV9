# Context Integrity — Quality Guard for Token-Optimized Sessions

Check the health of your current context to prevent hallucinations and stale-data errors.

## Args: $ARGUMENTS
- Empty: full integrity report (health score, alerts, recommendations)
- `check [file]`: verify a specific file is safe to edit
- `agents`: show agent task status and completion verification
- `survival`: show what facts would survive a compaction

## Steps

### Full Report (default)
1. Call `contextIntegrityEngine.report()`
2. Display:

```
CONTEXT INTEGRITY: [score]/100
===========================
Files tracked: [N] ([N] stale)
Agent tasks: [N] ([N] unverified, [N] failed)
Compactions: [N]

[If alerts exist:]
ALERTS:
  [severity] [type]: [detail]
    → [recommendation]
  ...

RECOMMENDATIONS:
  - Re-read stale files before editing: [list]
  - Verify agent results: [list]
  - [other actionable items]
```

### Check Mode
For a specific file: call `contextIntegrityEngine.checkEdit(path)` and report whether it's safe.

### Agents Mode
List all tracked agent tasks with status, showing which completed, which failed silently, and which are still running.

### Survival Mode
Call `contextIntegrityEngine.getCompactionSurvivalFacts()` — show what critical facts would be preserved across a compaction event.

## Output Rules
- Keep output under 300 tokens
- Only show alerts if there are actual issues
- Health score interpretation: 90-100 = safe, 70-89 = caution, <70 = re-read critical files
