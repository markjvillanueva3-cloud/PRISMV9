# Quick Ref — Zero-Cost Context Card

Print this reference card verbatim. No tool calls needed. Just read and relay.

```
PRISM QUICK REFERENCE
=====================

PROJECT ROOT: C:/PRISM/mcp-server/
STATE DIR:    C:/PRISM/state/
COMMANDS:     ~/.claude/commands/
MEMORY:       ~/.claude/projects/C--Windows-System32/memory/MEMORY.md

KEY PATHS
├─ src/engines/          — 880+ engines (core calculation/logic)
├─ src/tools/dispatchers/ — 66 dispatchers (MCP tool handlers)
├─ src/algorithms/       — 52 algorithms (optimization/selection)
├─ src/hooks/            — 22 hook files + 213 hookify rules
├─ src/registries/       — 23 registries (type/config stores)
├─ src/schemas/          — 72 Zod action schemas
├─ src/data/             — 67 catalogs (46K tools, 910 machines, holders, grades)
├─ data/milestones/      — 110 milestone envelopes (all complete)
├─ data/roadmap-index.json — roadmap v5.3.0
├─ data/docs/            — MASTER_INDEX, SYSTEM_INVENTORY, DIRECTORY_DIGEST, ENGINE_DIGEST, DSL

DISPATCHERS (66, 1592+ actions)
  Core: MaterialDispatcher, ToolDispatcher, MachineDispatcher, ProcessDispatcher
  CAM: HyperMillDispatcher, MastercamDispatcher, FusionDispatcher, MultiCamDispatcher, camDispatcher
  Analysis: CostDispatcher, QualityDispatcher, WearDispatcher, ForceDispatcher, calcDispatcher
  Planning: JobPlanDispatcher, SetupDispatcher, FixtureDispatcher, StockDispatcher
  Data: CatalogDispatcher, KnowledgeDispatcher, StrategyDispatcher
  New: cncOpsDispatcher, machineSetupDispatcher, vibrationPhysicsDispatcher, mechanicalDesignDispatcher
  See: data/docs/DISPATCHER_DIGEST.md for full list with action counts

ENGINE CATEGORIES
  Cutting: speeds-feeds, tool-selection, wear-prediction, force-model
  Material: material-properties, hardness, machinability, thermal
  Machine: spindle-analysis, axis-limits, power-check, vibration
  Quality: surface-finish, tolerance, GD&T, inspection
  Cost: cycle-time, tool-cost, machine-rate, batch-optimization
  CAM: toolpath-strategy, post-processor, simulation

CATALOGS (src/data/ — 67 files, 46K+ tools, 910 machines)
  machine-profiles-catalog*.ts   — 910 machines (51+180+679) across 48 mfrs
  machine-kinematics-catalog.ts  — 250 machines, 33 mfrs, 132 collision zones
  osg-tool-catalog.ts            — 11,550 tools
  additional-tool-catalog.ts     — 13,257 tools (Flash/MA Ford/Korloy/YG-1/Accupro)
  guhring-tool-catalog.ts        — 3,421 tools
  sandvik-tool-catalog.ts        — 2,418 tools
  haimer-holder-catalog.ts       — 489 holders
  big-daishowa-holders.ts        — 131 holders
  workholding-catalog.ts         — 44 entries
  multi-manufacturer-grades.ts   — 50 grades
  collision-avoidance-data.json  — 41,085 tools

TEST COMMANDS
  npm test                       — full suite (12900+ tests)
  npx vitest run --pool=forks    — backend tests
  npx vitest run src/engines/    — engine tests only
  npx vitest run [file]          — single file
  npm run build                  — TypeScript build check

COMMON PATTERNS
  Engine:     src/engines/[Name]Engine.ts → export class [Name]Engine { calculate() }
  Dispatcher: src/tools/dispatchers/[name]Dispatcher.ts → switch(action) case blocks
  Algorithm:  src/algorithms/[Name]Algorithm.ts → export function optimize[Name](...)
  Registry:   src/registries/[Name]Registry.ts → export const [name]Registry
  Test:       src/__tests__/[name].test.ts → describe("[Name]Engine", () => {...})

SLASH COMMANDS (key ones)
  /status        — instant system overview (this + counts)
  /health        — full 11-check health audit
  /what-changed  — recent git activity + drift check
  /compact       — pre-compaction prep
  /context       — context budget inspector
  /forge         — code generation workflows
  /forge-debug   — bug sweep
  /forge-tests   — test generation
  /milestone     — milestone management
  /pick-task     — get next task from roadmap

TOKEN-SAVING COMMANDS (use these FIRST before exploring)
  /digest-all    — load full system map in ~1100 tokens
  /navigate      — zero-IO file location (topic → directory)
  /code-index    — DSL shortcode lookup (E0001 → path)
  /smart-route   — find most efficient path for any query
  /boot          — ultra-fast session bootstrap (~100 tokens)

STRATEGIES: 433 total (66 base + 177 MultiCam + 256 MultiCamExt + 24 novel)
KNOWLEDGE BASE: 867+ tribal tips (5 CAM systems at 117 parity + 121 controller)
DSL INDEX: 1,865 shortcode mappings (E/D/A/T/C/H/RG/U/M/DOC/SV/R/X)
DOC SCORE: 97/100 | DEP HEALTH: 100/100
```
