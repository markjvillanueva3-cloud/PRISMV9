---
name: wedm-learn
description: Extract Wire EDM knowledge from PDFs, videos, and documents
version: 1.0.0
engines:
  - PDFExtractionEngine
  - VideoLearningEngine
  - TribalKnowledgeEngine
  - WEDMFeedbackCalibrationEngine
  - WEDMNeuralTrainingEngine
actions:
  - wedm_extract_pdf_knowledge
  - wedm_extract_video_knowledge
  - wedm_ingest_tribal_tip
  - wedm_calibration_report
hooks:
  - hook_wedm_knowledge_quality
  - hook_wedm_learning_trigger
triggers:
  - "learn wedm"
  - "wedm pdf"
  - "wedm video"
  - "extract edm knowledge"
---

# /wedm-learn — Wire EDM Knowledge Extraction

Extract and integrate WEDM knowledge from various sources:
- PDF manuals and technical papers
- Video tutorials and training
- Operator notes and tribal knowledge
- Machine documentation

## Usage

```
/wedm-learn <source> [options]
```

## Arguments

- `source` — Path to PDF, video URL, or text description
- `--type` — Source type (pdf|video|manual|tip|paper)
- `--focus` — Knowledge focus (parameters|troubleshooting|technique|all)
- `--machine` — Specific machine context
- `--validate` — Cross-validate against existing knowledge

## Knowledge Types

| Type | Source | Extraction Method |
|------|--------|-------------------|
| `pdf` | Technical PDFs | OCR + NLP parsing |
| `video` | YouTube, local | Frame + transcript analysis |
| `manual` | Machine docs | Structured extraction |
| `tip` | Operator notes | Tribal knowledge format |
| `paper` | Research papers | Academic parsing |

## Extraction Pipeline

1. **Ingest** — Load source material
2. **Parse** — Extract text, images, tables
3. **Classify** — Categorize knowledge type
4. **Validate** — Check against physics/existing data
5. **Format** — Convert to PRISM knowledge format
6. **Index** — Add to searchable knowledge base
7. **Train** — Update neural models if applicable

## Output

```json
{
  "extraction": {
    "source": "Mitsubishi_FA-20S_Manual.pdf",
    "pages_processed": 245,
    "knowledge_items": 47
  },
  "categories": {
    "parameters": 18,
    "troubleshooting": 12,
    "techniques": 9,
    "specifications": 8
  },
  "items": [
    {
      "id": "WEDM-LEARN-001",
      "type": "parameter",
      "content": "E1234 optimal for D2 steel 20-30mm: ON=4.5us, OFF=12us",
      "confidence": 0.92,
      "source_page": 87
    },
    {
      "id": "WEDM-LEARN-002",
      "type": "troubleshooting",
      "content": "Wire break at corners: reduce feed 15-20%, increase flushing",
      "confidence": 0.88,
      "source_page": 142
    }
  ],
  "model_updates": {
    "neural_retrain_triggered": true,
    "tips_added": 12,
    "parameters_refined": 5
  }
}
```

## Examples

```bash
# Learn from PDF manual
/wedm-learn ./manuals/FA-20S-Programming.pdf

# Extract from YouTube video
/wedm-learn "https://youtube.com/watch?v=abc123" --type video

# Add operator tip
/wedm-learn "thick D2 needs extra upper flush above 2 inches" --type tip

# Focus on troubleshooting
/wedm-learn machine_docs.pdf --focus troubleshooting

# Validate against existing
/wedm-learn new_paper.pdf --validate
```

## Knowledge Quality Hook

`hook_wedm_knowledge_quality` validates:
- Physics consistency (Ra bounds, MRR limits)
- No contradictions with verified knowledge
- Source credibility scoring
- Duplicate detection

## Learning Trigger

When high-quality knowledge extracted:
1. `hook_wedm_learning_trigger` fires
2. `WEDMFeedbackCalibrationEngine` updates Bayesian priors
3. `WEDMNeuralTrainingEngine` schedules retraining if threshold met

## Integration

- Feeds `/wedm-troubleshoot` with new tips
- Enriches `/wedm-ai-advisor` neural models
- Updates `/wedm-jm-die` customer patterns

## Leverages

- `PDFExtractionEngine` — PDF parsing and OCR
- `VideoLearningEngine` — Video analysis
- `TribalKnowledgeEngine` (1,100+ tips) — Tip integration
- `WEDMFeedbackCalibrationEngine` (229 LOC) — Bayesian updates
- `WEDMNeuralTrainingEngine` (2,436 LOC) — Model retraining
