# Full Job — Complete Manufacturing Job Pipeline

End-to-end manufacturing pipeline: material identification, tool selection, speed/feed optimization, CNC program generation, setup sheet, cost quote, and quality plan. One command from "I have a part" to "here's everything you need to make it."

## Args:
- Material + operation description (e.g., "7075-T6 pocket 4" deep with Ø1/2 endmill")
- File path to G-code for optimization (e.g., "C:/programs/part123.nc")
- `quote-only`: skip program generation, just quote

## Phase 1: Material & Operation Analysis
1. Parse the input for material, dimensions, features, tolerances
2. `/material-lookup` — resolve ISO group, properties, machinability rating
3. Identify operations needed (roughing, semi-finishing, finishing, drilling, tapping)
4. If drawing/model referenced, extract critical dimensions and GD&T

## Phase 2: Tool Selection
1. `/tool-catalog` — search 46,590 tools for best candidates per operation
2. Consider: material, diameter, flute count, coating, reach, holder compatibility
3. Select primary + backup tool for each operation
4. Check collision data (41,085 tools with collision profiles)

## Phase 3: Speed/Feed Optimization
For each operation + tool combination:
1. Run `ultimateSpeedFeedEngine.calculate()` with full inputs:
   - Material, tool geometry, machine limits, coolant, strategy
   - Include: stability analysis, thermal check, power budget, tool life
2. Present 3 alternatives: conservative / balanced / aggressive
3. Include: forces, deflection, surface finish prediction, cost per part
4. `/spindle-optimize` if chatter risk detected

## Phase 4: CNC Program Generation (skip if `quote-only`)
1. `/program-gen` — assemble complete program with:
   - Safe start block, tool changes, work offsets
   - Optimized speeds/feeds from Phase 3
   - Canned cycles where applicable
   - Coolant control, chip management
2. `/program-validate` — verify:
   - Syntax correctness
   - No rapid into material
   - Power/torque within limits
   - Feed rate consistency

## Phase 5: Setup Sheet
1. `/setup-sheet-generate` — create operator-ready documentation:
   - Fixture/workholding diagram
   - Tool list with offsets, stickout, projected life
   - Speeds/feeds table per operation
   - Critical dimensions and tolerances
   - First-article inspection checklist

## Phase 6: Cost Quote
1. `/material-price` — raw material cost (market-adjusted)
2. `/stock-optimize` — optimal stock size, nesting if applicable
3. `/secondary-ops` — finishing operations (anodize, heat treat, plating)
4. `/quote-job` — complete quote with:
   - Material cost, machining time, setup time
   - Tool cost per part (with regrind economics)
   - Secondary op costs
   - Price breaks (1, 10, 50, 100, 500 pcs)
   - DfM feedback

## Phase 7: Quality Plan
1. `/quality-check` — generate:
   - Process capability prediction (Cp/Cpk) per critical dimension
   - Inspection plan with measurement methods
   - SPC setup for production runs
   - First-article requirements

## Output Summary
```
FULL JOB COMPLETE — [Part Name/Description]
=============================================
Material:    [name] (ISO [group], [hardness])
Operations:  [N] ([list])
Tools:       [N] selected from [N] candidates
Program:     [N] lines, [cycle time] estimated
Setup Sheet: Generated
Quote:       $[X] per part ([N] qty price break)
Quality:     Cp [X] / Cpk [X] on [N] critical dims
Files:       [list of generated files]
```

## Key Engines Used
UltimateSpeedFeedEngine (31 models), CycleTimeEstimatorEngine, GCodeSafetyAnalyzerEngine,
SetupSheetFromGCodeEngine, MaterialDatabaseEngine, ToolCatalogEngine,
MachineProfileEngine, ProcessCapabilityEngine

## Error Handling
- Unknown material: fall back to ISO group estimation, warn user
- No suitable tool found: suggest closest alternatives
- Power exceeded: auto-scale to machine limits, report reduction
- Missing dimensions: ask user for critical inputs before proceeding
