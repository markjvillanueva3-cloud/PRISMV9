# Material Lookup — PRISM Materials Database Query

You are querying the PRISM materials database. This skill provides instant access to alloy properties, compositions, machinability data, and material comparisons across 300+ alloys and 14 selection-engine candidates.

## Args: $ARGUMENTS
- `[alloy-name]`: look up a specific alloy (e.g., `4140`, `304`, `Ti-6Al-4V`, `Inconel 718`)
- `compare [a] [b]`: side-by-side comparison of two alloys
- `category [cat]`: list alloys in a category (carbon, alloy, stainless, aluminum, titanium, nickel, cast-iron, copper, tool-steel)
- `search [property] [operator] [value]`: find alloys matching criteria (e.g., `search uts_annealed > 800`)
- `machinability [alloy]`: detailed machinability report from MaterialSelectionEngine
- `stats`: database coverage statistics
- Empty: show database summary and usage examples

## Data Sources
1. **Physical Properties**: `C:/PRISM/scripts/alloy_physical_properties_db.py` — 300+ alloys, 9 properties each
2. **Compositions**: `C:/PRISM/scripts/alloy_compositions_db.py` — 300+ alloys, element wt% specs
3. **Selection Engine**: `C:/PRISM/mcp-server/src/engines/MaterialSelectionEngine.ts` — 14 built-in alloys with machinability data
4. **Master Registry**: `C:/PRISM/data/materials/MATERIALS_MASTER.json` — orchestration registry

## Step 1: Parse Query
Determine the lookup mode from args. Normalize alloy names:
- Strip "AISI ", "SAE ", "UNS " prefixes for matching
- Handle common aliases: "304 SS" → "304 Stainless", "Ti64" → "Ti-6Al-4V"
- Case-insensitive matching

## Step 2: Execute Query

### Single Alloy Lookup (`/material-lookup 4140`)
1. Search alloy_physical_properties_db.py for matching entry
2. Search alloy_compositions_db.py for composition data
3. Check MaterialSelectionEngine.ts for machinability data (14 alloys only)
4. Present:
```
MATERIAL: AISI 4140 (Chromium-Molybdenum Steel)
================================================
Physical Properties:
  Density:         7.85 g/cm³
  Thermal Cond:    42.6 W/m-K
  Specific Heat:   473 J/kg-K
  Elastic Mod:     205 GPa
  Solidus:         1430°C
  Liquidus:        1495°C
  Yield (annealed): 655 MPa
  UTS (annealed):   900 MPa
  Hardness:        197 BHN

Composition (wt%):
  C: 0.38-0.43 | Mn: 0.75-1.00 | Cr: 0.80-1.10 | Mo: 0.15-0.25
  Si: 0.15-0.35 | P: ≤0.035 | S: ≤0.040

Machinability: [data if available from SelectionEngine]
  ISO Group: P | Speed Factor: 0.85 | Chip: long | Wear: moderate
```

### Comparison (`/material-lookup compare 4140 4340`)
Side-by-side table of all properties with delta column highlighting differences.

### Category (`/material-lookup category stainless`)
List all stainless steel alloys with key properties (UTS, hardness, density).

### Search (`/material-lookup search hardness_bhn > 300`)
Supported properties: density, thermal_cond, specific_heat, elastic_mod, solidus, liquidus, yield_annealed, uts_annealed, hardness_bhn
Operators: `>`, `<`, `>=`, `<=`, `=`, `range [min] [max]`
Return matching alloys sorted by the searched property.

### Stats (`/material-lookup stats`)
```
MATERIALS DATABASE STATS
========================
Physical Properties DB:  [N] alloys (9 properties each)
Compositions DB:         [N] alloys (element wt% specs)
Selection Engine:        14 alloys (full machinability data)
Master Registry:         [N] entries

Categories:
  Carbon Steel:     [N] alloys
  Alloy Steel:      [N] alloys
  Stainless Steel:  [N] alloys
  Aluminum:         [N] alloys
  Titanium:         [N] alloys
  Nickel/Superalloy:[N] alloys
  Cast Iron:        [N] alloys
  Copper:           [N] alloys
  Tool Steel:       [N] alloys

Accuracy: 81.5% subcategory-specific, 83.5% composition match
```

## Step 3: Report
Present results in a clean, scannable format. For numeric values, include units.

## Error Handling
- **Alloy not found**: "No match for '[query]'. Did you mean: [closest matches]?" (fuzzy match on name)
- **Property not available**: "Property [x] not tracked. Available: density, thermal_cond, ..."
- **DB file missing**: "Materials DB not found at expected path. Run /scripts validate to check."
- **Ambiguous name**: If multiple matches (e.g., "304" matches "304 Stainless" and "304L"), list all and ask.

## Chaining
- Material selection: `/material-lookup search yield > 500` → pick alloy → feed to engine calcs
- Quality check: `/material-lookup [alloy]` → verify properties match what engines use
- Comparison: `/material-lookup compare [old] [new]` → justify material substitution
- Pairs with: `/forge-materials` (pipeline), `/scripts` (run accuracy script), `/trace` (trace material usage in engines)
