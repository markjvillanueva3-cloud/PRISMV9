# Hook Profile — Hook Overhead Analyzer

You are profiling the hook system to identify token overhead, find the heaviest hooks, and suggest optimizations. With 9 hook scripts and 46+ hookify rules firing on every tool call, understanding their cost is essential for token efficiency.

## Args: $ARGUMENTS
- Empty: full profile — all hooks and rules
- `scripts`: profile shell hook scripts only
- `rules`: profile hookify rules only
- `heavy`: show only the heaviest hooks (top 5 by estimated token cost)
- `optimize`: full profile + actionable optimization suggestions
- `[hook-name]`: profile a specific hook script or rule

## Step 1: Inventory Hook Scripts
Read `~/.claude/settings.json` and catalog all registered hooks:

For each hook script:
1. Read the script file from `~/.claude/hooks/`
2. Measure: line count, complexity (conditionals, external calls)
3. Identify: what events it handles, what tools it matches
4. Estimate output size: does it produce additionalContext? deny? rewrite?

```
HOOK SCRIPTS
============
Script                    | Event          | Lines | Matches           | Output Type
--------------------------|----------------|-------|-------------------|------------
pretooluse-unified        | PreToolUse     | [N]   | Bash,Write,Edit.. | deny/rewrite
posttooluse-unified       | PostToolUse    | [N]   | Bash,Write,Edit.. | additionalContext
auto-approve              | PermissionReq  | [N]   | *                 | approve
pretooluse-linting        | PreToolUse     | [N]   | Write,Edit        | deny/warn
session-start-unified     | SessionStart   | [N]   | *                 | additionalContext
precompact-save           | PreCompact     | [N]   | *                 | additionalContext
configchange-guard        | ConfigChange   | [N]   | *                 | deny
stop-completion-check     | Stop           | [N]   | *                 | additionalContext
task-completed-chain      | TaskCompleted  | [N]   | *                 | additionalContext
```

## Step 2: Inventory Hookify Rules
Read hookify configuration and catalog all rules:

```
HOOKIFY RULES
=============
Type             | Count | Event              | Avg Output
-----------------|-------|--------------------|----------
block            | [N]   | PreToolUse         | ~50 tokens (deny)
security         | [N]   | PreToolUse         | ~50 tokens (deny)
quality          | [N]   | PostToolUse        | ~100 tokens (warn)
runtime          | [N]   | PreToolUse         | ~50 tokens (deny)
token            | [N]   | PostToolUse        | ~80 tokens (compress)
autofire         | [N]   | UserPromptSubmit   | ~200 tokens (suggest)
```

## Step 3: Estimate Token Overhead
Calculate per-event and per-session overhead:

### Per Tool Call Estimate
For each tool call, estimate which hooks fire and their output:
- **PreToolUse**: pretooluse-unified (always) + pretooluse-linting (Write/Edit only) + hookify block/security/runtime rules
- **PostToolUse**: posttooluse-unified (always) + hookify quality/token rules
- **PermissionRequest**: auto-approve (always)

### Compression Effectiveness
The posttooluse-unified hook has tiered compression:
- 5K threshold: light compression
- 8K threshold: moderate compression
- 10K threshold: heavy compression
- 20K threshold: extreme compression

Estimate: what % of tool outputs hit each tier?

### Per-Session Estimate
```
TOKEN OVERHEAD ESTIMATE
=======================
Per Bash call:        ~[N] tokens (pretooluse check + posttooluse compress)
Per Read call:        ~[N] tokens (pretooluse check + posttooluse compress)
Per Edit/Write call:  ~[N] tokens (pretooluse + linting + posttooluse + quality)
Per session (~100 tool calls): ~[N]K tokens overhead

Breakdown:
  Shell scripts:  ~[N]K tokens/session ([X]%)
  Hookify rules:  ~[N]K tokens/session ([X]%)
  Compression:    SAVES ~[N]K tokens/session (net positive)
  Auto-approve:   ~[N] tokens/session (minimal)
```

## Step 4: Identify Heaviest Hooks
Rank hooks by estimated token cost:

```
HEAVIEST HOOKS (top 5)
======================
Rank | Hook/Rule                  | Est. Tokens/Call | Fires/Session | Total
-----|----------------------------|------------------|---------------|------
  1  | posttooluse-unified        | [N]              | ~[N]          | ~[N]K
  2  | pretooluse-unified         | [N]              | ~[N]          | ~[N]K
  3  | [hookify autofire rules]   | [N]              | ~[N]          | ~[N]K
  4  | [...]                      | [N]              | ~[N]          | ~[N]K
  5  | [...]                      | [N]              | ~[N]          | ~[N]K
```

If args = `heavy`, stop here.

## Step 5: Optimization Suggestions (`/hook-profile optimize`)
Based on the analysis, suggest specific optimizations:

### High-Impact Suggestions
- **Tighten compression**: If most outputs are 3-5K, lower the first tier from 5K to 3K
- **Merge similar rules**: If multiple hookify rules check the same pattern, consolidate
- **Reduce autofire**: If autofire rules fire but are rarely useful, disable or narrow triggers
- **Skip cheap tools**: If hooks fire on Read/Glob but add no value, exclude those tools from matchers

### Low-Impact (skip unless desperate)
- **Remove auto-approve**: Saves ~10 tokens/call but adds friction
- **Disable linting**: Saves ~50 tokens/call but loses quality checks

```
OPTIMIZATION PLAN
=================
Suggestion                              | Est. Savings | Risk
----------------------------------------|-------------|------
[suggestion 1]                          | ~[N]K/sess  | LOW
[suggestion 2]                          | ~[N]K/sess  | LOW
[suggestion 3]                          | ~[N]K/sess  | MEDIUM
Total potential savings:                | ~[N]K/session
```

## Step 6: Report
```
HOOK PROFILE COMPLETE
=====================
Scripts:        [N] active ([N] archived)
Hookify rules:  [N] total ([N] block, [N] security, [N] quality, [N] runtime, [N] token, [N] autofire)
Overhead:       ~[N]K tokens/session
Compression:    SAVES ~[N]K tokens/session
Net impact:     [POSITIVE — compression saves more than hooks cost / NEGATIVE — hooks cost more]
Heaviest:       [hook name] (~[N]K/session)
Suggestions:    [N] optimizations available (run /hook-profile optimize)
```

## Error Handling
- **settings.json not found**: "Hook settings not found. Are hooks configured?"
- **Hook script missing**: "Script registered but file not found: [path]"
- **Hookify not installed**: "Hookify plugin not detected. Only shell hooks profiled."
- **No hooks at all**: "No hooks configured. Nothing to profile."

## Chaining
- Optimization flow: `/context` → identify hooks as heavy → `/hook-profile` → find culprits → `/hook-profile optimize` → apply changes
- After adding hooks: `/forge-hooks` → create hooks → `/hook-profile` → verify overhead is acceptable
- Pairs with: `/context` (overall budget), `/slim` (trim other context), `/forge-hooks` (hook creation)
