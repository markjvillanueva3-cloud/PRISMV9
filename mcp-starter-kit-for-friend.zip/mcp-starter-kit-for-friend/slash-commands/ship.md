# Ship / Complete Unit Checklist

You are completing a PRISM roadmap unit. This is the end-of-unit protocol that ensures nothing is forgotten before marking a unit as done. Execute every section — skip nothing.

## Args: $ARGUMENTS
- Empty: auto-detect from ACTIVE_CLAIM.json
- `[unit-id]`: complete specific unit (e.g., `SYS-MS0-U01`)

## Step 1: Identify the Unit
If no args provided, read `C:/PRISM/state/ACTIVE_CLAIM.json` to get the active unit.
If args provided, use that unit ID.
If neither exists, abort with: "No active claim found. Specify a unit ID: `/ship SYS-MS0-U01`"

Read the milestone envelope from `C:/PRISM/mcp-server/data/milestones/[milestoneId].json`.
Load the specific unit and its exit conditions.

## Step 2: Verify Exit Conditions
For each exit condition listed in the unit:
- Check whether it has been met
- Report pass/fail for each
- If any FAIL: warn but continue (user may override)

## Step 3: Run Build
Run `npm run build` from `C:/PRISM/mcp-server/` and verify:
- 0 new TypeScript errors introduced
- Build completes successfully

## Step 4: Run Tests (if applicable)
If tests exist for the changed files:
- Run `npm test` or relevant test subset
- Report pass/fail count

## Step 4B: Quality Gate
Run `/verify-loop test` — build + targeted test run on changed files in one command.
Then run `/de-sloppify staged` — post-generation polish on staged files (import order, dead code, naming).
Both must complete before commit. For deep analysis, use `/forge-audit` or `/forge-types`.

## Step 5: Auto-Registration Check
For any new files created during this unit:

**A. New Engine?** Check if any new `.ts` files were added under `src/engines/`:
- Verify it's listed in MASTER_INDEX_COMPACT.md engine inventory
- Verify it's wired to a dispatcher action

**B. New Dispatcher?** Check if any new dispatcher was added under `src/tools/dispatchers/`:
- Verify it's registered in `dispatchers/index.ts`
- Verify actions are listed in MASTER_INDEX_COMPACT.md

**C. New Registry Data?** Check for new data files:
- Verify the registry loader can find them

**D. New Algorithm?** Check `src/algorithms/`:
- Verify it's registered in AlgorithmRegistry

## Step 6: Update Milestone Envelope
Update the unit's status in the envelope JSON:
```json
{ "status": "complete" }
```
If ALL units in the milestone are now complete, also update the milestone status to "complete".

## Step 7: Update Roadmap Index
Read `C:/PRISM/mcp-server/data/roadmap-index.json` and update:
- The milestone's `completed_units` count
- If milestone complete: set `"status": "complete"` and increment `completed_milestones`
- Bump the patch version

## Step 8: Release Claim
Delete the claim directory: `C:/PRISM/mcp-server/data/claims/[milestoneId]/[unitId]/`
Delete `C:/PRISM/state/ACTIVE_CLAIM.json`

## Step 9: Update Position Tracker
Update `C:/PRISM/state/CURRENT_POSITION.md`:
- Increment completion counts
- Add this unit to the completed list
- Update "last session" notes

## Step 10: Persist Key Findings
If any significant discoveries, fixes, or patterns were learned during this unit:
1. Use `/remember` protocol to save them (deduplicated, compressed, correctly routed)
2. Candidates: new fix patterns, updated counts, architecture decisions, safety findings
3. Skip if nothing noteworthy was learned (don't force memories)

## Step 11: Summary Report
```
SHIP COMPLETE
=============
Unit:       [unit-id] — [title]
Milestone:  [milestone-id] — [title] ([X]/[Y] units done)
Exit Conds: [N]/[N] passed
Build:      [pass/fail]
Tests:      [N passed, N failed / not applicable]
Auto-Reg:   [N items verified / nothing new]
Envelope:   Updated
Index:      Updated (v[X.Y.Z])
Claim:      Released

Next: /pick-task to claim your next unit
       /remember [key finding] to persist important discoveries
```
