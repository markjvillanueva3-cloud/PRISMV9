# Batch Check — Analyze tool calls for batching opportunities

Review recent tool call patterns and suggest optimizations.

## Usage
- `/batch-check` — analyze last 10 tool calls
- `/batch-check stats` — show call frequency stats
- `/batch-check summary` — compact opportunity summary

## Steps
1. Call toolCallBatchEngine.analyze() for pattern detection
2. Display opportunities with estimated savings
3. If "stats" → call getStats() and show tool distribution + parallel ratio
4. If "summary" → call getSummary() for compact output
