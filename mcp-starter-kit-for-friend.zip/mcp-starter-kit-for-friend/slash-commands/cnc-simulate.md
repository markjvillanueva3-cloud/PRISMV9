# CNC Simulate — Vericut-Class G-Code Simulation

Run full CNC simulation pipeline on G-code: collision detection, cutting physics, tool life prediction, cost estimation, safety scoring.

## Args: $ARGUMENTS
- Empty: prompt for G-code input
- G-code file path: simulate that file
- `physics <Vc> <f> <ap> <ae> <D> <L> <material>`: quick physics check for one cut
- `predict <material>`: predict tool life and cost for a program

## Steps

1. Parse G-code blocks from input
2. Call `cncSimulationPipelineEngine.simulate()` with machine/tool/material params
3. Call `simulationReportEngine.generateReport()` on the result
4. Display: collision report, physics summary, cost breakdown, safety scorecard

## Output Format

```
CNC SIMULATION REPORT
=====================
Program: [N] blocks | Machine: [brand model] | Material: [material]

SAFETY: [SAFE/CAUTION/WARNING/DANGER] ([score]%)

Collisions: [N] | Axis Violations: [N]
Max Force: [N]N | Max Temp: [N]C | Max Deflection: [N]um

Cycle Time: [N]s (cutting [N]% | rapid [N]% | idle [N]%)
Tool Life: [N]% consumed | Changes needed: [N]

Cost: $[total] (machine $[M] + tool $[T] + energy $[E])
Cost/min: $[rate]

RECOMMENDATIONS:
- [rec1]
- [rec2]
```

## What Makes This Different from Vericut

PRISM simulates 8 layers vs Vericut's 2:
1. G-code parsing + axis limits (same as Vericut)
2. Collision detection (same as Vericut)
3. Kienzle cutting force per block (PRISM only)
4. Loewen-Shaw thermal analysis (PRISM only)
5. Tool deflection prediction (PRISM only)
6. Taylor tool life tracking (PRISM only)
7. Cost-per-part computation (PRISM only)
8. Auto-fix suggestions with exact values (PRISM only)
