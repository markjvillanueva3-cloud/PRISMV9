# Unwired Review — Structured Unwired Engine Triage

Systematically triage the 63+ unwired engines in PRISM — engines that exist on disk but aren't exported from index.ts or reachable from any dispatcher. Score, rank, and generate wiring stubs for the best candidates.

## Args: $ARGUMENTS
- Empty: full triage report with rankings
- `list`: ranked triage table only (no wiring stubs)
- `[engine-name]`: inspect one engine and generate its wiring stub
- `domain [name]`: triage engines in a specific domain (cutting, thermal, safety, etc.)
- `top [N]`: generate wiring stubs for top N candidates (default 3)
- `wire [engine-name]`: actually wire the engine (add export + dispatcher action + test)


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (systematic scan + scoring, optional code generation)
2. Domain: TypeScript Engineering + Manufacturing Process
3. Roles: Senior TypeScript Engineer + Systems Architect
4. Model: SONNET (OPUS for `wire` mode)
5. Effort: MEDIUM (HIGH for `wire` mode)

## Phase 2: Inventory Unwired Engines

1. Glob `C:/PRISM/mcp-server/src/engines/*.ts` — all engine files (PREFER: use ENGINE_DIGEST.md instead of Glob)
2. Read `C:/PRISM/mcp-server/src/engines/index.ts` — extract all exported engines
3. Diff: files on disk minus exported = unwired engines
4. For each unwired engine, quick-read first 30 lines to extract:
   - Class name and exported singleton (if any)
   - `calculate()` or `compute()` method signature
   - Input/output types
   - Line count (proxy for implementation completeness)
   - Domain (from filename and imports)

## Phase 3: Score Each Engine

Score on 4 dimensions (1-5 each):

| Dimension | 5 (Best) | 1 (Worst) |
|-----------|----------|-----------|
| **Domain Need** | Thin domain, high user demand | Saturated domain |
| **Completeness** | Full implementation, AtomicValue returns | Stub/placeholder |
| **Dispatcher Fit** | Clear dispatcher target, action name obvious | No natural home |
| **Test Existence** | Has test file | No tests anywhere |

**Priority Score** = DomainNeed×3 + Completeness×2 + DispatcherFit×2 + TestExistence×1

## Phase 4: Output Triage Report

```
UNWIRED ENGINE TRIAGE
======================
Total on disk:    [N] engine files
Exported/wired:   [N]
Unwired:          [N]

RANK | Engine                     | Domain    | Lines | Score | Recommendation
-----|----------------------------|-----------|-------|-------|---------------
  1  | TroubleshootingEngine      | Diagnosis | 315   | 38    | WIRE NOW
  2  | DigitalTwinEngine          | Digital   | 311   | 35    | WIRE NOW
  3  | ProcessPlanEngine          | Planning  | 363   | 34    | WIRE NOW
  4  | FixtureDesignEngine        | Workhold  | 334   | 32    | WIRE SOON
  5  | HarmonicAnalysisEngine     | Vibration | 234   | 30    | WIRE SOON
  ...
  N  | [placeholder engine]       | Unknown   | 15    | 8     | DEPRECATE

Domain Summary:
  Diagnosis:  [N] unwired ([names])
  Planning:   [N] unwired ([names])
  Vibration:  [N] unwired ([names])
  ...
```

## Phase 5: Generate Wiring Stubs (if not `list` mode)

For each top candidate, generate ready-to-paste code:

### 5A: index.ts Export
```typescript
export {
  engineSingleton,
  EngineName,
  type InputType,
  type ResultType,
} from "./EngineName.js";
```

### 5B: Dispatcher Action Case
```typescript
case "action_name": {
  result = engineSingleton.calculate({
    param1: params.param1 || params.alias1 || default1,
    param2: params.param2 || params.alias2,
    // ... normalized from dispatcher params
  });
  break;
}
```

### 5C: Extract Key Values
```typescript
case "action_name":
  return { key1: result.field1?.value, key2: result.field2?.value, safe: result.is_safe };
```

### 5D: Suggested Test
```typescript
it("action_name returns valid result", () => {
  const r = engine.calculate({ /* minimal valid input */ });
  expect(r).toHaveProperty("key_output");
  expect(r.key_output.value).toBeGreaterThan(0);
});
```

## Phase 6: Wire Mode (if `wire [engine-name]`)

Actually perform the wiring:
1. Add export to `index.ts`
2. Add import + case handler to appropriate dispatcher
3. Add extract key values entry
4. Write 3-5 tests
5. Run `npm run build` — must pass
6. Run `npm test` — must pass
7. Update MASTER_INDEX_COMPACT.md (move from unwired to exported)
8. Commit: `feat(wiring): wire [EngineName] to [dispatcher] [UNWIRED-REVIEW]`

## Error Handling
- Engine file has no `calculate()` method: mark as NEEDS REFACTOR
- Engine returns raw numbers (not AtomicValue): mark as NEEDS DSL FIX
- Engine depends on missing imports: mark as BROKEN
- Multiple engines serve same purpose: mark duplicates for DEPRECATE review

## Safety Rails
- `list` mode is read-only — never modifies files
- `wire` mode runs build + tests before committing
- Never auto-deprecate — only recommend, let user decide
- Preserve all existing functionality when wiring
