# Release Ready — Pre-Release Validation Suite

Complete pre-release verification: full test suite, speed/feed gauntlet, code quality review, audit scan, drift check, type coverage, health check, and documentation sync. Proves the system is ship-ready.

## Args:
- Empty: full validation (all phases)
- `quick`: build + test + critical checks only
- `version=<X.Y.Z>`: tag with version after passing

## Phase 1: Full Test Suite
1. `/test` — run all tests
   - All backend tests (~9680)
   - All web tests (~76)
   - All E2E tests (~11)
   - All cad-engine tests (~2085)
   - Zero failures required
   - Report any new tests since last release

## Phase 2: Speed/Feed Gauntlet
1. `/test-speed-feed` — run all 401 speed/feed tests
   - Core: 76 tests (original)
   - R1 Breadth: 206 tests (materials, operations, physics, statistics)
   - R2 Depth: 119 tests (determinism, performance, workflows, regressions)
   - All must pass
   - Performance: single calc <50ms, full calc <50ms, 100 calcs <2s

## Phase 3: Code Quality Review
1. `/scrutinize` — scan for quality issues
   - No TODO/FIXME in production code
   - No placeholder implementations
   - No `any` types in new code
   - No magic numbers without constants
   - No commented-out code blocks

## Phase 4: System Audit
1. `/forge-audit` — comprehensive quality scan
   - CRITICAL findings: 0 (blocks release)
   - MAJOR findings: document and plan
   - MINOR findings: acceptable

## Phase 5: Registry Drift Check
1. `/forge-drift` — verify all counts match
   - Engine files vs MASTER_INDEX
   - Algorithm count vs registry
   - Hook count vs documentation
   - Test count vs reported numbers

## Phase 6: Type Coverage
1. `/forge-types` — TypeScript analysis
   - `any` count trend (must not increase)
   - New code fully typed
   - No implicit `any` in public APIs

## Phase 7: System Health
1. `/health` — full health check
   - Build: PASS (0 errors, 0 warnings)
   - Dependencies: no security vulnerabilities
   - Bundle size: within limits

## Phase 8: Live Metrics
1. `/counts` — verify all metrics
   - Cross-reference against MEMORY.md claims
   - Flag any discrepancies

## Phase 9: Documentation Sync
1. `/update-all-docs` — sync all documentation
   - MASTER_INDEX_COMPACT.md current
   - SYSTEM_INVENTORY.md current
   - MEMORY.md counts accurate
   - SLASH_COMMANDS.md complete
   - All engine JSDoc present

## Output Summary
```
RELEASE READY — PRISM v[X.Y.Z]
=================================
PHASE         | STATUS  | DETAILS
──────────────|─────────|──────────────────
Tests         | [P/F]   | [N] passed / [N] failed
Speed/Feed    | [P/F]   | 401/401 in [N]ms
Code Quality  | [P/F]   | [N] CRIT / [N] MAJ / [N] MIN
Audit         | [P/F]   | [N] findings
Drift         | [P/F]   | [N] mismatches
Types         | [P/F]   | [N] any types
Health        | [P/F]   | Build OK, Deps OK
Metrics       | [P/F]   | All counts verified
Docs          | [P/F]   | [N] files updated

VERDICT: [SHIP IT / BLOCKED]

System Snapshot:
  Engines: [N] | Algorithms: [N] | Hooks: [N]
  Tests: [N]   | Formulas: [N]   | Actions: [N]
  Materials: [N] | Tools: [N]    | Machines: [N]
  Commands: [N] | Tips: [N]

[If BLOCKED: list of blocking issues]
[If SHIP IT: ready to tag and release]
```

## Key Engines Used
All test and diagnostic infrastructure. No manufacturing engines directly —
this validates the entire system end-to-end.
