# Boot — Ultra-Fast Session Bootstrap

Minimal-cost session initialization. Loads ONLY what's needed in < 5 seconds, < 50 tokens output.

## What to do:
1. Read `C:/PRISM/mcp-server/data/quick-ref.json` (35 lines, ~100 tokens)
2. Output the `compact` field as the session header
3. Output the `recent_commits` array (last 5 commits)
4. Done. No other files needed.

## Output format:
```
BOOT: [compact field from quick-ref.json]
Recent: [last 3 commits, one per line]
Ready.
```

## Token-Efficient Alternatives (if quick-ref.json is stale):
- `/digest-all` loads full system map in ~1100 tokens (DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX)
- `/navigate <topic>` does zero-IO file location via FileSystemNavigatorEngine
- `/code-index <shortcode>` resolves E0001→path instantly (1,865 entries)

## What NOT to do:
- Do NOT read SYSTEM_INVENTORY.md (2000+ tokens)
- Do NOT read MEMORY.md (loaded automatically)
- Do NOT read PATH_INDEX.md (unless needed for a task)
- Do NOT run any filesystem counts (quick-ref.json has them)
- Do NOT run git commands (quick-ref.json has recent commits)
- Do NOT run Glob/Grep to explore — use `/navigate` or `/digest-all` instead
