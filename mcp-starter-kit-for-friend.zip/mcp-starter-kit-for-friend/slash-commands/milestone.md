# Milestone — Quick Milestone Viewer

You are showing a focused, at-a-glance view of a specific PRISM milestone. This is the fast-path alternative to `/rgs` — no roadmap operations, no claims, just a clear picture of where a milestone stands right now.

## Args: $ARGUMENTS
- `[milestone-id]`: show a specific milestone (e.g., `milestone SYS-MS6`)
- `[track]`: show all milestones in a track (e.g., `milestone SYS`, `milestone QA`)
- `next`: show the most likely next milestone to work on (incomplete, unblocked, highest priority)
- `progress`: show overall progress summary across all tracks
- Empty: same as `next`

## Step 1: Load Data
Read `C:/PRISM/mcp-server/data/roadmap-index.json` for the milestone registry.
If a specific milestone is requested, read its envelope from `C:/PRISM/mcp-server/data/milestones/[milestone-id].json`.
Check `C:/PRISM/state/ACTIVE_CLAIM.json` for any active claim.

## Step 2: Display — Single Milestone (`/milestone SYS-MS6`)
```
MILESTONE: SYS-MS6 — Dispatcher Parameter Schemas
==================================================
Track:    SYS (Systems)
Status:   INCOMPLETE
Priority: P1
Units:    [X]/[Y] complete

Units:
  [x] U01 — [title] (complete)
  [ ] U02 — [title] (pending)
  [ ] U03 — [title] (pending — blocked by U02)
  ...

Blocked By:  [list of prerequisite milestones, or NONE]
Blocks:      [list of milestones waiting on this one, or NONE]
Active Claim: [unit-id if claimed, or NONE]

Estimated Scope:
  Files likely touched: [list key source dirs/files]
  Related tests:        [list test files]
  Risk level:           [LOW/MEDIUM/HIGH based on blast radius]

Quick Actions:
  /pick-task        — claim a unit from this milestone
  /scope SYS-MS6   — analyze change impact before starting
  /trace [component] — check wiring for related components
```

## Step 3: Display — Track View (`/milestone SYS`)
```
TRACK: SYS — Systems
=====================
Milestones: [N] total, [M] complete, [K] remaining

  [x] SYS-MS0 — Hook/Context Optimization (COMPLETE)
  [x] SYS-MS4 — Engine Wiring Audit (COMPLETE)
  [x] SYS-MS5 — MASTER_INDEX Regen (COMPLETE)
  [x] SYS-MS7 — Stub/Fallback Remediation (COMPLETE)
  [ ] SYS-MS1 — Mega-Dispatcher Decomposition (0/[Y] units)
  [ ] SYS-MS2 — Test Coverage (0/[Y] units)
  [ ] SYS-MS3 — Automation (0/[Y] units)
  [ ] SYS-MS6 — Dispatcher Parameter Schemas (0/[Y] units)

Recommended Next: SYS-MS6 (P1, no blockers)
```

## Step 4: Display — Progress View (`/milestone progress`)
```
PRISM PROGRESS
==============
Overall: [M]/[N] milestones complete ([X]%)

By Track:
  S  (Setup):        [M]/[N] [=========>  ] [X]%
  L  (Layers):       [M]/[N] [==========] 100%
  QA (Quality):      [M]/[N] [==========] 100%
  REM (Remediation): [M]/[N] [==========] 100%
  SYS (Systems):     [M]/[N] [=====>     ] [X]%
  CC (CAD/CAM):      [M]/[N] [==========] 100%

Open Findings: [N] CRITICAL, [N] MAJOR
Active Claim:  [unit or NONE]
Test Suite:    [N] passing, [N] failing

Recommended: /milestone [next-milestone-id]
```

## Step 5: Display — Next View (`/milestone next` or `/milestone`)
Determine the best next milestone:
1. Filter to incomplete milestones
2. Exclude milestones blocked by incomplete prerequisites
3. Sort by priority (P0 > P1 > P2)
4. If tied, prefer milestones in actively worked tracks
5. Display the top candidate using the single-milestone format from Step 2

## Error Handling
- **Milestone not found**: "No milestone matching '[id]'. Available: [list ids]. Try `/milestone progress` for overview."
- **Track not found**: "Unknown track '[track]'. Available tracks: S, L, QA, REM, SYS, CC"
- **Empty roadmap**: "No milestones found. Check `mcp-server/data/roadmap-index.json` exists."
- **Envelope missing**: "Milestone [id] is in the index but has no envelope file. Run `/sync` to detect drift."

## Chaining
- From `/milestone`: → `/pick-task` to claim a unit, → `/scope` to analyze impact
- Fed by: `/ship` (updates milestone status), `/sync` (fixes drift)
- Quick context: call at session start after `/startup` to orient
