# Action Help — Quick parameter lookup for any dispatcher action

Look up what parameters an action expects without reading dispatcher source.

## Usage
- `/action-help material_lookup` — show params for material_lookup
- `/action-help strategy` — search all actions matching "strategy"

## Steps
1. Parse $ARGUMENTS for action name or search query
2. Try actionSchemaCacheEngine.getSchema(name) for exact match
3. If no exact match, use actionSchemaCacheEngine.searchSchemas(query)
4. Display: action name, dispatcher, parameters, signature

## Output Format
```
ACTION: [name]
DISPATCHER: [dispatcher]
PARAMS: [param1, param2, ...]
SIGNATURE: action(param1, param2)
```
