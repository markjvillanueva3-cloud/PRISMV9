# Pressure — Context Window Pressure Monitor

Check context window utilization and predict when compaction is needed.

## Steps
1. Estimate current context usage from conversation length
2. Calculate burn rate from recent token accumulation
3. Predict time until compaction threshold (85%)

4. Output compact status:
```
CONTEXT PRESSURE
================
Status: [GREEN/YELLOW/ORANGE/RED]
Usage: ~[N]K / 200K ([pct]%)
Burn rate: ~[N]K tokens/min
Time to compact: ~[N] min
Time to full: ~[N] min

Recommendation: [action]
```

5. Recommendations by tier:
   - GREEN (<50%): Normal operation
   - YELLOW (50-70%): Use /slim, avoid large reads
   - ORANGE (70-85%): Run /compact soon, use Grep over Read
   - RED (85%+): Run /compact NOW or /handoff

6. Keep output under 200 tokens.
