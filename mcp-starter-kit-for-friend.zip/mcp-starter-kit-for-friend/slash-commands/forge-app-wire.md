# Forge App Wire — PRISM App UI Full Feature Wiring Pipeline

You are running an exhaustive UI-to-backend integration wiring pipeline across the entire PRISM web application. This command audits every backend route, API endpoint, MCP tool, and engine — then ensures every capability has a corresponding UI component, API client function, TypeScript type, state management context, and route. The goal: when the app UI ships, every PRISM feature is seamlessly accessible.

## Args: $ARGUMENTS
- Empty: full pipeline — audit → map → wire → build → verify (all features)
- `audit`: Phase 1-2 only — produce wiring gap report without modifications
- `[feature]`: focus on a specific feature (e.g., `orchestration`, `compliance`, `telemetry`)
- `routes`: audit and wire missing Express route modules only
- `pages`: create stub pages for all unwired features
- `api`: audit and generate missing API client functions only
- `types`: audit and generate missing TypeScript request/response types
- `components`: create missing UI components for wired features
- `quick`: count-level gap report only

## EXHAUSTIVE WIRING LAW (HARD RULE)
- **Every backend route MUST have a corresponding API client function.**
- **Every API client function MUST have TypeScript request/response types.**
- **Every user-facing feature MUST have a page/route in the React app.**
- **Every page MUST connect to its backend via the API client layer (never direct fetch).**
- **Every data flow MUST pass through a context/hook for state management.**
- "Fully wired" claims REQUIRE citing: route file, API client, type file, component, context/hook.
- Completeness > Speed. An unwired feature is invisible to users. A missing type is a runtime crash.

## Phase 0: Bootstrap
1. Load system map via `/digest-all` (~1100 tokens)
2. Read MEMORY.md for current app state
3. Read `C:/PRISM/web/src/App.tsx` for current route definitions
4. Read `C:/PRISM/mcp-server/src/routes/index.ts` for backend route registry

Output bootstrap card:
```
FORGE APP-WIRE INITIALIZED
============================
Mode:           [full/audit/routes/pages/api/types/components]
Backend Routes: [N] modules ([N] endpoints)
Frontend Pages: [N] pages ([N] sub-routes)
API Clients:    [N] files ([N] functions)
Type Files:     [N] files
Contexts:       [N] providers
Target:         100% feature coverage, 100% type safety
```

## Phase 1: Full App Wiring Audit

### 1A: Backend Route Inventory
Scan `C:/PRISM/mcp-server/src/routes/`:
- Glob all `*.ts` route files
- For each: count endpoints (router.get/post/put/delete/patch)
- Record: route prefix, endpoint count, which MCP tools it calls (callTool references)
- Classify: USER_FACING (needs UI), INFRASTRUCTURE (internal), ADMIN (admin panel)

### 1B: Frontend Page Inventory
Scan `C:/PRISM/web/src/`:
- Read `App.tsx` for all route definitions (React Router)
- For each page: list sub-routes, lazy-load status, context providers
- Scan `src/pages/` for all page components
- Scan `src/components/` for feature-specific component directories

### 1C: API Client Inventory
Scan `C:/PRISM/web/src/api/`:
- For each API client file: list all exported functions
- For each function: extract endpoint URL, HTTP method, request/response types
- Cross-reference against backend routes

### 1D: Type Inventory
Scan `C:/PRISM/web/src/types/`:
- For each type file: list all exported interfaces/types
- Cross-reference against API client function signatures
- Flag: `any` usage, missing response types, untyped request bodies

### 1E: State Management Inventory
Scan `C:/PRISM/web/src/contexts/` and `src/hooks/`:
- List all context providers and their state shape
- List all custom hooks and what API functions they call
- Cross-reference: which features have context vs raw useState

### 1F: Cross-Layer Gap Matrix
Build the definitive wiring matrix:

| Feature | Backend Route | Endpoints | API Client | Types | Page | Context/Hook | Status |
|---------|--------------|-----------|------------|-------|------|-------------|--------|
| SFC | sfc.ts | 7 | sfc.ts | sfc.ts | SfcCalculatorPage | useSfc | COMPLETE |
| PPG | ppg.ts | 8 | ppg.ts | ppg.ts | PpgPage | usePpg | COMPLETE |
| Learning | learning.ts | 10 | learning.ts | learning.ts | LearningDashboard | LearningContext | COMPLETE |
| Quality | quality.ts | 4 | quality.ts | quality.ts | QualityPage | — | COMPLETE |
| ERP | erp.ts | 10 | erp.ts | erp.ts | ErpDashboard | ErpContext | COMPLETE |
| CAM | cam.ts | 4 | cam.ts | — | CamStrategyPage | — | PARTIAL |
| Cost | cost.ts | 4 | cost.ts | — | CostEstimatorPage | — | COMPLETE |
| Data | data.ts | 7 | data.ts | — | DataManagementPage | — | COMPLETE |
| Safety | safety.ts | 4 | safety.ts | — | SafetyDashboardPage | — | COMPLETE |
| Auth | auth.ts | 6 | auth.ts | — | LoginPage | — | COMPLETE |
| **Orchestration** | orchestration.ts | 26 | **MISSING** | **MISSING** | **MISSING** | **MISSING** | **NONE** |
| **Session** | session.ts | 32 | **MISSING** | **MISSING** | **MISSING** | **MISSING** | **NONE** |
| **Compliance** | compliance.ts | 8 | **MISSING** | **MISSING** | **MISSING** | **MISSING** | **NONE** |
| **Telemetry** | telemetry.ts | 7 | **MISSING** | **MISSING** | **MISSING** | **MISSING** | **NONE** |
| **Threads** | threads.ts | 12 | **MISSING** | **MISSING** | **MISSING** | **MISSING** | **NONE** |
| **Admin** | admin.ts | 6 | **MISSING** | **MISSING** | **MISSING** | **MISSING** | **NONE** |
| **Validate** | validate.ts | 7 | — (internal) | — | — | — | INFRA |
| **Dev** | dev.ts | 9 | — (internal) | — | — | — | INFRA |

### 1G: MCP Tool → UI Mapping
For each MCP tool registered in `src/index.ts`:
- Which route module(s) call this tool?
- Which UI page(s) can trigger this tool?
- Flag tools with no UI path (backend-only capabilities)

Output:
```
PHASE 1: APP WIRING AUDIT
===========================
Backend Routes:  [N] modules / [N] endpoints
Frontend Pages:  [N] pages / [N] sub-routes
API Clients:     [N] files / [N] functions
Type Files:      [N] files / [N] interfaces

WIRING STATUS:
  COMPLETE:      [N] features (full stack wired)
  PARTIAL:       [N] features (some layers missing)
  NONE:          [N] features (backend only, no UI)
  INFRA:         [N] modules (internal, no UI needed)

UNWIRED USER-FACING FEATURES:
  1. Orchestration — 26 endpoints, 0 UI components
  2. Compliance — 8 endpoints, 0 UI components
  3. Telemetry — 7 endpoints, 0 UI components
  4. Admin — 6 endpoints, 0 UI components
  5. Threads — 12 endpoints, 0 UI components
  ...

TYPE GAPS:
  [N] API functions with `any` return type
  [N] request bodies without interface
  [N] response shapes untyped
```

## Phase 2: Wiring Plan Generation

### 2A: Feature Priority Matrix
Rank unwired features by user impact:
| Priority | Criteria |
|----------|----------|
| P0 | Core user features with complete backend (Orchestration, Compliance) |
| P1 | Admin/monitoring features (Telemetry, Admin panel) |
| P2 | Type safety gaps in existing features (CAM, Cost, Data missing types) |
| P3 | State management gaps (features without context/hooks) |
| P4 | Component quality (missing loading states, error handling, responsive design) |

### 2B: Wiring Layers Per Feature
For each unwired feature, define the full wiring stack:
```
1. Types        → src/types/{feature}.ts          (request/response interfaces)
2. API Client   → src/api/{feature}.ts            (fetch functions)
3. Context/Hook → src/contexts/{Feature}Context.tsx (state management)
4. Components   → src/components/{feature}/        (UI components)
5. Page         → src/pages/{Feature}Page.tsx      (page component)
6. Route        → App.tsx                          (lazy-loaded route)
7. Navigation   → Layout sidebar/nav              (menu entry)
```

### 2C: Component Design Per Feature
For each P0/P1 feature, design the UI:

**Orchestration Page** (`/orchestration`):
- WorkflowBuilder — visual multi-step workflow editor
- WorkflowList — list/search existing workflows
- WorkflowRunner — execute with live progress
- WorkflowHistory — execution history with logs
- ChainViewer — engine chain visualization

**Compliance Dashboard** (`/compliance`):
- StandardsTracker — ISO/ASME/DIN compliance status
- AuditTrail — chronological audit log with filters
- CertificationManager — certification status tracking
- DeviationReports — non-conformance reporting
- RegulatoryScanner — automated compliance checks

**Telemetry Dashboard** (`/telemetry`):
- SystemMetrics — real-time system KPIs (Recharts)
- UsageAnalytics — feature usage heatmap
- PerformanceMonitor — API latency, throughput graphs
- CostTracker — token/compute cost tracking
- AlertManager — alert configuration and history

**Admin Panel** (`/admin`):
- SystemStatus — health checks, build info, uptime
- UserManagement — user list, roles, permissions
- ConfigEditor — system configuration
- CacheManager — cache stats, purge controls
- LogViewer — structured log browser

**Thread Manager** (`/threads`):
- ThreadList — active/completed threads
- ThreadDetail — step-by-step execution view
- ParallelView — concurrent thread visualization
- ResourceMonitor — thread resource usage

Output batch plan for user approval.

## Phase 3: Execute Wiring

### 3A: Generate TypeScript Types
For each unwired feature:
1. Read backend route file → extract request/response shapes
2. Read MCP tool schemas → extract action parameter types
3. Generate comprehensive type file:
   ```typescript
   // src/types/{feature}.ts
   export interface {Feature}Request { ... }
   export interface {Feature}Response { ... }
   export interface {Feature}ListItem { ... }
   export interface {Feature}Config { ... }
   ```
4. Export all types from a barrel `src/types/index.ts`

### 3B: Generate API Client Functions
For each unwired feature:
1. Read backend route → extract all endpoints with methods
2. Generate API client file following existing pattern (see `src/api/sfc.ts`):
   ```typescript
   // src/api/{feature}.ts
   import { apiClient } from './client';
   import type { {Feature}Request, {Feature}Response } from '../types/{feature}';

   export async function getFeatureData(params: {Feature}Request): Promise<{Feature}Response> {
     return apiClient.post('/api/v1/{feature}/action', params);
   }
   ```
3. Export from `src/api/index.ts` barrel

### 3C: Generate Context/Hook
For features with complex state:
1. Create context provider following existing pattern (see `LearningContext.tsx`):
   ```typescript
   // src/contexts/{Feature}Context.tsx
   const {Feature}Context = createContext<{Feature}State | null>(null);
   export function {Feature}Provider({ children }) { ... }
   export function use{Feature}() { return useContext({Feature}Context); }
   ```
2. Include: state shape, actions, localStorage persistence, autosave

For simpler features:
1. Create custom hook:
   ```typescript
   // src/hooks/use{Feature}.ts
   export function use{Feature}() {
     const [data, setData] = useState<{Feature}Response | null>(null);
     const [loading, setLoading] = useState(false);
     // ... fetch, error handling, caching
   }
   ```

### 3D: Generate Page Components
For each unwired feature:
1. Create page component following existing patterns:
   ```typescript
   // src/pages/{Feature}Page.tsx
   export default function {Feature}Page() {
     return (
       <{Feature}Provider>
         <div className="...">
           <h1>{Feature}</h1>
           {/* Tab layout or dashboard grid */}
         </div>
       </{Feature}Provider>
     );
   }
   ```
2. Include: loading states (Spinner), error boundaries, responsive layout
3. Use existing UI components (Card, Button, Table, Tabs, Badge, etc.)
4. Follow Tailwind patterns from existing pages

### 3E: Generate Sub-Components
For each page, create feature-specific components:
1. Create directory `src/components/{feature}/`
2. Build each component identified in Phase 2C
3. Wire to API client via context/hooks
4. Include: loading skeleton, empty state, error state

### 3F: Wire Routes
1. Add lazy imports to `App.tsx`:
   ```typescript
   const {Feature}Page = lazy(() => import('./pages/{Feature}Page'));
   ```
2. Add route definitions:
   ```typescript
   <Route path="/{feature}" element={
     <Suspense fallback={<PageLoader />}>
       <{Feature}Page />
     </Suspense>
   } />
   ```
3. Add sub-routes for nested features

### 3G: Wire Navigation
1. Find the layout/sidebar/navigation component
2. Add menu entries for each new page:
   - Icon (from existing icon set or Heroicons)
   - Label
   - Route path
   - Optional badge (e.g., alert count for Telemetry)

**Build gate after each feature wiring**

## Phase 4: Type Safety Hardening

### 4A: Fix Existing Type Gaps
For features marked COMPLETE but with type issues:
1. Add missing response types for API functions using `any`
2. Replace untyped request bodies with interfaces
3. Add proper generics to API client base functions

### 4B: Validate End-to-End Type Chain
For every feature:
```
Backend handler return type ← matches → API response type
API request param type      ← matches → Component prop type
Context state shape         ← matches → Component consumed type
```
Flag any break in the type chain.

### 4C: Add Zod Runtime Validation (Client-Side)
For critical features (SFC, PPG, Quality):
1. Add Zod schemas for form validation
2. Validate before API call (not just server-side)
3. Show inline validation errors in UI

## Phase 5: Integration Verification

### 5A: Build Gate
```bash
cd /c/PRISM/web && npm run build
```
Must: 0 TypeScript errors, 0 missing imports, all lazy loads resolve.

### 5B: Route Verification
For each new route:
1. Verify lazy-load import path is correct
2. Verify Suspense fallback renders
3. Verify no circular dependencies

### 5C: API Client Verification
For each new API client function:
1. Verify endpoint URL matches backend route
2. Verify HTTP method matches
3. Verify request/response types align

### 5D: Cross-Feature Navigation
Verify:
- All new pages appear in navigation
- All route paths are unique (no collisions)
- Back navigation works
- Deep links work (e.g., `/orchestration/workflow/123`)

### 5E: E2E Smoke Test
For each new page:
1. Navigate to route
2. Verify page loads without console errors
3. Verify API calls fire to correct endpoints
4. Verify loading/error states display

## Phase 6: Registration & Documentation

### 6A: Update SYSTEM_INVENTORY
- New page count
- New API endpoint coverage
- Feature wiring matrix

### 6B: Update MEMORY.md
- App wiring coverage percentage
- New feature pages created
- Remaining gaps

### 6C: Commit Strategy
Atomic commits per feature:
- `feat(app): wire Orchestration feature — page + API + types + context [FORGE-APP-WIRE]`
- `feat(app): wire Compliance dashboard — page + API + types [FORGE-APP-WIRE]`
- `feat(app): wire Telemetry analytics — page + API + types + charts [FORGE-APP-WIRE]`
- `fix(types): add missing TypeScript types for CAM/Cost/Data features [FORGE-APP-WIRE]`

## Final Report
```
FORGE APP-WIRE COMPLETE
========================
BEFORE → AFTER
Pages:         [N] → [N] (+[N])
Routes:        [N] → [N] (+[N])
API Clients:   [N] → [N] (+[N] functions)
Type Files:    [N] → [N] (+[N] interfaces)
Contexts:      [N] → [N] (+[N])
Components:    [N] → [N] (+[N])

FEATURE COVERAGE:
  COMPLETE:    [N]/[N] features
  PARTIAL:     [N] features
  UNWIRED:     [N] features

TYPE SAFETY:
  `any` usage: [N] → [N] (-[N])
  Untyped:     [N] → [N] (-[N])

Build:     PASS
Tests:     [N] passing (+[N] new)
Commits:   [N]

Remaining: [list or "ZERO — 100% wired"]
Next:      /forge-mcp-wire (backend) or /release-ready (ship)
```

## Safety Rails
- READ-ONLY in `audit` mode — never modify source code
- Never modify existing components — only add new ones
- Never change existing API contracts — only add new endpoints
- Never modify backend routes — this command only touches the web/ directory
- Follow existing patterns exactly (component structure, naming, styling)
- All new components must include loading + error states
- All API functions must include error handling (try/catch)
- All types must be explicit — never use `any` in new code
- Build gate after every feature (never skip)
- Maintain mobile responsiveness (Tailwind responsive classes)

## Context Management
- If context > 70% → `/compact quick`, save feature progress
- Wire one complete feature stack at a time (types → API → context → page → nav)
- Use DSL shortcodes in all output

## Architecture Patterns to Follow
Reference these files for existing patterns:
- **Page**: `C:/PRISM/web/src/pages/SfcCalculatorPage.tsx`
- **API Client**: `C:/PRISM/web/src/api/sfc.ts`
- **Types**: `C:/PRISM/web/src/types/sfc.ts`
- **Context**: `C:/PRISM/web/src/contexts/LearningContext.tsx`
- **Hook**: `C:/PRISM/web/src/hooks/useSfc.ts`
- **Component**: `C:/PRISM/web/src/components/sfc/` directory
- **Sub-route**: `C:/PRISM/web/src/components/learning/` directory
- **UI Primitives**: `C:/PRISM/web/src/components/ui/` directory

## Skills Chained
`/digest-all` → `/forge-wiring audit` → `/forge-schema` → `/forge-types` →
`/forge-tests scan` → `/test` → `/forge-drift` → `/addtomatrix` → `/update-all-docs`

## Error Handling
- **Import resolution failure**: Log component name, create stub, continue
- **Type generation failure**: Create interface with TODO comments, flag for manual review
- **Build failure**: Revert last feature, diagnose, fix, retry (max 3)
- **Missing backend route**: Log gap, skip UI generation for that feature
- **Context exhaustion**: Commit completed features, save state, report remaining
