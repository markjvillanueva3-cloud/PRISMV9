# Context Map — Visualize Context Window Contents

Show a live map of what's consuming context window space.

## Instructions
Use `contextWindowMapEngine` from `src/engines/ContextWindowMapEngine.ts` to:
1. List all tracked segments by type (file, tool-output, conversation, memory, system)
2. Show ASCII bar chart of usage by type
3. Identify stale segments that can be reclaimed
4. Show utilization percentage and top consumers

Output format: chart + one-liner status + reclaimable tokens suggestion.
Keep output under 30 lines.

$ARGUMENTS
