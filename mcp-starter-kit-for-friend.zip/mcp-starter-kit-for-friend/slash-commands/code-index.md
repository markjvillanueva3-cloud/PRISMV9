# Code Index — PRISM DSL Shortcode Lookup

Resolve shortcodes to file paths or search the Code System Index.
The DSL maps 1800+ PRISM files to compact codes for token savings.

## Args: - Empty: show category summary
- \: resolve a shortcode (e.g., \, \, \)
- \: search by name (e.g., \)
- \: list category (e.g., \ for all dispatchers)
- \: find code for a path
- \: regenerate the index from current file system

## Categories
| Prefix | Label | Example |
|--------|-------|---------|
| D | Dispatcher (55) | D01=atcsDispatcher |
| E | Engine (856) | E0001=AHPEngine |
| A | Algorithm (51) | A01=... |
| S | Schema (60) | S01=... |
| H | Hook (21) | H01=... |
| U | Util (16) | U01=Config |
| V | Validation (3) | V01=actionParamValidator |
| SV | Service (3) | SV01=RoadmapLoader |
| C | Catalog/Data (62) | C01=... |
| T | Test (526) | T001=... |
| R | Root/Config (11) | R01=package.json |
| M | Milestone (110) | M001=... |
| DOC | Documentation (33) | DOC01=... |
| X | External (8) | X06=MEMORY |

## How to Use
1. Read the compact reference:  (~100 lines)
2. Full JSON index:  (1812 entries)
3. Human-readable: 
4. Engine:  /  / 

## Execution
If args is empty, read  and display it.
If args is a code (starts with letter + digits), resolve it using the JSON index.
If args starts with "search", search the JSON index by name pattern.
If args starts with "cat", list all entries for that category prefix.
If args is "refresh", run the index generator script to rebuild from current file system.

The index JSON is at .
Read it once, then answer from memory. Do NOT re-read for each lookup.
