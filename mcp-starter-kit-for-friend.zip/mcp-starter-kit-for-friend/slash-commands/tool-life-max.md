# Tool Life Max — Squeeze Every Dollar from Every Cutter

Most shops replace tools too early (wasting money) or too late (scrapping parts). This command calculates the TRUE economic tool life for every tool in your job, optimizes replacement schedules, and identifies regrind opportunities — turning tooling from your biggest consumable cost into a managed asset.

**Value**: Average shop spends $15,000-80,000/year on tooling. Optimizing replacement timing saves 15-30% = $2,250-24,000/year. Preventing one catastrophic tool failure per month saves $500-5,000 in scrapped parts.

## Args:
- Tool + material + operation (e.g., "1/2 4FL carbide endmill, 7075-T6, roughing")
- `all-tools [job-file]`: analyze every tool in a job/program
- `regrind`: include regrind analysis and cost comparison
- `fleet`: analyze tool inventory across multiple jobs
- `coupled [material]`: coupled tool life (Taylor × BUE × chatter × thermal) via `prism_calc` action `coupled_tool_life`
- `optimal-change`: find optimal change point minimizing cost-per-good-part via `prism_calc` action `optimal_tool_change`
- `bayesian [machineId]`: use machine-learned Taylor coefficients via `prism_calc` action `bayesian_kienzle_update` + `taylor_coefficient_track`
- `kaplan-meier`: non-parametric survival curve from tool life data via `prism_calc` action `kaplan_meier`

## Phase 1: Current Tool Life Baseline
For each tool:

1. `/tool-catalog` — get tool specs and manufacturer's recommended parameters
   - Tool geometry, coating, substrate
   - Manufacturer's rated tool life (usually conservative)

2. Run `ultimateSpeedFeedEngine.calculate()` at current parameters:
   - Current Vc, fz, ap, ae
   - Calculate chip thickness, MRR, cutting forces

3. `/wear-analysis` — physics-based wear prediction:
   - Flank wear rate (Takeyama-Murata model)
   - Crater wear rate (Fick diffusion model)
   - Notch wear prediction
   - Stochastic reliability (log-normal distribution)
   - Time to VB = 0.3mm (ISO standard end-of-life)

4. Establish baseline:
   - Current tool life in minutes and parts
   - Current cost per part (tool price ÷ parts per tool)
   - Current failure mode (gradual wear vs catastrophic)

## Phase 2: Economic Tool Life Optimization
The cheapest tool life isn't the longest — it's the one that minimizes TOTAL cost.

1. **Taylor Tool Life Analysis**:
   - V×T^n = C — map the speed-life curve
   - Calculate minimum-cost velocity (Vc_opt)
   - Calculate maximum-production velocity (Vc_max)
   - Find the sweet spot between the two

2. **Cost-per-part curves at different parameters**:
   | Speed (Vc) | Tool Life | Parts/Tool | Tool $/Part | Machine $/Part | TOTAL $/Part |
   |------------|-----------|------------|-------------|----------------|--------------|
   | -20% | [X] min | [X] | $[X] | $[X] | $[X] |
   | -10% | [X] min | [X] | $[X] | $[X] | $[X] |
   | Current | [X] min | [X] | $[X] | $[X] | $[X] |
   | +10% | [X] min | [X] | $[X] | $[X] | $[X] |
   | +20% | [X] min | [X] | $[X] | $[X] | $[X] |
   | **Optimal** | **[X] min** | **[X]** | **$[X]** | **$[X]** | **$[X]** |

3. **Multi-variable optimization**:
   - DOC vs tool life tradeoff
   - Stepover vs tool life tradeoff
   - Combined optimization: speed + DOC + stepover for minimum $/part

## Phase 3: Replacement Schedule Optimization

1. **Reliability-based replacement**:
   - Weibull distribution of tool failures
   - Set replacement at 95% survival probability (5% failure risk)
   - vs. 99% survival (1% risk) — cost of extra safety margin
   - Calculate: cost of premature replacement vs cost of in-cut failure

2. **Optimal replacement policy**:
   ```
   REPLACEMENT STRATEGY
   ━━━━━━━━━━━━━━━━━━━
   Replace at:     [X] parts ([X] min cutting time)
   Confidence:     [X]% this tool survives to replacement
   Risk per part:  [X]% chance of failure on any given part

   Cost comparison:
     Replace too early (current):  $[X]/year wasted in unused tool life
     Replace at optimal:           $[X]/year (baseline)
     Replace too late (push it):   $[X]/year in scrapped parts + downtime
   ```

3. **In-process monitoring recommendations**:
   - Spindle load threshold for tool change (% of normal)
   - Sound frequency signature of worn tool
   - Surface finish degradation trigger point
   - Chip color/shape change indicators

## Phase 4: Regrind Analysis (if `regrind` flag)

1. **Regrind feasibility**:
   - Tool geometry allows regrind? (coating thickness, substrate exposure)
   - Expected performance after regrind (typically 80-95% of new)
   - Number of regrinds before geometry is compromised
   - Coating options for reground tools

2. **Regrind economics**:
   ```
   REGRIND ANALYSIS
   ━━━━━━━━━━━━━━━━
   New tool cost:        $[X]
   Regrind cost:         $[X] ([X]% of new)
   Performance retained: [X]%
   Max regrinds:         [X]

   Lifetime comparison:
     Buy new every time:  $[X] per [N] parts
     Regrind [N] times:   $[X] per [N] parts
     SAVINGS:             $[X] per tool lifetime ([X]%)

   Annual savings at [N] tools/year: $[X]
   ```

3. **Regrind schedule**:
   - When to regrind (don't wait until tool is destroyed)
   - Regrind vendor turnaround time
   - Buffer inventory needed during regrind cycle

## Phase 5: Fleet Optimization (if `fleet` flag)

1. **Cross-job tool sharing**:
   - Same tool used across multiple jobs?
   - Can tool life tracking carry across jobs?
   - Optimal sequence: run tight-tolerance jobs with fresh tools, roughing with worn tools

2. **Inventory optimization**:
   - Minimum stock levels per tool type
   - Reorder points based on consumption rate
   - Bulk discount thresholds from catalog

3. **Tool standardization opportunities**:
   - Can 3 similar tools be replaced by 1 standard?
   - Cost of slightly suboptimal parameters vs inventory simplification
   - Impact on setup time (fewer tool changes)

## Output Summary
```
TOOL LIFE MAX — [Tool Description]
====================================
Material:       [workpiece material]
Operation:      [roughing/finishing/etc.]

CURRENT STATE:
  Tool life:        [X] min / [X] parts
  Cost per part:    $[X] (tool only)
  Failure mode:     [gradual/catastrophic]
  Replacement:      [when currently replaced]

OPTIMIZED:
  Optimal Vc:       [X] m/min (was [X])
  Optimal life:     [X] min / [X] parts
  Cost per part:    $[X] (was $[X])
  SAVINGS:          $[X]/part ([X]% reduction)

REPLACEMENT SCHEDULE:
  Replace at:       [X] parts (95% confidence)
  Monitor:          spindle load > [X]% = change now
  Annual savings:   $[X] vs current schedule

REGRIND OPPORTUNITY:
  [X] regrinds × $[X] each = $[X] saved per tool lifetime
  Annual savings:   $[X]

TOTAL ANNUAL SAVINGS: $[X]
  Parameter optimization:  $[X]
  Schedule optimization:   $[X]
  Regrind savings:         $[X]
```

## Key Engines Used
AdvancedWearPhysicsEngine, UltimateSpeedFeedEngine, ReliabilityEngineeringEngine,
SustainabilityLCAEngine, ConstitutiveModelEngine, ToolWearCompensationEngine
