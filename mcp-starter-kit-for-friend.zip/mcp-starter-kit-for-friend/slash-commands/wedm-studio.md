---
name: wedm-studio
description: Interactive Wire EDM programming studio with full pipeline
version: 1.0.0
engines:
  - WEDMStudioEngine
  - WEDMProgramOptimizerEngine
  - WEDMCalculatorAIEngine
  - WireEDMDeepReasoningEngine
  - WEDMNeuralTrainingEngine
  - WedmProgramIndexEngine
actions:
  - wedm_studio_pipeline
  - wedm_advanced_analysis
  - wedm_optimize_params
  - wedm_full_documentation
  - wedm_get_recommendation
hooks:
  - hook_wedm_program_sanity
  - hook_wedm_machine_limits
  - hook_wedm_safety_check
triggers:
  - "wedm studio"
  - "wire edm studio"
  - "interactive wedm"
  - "full wedm workflow"
---

# /wedm-studio — Interactive Wire EDM Programming Studio

Full-featured Wire EDM programming environment:
- Complete part-to-program pipeline
- Real-time parameter optimization
- Neural-enhanced predictions
- Interactive debugging
- Integrated documentation

## Usage

```
/wedm-studio [part] [options]
```

## Arguments

- `part` — Part file (DXF, STEP, IGES) or description
- `--mode` — Studio mode (guided|expert|batch)
- `--machine` — Target machine (default: FA-20S)
- `--material` — Workpiece material
- `--goal` — Optimization goal (quality|speed|balance)

## Pipeline Stages

| Stage | Engine | Output |
|-------|--------|--------|
| 1. Parse | GeometryParsingEngine | Features, dimensions |
| 2. Feasibility | WEDMFeasibilityEngine | Constraints, warnings |
| 3. Strategy | WireEDMDeepReasoningEngine | Cut sequence plan |
| 4. Parameters | WEDMNeuralTrainingEngine | Optimized E-codes |
| 5. Toolpath | WEDMProgramOptimizerEngine | Wire path |
| 6. G-code | MitsubishiFAPostEngine | NC program |
| 7. Validate | WEDMProgramAnalyzerEngine | Safety check |
| 8. Document | WEDMDocumentationEngine | Full docs |

## Studio Modes

### Guided Mode (default)
- Step-by-step workflow
- Explains each decision
- Asks for confirmation at critical points
- Best for learning or complex parts

### Expert Mode
- Minimal prompts
- Direct parameter control
- Advanced overrides
- For experienced programmers

### Batch Mode
- Process multiple parts
- Automatic decisions
- Summary reports only
- For production runs

## Interactive Features

```
Commands while in studio:
  preview    — 3D toolpath visualization
  simulate   — Virtual cut simulation
  analyze    — Deep parameter analysis
  compare    — Compare with similar jobs
  optimize   — Re-optimize current stage
  back       — Return to previous stage
  docs       — Generate documentation
  export     — Export NC program
```

## Output

```json
{
  "session": {
    "id": "studio_20260416_001",
    "mode": "guided",
    "stages_completed": 8
  },
  "part": {
    "name": "punch_insert_D2",
    "features": 12,
    "complexity": "medium"
  },
  "program": {
    "file": "O1234.NC",
    "lines": 847,
    "estimated_time_min": 52
  },
  "parameters": {
    "ecode": "E1847",
    "passes": 4,
    "wire": "Brass 0.25mm"
  },
  "predictions": {
    "ra_um": 0.72,
    "mrr_mm2_min": 48.5,
    "wire_break_prob": 0.03
  },
  "documentation": {
    "setup_sheet": "setup_O1234.pdf",
    "traveler": "traveler_O1234.pdf"
  }
}
```

## Examples

```bash
# Start guided session
/wedm-studio part.dxf

# Expert mode with material
/wedm-studio punch.step --mode expert --material D2

# Batch process directory
/wedm-studio ./parts/ --mode batch --goal speed

# Specific machine
/wedm-studio insert.iges --machine "FA-20S" --goal quality
```

## Integration

- Calls `/wedm-feasibility` at Stage 2
- Uses `/wedm-ai-advisor` for Stage 4
- Invokes `/wedm-troubleshoot` if issues arise
- Generates `/wedm-report` at completion

## Safety Hooks

- `hook_wedm_program_sanity` — Validates all G-code
- `hook_wedm_machine_limits` — Enforces travel limits
- `hook_wedm_safety_check` — Final safety validation

## Leverages

- `WEDMStudioEngine` — Session orchestration
- `WireEDMDeepReasoningEngine` (1,081 LOC) — Strategy planning
- `WEDMNeuralTrainingEngine` (2,436 LOC) — All 10 neural models
- `WEDMProgramOptimizerEngine` (561 LOC) — Toolpath optimization
- 119 WEDM engines total available
