# Quality Check — Shop Floor Quality Engineering Workflow

Run quality engineering calculations: SPC analysis, process capability (Cpk), tolerance stack-up, GD&T validation, and CMM planning through the prism_quality dispatcher.

## Args: $ARGUMENTS
- Empty: show available quality actions and prompt for workflow
- `spc [feature-name] [measurements...]`: run SPC control chart analysis
- `cpk [feature-name] [USL] [LSL]`: process capability prediction
- `stack [features...]`: tolerance stack-up (RSS or worst-case)
- `gdt [callout]`: GD&T validation against drawing spec
- `plan [part-name]`: CMM inspection planning
- `gauge [measurements...]`: gauge R&R measurement system analysis
- `full [part-name]`: complete quality chain (SPC → Cpk → stack → report)
- `multivariate [measurements-csv]`: multivariate SPC with PCA + CUSUM/EWMA + Hotelling T²
- `capability-ci [feature] [USL] [LSL]`: Cpk with Bootstrap BCa confidence intervals
- `dimensionless [params]`: compute 8 process health dimensionless numbers

## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (dispatcher action chaining with data formatting)
2. Domain: Quality Engineering + Metrology + Statistics
3. Roles: Quality Engineer + Manufacturing Process Expert
4. Model: SONNET
5. Effort: MEDIUM

## Phase 2: Parameter Resolution

### For SPC:
- Feature name and measurement data (array of values)
- Control limits (auto-calculated or user-specified)
- Subgroup size (default 5)
- Western Electric rules enabled by default

### For Cpk:
- Feature name, USL (upper spec limit), LSL (lower spec limit)
- Process mean and std dev (from measurements or estimated)
- Target Cpk threshold (default 1.33)

### For Tolerance Stack:
- List of features with nominal + tolerance
- Method: RSS (default) or worst-case
- Contributing dimensions and their distributions

### For GD&T:
- GD&T callout string (e.g., "position 0.05 MMC A|B|C")
- Measured values for datum features
- Feature measured values

## Phase 3: Execute Quality Calculations

### SPC Workflow:
```
1. prism_quality → spc_calculate
   Input: measurements, subgroup_size, control_rules
   Output: X-bar, R chart, control limits, out-of-control points

2. Interpret: stable/unstable, which rules violated, trend detection
```

### Cpk Workflow:
```
1. prism_quality → cpk_predict
   Input: measurements or (mean, std_dev), USL, LSL
   Output: Cp, Cpk, Pp, Ppk, sigma level

2. Assess: Cpk >= 1.33 CAPABLE, 1.0-1.33 MARGINAL, <1.0 NOT CAPABLE
```

### Stack-Up Workflow:
```
1. prism_quality → tolerance_stack
   Input: dimensions[], tolerances[], method (RSS|worst_case)
   Output: stack result, probability of interference

2. Compare against assembly tolerance requirement
```

### GD&T Workflow:
```
1. prism_quality → gdt_validate
   Input: callout, datum_values, feature_values
   Output: pass/fail, actual vs allowed, bonus tolerance (if MMC/LMC)

2. Report conformance status
```

### Full Chain:
Run SPC → Cpk → stack → GD&T in sequence, producing a unified quality report.

## Phase 4: Output Quality Report

```
QUALITY REPORT — [Part/Feature]
====================================
SPC Status:    [IN CONTROL / OUT OF CONTROL]
  X-bar:       [X] ± [X]    (UCL: [X], LCL: [X])
  R:           [X]           (UCL: [X])
  Violations:  [none / Rule X at point N]

Process Capability:
  Cp  = [X]    Cpk = [X]    Sigma: [X]σ
  Status: [CAPABLE / MARGINAL / NOT CAPABLE]
  Est. defect rate: [X] ppm

Tolerance Stack (if applicable):
  Method:      [RSS / Worst-case]
  Stack:       [X] ± [X] mm
  Assembly OK: [YES / NO]  (margin: [X] mm)

GD&T (if applicable):
  Callout:     [description]
  Actual:      [X] mm    Allowed: [X] mm
  Status:      [PASS / FAIL]    Bonus: [X] mm

Recommendation:
  [actionable recommendation based on results]
```

## Error Handling
- Insufficient measurements for SPC: warn, need minimum 20 data points
- Cpk with no spec limits: cannot calculate, prompt user
- Stack-up with single dimension: no stack needed, return tolerance directly
- GD&T parsing failure: show supported callout formats
