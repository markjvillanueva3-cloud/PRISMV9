# Forge Deps — Dependency Health Analyzer

You are running a specialized autopilot pipeline that analyzes dependency health across the PRISM project. Checks for outdated packages, security advisories, unused dependencies, and circular imports. Designed to run in the **background**.

## Args: $ARGUMENTS
- Empty: full dependency health check — npm audit + outdated + unused + circular
- `security`: only run security audit (npm audit)
- `outdated`: only check for outdated packages
- `unused`: only find unused dependencies
- `circular`: only detect circular imports
- `quick`: summary counts only
- `fix`: auto-update safe dependencies (patch/minor only)


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` -- loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` -- zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` -- resolve E0001->path instantly (1,865 indexed files)

## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: LOW-MODERATE (mostly tool output parsing)
2. Domain: Package Management + Security
3. Roles: DevOps Engineer + Security Auditor
4. Model: SONNET (systematic checks, not creative)
5. Effort: LOW

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Dependency Analysis

### 3A: Security Audit
Run in `C:/PRISM/mcp-server/`:
1. `npm audit --json` — parse vulnerability report
2. Classify: CRITICAL (remote code exec, auth bypass), HIGH (data exposure), MODERATE (DoS), LOW (info disclosure)
3. Check if fixes are available (`npm audit fix --dry-run`)
4. For each vulnerability: package name, severity, path, fix available?

Also check `C:/PRISM/cad-engine/` (Python):
1. `pip audit` or `pip list --outdated` — check for known CVEs
2. Check `requirements.txt` for pinned vs unpinned versions

### 3B: Outdated Dependencies
Run in `C:/PRISM/mcp-server/`:
1. `npm outdated --json` — current vs wanted vs latest
2. Classify updates:
   - **Patch** (x.y.Z): safe to auto-update
   - **Minor** (x.Y.0): usually safe, check changelog
   - **Major** (X.0.0): breaking changes likely — manual review needed
3. Flag dependencies >6 months behind latest
4. Flag dependencies with no recent releases (abandoned?)

### 3C: Unused Dependencies
Scan `package.json` dependencies:
1. For each dependency, grep source code for imports
2. If no imports found → candidate for removal
3. Check devDependencies separately (may be used in config, scripts, tests)
4. Cross-reference with `tsconfig.json` types, jest config, build config

### 3D: Circular Import Detection
Analyze TypeScript import graph:
1. Build import adjacency list from source files
2. Run cycle detection (DFS with back-edge detection)
3. For each cycle: list the chain (A → B → C → A)
4. Classify: tight cycles (2-3 files) vs loose cycles (4+ files)
5. Flag cycles involving safety-critical files as CRITICAL

### 3E: Dependency Size Analysis
Check for bloated dependencies:
1. List top 10 largest `node_modules/` directories
2. Flag dependencies >5MB that might have lighter alternatives
3. Check for duplicate packages (same package, different versions)

## Phase 4: Health Report

```
FORGE DEPS REPORT
=================
Project:    PRISM MCP Server
Node:       [version]
npm:        [version]
Packages:   [N] dependencies, [M] devDependencies

SECURITY:
  CRITICAL: [N] vulnerabilities
    - [package]: [description] — fix: [available/none]
  HIGH:     [N] vulnerabilities
  MODERATE: [N] vulnerabilities
  LOW:      [N] vulnerabilities
  Auto-fixable: [N]/[total]

OUTDATED:
  Major behind:  [N] packages (breaking changes)
    - [package]: [current] → [latest] (last updated [date])
  Minor behind:  [N] packages
  Patch behind:  [N] packages
  Up to date:    [N] packages

UNUSED:
  Candidates for removal: [N]
    - [package] — no imports found in src/
  DevDependency review: [N]
    - [package] — used only in [config/test/script]

CIRCULAR IMPORTS:
  Cycles found: [N]
    - [A] → [B] → [C] → [A]
    ...
  Safety chain cycles: [N] (CRITICAL if >0)

SIZE:
  node_modules total:  [X] MB
  Top 5 largest:
    1. [package] — [X] MB
    ...
  Duplicates: [N] packages with multiple versions

HEALTH SCORE: [N]/100
```

## Phase 5: Forge Postflight (`/forge-postflight deps`)
1. **Gate 1 — DSL**: SKIP (deps don't affect DSL)
2. **Gate 2 — Matrix**: SKIP (no new products)
3. **Gate 3 — Trace**: SKIP (no wiring changes)
4. **Gate 4 — Sync**: RUN — verify package counts
5. **Gate 5 — Memory**: RUN — update MEMORY.md with health score and critical issues
6. **Gate 6 — Hookify**: SKIP

## Phase 6: Auto-Commit (fix mode only)
`chore(deps): update [N] dependencies, fix [M] vulnerabilities [FORGE-DEPS]`

## Summary Report
```
FORGE DEPS COMPLETE
===================
Packages:    [N] analyzed
Security:    [N] vulnerabilities ([M] critical)
Outdated:    [N] packages behind
Unused:      [N] removal candidates
Circular:    [N] import cycles
Health:      [score]/100
Fixed:       [N] (or "report only")
Next:        npm audit fix for auto-fixable, manual review for major updates
```

## Error Handling
- **npm audit fails**: Try `npm audit --registry=https://registry.npmjs.org` with explicit registry
- **pip not available**: Skip Python dependency check, note in report
- **node_modules missing**: Run `npm install` first
- **Context budget**: Run security-only check (smallest output)

## Safety Rails
- In fix mode: ONLY apply patch updates, never major version bumps
- Never remove dependencies without confirming they're truly unused
- Never auto-fix security vulnerabilities that require major version changes
- Always run full test suite after any dependency changes
- Never modify package-lock.json manually — let npm manage it
- Flag but don't auto-fix circular imports (architectural change needed)
