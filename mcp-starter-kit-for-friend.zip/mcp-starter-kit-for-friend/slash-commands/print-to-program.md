# Print to Program — Upload Print → Get CNC Program

Run the full Print-to-Program pipeline: describe or upload a part → extract features → select tools from user inventory → generate operation sequence → calculate physics-backed S/F → assemble CNC program → post-process for your machine → setup sheet + quote + ROI suggestions.

## Args: $ARGUMENTS
- Empty: interactive mode — prompt for part description, material, machine
- `"<description>"`: direct mode — e.g., `/print-to-program "100x80x10mm aluminum plate, 4x 6.35mm thru holes, 50x30x5mm pocket"`
- `full`: run with Fusion 360 integration (generates F360 script)
- `quick`: skip stochastic analysis for faster results

## Execution

1. **Gather Input** — If no description provided, ask:
   - Part description (dimensions, features, tolerances)
   - Material (e.g., 6061-T6, Ti-6Al-4V, 4140)
   - Machine (e.g., Haas VF-2, DMG DMU 50)
   - Quantity (for ROI calculations)
   - Optimize for: productivity / tool_life / cost / quality / balanced

2. **Run Pipeline** — Call PrintToProgramPipelineEngine via dispatcher:
   ```
   Action: print_to_program_enhanced (camDispatcher)
   Input: { material, machine, description, quantity, optimize_for }
   ```

3. **Report Results**:
   ```
   PRINT → PROGRAM COMPLETE
   ========================
   Features:    [N] extracted ([source])
   Tools:       [N] from inventory, [N] missing
   Operations:  [N] operations, [N] tool changes
   Cycle Time:  [X.X] min
   Cost:        $[X.XX]/part
   Confidence:  [X]%

   PROGRAM: [N] lines of G-code
   SAFETY:  [N] checks passed, [N] warnings
   PLAYBOOK: [N] rules applied

   MISSING TOOLS:
     - [type] ∅[X]mm — est. $[X] — [priority]

   ROI SUGGESTIONS:
     - [item] — $[cost] → saves $[X]/part, payback [N] parts
   ```

4. **Offer Outputs**:
   - Download G-code
   - View setup sheet
   - View cost breakdown
   - Generate Fusion 360 script (if `full` mode)

## Engines Used
- PrintToProgramPipelineEngine (master orchestrator)
- BlueprintOCREngine (print reading)
- PrintToGeometryEngine (45 feature types → CadQuery)
- SpeedFeedOrchestratorEngine (67-point physics)
- InventoryAwareToolSelectorEngine (user tools)
- OperationSequencerEngine (topo sort + TSP)
- CNCProgramAssemblerEngine (multi-op G-code)
- PostProcessorPipelineEngine (17 dialects)
- QuoteEstimatorEngine (physics-backed costing)
- ROIAdvisorEngine (upgrade payback)
- Fusion360CodeGeneratorEngine (optional F360 script)

## Error Handling
- If feature extraction fails → ask user to describe features manually
- If no user tools → use catalog recommendations with purchase suggestions
- If machine unknown → use generic profile with lower confidence
- Pipeline stages can fail independently — partial results still valuable
