---
description: "Look up secondary operations (anodize, heat treat, plating, NDT, grinding) — pricing, specs, material compatibility, vendors"
---

# Secondary Ops — Manufacturing Secondary Operations Lookup

Query the secondary operations catalog for pricing, material compatibility, spec references, and vendor recommendations.

## Usage
- No args: list all categories and operation counts
- Material name: show compatible operations for that material
- Operation name: show detailed pricing, specs, and vendors
- "recommend [material] [application]": get recommendations (e.g., "recommend aluminum_6061 corrosion")

## Actions Used
- `sec_ops_list` — List all or by category
- `sec_ops_quote` — Get pricing for specific operation + quantity
- `sec_ops_recommend` — Material + application recommendations
- `sec_ops_find_vendors` — Find capable vendors
- `sec_ops_batch_quote` — Price multiple operations together

## Output
For each operation show:
- Name, category, description
- Base cost per part + batch pricing tiers
- Min lot charge
- Lead time (standard / rush)
- Material compatibility (green = compatible, red = incompatible)
- Spec references (MIL, ASTM, AMS)
- Masking requirements and cost
- Available vendors with quality ratings

$ARGUMENTS
