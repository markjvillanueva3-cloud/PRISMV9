---
name: wedm-report
description: Generate Wire EDM production reports and analytics
version: 1.0.0
engines:
  - WEDMReportingEngine
  - WEDMBatchProgramAnalyzerEngine
  - WedmProgramIndexEngine
  - ShopMetricsEngine
  - QuoteEstimatorEngine
actions:
  - wedm_generate_report
  - wedm_production_summary
  - wedm_efficiency_analysis
  - wedm_trend_analysis
hooks:
  - hook_wedm_report_validation
triggers:
  - "wedm report"
  - "edm production report"
  - "wire edm analytics"
  - "wedm summary"
---

# /wedm-report — Wire EDM Production Reporting

Generate comprehensive WEDM reports and analytics:
- Production summaries
- Efficiency metrics
- Quality analysis
- Cost tracking
- Trend identification

## Usage

```
/wedm-report <type> [options]
```

## Arguments

- `type` — Report type (daily|weekly|monthly|job|machine|custom)
- `--period` — Time period (today|week|month|quarter|custom range)
- `--machine` — Filter by machine
- `--customer` — Filter by customer
- `--format` — Output format (json|pdf|excel|html)

## Report Types

| Type | Contains | Frequency |
|------|----------|-----------|
| `daily` | Shift production, issues, metrics | End of day |
| `weekly` | Aggregated stats, trends | Weekly |
| `monthly` | Full analytics, KPIs | Monthly |
| `job` | Single job analysis | On demand |
| `machine` | Machine utilization | On demand |
| `custom` | User-defined metrics | On demand |

## Metrics Tracked

### Production
- Parts completed
- Total cut time
- Setup time
- Wire consumption
- Cycle efficiency

### Quality
- Surface finish achieved vs target
- Dimensional accuracy
- Scrap rate
- Rework frequency

### Efficiency
- Machine utilization %
- Actual vs estimated time
- Wire breaks per hour
- First-pass yield

### Cost
- Cost per part
- Wire cost
- Machine time cost
- Variance from quote

## Output

```json
{
  "report": {
    "type": "weekly",
    "period": "2026-04-08 to 2026-04-15",
    "generated": "2026-04-15T17:00:00Z"
  },
  "production": {
    "parts_completed": 47,
    "total_cut_time_hr": 38.5,
    "setup_time_hr": 6.2,
    "wire_consumed_m": 2450
  },
  "quality": {
    "avg_ra_achieved_um": 0.68,
    "avg_ra_target_um": 0.75,
    "dimensional_pass_rate": 0.98,
    "scrap_count": 1,
    "rework_count": 2
  },
  "efficiency": {
    "machine_utilization": 0.82,
    "actual_vs_estimated": 0.95,
    "wire_breaks_per_hr": 0.12,
    "first_pass_yield": 0.96
  },
  "cost": {
    "total_cost_usd": 4250,
    "avg_cost_per_part_usd": 90.43,
    "wire_cost_usd": 612,
    "variance_from_quote": -0.03
  },
  "trends": {
    "utilization_trend": "stable",
    "quality_trend": "improving",
    "efficiency_trend": "improving"
  },
  "issues": [
    {
      "date": "2026-04-11",
      "issue": "Repeated breaks on thick S7 section",
      "resolution": "Increased upper flush, added skim pass"
    }
  ],
  "recommendations": [
    "Schedule guide replacement (approaching 500hr)",
    "Consider Zinc wire for upcoming carbide job"
  ]
}
```

## Examples

```bash
# Daily production report
/wedm-report daily

# Weekly report for specific machine
/wedm-report weekly --machine "FA-20S"

# Monthly customer report
/wedm-report monthly --customer ALCOA --format pdf

# Single job analysis
/wedm-report job --job-id JOB-2026-0415-001

# Custom date range
/wedm-report custom --period "2026-03-01 to 2026-03-31" --format excel
```

## Report Validation Hook

`hook_wedm_report_validation` ensures:
- Data completeness
- Metric consistency
- No impossible values (utilization > 100%)
- Proper time range boundaries

## Automated Scheduling

Reports can be scheduled via PRISM automation:
- Daily reports: 5:00 PM each workday
- Weekly reports: Monday 8:00 AM
- Monthly reports: 1st of month

## Integration

- Pulls data from `/wedm-batch` completions
- Uses `/wedm-cost` for variance analysis
- Feeds `/wedm-ai-advisor` for model improvement
- Exports to shop ERP if configured

## Leverages

- `WEDMReportingEngine` — Report generation
- `WEDMBatchProgramAnalyzerEngine` — Batch analysis
- `WedmProgramIndexEngine` — Historical data
- `ShopMetricsEngine` — Shop-wide KPIs
- `QuoteEstimatorEngine` — Cost comparison
