# Forge Hooks — Hook Discovery + Creation Autopilot

You are running a specialized autopilot pipeline focused on discovering, designing, building, and registering new Claude Code hooks that benefit the PRISM system and app. This command chains system analysis, hook identification, creation via hookify, testing, and registration into one continuous flow.

## Args: $ARGUMENTS
- Empty: full discovery — analyze the system, find hook gaps, create the best candidates
- `[hook-name]`: skip discovery, go straight to creating a specific hook
- `[count]`: create up to N hooks (default: 3)
- `list`: just analyze and list hook opportunities without creating any
- `audit`: audit existing hooks for quality and gaps

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when identifying hook opportunities.
- Consider every failure mode, anti-pattern, and efficiency opportunity that could be automated via hooks.
- "Already covered" claims REQUIRE citing the SPECIFIC existing hook/rule by name.
- **Completeness > Speed.** A missed hook means repeated waste or errors.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
Analyze the session:
1. Complexity: MODERATE-COMPLEX (hooks require understanding tool patterns and failure modes)
2. Domain: Systems Architecture + DevOps/Automation + Security
3. Roles: Principal Systems Architect + Senior Security Auditor
4. Model: OPUS (hook design requires careful reasoning about side effects)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: System Analysis — Discover Hook Opportunities
Analyze the PRISM ecosystem and Claude Code usage patterns to identify high-value hook candidates:

### 3A: Inventory Existing Hooks
1. Read `~/.claude/settings.json` to catalog all configured hooks (pretooluse, posttooluse, session-start, precompact, etc.)
2. Read `~/.claude/hooks/` directory to understand the hook library
3. List all hookify rules via `/hookify list` data
4. Map coverage: what tool events are already hooked? What gaps exist?
5. Note the following ECC hooks already exist in `H:/prism/.claude/helpers/` and should be marked COVERED during gap analysis:
   - `compact-counter.mjs` — PostToolUse: suggests /compact at 50/75/100 tool calls (uses tool-counter.mjs)
   - `safety-gates.mjs` — PreToolUse Task: pre-task risk detection for safety-critical edits
   - `safety-escalation.mjs` — PostToolUse Task: post-task safety flag escalation
   - `directory-freeze.mjs` — PreToolUse Write/Edit: blocks writes to dirs listed in frozen-dirs.json
   - `mcp-health-recovery.mjs` — PostToolUseFailure: MCP failure detection and recovery
   - `pattern-extractor.mjs` — Stop: extracts manufacturing/code patterns on session stop
   - `review-merge.mjs` — utility (not a hook): merges dual-perspective review findings via review-rubric.json

Current hook categories to check:
- **pretooluse**: Tool redirects, safety blocks, file routing, linting
- **posttooluse**: Syntax checks, quality gates, output compression, anti-regression
- **precompact**: State saving before context compression
- **session-start**: Context loading, cleanup
- **userpromptsubmit**: Skill auto-suggestions
- **notification hooks**: Alerts on specific events

### 3B: Identify Gaps
Analyze across these dimensions:

**Safety & Guard Rails:**
- Are there tool usage patterns that should be blocked or redirected?
- Are there dangerous operations that lack confirmation gates?
- Are there security patterns not yet enforced (secrets in output, unsafe file paths)?
- Are there PRISM-specific safety rules not yet automated (S(x) bypass, placeholder detection)?

**Code Quality Automation:**
- What code quality checks run posttooluse that could catch more issues?
- Are there lint/format rules specific to PRISM that should auto-fire?
- What anti-regression checks would protect against known failure modes?
- Are there import patterns, naming conventions, or architecture rules to enforce?

**Workflow Optimization:**
- What repetitive tool sequences could be detected and optimized?
- What context-saving opportunities exist before compaction?
- What session-start operations would reduce onboarding time?
- What output compression rules would save tokens?

**PRISM App-Specific:**
- Material database integrity checks (hook on Write to materials dir)
- CAD engine safety (hook on bridge.py modifications)
- Roadmap envelope validation (hook on Write to milestones dir)
- Safety chain protection (hook on edits to safety-related files)
- Test regression gates (hook after test file modifications)

**Developer Experience:**
- Auto-formatting or auto-fixing common mistakes
- Smart file routing for PRISM directories
- Build/test auto-triggers after significant changes
- Context-aware suggestions based on current work

### 3C: Rank Candidates
Score each candidate on:
- **Safety Impact** (HIGH/MEDIUM/LOW): Does it prevent bugs, data loss, or security issues?
- **Frequency** (HIGH/MEDIUM/LOW): How often would it trigger?
- **Token Savings** (HIGH/MEDIUM/LOW): Does it reduce context usage?
- **Complexity** (HIGH/MEDIUM/LOW): How hard is it to implement correctly?
- **Side Effects** (HIGH/MEDIUM/LOW): Risk of false positives or blocking valid work?

Priority = (Safety * 3 + Frequency * 2 + TokenSavings * 2) / (Complexity + SideEffects * 2)

Present the ranked list:
```
HOOK OPPORTUNITIES
==================
Rank | Hook Name            | Event       | Safety | Freq | Tokens | Complex | Risk | Score
-----|----------------------|-------------|--------|------|--------|---------|------|------
  1  | material-write-guard | pretooluse  | HIGH   | MED  | LOW    | LOW     | LOW  | 9.5
  2  | test-regression-gate | posttooluse | HIGH   | MED  | LOW    | MED     | LOW  | 8.2
  ...
```

If args = `list`, stop here.

## Phase 4: Design Hooks
For each hook to create (top N from ranking or specified by args):

### 4A: Hook Architecture
Define:
- **Name**: descriptive, follows existing naming conventions
- **Event type**: pretooluse / posttooluse / precompact / userpromptsubmit / notification
- **Tool matcher**: Which tools does this hook intercept? (Bash, Write, Edit, Read, etc.)
- **Trigger conditions**: When should it fire vs. pass through?
- **Action**: What does the hook do? (block, warn, modify, log, suggest)
- **Implementation**: Hookify rule, shell script, or unified hook integration?

### 4B: Hook Implementation Decision
Choose the right implementation path:

**Option A — Hookify Rule** (preferred for simple pattern-based hooks):
- Use `/hookify hookify` or `/hookify writing-rules` to create
- Best for: content pattern matching, tool redirection, output compression
- Produces: YAML rule in hookify config

**Option B — Shell Script Hook** (for complex logic):
- Write a bash script in `~/.claude/hooks/`
- Best for: multi-step validation, external tool calls, stateful checks
- Integrate into `~/.claude/hooks/lib/common.sh` if shared logic

**Option C — Unified Hook Integration** (for hooks that should merge with existing):
- Add to `pretooluse-unified` or `posttooluse-unified`
- Best for: checks that fit naturally into the existing hook pipeline
- Avoids hook proliferation

### 4C: Failure Mode Analysis
For each hook, analyze:
- What are the false positive scenarios? (hook blocks valid work)
- What are the false negative scenarios? (hook misses invalid work)
- What's the blast radius of a hook bug? (blocks all tool calls vs. one type)
- What's the recovery path? (user can bypass? hook auto-disables?)

Design the hook to be:
- **Conservative**: Prefer warnings over blocks for new hooks
- **Specific**: Narrow tool matchers to minimize false triggers
- **Debuggable**: Include clear messages explaining why the hook fired
- **Bypassable**: Users should be able to override with explicit intent

## Phase 5: Create Hooks
For each designed hook, use the appropriate creation method:

### 5A: Hookify Rules
1. Use the hookify writing-rules pattern to define the rule
2. Add to hookify configuration
3. Verify the rule is syntactically correct

### 5B: Shell Script Hooks
1. Write the hook script to `~/.claude/hooks/{hook-name}.sh`
2. Make it executable
3. Source `common.sh` for shared utilities
4. Register in `~/.claude/settings.json` under the appropriate event

### 5C: Unified Hook Integration
1. Read the existing unified hook file
2. Add the new check function
3. Wire it into the main dispatch logic
4. Verify no conflicts with existing checks

Report per hook: `Created: {hook-name} ({event}) — [brief description]`

## Phase 6: Test Hooks
For each created hook:

### 6A: Dry Run Validation
1. Trace through the hook logic with a sample input that SHOULD trigger
2. Trace through with a sample input that should NOT trigger
3. Verify the hook produces the correct output format (block/warn/pass)

### 6B: Integration Check
1. Does the hook conflict with any existing hook?
2. Does the hook ordering matter? (pretooluse hooks run in config order)
3. Does the hook work with the auto-approve settings?

### 6C: Safety Check
1. Can the hook accidentally block critical operations?
2. Does the hook have an escape hatch?
3. Is the hook's error handling robust? (if the hook itself crashes, does it fail open or closed?)

Report:
```
HOOK VALIDATION
===============
{hook-name} ({event}):
  True positive:     PASS — correctly triggers on bad input
  True negative:     PASS — correctly passes good input
  No conflicts:      PASS — no existing hook overlap
  Ordering safe:     PASS — order-independent
  Fail-safe:         PASS — fails open on hook error
  Overall:           PASS
```

## Phase 7: Forge Postflight (`/forge-postflight hooks` protocol)
Run the shared integration protocol for newly created hooks:
1. **Gate 1 — DSL**: PARTIAL — if hooks enforce PRISM patterns, verify the patterns are correct
2. **Gate 2 — Matrix**: PARTIAL — if hooks are PRISM hook files (`src/hooks/`), register in MASTER_INDEX
3. **Gate 3 — Trace**: SKIP (Claude Code hooks don't have PRISM wiring)
4. **Gate 4 — Sync**: RUN — verify hook count in MEMORY.md matches settings.json + hookify config
5. **Gate 5 — Memory**: RUN — add new hooks to MEMORY.md hook inventory, update rule counts
6. **Gate 6 — Hookify**: SKIP (hooks don't need autofire rules for themselves)

Also verify:
- Hook is in `~/.claude/settings.json` under the correct event
- Hookify rules are in the hookify config
- No conflicts with existing hooks

Report the postflight results before proceeding to commit.

## Phase 8: Auto-Commit (`/auto-commit` protocol)
If any hooks were created:
1. Stage hook files, settings changes, hookify config
2. Commit: `feat(hooks): add [N] new hooks — [list names] [FORGE-HOOKS]`
3. Report the commit

## Summary Report
```
FORGE HOOKS COMPLETE
====================
Analyzed:      [N] system dimensions
Opportunities: [N] hook gaps identified
Created:       [N] hooks
  - {hook-1} (pretooluse) — [description]
  - {hook-2} (posttooluse) — [description]
  - {hook-3} (userpromptsubmit) — [description]
Validated:     [N]/[N] passed
Committed:     [commit hash]

Hook Coverage:
  pretooluse:       [N] hooks ([+M] new)
  posttooluse:      [N] hooks ([+M] new)
  precompact:       [N] hooks ([+M] new)
  session-start:    [N] hooks ([+M] new)
  userpromptsubmit: [N] hooks ([+M] new)

Total Hook Rules: [N] (was [M])

Next: /forge-hooks for more hooks, /forge-skills for skills, or /autopilot for roadmap work
```

## Error Handling
- **No gaps found**: Report "Hook coverage comprehensive" and suggest micro-optimizations
- **Hook conflicts**: If a new hook overlaps with an existing one, merge into the existing hook rather than creating a duplicate
- **False positive rate too high**: Downgrade from block to warn, or narrow the matcher
- **Context budget**: If running low, create the highest-priority hook only and report remaining candidates
- **Settings.json parse error**: Read the file first, make surgical edits, validate JSON after

## Safety Rails
- Never overwrite existing hooks without explicit instruction
- New hooks default to WARN mode, not BLOCK (promote to block after validation)
- Never create hooks that bypass safety checks or auto-approve dangerous operations
- Always test with both positive and negative cases before registering
- Hook errors must fail open (pass the tool call through) not fail closed (block everything)
- Never modify `pretooluse-unified` or `posttooluse-unified` without reading them first
- Hooks must include clear, actionable messages when they trigger
