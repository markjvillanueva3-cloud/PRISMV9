# Check DSL Compatibility

You are verifying that PRISM code conforms to the system's internal DSL (Domain-Specific Language) patterns, schemas, and conventions. This catches compatibility issues before they become runtime errors.

## Args: $ARGUMENTS
- Empty: check all recently modified files
- `[file-path]`: check specific file
- `engines`: check all engines for DSL compliance
- `dispatchers`: check all dispatchers for DSL compliance
- `all`: full system DSL audit

## DSL Patterns to Verify

### 1. AtomicValue Compliance (Engines)
Every calculation engine must return `AtomicValue` objects, not raw numbers:
```typescript
// CORRECT
return { value: 1234.5, unit: 'N', uncertainty: 0.05, source: 'Kienzle model' }

// WRONG
return 1234.5
```
Check: grep for `return` statements in engine `calculate()` methods that return plain numbers.

### 2. Dispatcher Action Schema
Every dispatcher action must follow the standard pattern:
```typescript
{
  name: 'action_name',
  description: 'What this action does',
  parameters: { /* Zod schema */ },
  handler: async (params) => { /* implementation */ }
}
```
Check: verify all actions have name, description, parameters, and handler.

### 3. Parameter Normalization
Dispatchers must normalize input parameters before passing to engines:
- Material names → standardized format (uppercase, trimmed)
- Units → SI base units
- Tool types → canonical identifiers
Check: look for raw parameter pass-through without normalization.

### 4. Safety Score Integration
Any engine that produces safety-relevant output must integrate with SafetyEngine:
- Force calculations → must feed S(x) scoring
- Temperature calculations → must check thermal limits
- Tool life predictions → must flag cliff warnings
Check: safety-relevant engines that don't call SafetyEngine.

### 5. Hook Registration
Hooks must follow the registration pattern:
```typescript
export const hookDefinition: HookDefinition = {
  id: 'unique-hook-id',
  event: 'event-name',
  phase: 'pre' | 'post',
  handler: async (context) => { /* ... */ }
}
```
Check: hook files that don't export `hookDefinition`.

### 6. Roadmap Schema Compliance
Milestone envelopes must conform to `roadmapSchema.ts`:
- Required fields: id, title, track, status, units[]
- Units require: id, title, status, steps[]
- Steps require: number, instruction
Check: parse all envelopes against Zod schema.

### 7. Registry Data Schema
Registry entries must match their declared schemas:
- Materials: must have `category`, `subcategory`, properties
- Tools: must have `type`, `material`, `geometry`
- Machines: must have `type`, `axes`, `workspace`
Check: spot-check registry entries for missing required fields.

### 8. Cadence Function Signature
Cadence functions must follow the standard signature:
```typescript
export function cadenceFunctionName(context: CadenceContext): CadenceResult
```
Check: cadence files that don't export a function matching this pattern.

## Report Format
```
DSL COMPATIBILITY CHECK
=======================
Scope: [what was checked]

AtomicValue:     [PASS/N violations] — [details]
Action Schema:   [PASS/N violations] — [details]
Param Normal:    [PASS/N violations] — [details]
Safety Integration: [PASS/N violations] — [details]
Hook Registration: [PASS/N violations] — [details]
Roadmap Schema:  [PASS/N violations] — [details]
Registry Schema: [PASS/N violations] — [details]
Cadence Sigs:    [PASS/N violations] — [details]

Overall: [COMPATIBLE / N ISSUES]
```

For each violation, show:
- File path and line number
- What pattern was violated
- Suggested fix
