# Add to Matrix — Register Products in MASTER_INDEX

You are registering new PRISM products (engines, dispatchers, algorithms, hooks, cadences, formulas, registries) in the system's tracking matrix. This ensures nothing gets created without being properly cataloged.

## Args: $ARGUMENTS
- Empty: scan for unregistered products and offer to register them
- `[file-path]`: register the specific file
- `scan`: scan only, report what's missing without fixing
- `all`: register everything that's missing

## What Gets Registered

### MASTER_INDEX_COMPACT.md (`C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md`)
The single source of truth for all system components. Every product must appear here.

### Product Types and Where to Find Them
| Product | Source Directory | Registration Target |
|---------|-----------------|-------------------|
| Engines | `src/engines/*.ts` | MASTER_INDEX engine inventory |
| Dispatchers | `src/tools/dispatchers/*Dispatcher.ts` | MASTER_INDEX dispatcher list + `dispatchers/index.ts` |
| Algorithms | `src/algorithms/*.ts` | MASTER_INDEX algorithm inventory + AlgorithmRegistry |
| Hooks | `src/hooks/*.ts` | MASTER_INDEX hook inventory |
| Cadences | `src/cadences/*.ts` | MASTER_INDEX cadence inventory |
| Formulas | `data/formulas/*.json` | FormulaRegistry |
| Registries | `src/registries/*.ts` | MASTER_INDEX registry list |

## Scan Protocol
1. **Inventory filesystem**: For each product type, glob the source directory and collect all files
2. **Inventory MASTER_INDEX**: Read MASTER_INDEX_COMPACT.md and extract listed products per category
3. **Diff**: Find files that exist on disk but aren't in MASTER_INDEX
4. **Report**:
```
MATRIX SCAN
===========
Engines:      [X] on disk, [Y] in index — [Z] unregistered
Dispatchers:  [X] on disk, [Y] in index — [Z] unregistered
Algorithms:   [X] on disk, [Y] in index — [Z] unregistered
Hooks:        [X] on disk, [Y] in index — [Z] unregistered
...

Unregistered Products:
  ENGINE: NewCuttingEngine.ts — not in MASTER_INDEX
  DISPATCHER: newDispatcher.ts — not in index.ts or MASTER_INDEX
  ...
```

## Registration Protocol
For each unregistered product:

1. **Read the file** to understand what it does (class name, exports, purpose)
2. **Add to MASTER_INDEX_COMPACT.md** in the appropriate section with:
   - Name, file path, brief description
   - Action count (for dispatchers)
   - Category/domain classification
3. **Add to code registry** if applicable:
   - Dispatchers → `dispatchers/index.ts`
   - Algorithms → AlgorithmRegistry
   - Formulas → FormulaRegistry
4. **Update counts** in CLAUDE.md files if they reference totals
5. **Report**: `Registered: [product-name] in MASTER_INDEX + [registry]`

## Post-Registration Verification
- Run `npm run build` to verify no import errors
- Verify MASTER_INDEX counts match filesystem counts
- Report: `Matrix sync complete. [N] products registered.`

## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
