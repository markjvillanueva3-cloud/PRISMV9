# Forge Skills — Skill Discovery + Creation Autopilot

You are running a specialized autopilot pipeline focused on discovering, designing, building, and registering new skills that benefit the PRISM system and app. This command chains system analysis, skill identification, creation, testing, and registration into one continuous flow.

## Args: $ARGUMENTS
- Empty: full discovery — analyze the system, find skill gaps, create the best candidates
- `[skill-name]`: skip discovery, go straight to creating a specific skill
- `[count]`: create up to N skills (default: 3)
- `list`: just analyze and list skill opportunities without creating any

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when identifying skill opportunities.
- Consider every applicable calculation, analysis method, and domain-specific workflow that could become a skill.
- "Already covered" claims REQUIRE citing the SPECIFIC existing skill by name.
- **Completeness > Speed.** A missed skill opportunity means repeated manual work.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
Analyze the session:
1. Complexity: MODERATE-COMPLEX (skill creation requires understanding system patterns)
2. Domain: Systems Architecture + TypeScript Engineering + Automation
3. Roles: Principal Systems Architect + Senior TypeScript Engineer
4. Model: OPUS (skill design requires deep reasoning)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: System Analysis — Discover Skill Opportunities
Analyze the PRISM ecosystem to identify high-value skill candidates:

### 3A: Inventory Existing Skills
1. Read all files in `~/.claude/commands/` to catalog what exists
2. List all plugin-provided skills (skill-creator, hookify, ralph-loop, etc.)
3. Map the current skill coverage: what workflows are already automated?

### 3B: Identify Gaps
Analyze across these dimensions:

**Workflow Automation Gaps:**
- What multi-step tasks do users repeat manually that could be a single command?
- What `/autopilot` sub-phases could benefit from standalone commands?
- What cross-cutting concerns (safety, quality, performance) lack dedicated skills?

**System Synergy Gaps:**
- Which PRISM subsystems (engines, dispatchers, algorithms, registries) lack dedicated management skills?
- What chaining opportunities exist (skill A output feeds skill B)?
- What monitoring/observability workflows are missing?

**Developer Experience Gaps:**
- What debugging workflows are common but tedious?
- What onboarding/context-loading tasks could be streamlined?
- What code generation patterns repeat across the codebase?

**PRISM App-Specific Gaps:**
- Materials database operations (query, validate, update, compare)
- CAD engine operations (create, validate, export pipelines)
- Safety chain operations (audit S(x) scores, find weak links)
- Roadmap operations beyond existing `/rgs` and `/pick-task`

### 3C: Rank Candidates
Score each candidate on:
- **Impact** (HIGH/MEDIUM/LOW): How much time/effort does it save?
- **Frequency** (HIGH/MEDIUM/LOW): How often would it be used?
- **Complexity** (HIGH/MEDIUM/LOW): How hard is it to build?
- **Synergy** (HIGH/MEDIUM/LOW): How well does it integrate with existing skills?

Priority = (Impact * 3 + Frequency * 2 + Synergy * 2) / (Complexity * 1.5)

Present the ranked list:
```
SKILL OPPORTUNITIES
===================
Rank | Skill Name          | Impact | Freq | Synergy | Complexity | Score
-----|---------------------|--------|------|---------|------------|------
  1  | material-lookup     | HIGH   | HIGH | HIGH    | MEDIUM     | 9.3
  2  | safety-audit        | HIGH   | MED  | HIGH    | MEDIUM     | 8.1
  ...
```

If args = `list`, stop here.

## Phase 4: Design Skills
For each skill to create (top N from ranking or specified by args):

### 4A: Skill Architecture
Define:
- **Name**: kebab-case, clear and concise
- **Trigger patterns**: What user phrases should activate it?
- **Args**: What parameters does it accept?
- **Dependencies**: What other skills/tools does it use?
- **Output format**: What does it report when done?
- **Error handling**: What can go wrong and how to recover?

### 4B: Skill Content Design
Write the skill as a markdown command file following the established patterns:
- Clear header with title
- Args section with examples
- Step-by-step execution protocol
- Report format at the end
- Error handling section

Design each skill to:
- Follow existing command conventions (see `/autopilot`, `/ship`, `/check-dsl` as reference)
- Chain with existing skills where possible
- Include safety rails where relevant
- Be useful standalone AND as part of larger pipelines

## Phase 5: Create Skills
For each designed skill:
1. Write the command file to `~/.claude/commands/{skill-name}.md`
2. Verify the file was written correctly
3. Report: `Created: /skill-name — [brief description]`

## Phase 6: Test Skills
For each created skill:
1. Mentally trace through the execution path — does every step make sense?
2. Check for missing references (does it reference files/tools that exist?)
3. Check for circular dependencies with other skills
4. Verify the args parsing covers edge cases
5. If the skill-creator plugin supports evals, run them

Report:
```
SKILL VALIDATION
================
/skill-name:
  Steps reachable:    YES
  References valid:   YES
  No circular deps:   YES
  Args coverage:      YES
  Overall:            PASS
```

## Phase 7: Forge Postflight (`/forge-postflight skills` protocol)
Run the shared integration protocol for newly created skills:
1. **Gate 1 — DSL**: SKIP (skills are markdown, not PRISM code)
2. **Gate 2 — Matrix**: SKIP (skills are command files, not PRISM components)
3. **Gate 3 — Trace**: SKIP (no wiring for command files)
4. **Gate 4 — Sync**: RUN — verify skill count in MEMORY.md matches `~/.claude/commands/` on disk
5. **Gate 5 — Memory**: RUN — add new skill names and purposes to MEMORY.md inventory
6. **Gate 6 — Hookify**: RUN — evaluate if new skills should have autofire trigger rules (userpromptsubmit)

Report the postflight results before proceeding to commit.

## Phase 8: Auto-Commit (`/auto-commit` protocol)
If any skills were created:
1. Stage the new command files
2. Commit: `feat(skills): add [N] new skills — [list names] [FORGE-SKILLS]`
3. Report the commit

## Summary Report
```
FORGE SKILLS COMPLETE
=====================
Analyzed:     [N] system dimensions
Opportunities: [N] skill gaps identified
Created:      [N] skills
  - /skill-1 — [description]
  - /skill-2 — [description]
  - /skill-3 — [description]
Validated:    [N]/[N] passed
Committed:    [commit hash]

Total Skills: [N] (was [M])

Next: /forge-skills for more skills, /forge-hooks for hooks, or /autopilot for roadmap work
```

## Error Handling
- **No gaps found**: Rare but possible — report "System well-covered" and suggest niche improvements
- **Skill conflicts**: If a new skill overlaps heavily with an existing one, merge or extend rather than duplicate
- **Context budget**: If running low, create the highest-priority skill only and report remaining candidates
- **Write failure**: If command file can't be written, report the path issue

## Safety Rails
- Never overwrite existing commands without explicit instruction
- Never create skills that bypass safety checks (S(x), build verification)
- Always validate that skill references point to real files/tools
- Skills must follow PRISM conventions (no placeholders, no stubs)
