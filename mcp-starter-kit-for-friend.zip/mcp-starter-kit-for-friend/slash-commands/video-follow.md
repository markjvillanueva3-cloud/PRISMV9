# Video Follow — Interactive CAD/CAM Learning from Video

Step through a tutorial video interactively — review each action, correct mistakes, and teach the system as you go.

## Args: $ARGUMENTS
- Path to a local video file (mp4, avi, mkv, mov)
- Optional: `--target onshape|tinkercad|freecad|cadquery` (default: cadquery)

## How It Works

Unlike `/video-replay` (fully autonomous), `/video-follow` pauses at each step and asks for your confirmation or correction. This is ideal for:
- Complex tutorials where autonomous extraction might miss details
- Teaching the system your preferences and conventions
- Learning CAD yourself by following along with the video

## Pipeline

1. **Extract** keyframes and actions from video
2. **For each step:**
   - Show the extracted action (type, parameters, confidence)
   - If uncertain, ask a clarifying question
   - Wait for you to: **confirm**, **correct**, or **skip**
   - Execute the confirmed/corrected action
   - Show the result
3. **Accumulate** corrections as learning patterns
4. **Report** session summary with accuracy statistics

## Usage

```
/video-follow path/to/tutorial.mp4
/video-follow tutorial.mp4 --target onshape
```

## Execution

```
Smart: COMPUTER VISION SPECIALIST + CAD ENGINEER | OPUS | HIGH
```

### Step 1: Extract Actions
Same as /video-replay — extract keyframes and classify actions.

### Step 2: Start Interactive Session
```typescript
const session = interactiveLearningSessionEngine.startSession(videoPath, actions);
```

### Step 3: Step-by-Step Review
For each action in the sequence:

1. **Present** the action:
   ```
   Step 3/12 (@0:45): EXTRUDE
   Parameters: depth = 25mm
   Confidence: 0.82
   ```

2. **If confidence < 0.6**, ask a clarifying question:
   ```
   ❓ I'm not sure about this step. Is this an extrude (depth ~25mm)
      or a revolve? What should the depth/angle be?
   ```

3. **Wait for user response:**
   - "yes" / "confirm" → proceed with extracted action
   - "skip" → skip this step
   - Correction: "the depth should be 30mm" → apply correction

4. **Execute** the confirmed/corrected action and show result

### Step 4: Session Summary
Show: total steps, confirmed %, corrected %, accuracy, patterns learned.

## Benefits Over /video-replay
- Higher accuracy through human oversight
- Builds a correction pattern database that improves future runs
- Educational — you learn CAD while teaching the system
- Handles complex/ambiguous operations that autonomous mode might miss

## Engines Used
VideoActionExtractorEngine, InteractiveLearningSessionEngine, CadQueryCodeGeneratorEngine,
ExecutionVerificationEngine, VideoReplayOrchestratorEngine
