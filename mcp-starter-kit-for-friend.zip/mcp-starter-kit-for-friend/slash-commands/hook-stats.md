# Hook Stats — Token savings from hooks this session

Show how many tokens hooks have saved by blocking/warning/rewriting tool calls.

## Usage
- `/hook-stats` — show current session hook savings
- `/hook-stats top` — show top 5 hook savers
- `/hook-stats roi` — show ROI vs session budget

## Steps
1. Call hookEfficiencyEngine.getStats()
2. Display: total saves, tokens saved, by-action breakdown
3. If "top" → show topSavers with token counts
4. If "roi" → call getROI() and show budget % saved
5. Include getStatusLine() as compact summary
