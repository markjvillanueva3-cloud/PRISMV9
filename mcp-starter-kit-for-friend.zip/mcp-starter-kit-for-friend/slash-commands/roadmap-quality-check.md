# Roadmap Quality Check — Post-Compact Session Scrutiny

Run this AFTER every /compact to verify the session produced quality work.

## Step 1: Read What Was Built
Read C:/PRISM/state/HANDOFF.md to see what was done last session.

## Step 2: Verify Build Quality
```bash
cd C:/PRISM/mcp-server && npx tsc --noEmit 2>&1 | grep -c "error TS"
```
Must be 0 new errors from our code.

## Step 3: Code Review
Run `/prism-review` — 3 parallel agents (physics, wiring, test) review changes.

## Step 4: Verify Wiring
For every engine wired in the last session:
- Is it IMPORTED? (grep for require/import in pipeline file)
- Is it CALLED? (grep for method call in pipeline file)
- Is the RESULT used? (grep for result variable usage)
- If imported but not called → FLAG as dead import
- If called but result discarded → FLAG as wasted computation

## Step 5: Verify No Conflicting Constants
```bash
cd C:/PRISM/mcp-server && grep -n "kc1_1.*1800\|kc1_1.*2000\|kc1_1.*2100" src/engines/*.ts | grep -v constants.ts | grep -v test
```
All kc1.1 values must match src/physics/constants.ts.

## Step 6: Verify No Duplicate Computations
Check: is force/life/Ra computed more than once for the same operation?
If yes → the second computation should READ the first result, not recompute.

## Step 7: Run Tests
```bash
cd C:/PRISM/mcp-server && npx vitest run 2>&1 | tail -5
```
Must be 0 regressions.

## Step 8: Report
Output a quality scorecard:
```
ROADMAP QUALITY CHECK
=====================
Build:          [PASS/FAIL] [N] errors
Code Review:    [PASS/FAIL] [issues found]
Wiring:         [N] engines wired, [N] actually called, [N] dead imports
Constants:      [CONSISTENT/CONFLICT]
Duplicates:     [NONE/N duplicate computations found]
Tests:          [N] passing, [N] failing, [N] regressions
Quality:        [PASS/NEEDS-WORK]
```
