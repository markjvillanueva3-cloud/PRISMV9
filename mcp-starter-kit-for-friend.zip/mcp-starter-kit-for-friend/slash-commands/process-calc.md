# Process Calc — Unified Manufacturing Process Calculator

Run a complete process calculation chain: material lookup, force prediction, power budget, and safety check in one command.

## Args: $ARGUMENTS
- Empty: interactive — ask for operation type, material, tool, and parameters
- `turning [material] [Vc] [f] [ap]`: turning force calculation
- `tapping [material] [thread-size] [blind|through]`: tapping torque + breakage risk
- `budget [machine-power-kW] [Vc] [ap]`: power budget + inverse feed solver
- `full [material] [operation]`: complete chain (force → power → safety)

## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (chained engine calls with parameter normalization)
2. Domain: Manufacturing Process + Applied Mechanics
3. Roles: Manufacturing Process Expert + Senior TypeScript Engineer
4. Model: SONNET
5. Effort: MEDIUM

## Phase 2: Parameter Resolution
Based on args, resolve all needed parameters:

### For Turning:
1. Look up material ISO group and kc1.1 from material name/ID
2. Default parameters: Vc=200 m/min (P), f=0.2 mm/rev, ap=2 mm, kr=95deg
3. Override with any user-specified values

### For Tapping:
1. Parse thread size (M6, M8, M10, M12, etc.) → diameter + pitch
2. Determine tap type (cut_spiral_point default, form if specified)
3. Default engagement 75%, coolant active

### For Power Budget:
1. Machine power in kW (default 15)
2. Tool or workpiece diameter for RPM calculation
3. ISO group for kc estimation

## Phase 3: Execute Calculations

### Turning Chain:
```
1. prism_calc → turning_force
   Input: Vc, f, ap, kr, iso_group, workpiece_diameter
   Output: Fc, Ff, Fp, power_kW, torque_Nm

2. prism_calc → power_budget
   Input: machine_power, Vc, ap, workpiece_diameter, feed_mm_rev
   Output: utilization_pct, max_feed, max_MRR, limiting_factor

3. Safety assessment from engine results
```

### Tapping Chain:
```
1. prism_calc → tapping_torque
   Input: thread_diameter, pitch, tap_type, hole_type, iso_group
   Output: torque_Nm, thrust_N, breakage_risk, max_safe_rpm

2. If spindle torque provided → check torque margin
3. Safety assessment from breakage risk
```

### Power Budget Chain:
```
1. prism_calc → power_budget
   Input: machine_power, Vc, ap, tool/workpiece diameter, feed, iso_group
   Output: required vs available power/torque, utilization, max feed, max MRR

2. Identify limiting factor (power vs torque)
3. Recommendation for parameter adjustment
```

## Phase 4: Output Process Card

Format results as a compact process card:

```
PROCESS CARD — [Operation] [Material]
========================================
Parameters:
  Vc = [X] m/min    f = [X] mm/rev    ap = [X] mm
  RPM = [X]         Tool: [description]

Forces:
  Fc = [X] N (tangential)    Ff = [X] N (feed)    Fp = [X] N (radial)
  Resultant = [X] N

Power & Torque:
  Required: [X] kW / [X] Nm
  Available: [X] kW / [X] Nm
  Utilization: [X]% ([power|torque] limited)

Envelope:
  Max feed at limit: [X] mm/rev
  Max MRR: [X] cm3/min

Safety: [SAFE / WARNING / UNSAFE]
  [recommendations from engines]
```

## Error Handling
- Missing material: use ISO group P (steel) defaults with warning
- Missing tool diameter: prompt user or use 20mm default
- Engine returns is_safe=false: highlight in red, show max safe parameters
- If any engine call fails: report partial results, note which calculation failed
