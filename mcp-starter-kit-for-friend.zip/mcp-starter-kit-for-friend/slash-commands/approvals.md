# /approvals — Approval Workflow & Timeline Management

Manage approval workflows, submit entities for approval, view pending decisions,
and browse record timelines and comments.

## Engine Coverage
- **ApprovalWorkflowEngine** — configurable multi-step approval chains with role-based routing,
  self-approval prevention, delegation, $0 exploit blocking, and cancel restrictions
- **RecordTimelineEngine** — immutable per-entity event log with threaded comments, file
  attachments, and auto-population from EventBus approval events

## Actions (via prism_business dispatcher)
### Approval Workflow
- `workflow_configure` — create/update a named workflow (entity_type, steps, thresholds)
- `workflow_submit` — submit an entity for approval (entity_type, entity_id, submitted_by, amount)
- `workflow_decide` — approve/reject a pending instance (instance_id, decider, decision, decider_roles)
- `workflow_pending` — list pending approvals for a decider
- `approval_workflow_status` — get detailed status of an approval instance
- `workflow_cancel` — cancel a pending approval (submitter only)
- `approval_workflow_list` — list all configured workflows
- `workflow_stats` — approval statistics (submitted, approved, rejected counts)
- `workflow_requires_approval` — check if an entity/amount requires approval
- `workflow_entity_history` — full approval history for a specific entity

### Record Timeline & Comments
- `timeline_get` — get timeline for an entity (entity_type, entity_id)
- `timeline_add` — add a manual timeline entry
- `comment_create` — create a threaded comment on an entity
- `comment_list` — list comments for an entity
- `comment_edit` — edit an existing comment (author only)
- `comment_delete` — soft-delete a comment (author only)

## Routes
- `POST /api/v1/erp/workflows` — configure workflow
- `POST /api/v1/erp/workflows/submit` — submit for approval
- `POST /api/v1/erp/workflows/decide` — approve/reject
- `GET  /api/v1/erp/workflows/pending` — pending approvals
- `POST /api/v1/erp/workflows/status` — instance status
- `POST /api/v1/erp/workflows/cancel` — cancel approval
- `GET  /api/v1/erp/workflows/list` — list workflows
- `GET  /api/v1/erp/workflows/stats` — stats
- `POST /api/v1/erp/timeline` — get timeline
- `POST /api/v1/erp/timeline/add` — add entry
- `POST /api/v1/erp/comments` — create comment
- `POST /api/v1/erp/comments/list` — list comments

## Usage
When the user asks about approval workflows, pending approvals, record timelines,
audit trails, or comment threads, use the actions above via the prism_business
dispatcher. Default workflows are seeded for: quote ($2500), purchase_order
($2500/$10000), invoice ($1000), payroll, and ncr.

$ARGUMENTS
