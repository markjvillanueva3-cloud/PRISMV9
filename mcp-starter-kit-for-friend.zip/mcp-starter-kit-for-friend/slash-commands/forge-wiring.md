# Forge Wiring — Architecture Wiring Validator

You are running a specialized autopilot pipeline that validates the full dispatcher-to-engine-to-algorithm wiring chains across the PRISM 11-layer architecture. Designed to run in the **background** — produces a wiring integrity report.

## Args: $ARGUMENTS
- Empty: full wiring validation — all dispatchers, engines, algorithms, hooks
- `[dispatcher]`: trace wiring for a specific dispatcher
- `[engine]`: trace wiring for a specific engine
- `orphans`: only find orphaned (unwired) components
- `dead`: only find dead exports and phantom references
- `quick`: count-level checks only

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL wiring paths** — every dispatcher→engine→algorithm chain must be traced.
- "Fully wired" claims REQUIRE citing specific import paths and switch cases.
- Check every engine export against dispatcher switch cases and registry entries.
- **Completeness > Speed.** An unwired engine is a dead capability.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: COMPLEX (deep cross-file analysis, import graph traversal)
2. Domain: Systems Architecture + PRISM 11-Layer Model
3. Roles: Principal Systems Architect + Integration Engineer
4. Model: OPUS (graph analysis requires careful reasoning)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Wiring Graph Construction

### 3A: Inventory Components
Scan and catalog all components:

**Dispatchers** (`C:/PRISM/mcp-server/src/tools/dispatchers/`):
- Glob all `*Dispatcher.ts` files
- For each: extract action list (case statements), imported engines, imported algorithms
- Record: name, file, action count, engine imports, algorithm imports

**Engines** (`C:/PRISM/mcp-server/src/engines/`):
- Glob all `*Engine.ts` and `*engine.ts` files
- For each: extract exported class/functions, imported dependencies
- Record: name, file, exports, import count

**Algorithms** (`C:/PRISM/mcp-server/src/algorithms/`):
- Glob all `*Algorithm.ts` and `*.algorithm.ts` files
- For each: extract exported functions, compute/calculate methods
- Record: name, file, exports

**Hooks** (`C:/PRISM/mcp-server/src/hooks/`):
- Glob all `*Hook.ts` files
- For each: extract trigger conditions, referenced dispatchers/engines
- Record: name, file, triggers

### 3B: Build Import Graph
For each file, trace imports:
1. Direct imports: `import { X } from './engines/Y'`
2. Re-exports: `export { X } from './engines/Y'`
3. Dynamic imports: `await import('./engines/Y')`
4. Index barrel exports: `index.ts` re-export chains

Build adjacency list: `dispatcher → [engines] → [algorithms]`

### 3C: Validate Wiring Chains

**Forward validation** (dispatcher → engine):
- For each dispatcher action, does it call at least one engine?
- For each engine call, does the engine file exist and export the called function?
- For each engine, does it call algorithms it imports?

**Reverse validation** (engine → dispatcher):
- For each engine, is it imported by at least one dispatcher?
- For each algorithm, is it imported by at least one engine?
- For each hook, is it referenced in the hook registry?

**Chain completeness** (L0 → L10):
- Does each chain have: dispatcher (L2) → engine (L4-L6) → algorithm (L7)?
- Are safety hooks (L3) wired for safety-relevant dispatchers?
- Are cadences (L9) wired for relevant engines?

## Phase 4: Wiring Report

### 4A: Findings Classification

**CRITICAL — Broken Wiring:**
- Dispatcher imports engine that doesn't exist (broken import)
- Engine exports function that no dispatcher calls (dead export — SYS-MS4 found 64 of these)
- Dispatcher action calls undefined engine method
- Circular dependency detected

**MAJOR — Missing Wiring:**
- Engine exists but no dispatcher imports it (orphaned engine)
- Algorithm exists but no engine uses it (orphaned algorithm)
- Hook references dispatcher that doesn't exist
- Registry lists component that doesn't exist on disk

**MINOR — Weak Wiring:**
- Engine imported but only partially used (some exports unused)
- Dispatcher has actions with no engine call (stub actions)
- Hook has overlapping triggers with another hook
- Long import chains (>3 hops from dispatcher to algorithm)

### 4B: Structured Report
```
FORGE WIRING REPORT
====================
Components: [D] dispatchers, [E] engines, [A] algorithms, [H] hooks
Chains:     [N] complete, [M] broken, [X] partial
Coverage:   [Y]% of engines wired

BROKEN WIRING (CRITICAL):
  [dispatcher:action] → [engine.method] — file not found
  ...

ORPHANED COMPONENTS (MAJOR):
  Engines:     [list of engines with no dispatcher import]
  Algorithms:  [list with no engine import]
  Hooks:       [list not in hook registry]

DEAD EXPORTS (MAJOR):
  [engine]: [export1], [export2] — exported but never imported
  ...

STUB ACTIONS (MINOR):
  [dispatcher]: [action1], [action2] — no engine call
  ...

WIRING GRAPH SUMMARY:
  dispatchers → engines:    [N] connections
  engines → algorithms:     [N] connections
  hooks → dispatchers:      [N] connections
  Average chain depth:      [N] hops
  Longest chain:            [dispatcher] → ... → [algorithm] ([N] hops)

INTEGRITY SCORE: [N]% ([M] issues across [X] components)
```

## Phase 5: Forge Postflight (`/forge-postflight wiring`)
1. **Gate 1 — DSL**: CONDITIONAL — if wiring issues found in safety chain
2. **Gate 2 — Matrix**: SKIP (no new products)
3. **Gate 3 — Trace**: RUN — use trace to verify critical chains
4. **Gate 4 — Sync**: RUN — compare wiring counts to known values
5. **Gate 5 — Memory**: RUN — update MEMORY.md with wiring integrity score
6. **Gate 6 — Hookify**: SKIP

## Phase 6: Auto-Commit
Only if dead exports were removed or broken imports fixed:
`fix(wiring): remove [N] dead exports, fix [M] broken imports [FORGE-WIRING]`

## Summary Report
```
FORGE WIRING COMPLETE
=====================
Scanned:     [D] dispatchers, [E] engines, [A] algorithms, [H] hooks
Chains:      [N] validated
Integrity:   [X]%
Orphaned:    [N] components
Dead:        [N] exports
Broken:      [N] imports
Next:        Fix broken imports, then /forge-wiring quick to verify
```

## Error Handling
- **Import resolution failure**: Log and continue — don't fail entire scan
- **Dynamic imports**: Flag as "unresolvable at static analysis time"
- **Context budget**: Run in quick mode (counts + broken imports only)
- **Large graph**: Process dispatchers in batches of 10

## Safety Rails
- READ-ONLY by default — never modify source code without explicit `fix` arg
- Never remove engine files — only flag as orphaned for manual review
- Never modify dispatcher action lists — only report gaps
- Dead export removal requires running full test suite after
- Safety chain wiring is always reported, never auto-fixed
