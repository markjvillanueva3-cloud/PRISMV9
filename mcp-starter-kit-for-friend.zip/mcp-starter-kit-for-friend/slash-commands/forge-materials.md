# Forge Materials — Material Database Pipeline Autopilot

You are running a specialized autopilot pipeline focused on the PRISM materials database — finding data gaps, generating missing properties, validating against published handbooks, running accuracy passes, and maintaining the 6,346-material database.

## Args: $ARGUMENTS
- Empty: full audit — analyze the database, find gaps, improve the worst areas
- `[material-name]`: focus on a specific material (e.g., "AISI 4340", "Ti-6Al-4V")
- `[category]`: focus on a category (P_STEELS, M_STAINLESS, K_CAST_IRON, N_NONFERROUS, S_SUPERALLOYS, H_HARDENED, X_SPECIALTY)
- `validate [alloy]`: validate a material's data against published values
- `compare [alloy1] [alloy2]`: compare two materials side-by-side
- `accuracy`: run accuracy metrics across the entire database
- `compositions`: check composition coverage and fill gaps
- `list`: just analyze and list data gaps without fixing any
- `spot-check`: validate 10 well-known alloys against handbook data

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** for material property modeling.
- Consider every constitutive model, phase diagram, empirical correlation, and thermodynamic relationship.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing material science coverage.
- **Completeness > Speed.** A missed material model is a permanent capability gap.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.

## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: COMPLEX (material science requires precise domain knowledge)
2. Domain: Manufacturing/Materials + Data Analysis + Python Engineering
3. Roles: Manufacturing Process Expert + Data Scientist + Senior Python Engineer
4. Model: OPUS (material data accuracy requires deep domain expertise)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Database Analysis

### 3A: Current State Assessment
1. Read `C:/PRISM/data/materials/MASTER_INDEX.json` for database metadata
2. Count materials per category:
   - P_STEELS: 2719 | M_STAINLESS: 822 | K_CAST_IRON: 122
   - N_NONFERROUS: 931 | S_SUPERALLOYS: 132 | H_HARDENED: 363
   - X_SPECIALTY: 1257
3. Check `_accuracy` metadata distribution:
   - How many have `confidence: HIGH`?
   - How many still have `confidence: LOW` or `ESTIMATED`?
4. Check composition coverage: metals should be 100% (5089/5089)

### 3B: Identify Data Gaps
Analyze across these dimensions:

**Missing Properties:**
- Materials with < 127 parameters
- Materials missing critical properties (yield_strength, thermal_conductivity, hardness)
- Materials missing machining properties (Kienzle kc11, Taylor coefficients)
- Materials missing Johnson-Cook parameters

**Low Confidence Data:**
- Properties tagged as `confidence: LOW` or `ESTIMATED`
- Properties using group-level defaults instead of alloy-specific values
- Properties without cited sources

**Composition Gaps:**
- Materials without composition data (especially X_SPECIALTY non-metals)
- Compositions missing key elements
- Compositions that don't sum to ~100%

**Validation Issues:**
- Properties that deviate >20% from published handbook values
- Inconsistent units or conversion errors
- Properties that violate physical constraints (e.g., negative thermal conductivity)

**Subcategory Resolution:**
- Materials with only ISO group classification (P, M, K, etc.)
- Materials not resolved to a subcategory (e.g., "alloy_steel_chromoly" vs just "alloy_steel")

### 3C: Quality Metrics
```
MATERIALS DATABASE AUDIT
=========================
Total Materials:     6,346
By Category:         P:[N] M:[N] K:[N] N:[N] S:[N] H:[N] X:[N]

Confidence Distribution:
  HIGH:              [N] ([X]%)
  MEDIUM_HIGH:       [N] ([X]%)
  MEDIUM:            [N] ([X]%)
  LOW:               [N] ([X]%)
  ESTIMATED:         [N] ([X]%)

Composition Coverage:
  Metals (6 cats):   [N]/5089 ([X]%)
  X_SPECIALTY:       [N]/1257 ([X]%)

Property Completeness:
  >= 127 params:     [N] ([X]%)
  >= 100 params:     [N] ([X]%)
  < 100 params:      [N] ([X]%)

Top Gaps:
  [category] — [N] materials need [property] improvement
  ...
```

If args = `list` or `accuracy`, stop here.

## Phase 4: Improve Materials Data
For each identified gap (prioritized by impact):

### 4A: Alloy-Specific Data (highest priority)
For well-known alloys (4340, 304, 7075-T6, Ti-6Al-4V, etc.):
1. Look up published data from handbooks (ASM, Machining Data Handbook, Sandvik)
2. Cross-reference with existing `alloy_physical_properties_db.py` (415 alloys)
3. Update the material JSON with alloy-specific values
4. Set confidence to HIGH with source citation

### 4B: Subcategory Refinement
For materials with only group-level data:
1. Resolve to the most specific subcategory possible
2. Apply subcategory-specific defaults (better than group-level)
3. Scale properties by hardness/composition where applicable
4. Set confidence to MEDIUM_HIGH

### 4C: Composition Enhancement
For materials missing compositions:
1. Check `alloy_compositions_db.py` (700+ compositions)
2. Use composition to derive thermal conductivity, specific heat
3. Use `k = k_iron * product(1 - alpha_i * wt%_i)` for steel thermal conductivity
4. Update composition-derived properties

### 4D: Validation Against Handbooks
For the spot-check set (or specified alloys):
1. Compare PRISM values against published handbook data
2. Flag any deviation > 10% as a potential error
3. Correct errors with handbook values
4. Document the source

Reference alloys for spot-check:
- AISI 1045, AISI 4340, AISI 304, AISI 316L, AISI D2
- AA 7075-T6, AA 6061-T6
- Ti-6Al-4V
- Inconel 718
- GG25 (gray cast iron)

## Phase 5: Run Enhancement Script (if needed)
If systematic improvements are needed:
1. Use or update `C:/PRISM/scripts/materials_deep_accuracy_v2.py`
2. Run with targeted scope (single category or subcategory)
3. Verify zero errors
4. Check that param count remains >= 127 for all materials

## Phase 6: Validate Results
After improvements:
1. Spot-check 10 materials against published data
2. Verify no material lost parameters (count >= 127)
3. Verify confidence distribution improved
4. Verify composition coverage maintained
5. Run any materials-related tests

```
VALIDATION RESULTS
==================
Spot-Check (10 alloys):
  [alloy]: [N] properties checked, [N] within 10% of handbook — [PASS/FAIL]
  ...

Parameter Integrity:
  All >= 127 params:  YES/NO
  Materials affected: [N]

Confidence Improvement:
  HIGH:     [before]% → [after]%
  LOW:      [before]% → [after]%
```

## Phase 7: Forge Postflight (`/forge-postflight materials` protocol)
Run the shared integration protocol for materials database changes:
1. **Gate 1 — DSL**: SKIP (material data is JSON, not PRISM code)
2. **Gate 2 — Matrix**: SKIP (materials are data, not code components)
3. **Gate 3 — Trace**: SKIP (materials don't participate in wiring chains)
4. **Gate 4 — Sync**: RUN — verify material counts and confidence metrics in MEMORY.md match actual database
5. **Gate 5 — Memory**: RUN — update MEMORY.md Materials section with new accuracy/coverage metrics
6. **Gate 6 — Hookify**: SKIP (material data changes don't need autofire rules)

Report the postflight results before proceeding to commit.

## Phase 8: Auto-Commit (`/auto-commit` protocol)
1. Stage updated material JSON files
2. Commit: `data(materials): improve [N] materials — [summary] [FORGE-MATERIALS]`
3. Report the commit

## Summary Report
```
FORGE MATERIALS COMPLETE
========================
Analyzed:      [N] materials across [N] categories
Gaps Found:    [N] data gaps
Improved:      [N] materials
  Alloy-specific upgrades:  [N]
  Subcategory refinements:  [N]
  Composition additions:    [N]
  Corrections:              [N]

Confidence Before → After:
  HIGH:          [X]% → [Y]%
  MEDIUM_HIGH:   [X]% → [Y]%
  LOW/ESTIMATED: [X]% → [Y]%

Composition: [X]% → [Y]%
Spot-Check:  [N]/10 alloys validated
Committed:   [commit hash]

Next: /forge-materials [category] for deeper work, /forge-safety for safety chain
```

## Error Handling
- **Conflicting handbook data**: Use the most authoritative source (ASM > Sandvik > calculated)
- **Missing reference data**: Use parametric models with MEDIUM confidence
- **Script errors**: Fix the script, don't manually edit 6,346 files
- **Context budget**: Improve the highest-priority category only, report remaining work

## Safety Rails
- Never reduce a material's parameter count below 127
- Never overwrite HIGH confidence data with lower confidence data
- Never change compositions without verifying they sum to ~100%
- Always preserve `_accuracy` metadata — update it, don't delete it
- Cite sources for every property change
- Never apply steel formulas to non-metals (X_SPECIALTY ceramics, polymers)
- Validate against at least 3 materials after any systematic change
- Back up the original data before running batch scripts
