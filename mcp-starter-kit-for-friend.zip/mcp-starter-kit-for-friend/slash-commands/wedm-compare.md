---
name: wedm-compare
description: Compare Wire EDM programs, parameters, and results
version: 1.0.0
engines:
  - WEDMProgramAnalyzerEngine
  - WedmProgramIndexEngine
  - JMDieProgramAnalyzerEngine
  - WEDMCalculatorAIEngine
actions:
  - wedm_compare_programs
  - wedm_compare_params
  - wedm_analyze_program
  - wedm_search_similar
hooks:
  - hook_wedm_comparison_sanity
triggers:
  - "compare wedm"
  - "wedm diff"
  - "compare edm programs"
  - "parameter comparison"
---

# /wedm-compare — Wire EDM Comparison Analysis

Compare WEDM programs, parameters, and results:
- Program-to-program diff
- Parameter effectiveness analysis
- Historical comparison
- Optimization opportunities

## Usage

```
/wedm-compare <target1> <target2> [options]
```

## Arguments

- `target1` — First program/parameter set/result
- `target2` — Second program or "optimal" or "similar"
- `--aspect` — Comparison focus (all|params|toolpath|time|quality)
- `--depth` — Analysis depth (quick|standard|deep)
- `--output` — Output format (summary|detailed|report)

## Comparison Modes

| Mode | Compares | Use Case |
|------|----------|----------|
| `programs` | Two NC programs | Before/after optimization |
| `params` | Parameter sets | E-code comparison |
| `results` | Actual outcomes | Production analysis |
| `optimal` | Against neural optimal | Improvement finding |
| `similar` | Against similar jobs | Pattern matching |

## Analysis Aspects

### Parameters
- ON/OFF time differences
- Current settings
- Servo voltage
- Wire tension/speed
- Flushing pressure

### Toolpath
- Cut sequence order
- Approach/retract strategy
- Corner handling
- Lead-in/lead-out

### Performance
- Cycle time
- Wire consumption
- Surface finish achieved
- Break frequency

## Output

```json
{
  "comparison": {
    "target1": "O1234.NC",
    "target2": "O5678.NC",
    "mode": "programs"
  },
  "summary": {
    "similarity_score": 0.73,
    "key_differences": 4,
    "recommendation": "target2 preferred for thick sections"
  },
  "parameters": {
    "on_time_us": { "t1": 4.2, "t2": 4.8, "diff": "+14%", "impact": "faster but rougher" },
    "off_time_us": { "t1": 12.0, "t2": 10.0, "diff": "-17%", "impact": "higher MRR" },
    "peak_current_A": { "t1": 180, "t2": 200, "diff": "+11%", "impact": "more aggressive" }
  },
  "toolpath": {
    "sequence_match": 0.85,
    "differences": [
      "Lead-in angle: 45° vs 90°",
      "Corner strategy: loop vs slow"
    ]
  },
  "performance": {
    "estimated_time": { "t1": 52, "t2": 45, "diff": "-13%" },
    "predicted_ra": { "t1": 0.72, "t2": 0.85, "diff": "+18%" },
    "wire_break_risk": { "t1": 0.03, "t2": 0.08, "diff": "+167%" }
  },
  "recommendations": [
    "Use T1 parameters for finish quality",
    "Use T2 approach strategy for time savings",
    "Consider hybrid: T2 roughing with T1 finish"
  ]
}
```

## Examples

```bash
# Compare two programs
/wedm-compare O1234.NC O5678.NC

# Compare against optimal
/wedm-compare current.nc optimal --material D2

# Find similar historical jobs
/wedm-compare newpart.dxf similar --aspect params

# Deep parameter analysis
/wedm-compare E1234 E5678 --aspect params --depth deep

# Generate full report
/wedm-compare prog1.nc prog2.nc --output report
```

## Comparison Sanity Hook

`hook_wedm_comparison_sanity` ensures:
- Same material type (or flags difference)
- Similar thickness range
- Compatible machine controllers
- Valid parameter ranges

## Similar Job Matching

Uses `WedmProgramIndexEngine` to find:
- Same customer patterns
- Similar geometries
- Matching materials/thicknesses
- Historical success rates

## Leverages

- `WEDMProgramAnalyzerEngine` — NC code analysis
- `WedmProgramIndexEngine` — 2,500+ program database
- `JMDieProgramAnalyzerEngine` — JM Die historical patterns
- `WEDMCalculatorAIEngine` — Performance predictions
