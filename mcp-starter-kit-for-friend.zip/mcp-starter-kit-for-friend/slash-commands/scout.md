---
effort: medium
maxTurns: 15
disallowedTools:
  - Edit
---

# Scout — Discover New MCP Servers, Plugins, Tools & Claude Features

Scans public sources for new capabilities that PRISM should integrate. Adds findings to a prioritized build queue. Run periodically (weekly) or on-demand.

## Args: $ARGUMENTS
- Empty: full scan (MCP servers + plugins + tools + Claude features)
- `mcp`: scan MCP server registries only
- `plugins`: scan Claude plugin ecosystem only
- `features`: scan Claude release notes only
- `tools`: scan AI tool ecosystem (LangChain, CrewAI, etc.)
- `queue`: show current build queue without scanning

## Step 1: Scan Sources

### MCP Server Discovery
Search these sources for new/updated MCP servers:
```
WebSearch: "MCP server" site:github.com created:>2025-01-01
WebSearch: "modelcontextprotocol" new server 2025 2026
WebSearch: smithery.ai MCP servers manufacturing CNC CAD
WebSearch: glama.ai MCP marketplace new
WebFetch: https://github.com/modelcontextprotocol/servers (official registry)
WebFetch: https://smithery.ai/explore (community registry)
```
For each found: extract name, description, relevance to manufacturing/CNC/CAD/ERP.
Score relevance 0-10 for PRISM integration value.

### Claude Plugin Discovery
```
WebSearch: Claude Code plugin 2025 2026 new
WebSearch: claude.ai plugins marketplace
WebSearch: "claude-plugins" npm package
```
Check our existing plugins: `ls ~/.claude/plugins/`

### Claude Feature Discovery
```
WebSearch: "Claude Code" changelog release notes 2025 2026
WebSearch: anthropic Claude new features API update
WebFetch: https://docs.anthropic.com/en/docs/about-claude/models (model updates)
WebFetch: https://code.claude.com/docs/en/changelog (Claude Code changelog)
```
Compare to our version (2.1.81). Flag features we don't have.

### AI Tool Ecosystem
```
WebSearch: LangChain manufacturing CNC tools 2025
WebSearch: CrewAI manufacturing agents
WebSearch: "function calling" CNC machining AI
WebSearch: CAD AI generation open source 2025 2026
```

## Step 2: Filter & Score

For each finding, evaluate:
- **PRISM relevance** (0-10): Does it help CNC programming, quoting, quality, learning?
- **Effort** (S/M/L/XL): How hard to integrate?
- **Overlap**: Do we already have this? (check ENGINE_DIGEST.md, MASTER_INDEX)
- **ROI**: manufacturing_impact / effort

Discard anything scoring < 5 relevance or that we already have.

## Step 3: Add to Build Queue

Save findings to `C:/PRISM/state/scout/build-queue.json`:
```json
{
  "scanned_at": "ISO timestamp",
  "sources_checked": ["github", "smithery", "changelog", ...],
  "findings": [
    {
      "name": "mcp-server-cad-viewer",
      "type": "mcp_server",
      "source_url": "https://...",
      "description": "3D CAD viewer MCP server",
      "relevance_score": 8,
      "effort": "M",
      "roi": 4.0,
      "overlap_with": "none | EngineName if exists",
      "priority": 1,
      "status": "queued | building | complete | rejected"
    }
  ]
}
```

## Step 4: Report

```
SCOUT REPORT — [date]
=====================
Sources scanned: [N]
Findings: [N] total | [N] high-relevance | [N] already-have

TOP PICKS (relevance >= 7):
  1. [name] — [description] | Relevance: [N] | Effort: [S/M/L] | ROI: [N]
  2. ...

NEW CLAUDE FEATURES (not in our version):
  - [feature] — [description] — available in v[X.Y.Z]
  ...

BUILD QUEUE: [N] items queued | [N] in progress | [N] complete

Next: /forge-from-scout to generate roadmap and build top picks
```

## Chaining
- Weekly scan: `/loop 7d /scout`
- Build top picks: `/scout` → `/forge-from-scout`
- Check queue: `/scout queue`
