# Safety Audit — PRISM Safety Chain Inspector

You are auditing PRISM's safety chain: the multi-layer defense system that prevents unsafe machining parameters from reaching production. This includes S(x) scoring, SafetyBlockError, cross-field physics validation, schema validation, and safety-classified algorithms. Use this to find weak links, verify coverage, or audit S(x) scores.

## Args: $ARGUMENTS
- Empty: full safety chain audit (all layers)
- `chain`: trace the safety chain flow (input → validation → physics → scoring)
- `coverage`: check which dispatchers/engines have safety integration
- `scores`: audit S(x) safety scoring implementation
- `physics`: run cross-field physics validation checks
- `critical`: list all safety-critical algorithms and their test coverage
- `blocks`: find all SafetyBlockError throw sites
- `weak`: find weak links (safety gaps, unchecked paths, missing validations)
- `[dispatcher-name]`: audit safety for a specific dispatcher

## Safety Chain Architecture
```
Input → Zod Schema Validation → Engine Calculation → Safety Calc Schema
  → Cross-Field Physics Validation → S(x) Score → APPROVED/BLOCKED
```

### Layer 1: Input Validation (Zod Schemas)
- `safetyActionSchemas.ts`: action-specific input validation
- Validates parameter types, ranges, required fields
- Catches: wrong types, missing params, out-of-range values

### Layer 2: Engine Calculation
- Algorithms with safety classification (critical/standard/informational)
- Critical algorithms must never produce unsafe values
- Division-by-zero guards, NaN checks, infinity guards

### Layer 3: Safety Calc Schema
- `safetyCalcSchema.ts`: structured output validation
- Ensures calculations return proper `{value, unit, uncertainty, source}` format
- AtomicValue pattern compliance

### Layer 4: Cross-Field Physics
- `crossFieldPhysics.ts`: imperative validation of physical relationships
- RPM consistency: n_rpm ≈ (Vc × 1000) / (π × D)
- Force plausibility by material hardness
- Tool life vs speed inverse (Taylor's law)
- Feed rate limits by material class
- Thermal limits: chip temperature < material melting point

### Layer 5: S(x) Safety Scoring
- Binary APPROVED (S(x) ≥ 0.70) / BLOCKED (S(x) < 0.70)
- SafetyBlockError thrown on block → prevents unsafe output
- No partial credit — failed checks = score 0

## Step 1: Parse Query and Execute

### Full Audit (`/safety-audit`)
Run all checks in sequence:
1. Read safetyDispatcher.ts — count actions, verify all 5 action categories wired
2. Read crossFieldPhysics.ts — verify all physics checks active
3. Read safetyCalcSchema.ts — verify structured output validation
4. Grep for SafetyBlockError throw sites across entire codebase
5. Check all critical algorithms have test coverage
6. Report:
```
SAFETY AUDIT REPORT
====================
Input Validation:
  Zod schemas:        [N] actions covered / [N] total safety actions
  Missing schemas:    [list any uncovered actions]

Engine Safety:
  Critical algorithms: [N] (all tested: [YES/NO])
  Division guards:     [N] files checked, [N] unguarded divisions found
  NaN/Infinity:        [N] files checked, [N] unchecked outputs found

Cross-Field Physics:
  Physics checks:      [N] active
  RPM consistency:     [ACTIVE/MISSING]
  Force plausibility:  [ACTIVE/MISSING]
  Tool life vs speed:  [ACTIVE/MISSING]
  Feed rate limits:    [ACTIVE/MISSING]
  Thermal limits:      [ACTIVE/MISSING]

S(x) Scoring:
  Block threshold:     0.70
  SafetyBlockError:    [N] throw sites across [N] files
  Binary scoring:      [VERIFIED — no partial credit]

Verdict: [SECURE / N WEAK LINKS FOUND]
```

### Coverage (`/safety-audit coverage`)
Check which dispatchers have safety integration:
```
SAFETY COVERAGE
===============
Dispatcher              | Schema | Physics | S(x) | Status
------------------------|--------|---------|------|--------
safetyDispatcher        | YES    | YES     | YES  | FULL
calculatorDispatcher    | YES    | PARTIAL | YES  | PARTIAL
turningDispatcher       | YES    | NO      | NO   | GAPS
...
Coverage: [N]/50 dispatchers have safety integration
```

### Weak Links (`/safety-audit weak`)
Find safety gaps:
1. Dispatchers with no safety schema validation
2. Engines that return raw numbers instead of AtomicValue
3. Algorithms classified as "critical" without test coverage
4. Division operations without zero-check guards
5. Array accesses without bounds checks on user-provided indices
6. S(x) scores that can be bypassed (hardcoded approval)

```
WEAK LINKS
==========
[severity] [file:line] — [description]
CRITICAL   calculatorDispatcher.ts:142 — No safety schema on sfc_calculate
MAJOR      ThermalEngine.ts:89 — Raw number return (no AtomicValue)
MAJOR      ToolWearPrediction.ts:56 — Division without zero-check
...
```

### Physics (`/safety-audit physics`)
Verify cross-field physics checks:
1. Read crossFieldPhysics.ts
2. List all active validation rules
3. Check for disabled or commented-out rules
4. Verify the validation is called in the safety chain (not bypassed)

### Blocks (`/safety-audit blocks`)
Find all SafetyBlockError throw sites:
1. Grep entire `src/` for `SafetyBlockError`
2. For each site: file, line, condition that triggers the block
3. Verify the error is never caught and swallowed

## Error Handling
- **Safety files missing**: "CRITICAL — safetyDispatcher.ts not found. Safety chain may be broken."
- **No SafetyBlockError found**: "WARNING — No safety blocks detected. Check if safety chain is wired."
- **Partial coverage**: Report gaps and suggest `/forge-safety` to harden.

## Chaining
- Full audit: `/safety-audit` → find weak links → `/forge-safety` → fix them
- Algorithm audit: `/algorithm-inspect safety` → list critical → `/safety-audit critical` → verify tests
- Pre-ship safety: `/scrutinize` (code quality) → `/safety-audit` (safety chain) → `/ship`
- After changes: `/scope [file]` → check safety impact → `/safety-audit [dispatcher]` → verify
- Pairs with: `/forge-safety` (hardening), `/algorithm-inspect` (algorithm details), `/trace` (safety wiring), `/check-dsl` (DSL compliance)
