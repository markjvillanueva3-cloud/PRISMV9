# Snapshot — Save/load session context snapshot

Capture or restore minimal session state for handoffs between sessions.

## Usage
- `/snapshot save` — create snapshot of current session state
- `/snapshot load` — load most recent snapshot
- `/snapshot clean` — remove old snapshots (keep last 5)

## Steps
1. If "save" → gather working files (from git status), recent commits (git log --oneline -5), active task, key decisions, next steps → call contextSnapshotEngine.create() then save()
2. If "load" → call loadLatest() then format() → display compact summary
3. If "clean" → call cleanup(5) → report removed count
4. Default (no args) → try loadLatest(), if exists show oneLiner(), else suggest "save"
