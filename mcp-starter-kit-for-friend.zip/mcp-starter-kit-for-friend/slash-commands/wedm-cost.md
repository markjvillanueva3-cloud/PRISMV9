---
name: wedm-cost
description: Wire EDM cost estimation and quoting
version: 1.0.0
engines:
  - QuoteEstimatorEngine
  - WEDMCalculatorAIEngine
  - EDMMaterialMachineWireEngine
actions:
  - wedm_estimate_time
  - wedm_estimate_cost
  - wedm_full_documentation
hooks:
  - hook_wedm_cost_confidence
triggers:
  - "wedm cost"
  - "wire edm quote"
  - "edm estimate"
  - "how much to edm"
---

# /wedm-cost — Wire EDM Cost Estimation

Generate cost estimates for Wire EDM work:
- Cycle time calculation (Kunieda MRR model)
- Wire consumption
- Machine rate
- Setup time
- Confidence scoring

## Usage

```
/wedm-cost <input> [options]
```

## Arguments

- `input` — Drawing path, dimensions, or description
- `--material` — Workpiece material
- `--thickness` — Thickness in mm
- `--perimeter` — Cut perimeter in mm
- `--passes` — Number of passes (default: auto)
- `--quantity` — Part quantity
- `--rush` — Rush job multiplier

## Cost Components

| Component | Method | Typical % |
|-----------|--------|-----------|
| Machine time | Kunieda MRR × passes | 60-70% |
| Wire consumption | Perimeter × passes × rate | 15-20% |
| Setup | Complexity factor | 10-15% |
| Programming | If new program | 5-10% |

## Calculation Models

**MRR (Kunieda):**
```
MRR = (Ie × ton × fp) / (ρ × Ce)
```

**Wire Consumption:**
```
Wire_m = perimeter_mm × passes × 1.1 / 1000
```

**Time:**
```
Time_min = (perimeter × thickness × passes) / (MRR × 60)
```

## Output

```json
{
  "estimate": {
    "total_usd": 245.00,
    "confidence": 0.85,
    "breakdown": {
      "machine_time_usd": 156.00,
      "wire_usd": 42.00,
      "setup_usd": 35.00,
      "programming_usd": 12.00
    }
  },
  "details": {
    "cycle_time_min": 52,
    "passes": 4,
    "wire_consumption_m": 84,
    "mrr_mm2_min": 45.2
  },
  "warnings": [
    "Thick section may require extra passes"
  ]
}
```

## Examples

```bash
# From drawing
/wedm-cost part.dxf --quantity 10

# From dimensions
/wedm-cost --perimeter 500 --thickness 25 --material D2

# Quick estimate
/wedm-cost "2 inch D2 punch, about 8 inches of cutting"

# Rush job
/wedm-cost part.step --rush 1.5
```

## Confidence Scoring

| Confidence | Meaning |
|------------|---------|
| >90% | Similar to historical jobs |
| 70-90% | Good data, some assumptions |
| 50-70% | Limited data, wider range |
| <50% | Requires manual review |

`hook_wedm_cost_confidence` warns if confidence <70%.

## Leverages

- `QuoteEstimatorEngine` — Cost framework
- `WEDMCalculatorAIEngine` — Neural-enhanced estimation
- Kunieda MRR model from physics constants
- JM Die historical job data
