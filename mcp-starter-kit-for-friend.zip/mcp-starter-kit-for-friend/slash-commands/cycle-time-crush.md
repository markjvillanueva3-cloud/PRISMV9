# Cycle Time Crush — Find Every Second Hiding in Your Program

Takes an existing CNC program and finds every opportunity to reduce cycle time while staying within machine limits, tool life constraints, and quality requirements. Most shops have 15-40% hidden cycle time they don't know about — in conservative feeds, unnecessary rapids, suboptimal tool paths, and idle time.

**Value**: 1 second saved per part × 10,000 parts/year × $2/min machine rate = $333/year per second saved. Finding 30 seconds = $10,000/year on ONE part number. Most shops run hundreds of part numbers.

## Args:
- Path to G-code program (e.g., "C:/programs/part123.nc")
- Material (e.g., "7075-T6", "316 stainless")
- `target=<N>%`: target cycle time reduction percentage
- `safe`: only suggest changes with zero quality risk

## Phase 1: Current State Analysis
1. Parse the G-code program completely:
   - Count lines, operations, tool changes
   - Identify: cutting time, rapid time, dwell time, tool change time
   - Map feed rates per tool/operation
   - Calculate current cycle time breakdown

2. `/program-validate` — verify current program is correct
   - No existing issues that mask optimization opportunities
   - Identify any safety violations that need fixing first

Output:
```
CURRENT STATE:
  Total cycle time:    [X] min [X] sec
  Cutting time:        [X] min ([X]% of total)
  Rapid time:          [X] min ([X]% of total)
  Tool change time:    [X] min ([X]% of total)
  Dwell time:          [X] min ([X]% of total)
  Idle/other:          [X] min ([X]% of total)
  Tools:               [N]
  Operations:          [N]
```

## Phase 2: Speed/Feed Optimization (biggest wins)
For each tool/operation in the program:

1. Run `ultimateSpeedFeedEngine.calculate()` with current parameters
   - Compare current Vc/fz against engine's balanced recommendation
   - Identify operations running significantly below optimal
   - Check if machine has headroom (power, torque, RPM)

2. `/auto-speed-feed` — generate optimized speeds/feeds
   - Line-by-line analysis of the entire program
   - Respect machine limits (from machine profile)
   - Three profiles: current → balanced → aggressive
   - For each change, calculate: time saved AND risk delta

3. Rank opportunities:
   - Large operations with conservative parameters = biggest wins
   - Small operations or finishing passes = diminishing returns
   - Flag any change that could affect surface finish or tolerance

## Phase 3: Rapid and Non-Cutting Optimization
1. **Rapid path optimization**:
   - Are rapids taking the shortest safe path?
   - Can clearance planes be lowered (reduce Z rapid distance)?
   - Are there unnecessary retract moves between adjacent features?

2. **Tool change optimization**:
   - Can tool order be rearranged to minimize changes?
   - Are there tools that could be combined (same tool, different operations)?
   - Is the tool change position optimal (closest to next cut start)?

3. **Dwell elimination**:
   - Are there unnecessary G4 dwells?
   - Can bore cycle dwells be reduced (if surface finish allows)?
   - Are spindle orient times being wasted?

## Phase 4: Strategy-Level Optimization
1. **Toolpath strategy review**:
   - Is roughing using high-efficiency milling (adaptive/trochoidal)?
   - Could rest machining eliminate redundant air cutting?
   - Are pocket strategies optimal (spiral vs zigzag vs adaptive)?

2. **Depth of cut optimization**:
   - Could fewer passes at deeper DOC reduce total time?
   - Power/torque budget check for deeper cuts
   - Stability check for deeper cuts (chatter risk)

3. **Tool consolidation**:
   - Can two similar tools be replaced by one?
   - Saves: tool change time + tool cost + setup complexity
   - Risk: slightly suboptimal parameters for one operation

## Phase 5: Quality-Gated Recommendations
Every recommendation gets a quality risk rating:

| Risk | Meaning | Action |
|------|---------|--------|
| ZERO | No quality impact (rapid optimization, dwell removal) | Auto-apply |
| LOW | Minimal quality impact (<5% Ra change, well within tolerance) | Recommend |
| MEDIUM | Moderate impact (monitor first articles) | Flag for review |
| HIGH | Could affect tolerance or finish | Only if explicitly requested |

## Phase 6: Cost Impact Calculation
For each recommendation:
- Time saved per part: [X] seconds
- Annual savings at [quantity] parts: $[X]
- Tool life impact: [increase/decrease/neutral]
- Implementation effort: [trivial/easy/moderate]
- ROI: savings / effort ranking

## Output Summary
```
CYCLE TIME CRUSH — [Program Name]
====================================
Current:    [X] min [X] sec per part
Optimized:  [X] min [X] sec per part
Saved:      [X] min [X] sec ([X]% reduction)

SAVINGS BREAKDOWN:
  Speed/feed optimization:  -[X] sec ([X]% of savings)
  Rapid path improvement:   -[X] sec ([X]% of savings)
  Tool change optimization: -[X] sec ([X]% of savings)
  Dwell/idle elimination:   -[X] sec ([X]% of savings)
  Strategy changes:         -[X] sec ([X]% of savings)

TOP CHANGES (ranked by time saved):
  #  | Change                          | Time  | Risk  | Annual $
  1  | [description]                   | -[X]s | [R]   | $[X]
  2  | [description]                   | -[X]s | [R]   | $[X]
  ...

ANNUAL IMPACT (at [N] parts/year):
  Machine time saved:  [X] hours/year
  Cost saved:          $[X]/year
  Tool cost change:    $[X]/year (±)
  NET SAVINGS:         $[X]/year

QUALITY ASSURANCE:
  Zero-risk changes:   [N] (auto-apply safe)
  Low-risk changes:    [N] (recommended)
  Medium-risk:         [N] (review first)
  High-risk:           [N] (only if requested)

Optimized program: [path] (or "use /auto-speed-feed to apply")
```

## Key Engines Used
UltimateSpeedFeedEngine, AutoSpeedFeedEngine, CycleTimeEstimatorEngine,
GCodeSafetyAnalyzerEngine, MotionDynamicsProfileEngine, AdvancedWearPhysicsEngine,
EngagementAdaptiveFeedEngine, MachineProfileEngine
