# Navigate — Find Any PRISM Component Instantly

Zero-IO file system navigation. Answers "where is X?" without any Glob/Grep.

## Args: $ARGUMENTS
- `cutting force` — find engines for cutting force
- `dispatcher action routing` — find dispatcher files
- `tool catalog data` — find catalog data files
- `welding laser` — find welding engines
- `token optimization` — find token-saving engines

## Steps

1. Call `fileSystemNavigatorEngine.navigate({ topic: "$ARGUMENTS" })`
2. Display top 3 results with directory, purpose, key files, DSL range
3. Show related directories for deeper exploration

## Output Format

```
NAVIGATE: $ARGUMENTS
=============================
1. [directory] (confidence: [N])
   Purpose: [description]
   Key files: [file1], [file2]
   DSL: [shortcode range]
   Related: [dir1], [dir2]

2. [directory] (confidence: [N])
   ...
```

## When to Use

- Before running Glob/Grep to find files
- At session start to orient yourself
- When a user asks "where is the code for X?"
- When building cross-references between components
