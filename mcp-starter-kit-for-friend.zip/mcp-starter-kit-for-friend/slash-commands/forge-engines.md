# Forge Engines — Engine Discovery + Creation Autopilot

You are running a specialized autopilot pipeline focused on discovering missing or weak engines in the PRISM system, designing new engines following AtomicValue/DSL patterns, implementing them, wiring them to dispatchers, and registering them in the matrix.

## Args: $ARGUMENTS
- Empty: full discovery — analyze the system, find engine gaps, create the best candidates
- `[engine-name]`: skip discovery, go straight to creating a specific engine
- `[domain]`: focus on a domain (cutting, thermal, safety, material, tool, coolant, surface, cad)
- `[count]`: create up to N engines (default: 3)
- `list`: just analyze and list engine gaps without creating any
- `audit`: audit existing engines for quality and DSL compliance

## Phase 0: Load System Map (READ these files — do NOT Glob/Grep)
1. Read `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` — full system in ~735 tokens
2. Read `C:/PRISM/mcp-server/data/docs/ENGINE_DIGEST.md` — ALL engines with 1-line descriptions (use THIS for gap analysis, not Glob)
3. Read `C:/PRISM/mcp-server/data/docs/DISPATCHER_DIGEST.md` — all dispatchers with action counts

**CRITICAL: Do NOT run Glob on src/engines/ to list engines. ENGINE_DIGEST.md already has every engine with its purpose. This saves ~2,000 tokens per invocation.**
**Do NOT read MASTER_INDEX.md (5,000 tokens). Use MASTER_INDEX_COMPACT.md (735 tokens) instead.**

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** before concluding engine gap analysis.
- Consider every applicable model, formula, algorithm, and combination — including novel cross-domain approaches.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing coverage before building new.
- **Completeness > Speed.** A missed mathematical model is a permanent capability gap.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: COMPLEX (engines are PRISM's core — require deep domain + engineering knowledge)
2. Domain: Manufacturing Process + TypeScript Engineering + Applied Mathematics
3. Roles: Manufacturing Process Expert + Senior TypeScript Engineer + Applied Mathematics Expert
4. Model: OPUS (engine design requires precision engineering calculations)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Engine Gap Analysis

### 3A: Inventory Existing Engines (use ENGINE_DIGEST — do NOT Glob)
1. You already loaded `ENGINE_DIGEST.md` in Phase 0 — it has ALL engines grouped by domain with 1-line descriptions
2. If you need shortcode for a specific engine: `codeSystemIndexEngine.lookup("src/engines/EngineName.ts")`
3. Engines are already categorized in ENGINE_DIGEST by domain:
   - **Cutting**: force, speed, feed, power, torque, chip
   - **Thermal**: temperature, heat, cooling, thermal
   - **Safety**: safety scoring, limits, validation
   - **Material**: material properties, machinability, compatibility
   - **Tool**: tool life, wear, selection, geometry
   - **Coolant**: flow, pressure, MQL, delivery
   - **Surface**: roughness, integrity, finish
   - **Machine**: kinematics, dynamics, capability
   - **CAD**: geometry, meshing, export, import
4. Count engines per domain, identify thin areas

### 3B: Identify Engine Gaps
Analyze across these dimensions:

**Missing Calculations:**
- What manufacturing calculations does PRISM NOT yet support?
- What formulas exist in `data/formulas/*.json` without corresponding engines?
- What dispatcher actions call engines that don't exist yet?
- What industry-standard calculations are absent?

**Weak Engines:**
- Engines that return raw numbers instead of AtomicValue
- Engines with hardcoded constants instead of registry lookups
- Engines that don't integrate with SafetyEngine
- Engines with no error handling for edge cases
- Engines that duplicate logic from other engines

**Domain Gaps by Manufacturing Process:**
- Turning: missing radial force, vibration, chatter prediction?
- Milling: missing engagement angle, helix effects, ramping?
- Drilling: missing breakthrough force, peck cycle optimization?
- Grinding: missing wheel wear, dressing interval, burn detection?
- 5-axis: missing tool orientation, collision detection, compensation?

**Integration Gaps:**
- Engines that exist but aren't wired to any dispatcher
- Engines that don't chain with related engines (e.g., force → power → safety)
- Results that should feed downstream calculations but don't

### 3C: Rank Candidates
Score each candidate:
- **User Value** (HIGH/MEDIUM/LOW): How useful is this to a machinist or engineer?
- **Domain Coverage** (HIGH/MEDIUM/LOW): Does it fill a critical gap in a thin domain?
- **Chainability** (HIGH/MEDIUM/LOW): Does it enable or improve other calculations?
- **Complexity** (HIGH/MEDIUM/LOW): How hard is it to implement correctly?
- **Data Available** (HIGH/MEDIUM/LOW): Do we have the formulas and reference data?

Priority = (UserValue * 3 + DomainCoverage * 2 + Chainability * 2 + DataAvailable) / (Complexity * 1.5)

```
ENGINE OPPORTUNITIES
====================
Rank | Engine Name              | Domain   | Value | Chain | Data | Complex | Score
-----|--------------------------|----------|-------|-------|------|---------|------
  1  | ChatterPredictionEngine  | Cutting  | HIGH  | HIGH  | HIGH | HIGH    | 8.0
  2  | GrindingBurnEngine       | Thermal  | HIGH  | MED   | HIGH | MED     | 8.5
  ...

Domain Coverage:
  Cutting:   [N] engines — [STRONG/MODERATE/THIN]
  Thermal:   [N] engines — [STRONG/MODERATE/THIN]
  Safety:    [N] engines — [STRONG/MODERATE/THIN]
  Material:  [N] engines — [STRONG/MODERATE/THIN]
  Tool:      [N] engines — [STRONG/MODERATE/THIN]
  ...
```

If args = `list`, stop here.

## Phase 4: Design Engines
For each engine to create (top N from ranking):

### 4A: Research the Calculation
1. Check `data/formulas/*.json` for relevant formulas
2. Check existing engines for patterns to follow
3. Identify the input parameters (what data does this engine need?)
4. Identify the output values (what does this engine produce?)
5. Identify the mathematical model (what equations drive the calculation?)
6. Identify uncertainty sources (what affects accuracy?)

### 4B: Engine Architecture
Following PRISM DSL patterns:
```typescript
// Required structure:
export class NewEngine {
  calculate(params: InputParams): AtomicValue | AtomicValue[] {
    // 1. Validate inputs
    // 2. Look up reference data from registries
    // 3. Apply mathematical model
    // 4. Compute uncertainty
    // 5. Return AtomicValue with { value, unit, uncertainty, source }
  }
}
```

Design decisions:
- What registry data does it need? (materials, tools, machines)
- Does it chain with other engines? (output feeds another engine's input)
- Does it need to integrate with SafetyEngine?
- What edge cases must be handled? (zero inputs, extreme values, missing data)

### 4C: Define Test Cases
Before writing the engine, define:
- 3+ known-good calculations with published reference values
- 2+ edge cases (boundary values, extreme materials)
- 1+ error cases (missing data, invalid inputs)

## Phase 5: Implement Engines
For each designed engine:

### 5A: Write the Engine
1. Create `src/engines/{EngineName}.ts`
2. Follow the AtomicValue return pattern
3. Use registry lookups (not hardcoded values)
4. Include uncertainty calculation
5. Add safety integration where relevant
6. Handle all identified edge cases

### 5B: Wire to Dispatcher
1. Find or create the appropriate dispatcher
2. Add an action that calls the new engine
3. Include parameter normalization
4. Include result formatting

### 5C: Write Tests
1. Create `src/__tests__/{EngineName}.test.ts`
2. Test all defined test cases
3. Test edge cases and error handling
4. Verify AtomicValue format compliance

### 5D: Build and Test
1. Run `/verify-loop` — build + targeted tests + inline review in one pass
2. All checks must pass before proceeding to Phase 6

### 5E: De-Sloppify
Run `/de-sloppify` on the newly created engine and test files to clean import order, remove debug output, and enforce naming conventions before postflight.

## Phase 6: Forge Postflight (`/forge-postflight engines` protocol)
Run the FULL shared integration protocol for newly created engines:
1. **Gate 1 — DSL**: RUN — verify AtomicValue return format, action schema, parameter normalization, safety integration
2. **Gate 2 — Matrix**: RUN — add to MASTER_INDEX_COMPACT.md engine inventory, register in dispatcher, update counts
3. **Gate 3 — Trace**: RUN — trace downstream (engine → algorithm → safety), trace upstream (dispatcher → action → engine), flag orphans
4. **Gate 4 — Sync**: RUN — verify engine count in MEMORY.md and CLAUDE.md matches disk
5. **Gate 5 — Memory**: RUN — add new engine names, domains, and wiring to MEMORY.md
6. **Gate 6 — Hookify**: RUN — evaluate if engine needs a quality hook (AtomicValue compliance, safety check)

All 6 gates apply to engines. Report full postflight results before proceeding to commit.

## Phase 7: Auto-Commit (`/auto-commit` protocol)
1. Stage engine files, dispatcher changes, tests
2. Commit: `feat(engines): add [N] engines — [list names] [FORGE-ENGINES]`
3. Report the commit

## Summary Report
```
FORGE ENGINES COMPLETE
======================
Analyzed:      [N] domains, [N] existing engines
Gaps Found:    [N] engine opportunities
Created:       [N] engines
  - {Engine1} (domain) — [calculation description]
  - {Engine2} (domain) — [calculation description]
Tests Added:   [N] test cases
Build:         PASS
Tests:         [N] passing (0 regression)
Matrix:        [N] engines registered
Committed:     [commit hash]

Engine Totals: [N] engines (was [M])

Domain Coverage After:
  Cutting:  [N] engines (+[M])
  Thermal:  [N] engines (+[M])
  ...

Next: /forge-engines [domain] for more engines, /forge-tests for test coverage
```

## Error Handling
- **Formula not available**: Research the calculation, document sources, implement from first principles
- **Registry data missing**: Create the registry entry or use sensible defaults with LOW confidence
- **Build failure**: Fix TypeScript errors before proceeding
- **Test failure**: Fix the engine, not the test (unless the test expectation is wrong)
- **Context budget**: Complete the current engine fully, commit, report remaining candidates

## Safety Rails
- Every engine must return AtomicValue format — no raw numbers
- Every engine must handle missing/invalid input gracefully
- Safety-relevant engines must integrate with SafetyEngine
- No hardcoded material or tool properties — use registry lookups
- Uncertainty must be computed, not set to 0
- All mathematical models must cite their source (paper, handbook, standard)
- Never create placeholder engines — if the math isn't known, don't build it
