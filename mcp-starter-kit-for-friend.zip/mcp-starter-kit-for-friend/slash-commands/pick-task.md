You are about to pick and claim a task from the PRISM Roadmap Generation System (RGS) via the TaskClaimService. This connects you to the multi-Claude coordination system so multiple terminals can work on different tasks without conflicts.

## Input
Arguments: $ARGUMENTS

## Step 1: Parse Arguments

Check the arguments:
- If empty or missing: show all available tasks across all incomplete milestones
- If `list`: show available tasks but do NOT claim any
- If a milestone ID (e.g., `REM-MS3`, `S3-MS2`, `QA-MS5`): filter to that milestone only
- If a unit ID (e.g., `REM-MS3-U02`): skip selection and claim that specific unit directly

## Step 2: Load the Roadmap Index

Read `C:/PRISM/mcp-server/data/roadmap-index.json`.

Extract all milestones where `status` is NOT `"complete"`. For each incomplete milestone, note:
- `id`, `title`, `track`, `status`, `total_units`, `completed_units`, `envelope_path`, `dependencies`

Check dependency satisfaction: a milestone is **blocked** if any of its dependencies have `status != "complete"`. Skip blocked milestones unless the user explicitly requested that milestone ID.

## Step 3: Load Milestone Envelopes

For each unblocked incomplete milestone, read its envelope JSON from `C:/PRISM/mcp-server/data/milestones/{envelope_path}`.

Extract units from the envelope. Units live in either:
- `envelope.units[]` (flat format) — each has `id`, `title`, `status`
- `envelope.phases[].units[]` (phased format) — same fields, nested under phases

Collect all units where `status` is NOT `"complete"`.

## Step 4: Check Claims

Check `C:/PRISM/mcp-server/data/claims/` for already-claimed units:
- For each incomplete milestone ID, check if directory `claims/{milestoneId}/` exists
- If it does, list subdirectories — each subdirectory name is a claimed unit ID
- Read `claim.json` inside each to get `instance_id`, `claimed_at`, `heartbeat_at`
- A claim is **stale** if `heartbeat_at` is more than 5 minutes old (stale claims can be reused)

Filter out actively-claimed (non-stale) units from the available list.

## Step 5: Categorize and Present

Group available units into three tiers:

### Tier A: MCP-Server Development Tools
Units involving infrastructure, dispatchers, services, schemas, coordination, hooks, orchestration, cadences, commands, or tooling.
Track hints: units from tracks like `L6`, `L7`, `L8`, `CC`, or milestones with words like "dispatcher", "service", "hook", "orchestrat", "infrastructure", "command", "schema", "coordination" in the title.

### Tier B: PRISM Domain
Units involving engines, algorithms, formulas, registries, manufacturing calculations, physics models, materials, tools, machines, safety, coolant, cutting force, surface finish, or any CNC/machining domain work.
Track hints: units from tracks like `S1`, `S2`, `S3`, `S4`, `L0`, `L1`, `L2`, `L3`, `L4`, `L5`, `REM`, or milestones with domain keywords in the title.

### Tier C: Debug / Optimize (Always Available)
This tier is always present regardless of roadmap state. It covers:
- Searching for improvements across any completed milestone
- Bug fixes discovered during other work
- Performance optimization opportunities
- Code quality improvements (TypeScript errors, lint, dead code)
- Documentation drift fixes

Present the results in this format:

```
## Available Tasks

### Tier A: MCP-Server Development Tools
| # | Milestone | Unit | Title | Priority |
|---|-----------|------|-------|----------|
| 1 | CC-MS0    | P0-U01 | ... | HIGH   |

### Tier B: PRISM Domain
| # | Milestone | Unit | Title | Priority |
|---|-----------|------|-------|----------|
| 2 | S3-MS2    | P0-U01 | Smart Material Selector | MEDIUM |

### Tier C: Debug / Optimize
Always available. Tell me what to audit, fix, or optimize.

Claimed by others: [list any actively claimed units]
Stale claims (reclaimable): [list any stale claims]
```

Priority is determined by:
- **HIGH**: milestone has no uncompleted dependencies and track is REM (remediation) or QA
- **MEDIUM**: milestone has no uncompleted dependencies, normal development track
- **LOW**: milestone has some soft dependencies incomplete but is technically startable

Sort by priority (HIGH first), then by milestone ID alphabetically.

## Step 6: Claim (unless `list` mode)

If the argument was `list`, stop here — just display the table.

Otherwise, if the user provided a specific unit ID in args, claim that unit. If YOLO mode is active (invoked via `/autopilot` or `/yolo-mode`), auto-select the highest priority available task (first row in Tier A, or Tier B if no Tier A, etc.) without asking. If not in YOLO mode, ask the user which numbered task they want to claim.

Once a task is selected, perform the claim:

1. Generate an instance ID: `claude-{timestamp}` (e.g., `claude-1709234567890`)
2. Create the claim directory: `C:/PRISM/mcp-server/data/claims/{milestoneId}/{unitId}/`
3. Write `claim.json` inside it:
```json
{
  "milestone_id": "<milestoneId>",
  "unit_id": "<unitId>",
  "instance_id": "<instanceId>",
  "claimed_at": "<ISO timestamp>",
  "heartbeat_at": "<ISO timestamp>"
}
```
4. Write `C:/PRISM/state/ACTIVE_CLAIM.json`:
```json
{
  "milestone_id": "<milestoneId>",
  "unit_id": "<unitId>",
  "instance_id": "<instanceId>",
  "claimed_at": "<ISO timestamp>"
}
```
This file enables the cadence heartbeat (function 15 in cadenceExecutor.ts) to auto-renew the claim every 60 seconds, preventing stale-reap while you work.

## Step 7: Load Unit Context and Begin Work

After claiming:
1. Read the full milestone envelope to get the unit's `steps[]`, `entry_conditions`, `exit_conditions`, `deliverables`, `rollback`, and `tools`
2. Read `C:/PRISM/state/CURRENT_POSITION.md` for session context
3. Apply `/smart` auto-configuration based on the unit's `model` and `role` fields if present
4. Begin executing the unit's steps sequentially

When the unit is complete, run the **completion checklist** — this ensures new products are automatically integrated into the system:

### Completion Checklist (Auto-Registration Protocol)

**A. Update Roadmap State:**
1. Update the unit's `status` to `"complete"` in the milestone envelope
2. Update `completed_units` count in `roadmap-index.json`
3. If all units in the milestone are complete, set milestone `status` to `"complete"` and add `completed_at` date

**B. Release Claim:**
4. Release the claim by removing `C:/PRISM/mcp-server/data/claims/{milestoneId}/{unitId}/`
5. Remove `C:/PRISM/state/ACTIVE_CLAIM.json`

**C. Auto-Register New Products:**
For each new file created during this unit, check if it needs integration:

6. **MASTER_INDEX check**: If you created any new file in `engines/`, `algorithms/`, `services/`, `schemas/`, `dispatchers/`, or `registries/`, add it to `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` in the appropriate section. Update the Section 15 summary counts.

7. **Dispatcher wiring check**: If you created a new engine or algorithm, verify it's exposed via at least one dispatcher action. If not, add the appropriate action to the relevant dispatcher (e.g., new calculation engine -> calcDispatcher, new safety engine -> safetyDispatcher).

8. **Registry registration**: If you created a new registry data file, verify it's loaded by the appropriate registry loader.

9. **Orchestration registration**: Run `prism_orchestrate action:roadmap_register milestone_id:{milestoneId}` to ensure the milestone is in the multi-Claude coordination registry.

**D. Update Position:**
10. Update `C:/PRISM/state/CURRENT_POSITION.md` with results summary
11. If any MASTER_INDEX or dispatcher changes were made, note them in the position update
