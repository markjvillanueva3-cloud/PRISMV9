# Video Learn — Video Tutorial to PRISM Components Pipeline

You are running a specialized pipeline that processes video tutorials (YouTube URLs or local video files) through AI-powered extraction, and forges new PRISM components (engines, algorithms, hooks, schemas, scripts, skills, tribal tips, formulas) to improve the app's capabilities.

This command chains video processing, AI-powered knowledge extraction, and component generation into one continuous flow — learning from real-world machining content and converting it into actionable PRISM intelligence.

## Args: $ARGUMENTS
- **Local video file**: process a local MP4/MKV/MOV/AVI/WEBM file using VideoLearningEngine (FFmpeg + Whisper + Claude Vision)
  Example: `/video-learn C:/PRISM/HYPERMILL/E-Learning/video.mp4`
- **Local directory**: batch-process all video files in a directory
  Example: `/video-learn C:/PRISM/HYPERMILL/E-Learning/Machine-simulation/`
- YouTube URL: process a specific video via YouTube pipeline
  Example: `/video-learn https://www.youtube.com/watch?v=r6NUt1cMzuI`
- Search topic: find and process the best matching tutorial
  Example: `/video-learn "titanium 5-axis milling techniques"`
- `fixture:<video_id>`: use pre-captured fixture data (offline, no API)
  Example: `/video-learn fixture:r6NUt1cMzuI`
- `--dry-run`: run pipeline + extraction but do not generate components
- `--tips-only`: only generate TribalKnowledgeEngine tips (fastest, safest)
- `--no-vision`: skip frame extraction + vision analysis (faster, cheaper)
- `--audio-only`: skip vision, transcription only (cheapest)
- `--max-components=<N>`: limit components generated (default: 5)
- `--domain=<cad|cam|shop|software|electronics|additive|auto>`: force domain classification (default: auto-detect)

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when extracting knowledge from videos.
- Extract every technique, parameter, formula, and empirical insight — no skipping.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/tip by name.
- Check PRISM's 499 formulas, 880+ engines, 204 tribal tips for existing coverage before dismissing content.
- **Completeness > Speed.** Every frame/segment may contain knowledge PRISM doesn't have yet.

## Input Routing
Determine input type from `$ARGUMENTS`:
1. **Local file** (path ending in `.mp4`, `.mkv`, `.mov`, `.avi`, `.webm`): Route to **Local Video Pipeline** (Phase L below)
2. **Local directory** (path exists as directory): Route to **Local Video Pipeline** in batch mode
3. **YouTube URL** (contains `youtube.com` or `youtu.be`): Route to Phase 2 (YouTube pipeline)
4. **Search topic** (quoted string, no URL/path): Use yt-dlp search, then Phase 2
5. **Fixture reference** (`fixture:<id>`): Load fixture, skip to Phase 2

## Phase L: Local Video Pipeline (VideoLearningEngine)

For local video files, use the VideoLearningEngine directly:

### L1: Prerequisites
```typescript
import { videoLearningEngine } from "./engines/VideoLearningEngine.js";
const prereqs = await videoLearningEngine.checkPrerequisites();
// Requires: ffmpeg on PATH, OPENAI_API_KEY (Whisper), ANTHROPIC_API_KEY (Vision)
```

### L2: Process Video
```typescript
// Single file
const result = await videoLearningEngine.processVideo(videoPath, {
  use_scene_detection: true,
  scene_threshold: 0.3,
  max_keyframes: 50,
  vision_batch_size: 4,
  domain_override: domainFlag,  // from --domain flag
  skip_vision: noVisionFlag,    // from --no-vision flag
  skip_transcription: false,
});

// Directory batch
const results = await videoLearningEngine.processDirectory(dirPath, opts);
```

### L3: Report Results
For each processed video, report:
```
VIDEO PROCESSED: [filename]
  Duration:     [N]s
  Transcript:   [N] segments, [N] chars
  Keyframes:    [N] extracted, [N] analyzed
  Knowledge:    [N] items
  Playbook:     [N] rules extracted, [M] added (rest deduped)
  Cost est:     $[whisper] + $[vision] = $[total]
```

### L4: Generate Components
Feed `result.knowledge_items` into the standard component generation pipeline (Phase 5 of YouTube flow).
Each VideoKnowledgeItem maps to TribalKnowledgeEngine tips by default. Use `--max-components` to also generate engines/hooks/algorithms from high-confidence items.

## THOROUGHNESS LAW (HARD RULE — applies to every phase)
- **NEVER skim, skip, or dismiss content without deep reading.** Every source gets a full assessment.
- "Low novelty" / "already covered" claims REQUIRE citing the SPECIFIC existing engine/tip — name it or extract it.
- Before committing: "Did I extract EVERYTHING useful from this video?"
- **Completeness > Speed.** Missing useful content is a permanent loss that degrades PRISM's value.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.

## Phase 1: Smart Config + Input Validation

### 1A: Smart Configuration
```
SMART CONFIG
Role:   Manufacturing Process Expert + Senior TypeScript Engineer + Knowledge Engineer
Model:  OPUS
Effort: HIGH
Reason: Video learning requires deep domain knowledge for extraction + engineering skill for component generation
```

### 1B: Parse Input
Input routing is handled by the **Input Routing** section above. For YouTube/search/fixture inputs, continue with Phase 2 below. For local files/directories, use **Phase L** above.
If empty: print usage and exit.

### 1C: Validate Prerequisites
- Python available at configured path
- For URL mode: yt-dlp installed (`pip show yt-dlp`)
- ANTHROPIC_API_KEY: Auto-loaded from `C:/PRISM/mcp-server/.env` by the extraction modules. No manual export needed — `_load_env_file()` in `knowledge_extract.py` handles this automatically.
- Output directory exists: `C:/PRISM/cad-engine/output/`

If prerequisites fail, report what's missing and suggest fixture mode as fallback.

### 1D: Check Learning Registry
Load `C:/PRISM/mcp-server/data/video-learned/learning-registry.json` via `C:/PRISM/cad-engine/src/learning_registry.py`.
If the video was already processed, report what was generated and ask whether to re-process or skip.

## Phase 2: Video Ingestion (CC-MS1 Pipeline)

Run the 6-module pipeline from `C:/PRISM/cad-engine/src/`:

### 2A: Ingest
```python
# Run via: python -c "from video_ingest import ingest; ..."
# Or use the integration runner: python scripts/run_integration_test.py --videos 1
```
Extract: VideoMetadata (title, duration, uploader, tags) + TranscriptSegment[] (timestamped text)

### 2B: Frame Extraction (skip if --no-vision or fixture mode)
Extract keyframes via scene detection or interval sampling. Target: 10-15 frames.

### 2C: OCR (skip if --no-vision or fixture mode)
Run Tesseract on extracted frames. Extract UI elements (menus, parameters, coordinates).

### 2D: Vision Analysis (skip if --no-vision or fixture mode or no API key)
Send frames to Claude API with domain-specific prompts. Extract software, UI state, feature trees, operations, parameters.

### 2E: Domain Classification
Classify into CAD/CAM/SHOP or non-machining domains (SOFTWARE/ELECTRONICS/ADDITIVE/etc.) using weighted keyword scoring. Auto-detection uses `_auto_detect_domain()` with keyword counts across 6+ domain categories.

### 2F: Platform Detection
Identify software name, version, CNC controller, or framework/tool from all available text.

**Fixture Mode Shortcut:**
Load video_id, title, transcript, expected_domain, expected_software from fixture JSON.
Set: ocr_text="", vision_text="", frames=[]

**Output:** Save unified result to `C:/PRISM/cad-engine/output/<video_id>/pipeline_result.json`

Report:
```
PIPELINE COMPLETE
  Title:     [title]
  Duration:  [N]s
  Domain:    [primary] (confidence: [N])
  Platform:  [software] [version]
  Transcript: [N] words
  Frames:    [N] analyzed
  OCR:       [N] text regions
  Vision:    [N] unique insights
```

## Phase 3: Knowledge Extraction

**Online mode (API available):** Call `C:/PRISM/cad-engine/src/knowledge_extract.py` with pipeline output.
**Offline/Fixture mode:** Call `C:/PRISM/cad-engine/src/knowledge_extract_offline.py` — enhanced rule-based extraction with 12 extractors: cutting parameters (RPM/SFM/IPM/DOC/chip load/stepover), tools, CAM strategies (11 types), safety warnings, procedures, troubleshooting, formulas, decision rules, CAD features, machine setup, G-code patterns, post-processing.

### 3A: Domain-Specific Extraction
Based on classified domain, apply targeted extraction:

**CAD domain prompts extract:**
- Features: sketch, extrude/pad, cut/pocket, fillet, chamfer, mirror, pattern, shell, revolve
- Constraints: dimensions, relationships, fully-constrained status
- Design intent: parametric relationships, design-for-manufacturing considerations
- Materials: material assignments mentioned
- Export: file formats (STEP, STL, IGES) and their uses

**CAM domain prompts extract:**
- Strategies: roughing (adaptive/trochoidal/pocket), finishing (parallel/contour/pencil), drilling (peck/spot/ream)
- Tools: type, diameter, flute count, material, coating
- Cutting parameters: speed (SFM/m-min), feed (IPT/mm-tooth), DOC, WOC, chip load
- Toolpath: strategy rationale, engagement control, entry/exit methods
- Post-processing: machine type, controller, post-processor name

**SHOP domain prompts extract:**
- Practices: workholding setup, tool measurement, work offsets (G54/G55)
- Machine operations: spindle warmup, coolant management, chip evacuation
- Controllers: G-code commands, M-codes, canned cycles
- Safety: material-specific warnings, tool breakage prevention, thermal management
- Troubleshooting: chatter fixes, surface finish issues, dimensional accuracy

### 3B: Confidence Scoring
Each extracted item gets a confidence score:
- Explicit mention with numeric values: 0.9
- Explicit mention without values: 0.7
- Implied from context: 0.5
- Inferred from domain knowledge: 0.3

### 3C: Cross-Reference
Link related items across domains (e.g., CAM tool selection references CAD material).

**Output:** Save to `C:/PRISM/cad-engine/output/<video_id>/knowledge.json`

## Phase 4: Knowledge Bridge

Call `C:/PRISM/cad-engine/src/knowledge_bridge.py` to map knowledge to component specs.

### 4A: Classify Each Knowledge Item
| Knowledge Type | Examples | PRISM Target |
|---|---|---|
| Formulas/equations | Vc = pi*D*N/1000, chip load = fz*z | Engine or Algorithm |
| Parameter tables | speeds/feeds per material+tool | Schema or Engine lookup |
| Safety warnings | "never machine titanium dry" | Hook (safety chain) |
| Decision rules | "use trochoidal for Inconel" | Engine or tribal tip |
| Step-by-step procedures | "work offset setup procedure" | Skill (5+ steps) or Script |
| Troubleshooting | "chatter = reduce DOC, increase speed" | TribalKnowledgeEngine tip |
| General advice | "always indicate vise to 0.0005" | TribalKnowledgeEngine tip |

### 4B: Deduplicate Against PRISM Inventory
Before generating, check what already exists:
1. Read `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` (~735 tokens — NOT the 5,000-token MASTER_INDEX.md). Check `TribalKnowledgeEngine.ts` KNOWLEDGE_BASE for existing tips
3. Check `data/formulas/*.json` for existing formula coverage
4. Score novelty: NEW (1.0), EXTENDS (0.6), DUPLICATE (0.0)

### 4C: Rank and Select ALL
Score: `(confidence * 2 + novelty * 3 + domain_value * 2) / complexity`
- Apply confidence gates per component type
- **Default: generate ALL qualifying specs** (max_components=50). Use --max-components to limit.
- Items below confidence gate are downgraded to tribal tips (if >= 0.5) or skipped

**Output:** Save to `C:/PRISM/cad-engine/output/<video_id>/component_specs.json`

Report:
```
KNOWLEDGE BRIDGE
  Items extracted:    [N]
  After dedup:        [N] unique
  Component specs:    [N] selected
    Tribal tips:      [N]
    Engines:          [N]
    Algorithms:       [N]
    Hooks:            [N]
    Skills:           [N]
    Other:            [N]
```

If `--dry-run`, stop here and print the specs.

## Phase 5: Component Generation + Auto-Write

**This phase is fully automatic.** All component types are generated and written to disk without manual intervention. The pipeline generates ALL derivable components, not just tips.

### 5A: Generate All Components
```python
from component_generator import generate_components
from component_writer import write_components

gen_result = generate_components(bridge_result.specs, video_id)
write_result = write_components(gen_result, dry_run=is_dry_run)
```

The generator produces file contents for all 8 component types:
- **TypeScript**: engines, algorithms, hooks
- **Markdown**: skills (slash commands)
- **Python**: scripts
- **JSON**: schemas, formulas

### 5B: Auto-Write to Disk
`C:/PRISM/cad-engine/src/component_writer.py` handles writing:
- **Tribal tips**: Appended to `TribalKnowledgeEngine.ts` KNOWLEDGE_BASE array
- **Engines**: New `.ts` files in `mcp-server/src/engines/`
- **Algorithms**: New `.ts` files in `mcp-server/src/algorithms/`
- **Hooks**: New `.ts` files in `mcp-server/src/hooks/`
- **Skills**: New `.md` files in `~/.claude/commands/`
- **Scripts**: New `.py` files in `scripts/`
- **Schemas**: New `.json` files in `mcp-server/data/video-learned/`
- **Formulas**: New `.json` files in `mcp-server/data/formulas/`

Safety: Never overwrites existing files (skips with warning). Tribal tips append-only. Hooks always `mode: "warning"`.

### 5C: Refine Generated Code
After auto-write, review each generated TypeScript file:
1. Open files with TODO markers
2. Fill in domain-specific calculation logic from extracted knowledge
3. Ensure type safety and import correctness
4. For engines: implement `calculate()` with actual formula from video
5. For algorithms: implement `calculate()` with equation from extraction
6. For hooks: implement handler with specific validation conditions

Every generated component includes provenance: `source: "video:<video_id>@<timestamp>s"`

Report after Phase 5:
```
COMPONENT GENERATION
  Generated:     [N] components ([N] types)
  Written:       [N] new files
  Modified:      [N] existing files
  Tips appended: [N] to TribalKnowledgeEngine
  Skipped:       [N] (already exist)
  Errors:        [N]
```

## Phase 5D: Brainstorm Follow-Up Work

Call `C:/PRISM/cad-engine/src/video_brainstorm.py` to brainstorm what else could be built from the extracted knowledge.

```python
from video_brainstorm import brainstorm_from_knowledge, generate_rgs_milestone, save_brainstorm

brainstorm = brainstorm_from_knowledge(knowledge, bridge_specs, video_id, title, domain)
milestone = generate_rgs_milestone(brainstorm, video_id, title, domain)
save_brainstorm(brainstorm, milestone, output_dir)
```

The brainstormer analyzes:
1. **Missing types**: Component types that could be generated but weren't (formulas, hooks, engines)
2. **Integration opportunities**: Ways to connect video knowledge to existing PRISM systems (MaterialDB, dispatchers)
3. **Enhancement ideas**: Validation, testing, and quality improvements for generated components

Report:
```
BRAINSTORM
  Ideas generated:  [N]
    Engines:        [N]
    Formulas:       [N]
    Hooks:          [N]
    Skills:         [N]
    Integrations:   [N]
    Enhancements:   [N]
```

## Phase 5E: RGS Milestone Generation

If brainstorm produces 2+ high/medium-value ideas, auto-generate an RGS milestone envelope:
- Milestone ID: `VL-{DOMAIN}-{video_id[:8]}`
- Each idea becomes a unit with actionable steps
- Saved to `C:/PRISM/cad-engine/output/<video_id>/{milestone_id}.json`
- **Does NOT auto-register** in roadmap-index.json (that requires `/rgs register`)

Report:
```
RGS MILESTONE
  ID:       [milestone-id]
  Title:    [title]
  Units:    [N]
  Priority: [high/medium]
  Status:   proposed (run /rgs register to activate)
```

If insufficient ideas, skip with: `No milestone generated — brainstorm produced < 2 worthy ideas`

## Phase 6: Registration

For each generated component:
1. **Engines/Algorithms**: Add to MASTER_INDEX_COMPACT.md, register in code
2. **Tribal tips**: No separate registration (embedded in TribalKnowledgeEngine)
3. **Hooks**: Register in hook registry
4. **Skills**: No matrix entry needed (command files auto-discovered)
5. **Formulas**: Add to FormulaRegistry index

## Phase 7: Verification

1. **TypeScript**: `npm run build` in `C:/PRISM/mcp-server/` — must pass
2. **Python tests**: `python -m pytest C:/PRISM/cad-engine/tests/` — must pass
3. **Full test suite**: `npm test` in `C:/PRISM/mcp-server/` — no regression
4. If any generated tests, run those specifically

If build fails: revert the failing component, report what went wrong, proceed with remaining components.

## Phase 8: Report + Commit

### Summary Report
```
VIDEO-LEARN COMPLETE
====================
Video:        [title] ([duration]s)
URL:          [url or fixture:<id>]
Domain:       [primary] (confidence: [N])
Platform:     [software] [version]

Pipeline:
  Transcript:  [N] words
  Frames:      [N] analyzed
  OCR:         [N] text regions
  Vision:      [N] unique insights

Knowledge:
  Items extracted:   [N]
  Unique (post-dedup): [N]
  Avg confidence:    [N]

Components Generated:
  Tribal tips:  [N] added to TribalKnowledgeEngine
  Engines:      [N] created
  Algorithms:   [N] created
  Hooks:        [N] created
  Skills:       [N] created
  Schemas:      [N] created
  Scripts:      [N] created
  Formulas:     [N] registered
  TOTAL:        [N] new PRISM components

Verification:
  Build:  PASS
  Tests:  [N] passing (0 regression)

Committed: [hash] feat(video-learn): [summary]

Next: /video-learn [another-url] or /forge to iterate on generated components
```

### Update Learning Registry
After successful verification, update `C:/PRISM/mcp-server/data/video-learned/learning-registry.json` via `learning_registry.py`:
- Add a RunRecord with video_id, title, domain, platform, extraction stats, components generated, component IDs, verification results
- Save the registry to disk

### Auto-Commit
Stage all new/modified files and commit:
`feat(video-learn): learn from [video-title] — [N] components [VIDEO-LEARN]`

## Error Handling
- **yt-dlp not found**: Print install command, suggest fixture mode
- **Video unavailable**: Report error, suggest alternative URL
- **No transcript**: Fall back to vision-only (if frames available), or report insufficient content
- **Claude API rate limit**: Retry 3x with backoff, then skip vision/extraction
- **Empty knowledge**: Report "insufficient extractable content — try a more specific tutorial"
- **Build failure after generation**: Revert failing files, report what failed, keep passing components
- **Context budget**: Save progress to output dir, compact, complete current phase, report remaining

## Safety Rails
- Never store API keys in generated files
- Never generate hooks with mode: "blocking" from video knowledge (use "warning")
- Generated engines must use registry lookups, not hardcoded constants
- All generated components carry provenance (video_id + timestamp)
- Tribal tip confidence reflects extraction confidence (never set to 1.0)
- Fixture mode never makes network calls
- Build must pass before committing — revert if it doesn't

## Chaining
- **Upstream**: Can be called from `/autopilot` Phase 4 or `/forge` Phase 4
- **Downstream**: Generated engines feed `/forge-engines audit`, tips feed `/material-lookup`
- **Pairs with**: `/scrutinize` (review generated code), `/forge-postflight` (full registration check)
- **Data source**: `/video-learn` output feeds `/forge` for deeper iteration on any component
