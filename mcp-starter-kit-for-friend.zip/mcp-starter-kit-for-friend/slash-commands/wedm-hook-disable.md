---
name: wedm-hook-disable
description: Kill switch for WEDM hooks — temporarily disable a specific hook by ID
engines: [HookExecutor]
actions: [wedm_hook_disable, wedm_hook_enable, wedm_hook_list_status]
triggers: [on-demand]
---

# /wedm-hook-disable

Emergency kill switch for WEDM hooks. Disables a specific WEDM hook by ID
temporarily, bypassing safety checks in controlled scenarios.

## Usage

`/wedm-hook-disable <hook-id>` — disable hook
`/wedm-hook-disable <hook-id> --enable` — re-enable hook
`/wedm-hook-disable --list` — show all WEDM hook statuses

## Example Hook IDs

- `wedm-calibration-validate` (blocking)
- `wedm-neural-sanity` (blocking)
- `wedm-gcode-injection` (blocking)
- `wedm-taper-limits` (blocking)
- `wedm-tension-safety` (blocking)
- `wedm-sx-safety` (blocking, S(x) gate)
- `wedm-svi-milestone-gate` (blocking)

## Safety

Disabling a blocking hook lowers `S(x)` safety score. Re-enable ASAP after the
specific exception is resolved. Every disable/enable is logged to audit trail
via `wedm-quality-audit` hook.

## Integration

- Updates `data/state/WEDM_HOOK_DISABLED.json` (append-only log)
- Notifies operator via `wedm-awareness-inject` on session start
- SVI tracks disabled hooks as Psi decrement
