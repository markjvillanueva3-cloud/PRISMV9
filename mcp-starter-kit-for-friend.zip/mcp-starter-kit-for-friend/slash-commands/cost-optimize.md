# Cost Optimize — Manufacturing Cost Minimization Pipeline

Find the cheapest way to make a part without sacrificing quality. Combines material costing, stock optimization, speed/feed alternatives, tool life economics, secondary operations pricing, and total cost breakdown with price breaks.

## Args:
- Part description (e.g., "6061-T6 bracket, 6x4x1 inch, 4 pockets, ±0.001 tolerance")
- `quantity=<N>`: target quantity for optimization (default: 100)
- `target=<$N>`: target cost per part to hit

## Phase 1: Material Cost Analysis
1. Parse input for material, dimensions, features
2. `/material-price` — market-adjusted material cost
   - Current market price per pound/kg
   - Alloy surcharges
   - Minimum order quantities
   - Alternative materials at lower cost (same ISO group)

## Phase 1B: Probabilistic Cost Analysis (NEW)
1. Call `prism_calc` action `probabilistic_costing` — full Monte Carlo cost distribution
   - Params: { baseCost, costComponents: [{name:"material",mean,stdDev}, {name:"labor",...}, {name:"tooling",...}], materialPriceHistory, confidenceLevel: 0.95 }
   - Returns: expectedCost, costCI (95% confidence interval), riskScore, componentSensitivity
   - Uses GARCH for material price volatility + Bootstrap BCa for CI
2. Call `prism_calc` action `capability_with_ci` — Cpk with bootstrap confidence intervals
   - If historical measurements exist, get REAL capability, not theoretical
3. Present: "This job will cost $X ± $Y (95% CI). Risk score: Z%"

## Phase 2: Stock Optimization
1. `/stock-optimize` — optimal stock size selection
   - Standard bar/plate sizes vs custom cut
   - Nesting optimization for multiple parts
   - Material utilization percentage
   - Buy-to-fly ratio
   - Drop/remnant value

## Phase 3: Speed/Feed Cost Comparison
For the planned operations:
1. Run `ultimateSpeedFeedEngine.calculate()` with 3 strategies:
   - **Conservative**: maximize tool life, minimize risk
   - **Balanced**: optimal cost-per-part tradeoff
   - **Aggressive**: minimize cycle time, accept shorter tool life
2. For each strategy, calculate:
   - Cycle time per part
   - Machine hour cost (rate × time)
   - Tool cost per part (tool price ÷ parts per tool)
   - Total variable cost per part

## Phase 4: Tool Life Economics
1. `/wear-analysis` — detailed tool economics
   - Tool life in minutes and parts for each strategy
   - Regrind potential and cost (vs new tool)
   - Tool change time cost
   - Optimal tool change interval (Gilbert economics)
   - Cost crossover point (when aggressive beats conservative)

## Phase 5: Secondary Operations
1. `/secondary-ops` — finishing operation costs
   - Anodize, heat treat, plating, grinding, NDT
   - Per-part pricing at target quantity
   - Alternative processes at lower cost
   - Batch size economics

## Phase 6: Complete Quote
1. `/quote-job` — comprehensive cost breakdown
   - Material cost per part
   - Machining cost per part (time × rate)
   - Tool cost per part
   - Setup cost amortized
   - Secondary ops per part
   - Overhead and margin
   - Price breaks: 1, 10, 50, 100, 500 pcs
   - DfM feedback for cost reduction

## Output Summary
```
COST OPTIMIZE COMPLETE — [Part Description]
=============================================
Target Qty:   [N] pcs
Material:     [name] ($[X]/lb, [X] lb/part)

COST BREAKDOWN (per part at [N] qty):
  Material:        $[X] ([X]% of total)
  Machining:       $[X] ([X]% — [X] min cycle time)
  Tooling:         $[X] ([X]% — [X] parts/tool)
  Setup:           $[X] ([X]% — amortized)
  Secondary ops:   $[X] ([X]%)
  ─────────────────────────────
  TOTAL:           $[X] per part

OPTIMIZATION WINS:
  vs Conservative: -$[X]/part ([X]% savings) using balanced strategy
  vs Default stock: -$[X]/part ([X]% savings) with optimized blank
  Alt material:    [name] saves $[X]/part (if acceptable)

PRICE BREAKS:
  1 pc:   $[X]  |  10 pcs:  $[X]  |  50 pcs:  $[X]
  100 pcs: $[X] |  500 pcs: $[X]

DfM SUGGESTIONS:
  [ranked list of design changes that reduce cost]
```

## Key Engines Used
MaterialDatabaseEngine, UltimateSpeedFeedEngine, AdvancedWearPhysicsEngine,
CycleTimeEstimatorEngine, SustainabilityLCAEngine, ProcessCapabilityEngine
