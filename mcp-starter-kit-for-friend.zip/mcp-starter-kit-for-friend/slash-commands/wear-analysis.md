# Wear Analysis — Advanced Tool Wear & Force Compensation

Comprehensive wear analysis combining adhesive (Usui) + abrasive (Archard) wear, force increase from flank wear, and thermal deflection compensation.

## Args: $ARGUMENTS
- `archard [material]`: Archard abrasive wear rate for specific workpiece type
- `force [VB_mm]`: Force increase from flank wear
- `thermal [temp_C]`: Thermal-compensated deflection at cutting temperature
- `full`: Run all three analyses with cross-linked results
- `coupled [material]`: coupled tool life (Taylor × BUE × chatter × thermal softening)
- `anomaly [signal-data]`: multi-sensor anomaly classification (EMD + PCA + SVM)
- `predict [machineId]`: machine-learned wear prediction using accumulated data
- Empty: interactive — ask for cutting conditions

## Workflow

1. **Archard Wear**: Predict abrasive wear rate — critical for cast iron, composites, hardened steel
2. **Force Compensation**: Calculate force increase from flank wear land (Smithey model)
3. **Thermal Deflection**: Adjust tool deflection for temperature-dependent Young's modulus

## Key Physics

**Archard**: `dVB/dt = K x H_wp/H_tool x sigma x v_s` — abrasive wear from hard particles
**Smithey**: `F_worn = F_fresh x (1 + Cw x VB)` — ploughing force on wear land
**Thermal**: `E(T) = E0 x (1 - alpha x dT)` — stiffness drops 5-15% at cutting temperature

## Safety Thresholds
- VB > 0.3mm: ISO 3685 tool change limit
- Force increase > 50%: SAFETY flag — tool change required
- HSS at > 400C: Tempering risk — permanent stiffness loss

## Actions Used
- `archard_wear` — abrasive wear rate calculation
- `wear_force_correction` — force increase from wear
- `thermal_deflection` — temperature-adjusted deflection
- `wear_progression` — existing Usui adhesive wear
