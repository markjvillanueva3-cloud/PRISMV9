# ROI Analysis — Upgrade Payback Calculator

Analyze your current shop setup and recommend upgrades with payback justification. Compares current tools, holders, coolant, and machine against optimal setup. Calculates per-part savings, payback period, and annual ROI.

## Args: $ARGUMENTS
- Empty: interactive — prompt for current setup and part volume
- `tools`: analyze tool upgrades only
- `holders`: analyze holder upgrades only
- `machine`: analyze machine upgrade ROI
- `full`: complete analysis across all categories

## Execution

1. **Gather Current Setup**:
   - Current tools (type, diameter, condition, cost)
   - Current machine (name, RPM, power, taper, age)
   - Current holders (type, TIR)
   - Current coolant (type)
   - Annual part volume
   - Current cost per part

2. **Run ROI Analysis**:
   ```
   Engine: ROIAdvisorEngine.analyze(current, optimal, volume, cycle_time, cost)
   ```

3. **Report**:
   ```
   ROI ANALYSIS
   =============
   Current setup cost/part:  $[X.XX]

   UPGRADE SUGGESTIONS (sorted by payback speed):

   QUICK WINS (payback < 3 months):
     [item] — $[cost] → saves $[X]/part
     Payback: [N] parts ([M] months)

   MEDIUM TERM (3-12 months):
     [item] — $[cost] → saves $[X]/part

   LONG TERM (12+ months):
     [item] — $[cost] → saves $[X]/part

   TOTAL INVESTMENT:     $[X]
   ANNUAL SAVINGS:       $[X]
   OVERALL ROI:          [X]%
   PAYBACK:              [X] months
   ```

## Engines Used
- ROIAdvisorEngine (payback analysis)
- SpeedFeedOrchestratorEngine (optimal S/F comparison)
- InventoryAwareToolSelectorEngine (tool gap analysis)
- QuoteEstimatorEngine (cost modeling)
