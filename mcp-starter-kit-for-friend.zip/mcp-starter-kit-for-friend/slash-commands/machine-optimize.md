# Machine Optimize — Full Machine Utilization Analysis

Maximize throughput on a specific machine while staying within its limits. Combines machine capability check, harmonic RPM selection, optimized speeds/feeds, stability analysis, and cycle time optimization.

## Args:
- Machine + operation description (e.g., "Haas VF-2SS roughing 4140 steel")
- Machine profile name from catalog (e.g., "haas_vf2ss")
- `chatter`: focus on chatter elimination
- `pareto`: multi-objective Pareto optimization (cost vs life vs finish vs MRR) via `prism_calc` action `pareto_optimize`
- `intelligence [machineId]`: full machine learning report via `prism_calc` action `machine_intelligence`
- `compare [machine1] [machine2]`: compare machines via `prism_calc` action `compare_machines`
- `fleet`: fleet-wide learning propagation via `prism_calc` action `fleet_learning`
- `dimensionless`: compute 8 process health numbers via `prism_calc` action `all_dimensionless`

## Phase 1: Machine Capability Assessment
1. Parse input for machine, material, operation
2. `/machine-check` — load machine profile (910 machines, 48 manufacturers)
   - Spindle speed range, power curve, torque curve
   - Axis travel, rapid rates, acceleration
   - Coolant system capabilities
   - Controller type and features

## Phase 2: Harmonic RPM Selection
1. `/spindle-optimize` — stability lobe analysis
   - Natural frequencies of spindle + tool + workpiece system
   - Stability lobes diagram (depth vs RPM)
   - Sweet-spot RPMs for maximum stable depth
   - Chatter-free zones identification

## Phase 3: Speed/Feed Optimization
For the selected stable RPMs:
1. Run `ultimateSpeedFeedEngine.calculate()` with machine limits enforced
   - Power budget constraint
   - Torque budget constraint
   - Feed rate limits (axis max feed)
   - Spindle speed clamped to machine range
2. Present 3 profiles: conservative / balanced / aggressive
3. Include: forces, deflection, power consumption %, torque %

## Phase 4: Stability Analysis
1. `/wear-analysis` — tool wear at optimized parameters
   - Predicted life at each profile
   - Force progression over tool life
   - Vibration trend prediction
2. Process damping analysis for low-speed stability
3. SSV (Spindle Speed Variation) recommendation if beneficial

## Phase 5: Cycle Time Optimization
1. `/process-calc` — full process calculation
   - Material removal rate at each profile
   - Cycle time comparison (conservative vs aggressive)
   - Machine utilization percentage
   - Bottleneck identification (spindle-limited vs feed-limited vs power-limited)

## Output Summary
```
MACHINE OPTIMIZE COMPLETE — [Machine] + [Material/Operation]
=============================================================
Machine:      [name] ([power]kW, [rpm_max] RPM max)
Material:     [name] (ISO [group])
Operation:    [type]

Spindle Analysis:
  Sweet-spot RPMs:  [list]
  Stable depth max: [X] mm at [X] RPM
  Chatter risk:     [LOW/MEDIUM/HIGH]
  SSV recommended:  [YES/NO]

Optimized Parameters:
Profile      | RPM   | Feed  | DOC   | Power% | Torque% | MRR
Conservative | [X]   | [X]   | [X]   | [X]%   | [X]%    | [X]
Balanced     | [X]   | [X]   | [X]   | [X]%   | [X]%    | [X]
Aggressive   | [X]   | [X]   | [X]   | [X]%   | [X]%    | [X]

Machine Utilization:
  Power usage:      [X]% of [X] kW
  Torque usage:     [X]% of [X] Nm
  Spindle usage:    [X]% of max RPM
  Limiting factor:  [spindle/power/torque/feed]
  Cycle time saved: [X]% vs default parameters
```

## Key Engines Used
MachineProfileEngine, UltimateSpeedFeedEngine, AdvancedWearPhysicsEngine,
MotionDynamicsProfileEngine, CycleTimeEstimatorEngine, ProcessCapabilityEngine
