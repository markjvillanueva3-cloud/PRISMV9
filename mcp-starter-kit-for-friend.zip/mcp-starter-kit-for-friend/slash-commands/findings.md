# Findings — Open Issue Tracker

You are scanning all PRISM milestone envelopes and state files to build a consolidated view of open findings (CRITICAL, MAJOR, MINOR). This helps prioritize what to fix next and tracks resolution progress.

## Args: $ARGUMENTS
- Empty: show all open findings across all milestones
- `critical`: show only CRITICAL findings
- `major`: show CRITICAL + MAJOR findings
- `[milestone-id]`: show findings for a specific milestone (e.g., `findings QA-MS7`)
- `[track]`: show findings for a track (e.g., `findings SYS`, `findings QA`, `findings REM`)
- `summary`: counts only, no details
- `resolved`: include resolved findings too

## Step 1: Scan Milestone Envelopes
Read all envelope files from `C:/PRISM/mcp-server/data/milestones/*.json`.
For each envelope, extract any findings data:
- Look for `findings`, `issues`, `audit_results`, or `open_items` fields in units
- Look for step results that contain severity markers (CRITICAL, MAJOR, MINOR)
- Track which milestone and unit each finding belongs to

## Step 2: Scan State Files
Check additional finding sources:
- `C:/PRISM/state/CURRENT_POSITION.md` — may list open issues
- `C:/PRISM/state/ralph_scrutiny_memories.md` — Ralph Loop findings
- `C:/PRISM/state/ralph_validation_memories.md` — validation findings
- `C:/PRISM/state/COMPREHENSIVE_AUDIT.json` — audit findings
- `C:/PRISM/state/CAPABILITY_AUDIT.json` — capability gaps

## Step 3: Cross-Reference MEMORY.md
Read MEMORY.md for known finding counts:
- Currently documented: "3 CRITICAL remaining, ~25 open MAJOR"
- Compare scanned findings against this baseline
- Flag any drift between documented and actual counts

## Step 4: Classify and Deduplicate
For each finding:
- Assign severity: CRITICAL / MAJOR / MINOR
- Assign category: SAFETY / QUALITY / ARCHITECTURE / WIRING / PERFORMANCE / DOCUMENTATION
- Deduplicate findings that appear in multiple sources
- Track resolution status: OPEN / IN_PROGRESS / RESOLVED

## Step 5: Apply Filters
Based on args, filter the findings list:
- `critical` → only CRITICAL severity
- `major` → CRITICAL + MAJOR
- `[milestone-id]` → only from that milestone
- `[track]` → only from milestones in that track (QA, SYS, REM, etc.)
- `resolved` → include RESOLVED findings in output

## Step 6: Report

### Full Report (default)
```
PRISM FINDINGS
==============
Total: [N] open ([N] CRITICAL, [N] MAJOR, [N] MINOR)
Resolved: [N] (not shown — use /findings resolved)

CRITICAL ([N]):
  [C1] [milestone] [category] — [description]
      Source: [envelope/state file]
      Unit: [unit-id if applicable]

  [C2] [milestone] [category] — [description]
      Source: [envelope/state file]

MAJOR ([N]):
  [M1] [milestone] [category] — [description]
  [M2] [milestone] [category] — [description]
  ...

MINOR ([N]):
  [m1] [milestone] [category] — [description]
  ...

By Track:
  QA:  [N] open
  SYS: [N] open
  REM: [N] open
  Other: [N] open

Memory Sync: [MATCH / DRIFT — documented says X, actual is Y]
```

### Summary Report (`/findings summary`)
```
FINDINGS SUMMARY
================
CRITICAL: [N]
MAJOR:    [N]
MINOR:    [N]
Total:    [N] open, [N] resolved

Top Tracks: [track]: [N], [track]: [N]
Memory:     [MATCH/DRIFT]
```

## Step 7: Suggest Next Actions
Based on findings:
- If CRITICAL > 0: "Fix CRITICALs before new feature work. Use `/pick-task` to find remediation units."
- If MAJOR > 10: "Consider a focused remediation sprint. Run `/rgs` to check for REM track units."
- If findings drift from MEMORY.md: "Update MEMORY.md counts: `/sync counts`"

## Error Handling
- **No findings found:** Report "No open findings detected — system clean" (verify this isn't a scan failure)
- **Envelope parse error:** Skip malformed envelopes, report which ones couldn't be parsed
- **Missing state files:** Skip missing files, note which sources were unavailable

## Chaining
- After `/findings`: fix issues → `/test` → `/auto-commit`
- Feeds into: `/pick-task` (find remediation units), `/audit-task` (verify fixes)
- Updated by: `/ship` (marks findings as resolved when units complete)
