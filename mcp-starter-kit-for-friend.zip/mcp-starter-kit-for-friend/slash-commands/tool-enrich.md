# Tool Enrich — Unified Tool Database Enrichment Pipeline

You are running a specialized pipeline that enriches the PRISM ToolCatalogEngine with cutting tool data extracted from PDFs, manufacturer websites, and video tutorials. The goal is comprehensive physical dimensions for collision avoidance, optimized cutting parameters per material, and manufacturer-specific recommendations.

## Args: $ARGUMENTS
- **PDF file**: extract tools from a manufacturer catalog PDF
  Example: `/tool-enrich C:/PRISM/CATALOGS/YU25_America.pdf`
- **PDF directory**: batch-extract from all PDFs in a folder
  Example: `/tool-enrich C:/PRISM/CATALOGS/`
- **URL**: scrape tool data from a manufacturer website
  Example: `/tool-enrich https://www.harveyperformance.com/in-the-loupe/speeds-feeds/`
- **Video**: extract tooling knowledge from a machining video
  Example: `/tool-enrich https://www.youtube.com/watch?v=XXXX`
- `inventory`: show catalog inventory status (extracted vs pending)
- `stats`: show current ToolCatalogEngine statistics
- `collision [tool_id]`: show collision zones for a specific tool
- `validate`: audit data completeness across all tools
- `--manufacturer=<name>`: filter extraction to specific manufacturer
- `--type=<end_mill|drill|ball_mill|holder>`: filter by tool type
- `--dry-run`: extract but don't integrate (preview mode)
- `--rebuild-collision`: regenerate collision-avoidance-data.json from all sources

## What We Extract

### 1. Physical Geometry (Collision Avoidance)
Every tool needs these dimensions for gouge-free toolpath generation:
| Field | ISO 13399 | Description | Priority |
|-------|-----------|-------------|----------|
| `cutting_diameter_mm` | DC | Cutting diameter | CRITICAL |
| `shank_diameter_mm` | DCONMS | Shank diameter | CRITICAL |
| `overall_length_mm` | LF/OAL | Overall length | CRITICAL |
| `flute_length_mm` | APMX/LU/LOC | Length of cut | CRITICAL |
| `neck_diameter_mm` | DCON | Neck/reduced diameter | HIGH |
| `neck_length_mm` | LN | Neck length | HIGH |
| `corner_radius_mm` | RE | Corner radius | MEDIUM |
| `point_angle_deg` | SIG | Drill point angle | MEDIUM |
| `helix_angle_deg` | - | Helix angle | LOW |
| `flute_count` | NOF | Number of flutes | MEDIUM |

### 2. Collision Zones (per tool)
Pre-computed diameter profile from tip to holder interface:
- **Cutting zone**: z=0 to z=LOC, diameter=DC
- **Neck zone**: z=LOC to z=LOC+LN, diameter=DCON (if reduced neck)
- **Shank zone**: z=shank_start to z=OAL, diameter=DCONMS
- **Holder zone**: z=stickout to z=stickout+gauge, diameter=holder_body_dia

### 3. Cutting Parameters (per material)
| Parameter | Unit | Source Priority |
|-----------|------|-----------------|
| `vc_min/max` | m/min | Manufacturer table > formula > estimate |
| `fz_min/max` | mm/tooth | Manufacturer table > Harvey calc > estimate |
| `ap_max` | mm (xD) | Manufacturer recommendation |
| `ae_max` | mm (xD) | Manufacturer recommendation |
| `ramp_angle_max` | deg | Catalog spec or 2-3 deg default |
| `plunge_rate` | mm/min | Catalog spec |
| `coolant_type` | enum | Through-tool / flood / MQL / dry |
| `max_rpm` | rpm | Holder or tool limit |

ISO material groups: P (steel), M (stainless), K (cast iron), N (aluminum), S (superalloy), H (hardened)

### 4. Manufacturer Recommendations
- **Application notes**: "best for slotting", "not recommended for titanium"
- **Grade suitability**: first_choice / second_choice / not_recommended per ISO group
- **Coating compatibility**: TiAlN, AlCrN, DLC, uncoated — per material
- **Chipbreaker geometry**: for inserts (positive/negative rake, chip control)
- **Holder compatibility**: recommended holder types, min/max stickout

### 5. Kinematics Data
- **Max RPM by holder type**: shrink_fit (42000), hydraulic (50000), ER collet (25000)
- **Runout spec**: holder runout (3um shrink, 5um hydraulic, 10um ER)
- **Balance grade**: G2.5 / G6.3 at max RPM
- **Deflection estimate**: based on tool geometry + stickout

## Phase 1: Source Detection + Smart Config

```
SMART CONFIG
Role:   Manufacturing Data Engineer + Collision Avoidance Specialist
Model:  OPUS
Effort: HIGH
Reason: Tool enrichment requires precise dimensional extraction + cutting parameter validation
```

### 1A: Detect Source Type
- **PDF** (file path ending `.pdf`): Route to Phase 2A
- **Directory** (path with no extension): Scan for PDFs, route to Phase 2A batch
- **URL with manufacturer domain**: Route to Phase 2B (web scraping)
- **YouTube URL**: Route to Phase 2C (video extraction)
- **`inventory`**: Show catalog-inventory.json status, exit
- **`stats`**: Call ToolCatalogEngine.stats(), show totals, exit
- **`validate`**: Run data completeness audit, exit

### 1B: Load Current State
1. Read `C:/PRISM/mcp-server/src/data/catalog-inventory.json` for extraction status
2. Check ToolCatalogEngine tool count via test or direct import
3. Load collision-avoidance-data.json for current coverage
4. Report: `[N] tools, [N] holders, [N] with collision data, [N] catalogs extracted`

## Phase 2A: PDF Catalog Extraction

### Step 1: Scout PDF
```python
import pymupdf
doc = pymupdf.open(pdf_path)
# Count pages, find tables, detect manufacturer, identify column format
```
Report:
```
PDF SCOUTED: [filename]
  Pages: [N] | Tables found: [N]/[first_50]
  Manufacturer: [detected or "Unknown"]
  Column format: [ISO 13399 / d1-d2-l1 / custom]
  Estimated tools: [N]
  Units: [inch/metric]
```

### Step 2: Detect Table Format
Look for these column header patterns (priority order):
1. **ISO 13399**: DC, DCONMS, OAL, APMX/LU, RE, NOF
2. **Guhring-style**: d1, d2, l1, l2, l3
3. **Generic**: Diameter, Shank, Length, LOC, Flute Length
4. **Transposed** (Haimer-style): dimensions as rows, sizes as columns
5. **Holder format**: Bore, Body Dia, Gauge Length, Taper

### Step 3: Extract with Universal Parser
Use the extraction infrastructure at `C:/PRISM/mcp-server/scripts/`:
- `extract-remaining-catalogs.py` — universal ISO 13399 extractor
- `extract-osg-tools.py` — OSG-specific (multi-column spanning headers)
- `extract-guhring-tools.py` — Guhring d1/d2/l1 format
- `extract-sandvik-tools.py` — Sandvik with European decimals
- `extract-haimer-holders.py` — transposed table format

Python: `C:/Users/Admin.DIGITALSTORM-PC/AppData/Local/Programs/Python/Python312/python.exe`
Library: pymupdf (for table extraction)

### Step 4: Validate Extracted Data
For each tool, check:
- [ ] cutting_diameter_mm > 0 and < 200mm (or < 6" for inch)
- [ ] shank_diameter_mm >= cutting_diameter_mm * 0.5 (shank not smaller than half cutting dia)
- [ ] overall_length_mm > flute_length_mm (OAL must exceed LOC)
- [ ] flute_length_mm > 0 and < overall_length_mm
- [ ] If drill: point_angle between 90-180 degrees
- [ ] No duplicate designations within same manufacturer

### Step 5: Generate TypeScript Catalog
1. Save extracted JSON to `src/data/{manufacturer}-tools-extracted.json`
2. Generate TypeScript: `src/data/{manufacturer}-tool-catalog.ts` (or add to `additional-tool-catalog.ts`)
3. Add `@ts-nocheck` if > 3000 array elements (TS2590 workaround)
4. Import in ToolCatalogEngine.ts
5. Add `_load{Manufacturer}Tools()` method following existing pattern

### Step 6: Generate Collision Zones
Run `scripts/generate-collision-data.py` to regenerate collision-avoidance-data.json

## Phase 2B: Website Scraping

### Supported Manufacturer Sites
| Site | Data Available | Method |
|------|---------------|--------|
| Harvey Performance | Speeds/feeds calculator, tool specs | WebFetch + parse HTML tables |
| Kennametal ToolBoss | Full tool specs, cutting data | WebFetch + JSON API |
| Sandvik CoroPlus | ISO 13399 data, recommendations | WebFetch + structured data |
| OSG USA | Tool specifications | WebFetch + parse catalog pages |
| ISCAR ITA | Grade recommendations, cutting data | WebFetch + parse results |

### Extraction Flow
1. **WebFetch** the URL
2. **Parse** HTML tables / JSON responses for tool dimensions
3. **Map** to standard schema (cutting_diameter_mm, shank_diameter_mm, etc.)
4. **Merge** with existing catalog data (update cutting parameters, add missing dimensions)
5. **Validate** against physical constraints

### Cutting Parameter Enrichment
For each tool in the catalog that lacks cutting parameters:
1. Look up manufacturer recommendations by tool series + material
2. If not available, use Harvey Performance calculator formulas:
   - `Vc = SFM * 0.3048` (surface speed)
   - `fz = chipload_base * sqrt(diameter/10)` (feed per tooth scaling)
   - `ap_max = LOC * 0.5` for roughing, `LOC * 0.1` for finishing
   - `ae_max = diameter * 0.5` for roughing, `diameter * 0.05` for finishing
3. Apply ISO group modifiers: P=1.0x, M=0.7x, K=0.8x, N=2.0x, S=0.3x, H=0.5x

## Phase 2C: Video Extraction

Chain to `/video-learn` with tooling-focused extraction prompts:
1. Extract tool dimensions mentioned (diameter, LOC, OAL)
2. Extract cutting parameters demonstrated (RPM, feed rate, DOC, WOC)
3. Extract material-specific recommendations
4. Extract holder/workholding setup details
5. Map to ToolCatalogEngine schema and merge

## Phase 3: Integration

### 3A: Import New Data into ToolCatalogEngine
Add import statement and loader method following existing patterns:
```typescript
import { NEW_TOOLS } from "../data/new-tool-catalog.js";
// In constructor:
this._loadNewTools();
// Add private method:
private _loadNewTools(): void { ... }
```

### 3B: Update Holder Lookup (if holders extracted)
Add to `_findHolder()` tier chain (currently 5-tier: Tungaloy -> Haimer -> Guhring -> BIG DAISHOWA -> generic)

### 3C: Regenerate Collision Data
```bash
python scripts/generate-collision-data.py
```

### 3D: Update catalog-inventory.json
Mark processed catalogs as extracted, update totals.

## Phase 4: Verification

1. `npx tsc --noEmit` — no new TypeScript errors
2. `npx vitest run src/__tests__/tool-catalog-engine.test.ts` — all 46+ tests pass
3. Spot-check: pick 3 random tools, verify dimensions are physically reasonable
4. Collision data: verify JSON regenerated with updated count

## Phase 5: Commit + Report

```
TOOL-ENRICH COMPLETE
====================
Source:        [PDF/URL/video] — [filename/url]
Manufacturer:  [name]
Tools added:   [N] ([N] end_mill, [N] drill, [N] ball_mill, ...)
Holders added: [N] (if applicable)
Collision:     [N] tools with Z-position profiles

Data Quality:
  With OAL:    [N]% | With LOC: [N]% | With shank: [N]%
  With neck:   [N]% | With cutting params: [N]%

Catalog Totals:
  Tools:    [N] across [N] manufacturers
  Holders:  [N] (5-tier lookup)
  Collision: [N] tools covered

Build: PASS | Tests: [N] passing
Committed: [hash]

Next: /tool-enrich [another-source] or /tool-catalog stats
```

## Data File Locations
| File | Purpose |
|------|---------|
| `src/data/*-tool-catalog.ts` | Per-manufacturer TypeScript tool arrays |
| `src/data/additional-tool-catalog.ts` | Multi-manufacturer overflow (Flash, MA Ford, etc.) |
| `src/data/*-holder-catalog.ts` | Holder catalogs (Tungaloy, Haimer, Guhring, BIG DAISHOWA) |
| `src/data/*-tools-extracted.json` | Raw extraction JSON (gitignored) |
| `src/data/collision-avoidance-data.json` | Pre-computed collision zones for all tools |
| `src/data/catalog-inventory.json` | PDF catalog inventory + extraction status |
| `src/engines/ToolCatalogEngine.ts` | Unified engine with all loaders |
| `scripts/extract-*.py` | Per-format extraction scripts |
| `scripts/generate-collision-data.py` | Collision zone generator |
| `scripts/generate-additional-catalog-ts.py` | JSON-to-TypeScript converter |

## Extraction Script Library
| Script | Format | Manufacturer |
|--------|--------|-------------|
| `extract-remaining-catalogs.py` | Universal ISO 13399 | Any with DC/DCONMS/OAL columns |
| `extract-osg-tools.py` | Multi-column spanning | OSG |
| `extract-guhring-tools.py` | d1/d2/l1/l2 | Guhring |
| `extract-sandvik-tools.py` | European decimals | Sandvik/WIDIA |
| `extract-haimer-holders.py` | Transposed tables | Haimer |

## Current Catalog Status
- **15/45 PDFs extracted** (see catalog-inventory.json for full list)
- **~24,807 tools** + **1,164 holders** across 15 manufacturers
- **22,062 tools** with pre-computed collision zones
- PDF extraction largely exhausted — remaining are indexable (Kennametal, ISCAR, Korloy rotating/turning, Ingersoll), image-based (REGO-FIX, Zeni), complex format (Emuge, Accupro, YG-1), or toolholding accessories (Global CNC, CAMFIX)
- Next enrichment targets: web-based cutting parameter data, manufacturer speed/feed calculators

## Safety Rails
- Never overwrite existing tool data — always merge/append
- Validate physical dimensions before integration (reject impossible values)
- Keep `@ts-nocheck` for large catalog files (>3000 elements)
- Build must pass before committing
- All extraction scripts save raw JSON first, then generate TypeScript
- Collision data regenerated from all sources, never hand-edited

## Chaining
- **Upstream**: `/autopilot`, `/forge`
- **Downstream**: `/tool-catalog` (query enriched data), `/machine-check` (collision avoidance)
- **Pairs with**: `/pdf-learn` (for general knowledge), `/video-learn` (for parameter extraction)
- **Data feeds**: CollisionEngine, SpindleOptimizeEngine, WearAnalysisEngine
