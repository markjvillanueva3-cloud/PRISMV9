# Hook Status — Enforcement Dashboard

Show the current state of all enforcement hooks, session trackers, and the stagnant engine ledger.

## Args: $ARGUMENTS
- Empty: full dashboard
- `ledger`: show only the unwired engine ledger
- `session`: show only session edit/wiring/knowledge trackers

## Dashboard Output

```
ENFORCEMENT DASHBOARD
=====================
Hooks: [N] active across [N] events
  PRE:     [N] (knowledge consult, context retention, plan-before-build, duplicate check, stagnant check, KG reminder, safety-gates, directory-freeze)
  POST:    [N] (stub detector, test quality, constants, unit counter, knowledge tracker, auto-compact, engine review reminder, compact-counter, safety-escalation, mcp-health-recovery)
  COMPACT: [N] (review gate, wiring gate, forge-triple gate, index sync, session audit agent)
  POST-COMPACT: [N] (auto-continue)
  STOP:    [N] (wiring gate, pattern-extractor)

Session Trackers:
  Edits:              [N] / 60 (BLOCK threshold)
  Engine edits:       [N] since last /prism-review
  Engines written:    [list]
  Tests written:      [list]
  Knowledge consulted: [domains]
  Plan active:        [yes/no — engine name]
  Compaction pressure: [LOW/MODERATE/HIGH]

Unwired Engine Ledger:
  Total tracked:    [N]
  Currently unwired: [N]
  Wired since last: [N]
  Stagnant (2+ sessions): [list with dates]

  [engine_name] — unwired for [N] sessions (since YYYY-MM-DD)
  [engine_name] — wired ✓ (resolved)
  ...
```

## How to Read

Read the relevant state files:
1. `C:/PRISM/state/session-edit-counter.json` — edit counts, engine/test tracking
2. `C:/PRISM/state/session-wiring-tracker.json` — engines written this session
3. `C:/PRISM/state/knowledge-consult-tracker.json` — domain consultation tracking
4. `C:/PRISM/state/active-plan.json` — current build plan
5. `C:/PRISM/state/auto-compact-tracker.json` — compaction pressure
6. `C:/PRISM/state/unwired-engines-ledger.json` — PERSISTENT stagnant engine tracker
7. `C:/PRISM/state/stagnant-check-done.json` — today's stagnant check status
8. `H:/prism/.claude/cache/frozen-dirs.json` — directory freeze list (read by directory-freeze.mjs)
9. `H:/prism/.claude/cache/counters/` — tool call counters (read by compact-counter.mjs, mcp-health-recovery.mjs)

Present the data in the format above. Highlight any CRITICAL items (stagnant engines, high edit count, missing plans).
