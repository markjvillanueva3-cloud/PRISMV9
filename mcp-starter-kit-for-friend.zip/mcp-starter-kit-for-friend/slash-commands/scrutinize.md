---
effort: medium
maxTurns: 15
---

# Scrutinize — Standalone Code Quality Review

You are performing a focused code quality review. This is the standalone version of Autopilot Phase 6 — lighter than a full audit, heavier than a glance. Use before committing, before shipping, or anytime you want a quick quality check.

## Args: $ARGUMENTS
- Empty: review all uncommitted changes (`git diff HEAD`)
- `staged`: review only staged changes (`git diff --cached`)
- `[file-path]`: review a specific file
- `[pattern]`: review files matching a glob (e.g., `src/engines/*.ts`) (PREFER: use ENGINE_DIGEST.md instead of Glob)
- `last`: review changes in the last commit (`git diff HEAD~1`)
- `quick`: abbreviated check — TypeScript errors + any-count only

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL quality dimensions** — correctness, safety, performance, DSL compliance, math accuracy.
- Check every formula and physics model against published references when reviewing engine code.
- "Clean" claims REQUIRE citing specific checks performed.
- **Completeness > Speed.** A missed defect in production code is permanent technical debt.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Step 1: Identify Review Scope
Based on args, determine which files to review:
- Empty: `git diff HEAD --name-only` from `C:/PRISM/mcp-server/`
- `staged`: `git diff --cached --name-only`
- `last`: `git diff HEAD~1 --name-only`
- `[file]`: the specified file
- `[pattern]`: glob match

If no changes found: report "Nothing to scrutinize — working tree clean" and stop.

## Step 2: TypeScript Compilation Check
Run `npm run build` from `C:/PRISM/mcp-server/`:
- If PASS: note "Build: PASS"
- If FAIL: report errors with file:line, these are CRITICAL findings

## Step 3: Quality Scan
For each file in scope, check for:

### Code Smells (MINOR)
- `any` type usage (more than 3 per file = flag)
- `console.log` / `console.debug` left in production code
- Hardcoded magic numbers (numbers without named constants)
- Commented-out code blocks (>3 lines)
- Functions longer than 50 lines
- Deeply nested conditionals (>3 levels)

### Implementation Gaps (MAJOR)
- `TODO` / `FIXME` / `HACK` comments
- Empty catch blocks (`catch (e) {}`)
- Missing error handling on async operations
- Placeholder implementations (empty function bodies, `return null`)
- Switch statements without default cases
- Unused imports or variables

### Safety Concerns (CRITICAL)
- Division without zero-check on dynamic values
- Array access without bounds check on user input
- S(x) safety score bypass or hardcoded approval
- Unchecked type assertions (`as any`, `as unknown as X`)
- Missing null/undefined checks on optional chains

### DSL Compliance (MAJOR)
- Engine calcs returning raw numbers instead of `{value, unit, uncertainty, source}`
- Dispatcher actions missing name, description, or parameters
- Missing parameter normalization before engine calls
- Safety-relevant outputs not feeding S(x) scoring

## Step 4: Report Findings
```
SCRUTINY REPORT
===============
Scope:    [N] files reviewed ([source: git diff / staged / specific])
Build:    [PASS/FAIL]

Findings:
  CRITICAL: [N]
  MAJOR:    [N]
  MINOR:    [N]

Details:
  [severity] [file:line] — [description]
  [severity] [file:line] — [description]
  ...

Verdict:  [CLEAN — ship it / FIX CRITICAL FIRST / REVIEW MAJORS]
```

## Step 5: Auto-Fix Offer
If findings exist:
- CRITICAL: "Fix these before committing. Fixing now..."
- MAJOR: Fix if straightforward (<5 lines each)
- MINOR: Log but don't fix unless asked

After fixing, re-run build to verify no regressions.

## Quick Mode (`/scrutinize quick`)
Abbreviated check — only:
1. `npm run build` (TypeScript errors)
2. Count `any` types in changed files
3. Count `TODO`/`FIXME` in changed files
4. Report one-liner: `Quick: Build [P/F] | any:[N] | TODO:[N] — [CLEAN/REVIEW]`

## Error Handling
- **Not in git repo**: "Not a git repository. Specify a file path instead."
- **No changes**: "Working tree clean — nothing to scrutinize."
- **Build hangs**: Kill after 60s, report as BUILD TIMEOUT

## Chaining
- Before committing: `/scrutinize staged` → fix → `/auto-commit`
- Before shipping: `/scrutinize` → fix → `/ship`
- After forge: `/forge-engines` → `/scrutinize` → `/auto-commit`
- Quick check: `/scrutinize quick` (5-second quality pulse)
- Pairs with: `/scope` (impact analysis), `/check-dsl` (DSL deep-dive), `/test` (run tests)

## Team Mode (`/scrutinize team`)
Upgrade to multi-role team scrutiny — launches 3 domain-specialist agents:
1. Auto-detect domain from files (physics, CAM, business, quality, infra, fusion)
2. Select 3 appropriate roles (see `/prism-review` for role matrix)
3. Each agent reviews from their specialist perspective
4. Consolidate into single report with cross-role insights
This is the same engine as `/prism-review` but invoked via /scrutinize for convenience.
The review rubric is defined in `H:/prism/.claude/helpers/review-rubric.json` — 7 dimensions: correctness, completeness, consistency, safety, performance, physics_accuracy, shop_acceptance.

## Deeper Analysis (background forge commands)
When scrutinize findings suggest systemic issues, recommend these background-runnable forge commands:
- Many `any` types → `/forge-types report` for full type coverage map
- Many code smells → `/forge-audit` for comprehensive quality scan
- Dead code suspected → `/forge-cleanup dead-code` for unused export detection
- Dependency issues → `/forge-deps security` for vulnerability check
- Wiring concerns → `/forge-wiring` for full chain validation
- Multi-role deep review → `/prism-review` for 3-agent domain-specific team review
