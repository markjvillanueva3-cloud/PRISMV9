# YOLO Mode — Maximum Velocity Development

Move fast, decide autonomously, minimize questions, maximize output, auto-fix issues.

## Args: $ARGUMENTS
- Empty: activate YOLO mode
- `off`: deactivate
- `status`: report state

## Core Rules
- **Zero questions**: Never ask "Should I proceed?", "Ready?", or variations. Just flow.
- **Auto-select**: Pick highest priority task without waiting for confirmation.
- **Immediate execution**: Read, act, parallel ops. Don't explain what you're about to do — just do it.
- **Write directly**: Don't propose changes — make them. Fix issues without asking.
- **Only ask** if genuinely blocking ambiguity (two fundamentally different outcomes, can't infer intent).

## Auto-Fix Protocol
```
MAX_ATTEMPTS = 3 per error
1. DIAGNOSE — read error output, identify root cause
2. FIX — apply fix based on error type
3. RETRY — re-run failed action
4. After 3 fails → LOG, SKIP, REPORT at end
```

**Error handling by type:**
| Error | Fix approach |
|-------|-------------|
| Build/compile | Parse file:line, fix type/import/syntax, rebuild |
| Test failure | Fix CODE not test (unless expectation wrong), re-run |
| Hook block | Read block reason, switch to correct tool/approach |
| Git conflict | Read markers, keep version matching intent, resolve |
| Import error | Check path, update import, break circular deps |
| Runtime error | Read stack trace, add guards/null checks |

**Rollback**: Note git HEAD before risky changes. After 3 fails: `git stash`, restore, report.

## Safety Rails (always enforced, even in YOLO)
- Hookify BLOCK rules (rm -rf, force-push, reset --hard, delete-main, drop-table)
- Hookify WARN rules (secrets, XSS, SQL injection, path traversal)
- pretooluse-unified guards (safety chain, material DB, file routing)
- Never skip tests/builds, never commit secrets, never bypass S(x)

## Activation
```
YOLO MODE: ACTIVE
Permissions: BYPASS (hooks enforced) | Decisions: AUTONOMOUS
Questions: CRITICAL ONLY | Auto-fix: 3 attempts | Safety: ENFORCED
```

## Deactivation (`/yolo-mode off`)
```
YOLO MODE: DEACTIVATED
Auto-fix log: [N] errors fixed, [N] skipped
Returning to interactive mode.
```
