# Video Replay — Autonomous CAD/CAM from Video

Watch a tutorial video and automatically reproduce the demonstrated CAD work.

## Args: $ARGUMENTS
- Path to a local video file (mp4, avi, mkv, mov)
- Optional: `--dry-run` (extract + generate code but don't execute)
- Optional: `--target onshape|tinkercad|freecad|cadquery` (default: cadquery)
- Optional: `--parametric` (generate parametric script with named variables)

## Pipeline

1. **Extract** keyframes from video (FFmpeg)
2. **Recognize** CAD operations at each step (Claude Vision + action classifier)
3. **Validate** action sequence (logical consistency, dependency graph)
4. **Generate** CadQuery Python script (or Playwright GUI script)
5. **Execute** the generated code via CadBridge
6. **Verify** output geometry matches video expectations
7. **Retry** with corrections if needed (up to 3 attempts)
8. **Report** results with generated script + execution summary

## Usage

```
/video-replay path/to/tutorial.mp4
/video-replay tutorial.mp4 --dry-run
/video-replay tutorial.mp4 --target onshape
/video-replay tutorial.mp4 --parametric
```

## Execution

```
Smart: COMPUTER VISION SPECIALIST + CAD ENGINEER | OPUS | HIGH
```

### Step 1: Validate Input
- Confirm video file exists at the provided path
- Check FFmpeg is available (`ffmpeg -version`)
- Parse optional flags from args

### Step 2: Extract Actions
Use VideoActionExtractorEngine to process the video:
```typescript
const actions = videoActionExtractorEngine.processVideoForActions(videoPath, {
  keyframe_interval_s: 2,
  ocr_enabled: true,
  target_software: target || "generic"
});
```

### Step 3: Review Extracted Actions
Display the extracted action sequence to user:
- Show each step: timestamp, operation, parameters, confidence
- Highlight low-confidence steps (< 0.6) that may need review
- Show difficulty rating and estimated complexity

### Step 4: Generate Code
Use CadQueryCodeGeneratorEngine (or PlaywrightAutomationEngine for GUI targets):
```typescript
const { script } = cadQueryCodeGeneratorEngine.generateScript(actions.actions);
```
If `--parametric`, use `makeParametric()` to extract dimensions as variables.

### Step 5: Execute (unless --dry-run)
Use ExecutionVerificationEngine to run and verify:
```typescript
const result = executionVerificationEngine.executeWithProgress(actions.actions, script);
```

### Step 6: Report
Use VideoReplayOrchestratorEngine.generateReport() for final summary.
Display: actions extracted, code generated, execution results, output files.

## Requirements
- FFmpeg installed and on PATH
- Python + CadQuery installed (for CadQuery execution)
- Playwright MCP tools available (for GUI targets)

## Engines Used
VideoActionExtractorEngine, CADOperationTaxonomyEngine, CadQueryCodeGeneratorEngine,
PlaywrightAutomationEngine, ExecutionVerificationEngine, VideoReplayOrchestratorEngine
