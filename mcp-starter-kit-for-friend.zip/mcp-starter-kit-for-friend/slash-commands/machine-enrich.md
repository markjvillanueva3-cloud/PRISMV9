# Machine Enrich — Machine Database Enrichment Pipeline

Query, audit, and enrich the PRISM machine database across all data layers (CORE, ENHANCED, LEVEL5).

## Args
- Empty: show enrichment stats and data coverage summary
- `stats`: detailed statistics — profiles by brand, type, data layer
- `search [query]`: find machines by name/brand/type across all catalogs
- `audit`: audit data completeness — find machines with missing fields
- `compare [model]`: compare a machine's data across all layers (catalog vs POST vs lathe vs LEVEL5)
- `torque [model]`: show torque curve data for a lathe
- `controller [brand]`: show controller G-code features for a manufacturer
- `cad [model]`: show CAD/STEP file references from LEVEL5
- `gaps`: identify machines in CORE/LEVEL5 not yet in catalog
- `extract`: re-run extraction scripts to regenerate enrichment data
- `kinematics [model]`: generate/show full kinematic chain, transformations, and collision zones
- `collision [model] [x] [y] [z] [tool_dia]`: check if a tool position is collision-safe
- `coverage`: show kinematic data coverage (LEVEL5 vs inferred)
- `add [brand] [model]`: interactively add a new machine profile

## Data Sources
All machine data lives in these files:
1. **Main Catalog** (`src/data/machine-profiles-catalog.ts`): 59 ExtendedMachineProfile entries, 7 brands (Haas, DMG MORI, Mazak, Makino, Okuma, Hermle, Doosan)
2. **Extension Catalog** (`src/data/machine-profiles-catalog-ext.ts`): 180 profiles, 26 additional manufacturers from ENHANCED monolith databases
3. **Enrichment Catalog** (`src/data/machine-enrichment-catalog.ts`): CORE + LEVEL5 data:
   - POST_DB_PROFILES: 232 machines with controller G-code mappings
   - LATHE_DEEP_PROFILES: 15 lathes with torque curves, rigidity, turret specs
   - CONTROLLER_FEATURES: 17 controller feature sets (HSM codes, TCP, coolant, probing)
   - CAD_ENRICHMENTS: 65 Haas machines with STEP file references + kinematics
4. **MachineProfileEngine** (`src/engines/MachineProfileEngine.ts`): Runtime Map with 17 defaults + 239 from catalog
5. **MachineRegistry** (`src/registries/MachineRegistry.ts`): 824 machines x 4 layers (separate data model)

## Extraction Scripts
- `scripts/extract-machines.mjs`: ENHANCED monolith -> catalog-ext.ts (180 profiles)
- `scripts/extract-core-machines.mjs`: CORE + LEVEL5 -> machine-enrichment-catalog.ts (312 data points)

## Workflow

### Stats (default)
1. Import from all three catalog files
2. Count profiles, brands, types, data layers
3. Show coverage matrix: which brands have which data types

### Search
1. Search across EXTENDED_MACHINE_CATALOG + POST_DB_PROFILES + LATHE_DEEP_PROFILES
2. Show matching profiles with key specs
3. Indicate which data layers are available for each match

### Audit
1. Load all catalogs
2. Check each profile for: missing torque, missing accuracy, missing table/rotary_table, missing weight
3. Cross-reference POST_DB against catalog — find machines with controller features but no catalog entry
4. Report completeness percentage per brand

### Compare
1. Find machine by model name across all data sources
2. Show side-by-side: catalog profile vs POST DB vs lathe deep specs vs LEVEL5
3. Highlight discrepancies or missing data

### Torque Curve
1. Look up machine in LATHE_DEEP_PROFILES
2. Display torque curve points (RPM vs Nm)
3. Show derived values: constant torque range, constant power range, peak torque RPM

### Controller Features
1. Look up brand in CONTROLLER_FEATURES
2. Display G-code mappings: HSM, TCP, coolant, probing, threading, work offsets
3. Compare mill vs lathe controller features for same brand

### CAD References
1. Look up model in CAD_ENRICHMENTS
2. Show STEP file path, size, kinematic chain, collision zones
3. Report 5-axis type (table-table, head-head, etc.)

### Kinematics
1. Find machine in EXTENDED_MACHINE_CATALOG or POST_DB_PROFILES
2. Call `getKinematicModel(profile)` from MachineKinematicsEngine
3. Display: kinematic type, chain, transformations, collision zones
4. If source=level5: note real STEP data; if inferred: note rule-based generation
5. Show work envelope with all axis ranges

### Collision Check
1. Find machine, generate kinematic model
2. Call `checkCollision(model, {x, y, z}, toolDia, toolLen)`
3. Display: SAFE/VIOLATIONS with zone names and distances
4. Show work envelope limits for reference

### Coverage
1. Call `getKinematicCoverage()`
2. Display: LEVEL5 count, with-collision count, inferrable types
3. Calculate: total catalog machines vs those with kinematic data

### Extract
1. Run `node scripts/extract-machines.mjs > src/data/machine-profiles-catalog-ext.ts`
2. Run `node scripts/extract-core-machines.mjs > src/data/machine-enrichment-catalog.ts`
3. Run `npm run build` to verify
4. Run `npm test -- --run src/__tests__/machine-profiles-catalog.test.ts` to verify
5. Report counts before/after

### Add Machine
1. Ask for brand, model, type, controller
2. Ask for travels (X, Y, Z), spindle specs (RPM, kW, Nm, taper)
3. Ask for tool changer (type, capacity)
4. Generate ExtendedMachineProfile entry
5. Append to appropriate catalog file
6. Build + test to verify

## Output Format
```
MACHINE DATABASE — Enrichment Dashboard
════════════════════════════════════════════════════════════
Catalog Profiles:   [N] (main) + [N] (ext) = [N] total
POST DB Profiles:   [N] machines, [N] controller configs
Lathe Deep Specs:   [N] with torque curves
CAD Enrichments:    [N] STEP file references
────────────────────────────────────────────────────────────
Brands:   [list]
Types:    VMC=[N]  HMC=[N]  5axis=[N]  lathe=[N]  mill_turn=[N]  other=[N]
Coverage: [N]% have torque data  [N]% have CAD refs  [N]% have controller G-codes
```

## Key Files
- `C:/PRISM/mcp-server/src/data/machine-profiles-catalog.ts`
- `C:/PRISM/mcp-server/src/data/machine-profiles-catalog-ext.ts`
- `C:/PRISM/mcp-server/src/data/machine-enrichment-catalog.ts`
- `C:/PRISM/mcp-server/src/engines/MachineProfileEngine.ts`
- `C:/PRISM/mcp-server/src/engines/MachineKinematicsEngine.ts` (kinematic inference + collision checking)
- `C:/PRISM/mcp-server/scripts/extract-machines.mjs`
- `C:/PRISM/mcp-server/scripts/extract-core-machines.mjs`
- `C:/PRISM/data/machines/CORE/` (source CORE databases)
- `C:/PRISM/data/machines/ENHANCED/` (source ENHANCED databases)
- `C:/PRISM/data/machines/LEVEL5/` (source LEVEL5 databases)
