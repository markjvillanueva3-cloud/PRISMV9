# Forge Docs — Documentation Gap Analyzer & Generator

You are running a specialized autopilot pipeline that identifies missing or outdated documentation across the PRISM project and optionally generates it. Designed to run in the **background** for analysis, with optional generation mode.

## Args: $ARGUMENTS
- Empty: full scan — find all documentation gaps
- `[file-path]`: analyze docs for a specific file or module
- `[subsystem]`: focus on dispatchers, engines, algorithms, hooks
- `generate`: analyze AND generate missing docs (non-background)
- `report`: analysis only (default, background-safe)
- `api`: focus on public API documentation only
- `inline`: focus on inline code comments only

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL documentation gaps** — every public API, engine method, algorithm, and formula must be documented.
- "Fully documented" claims REQUIRE citing specific JSDoc/README coverage percentages.
- **Completeness > Speed.** An undocumented engine is an unusable engine.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (code analysis + documentation writing)
2. Domain: Technical Writing + TypeScript Engineering
3. Roles: Technical Documentation Engineer + API Designer
4. Model: SONNET (report) / OPUS (generate — quality writing needs reasoning)
5. Effort: MEDIUM (report) / HIGH (generate)

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Documentation Audit

### 3A: Exported API Surface
For each source file in scope:
1. Extract all exported functions, classes, interfaces, types
2. Check for JSDoc/TSDoc comments on each export
3. Classify: DOCUMENTED (has JSDoc), PARTIAL (has comment but incomplete), UNDOCUMENTED
4. For documented exports: check quality (has @param, @returns, @example, @throws)

### 3B: File-Level Documentation
For each source file:
1. Does it have a file-level doc comment (top of file)?
2. Does it explain the module's purpose and responsibility?
3. Are complex algorithms explained?
4. Are non-obvious design decisions documented?

### 3C: Architecture Documentation
Check `C:/PRISM/docs/` directory:
1. Is there an up-to-date architecture overview?
2. Are the 11 layers (L0-L10) documented?
3. Are integration patterns documented (dispatcher→engine→algorithm)?
4. Are safety chain flows documented?
5. Are configuration options documented?

### 3D: README & Onboarding
1. Is `C:/PRISM/README.md` current?
2. Does it cover setup, build, test, deploy?
3. Are environment requirements documented?
4. Is there a contributing guide?

### 3E: Coverage Scoring
Per subsystem:
- **Exports documented**: (documented / total) * 100
- **Quality score**: (complete_jsdoc / total_jsdoc) * 100
- **File-level docs**: (files_with_header / total_files) * 100

## Phase 4: Generate Mode (only if args include `generate`)

### 4A: Priority Targets
Rank undocumented exports by:
- Is it a public API? (exported from index.ts) → HIGH
- Is it safety-related? → HIGH
- Is it used by >3 other files? → MEDIUM
- Is it a utility function? → LOW

### 4B: JSDoc Generation
For each target, generate JSDoc:
1. Read the function body to understand what it does
2. Infer parameter purposes from usage and naming
3. Identify return type and what it represents
4. Note any thrown errors or edge cases
5. Write a concise, accurate JSDoc block

Format:
```typescript
/**
 * Brief one-line description.
 *
 * Longer explanation if the function is complex.
 *
 * @param paramName - Description of the parameter
 * @returns Description of return value
 * @throws {ErrorType} When condition occurs
 */
```

### 4C: Validation
After generating docs:
1. Run `npx tsc --noEmit` — JSDoc must not introduce errors
2. Verify accuracy — doc matches actual behavior
3. Check consistency — follows existing documentation style

## Phase 5: Forge Postflight (`/forge-postflight docs`)
1. **Gate 1 — DSL**: SKIP
2. **Gate 2 — Matrix**: SKIP
3. **Gate 3 — Trace**: SKIP
4. **Gate 4 — Sync**: RUN — verify doc coverage metrics
5. **Gate 5 — Memory**: RUN — update MEMORY.md with coverage scores
6. **Gate 6 — Hookify**: SKIP

## Phase 6: Auto-Commit (generate mode only)
`docs: add JSDoc to [N] exports across [subsystems] [FORGE-DOCS]`

## Summary Report
```
FORGE DOCS COMPLETE
===================
Scanned:     [N] files, [M] exports
Documented:  [X]% exports, [Y]% files
Quality:     [Z]% of docs are complete (params + returns)
Generated:   [N] JSDoc blocks (or "report only")
Worst:       [subsystem] at [X]% coverage
Next:        /forge-docs generate to add missing docs
```

## Error Handling
- **Large files**: Sample exports (top 20) instead of all
- **Complex generics**: Document the generic purpose, not every type parameter
- **Context budget**: Run api-only mode for smallest scope

## Safety Rails
- In report mode: NEVER modify any files
- Generated JSDoc must be accurate — never guess at behavior
- Never overwrite existing documentation — only add missing docs
- Never document internal/private functions unless explicitly requested
- Preserve existing doc style and conventions
