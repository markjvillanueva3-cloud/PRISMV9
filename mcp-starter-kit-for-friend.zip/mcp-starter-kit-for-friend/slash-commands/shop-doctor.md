# Shop Doctor — Real-Time Manufacturing Problem Solver

When something goes wrong on the shop floor, every minute of diagnosis is a minute of lost production. This command connects symptoms (chatter, bad finish, broken tools, out-of-tolerance parts) to root causes using physics, then prescribes fixes ranked by likelihood and ease of implementation.

**Value**: Average unplanned downtime costs $100-500/hour. Cutting diagnosis time from 2 hours to 15 minutes = $150-750 saved per incident. Most shops have 2-5 incidents per week.

## Args:
- Symptom description (e.g., "chatter on finishing pass, 7075-T6, 1/2 endmill")
- `chatter`: vibration/chatter-specific diagnosis
- `finish`: surface finish problems
- `tolerance`: dimensional accuracy issues
- `tool-failure`: premature tool breakage/wear
- `thermal`: thermal drift or distortion problems

## Phase 1: Symptom Classification
Parse the symptom into structured diagnostic categories:

1. **What's happening?** (observable symptom)
   - Vibration/chatter (audible, visible, measured)
   - Poor surface finish (rough, wavy, torn, smeared)
   - Out of tolerance (oversize, undersize, taper, runout)
   - Tool failure (breakage, chipping, rapid wear, BUE)
   - Thermal issues (growth, distortion, discoloration)
   - Chip problems (bird-nesting, re-cutting, wrong shape)

2. **When does it happen?** (timing)
   - Always, intermittent, getting worse, only on certain features
   - Beginning vs end of cut, beginning vs end of tool life
   - Morning vs afternoon (thermal), certain days (environmental)

3. **What changed?** (recent changes)
   - New material lot, new tooling, program change
   - Machine maintenance, seasonal temperature change
   - New operator, different shift

## Phase 2: Physics-Based Root Cause Analysis
For each symptom category, calculate the most likely causes:

### Chatter Diagnosis:
1. `/spindle-optimize` — check if RPM is at a stable lobe
   - Calculate stability lobe diagram for current setup
   - Current RPM vs nearest stable pocket
   - Recommended RPM shift (often just ±200 RPM fixes it)

2. Run `ultimateSpeedFeedEngine.calculate()`:
   - Check radial engagement ratio (>50% ae/D = chatter risk)
   - Check axial DOC vs tool length ratio (stick-out problem?)
   - Check chip thickness (too thin = ploughing = chatter)

3. System stiffness analysis:
   - Tool deflection at current forces (cantilever beam model)
   - Workpiece flexibility (thin walls, unsupported spans)
   - Fixture rigidity (clamping force vs cutting force)

### Surface Finish Diagnosis:
1. Theoretical Ra from current parameters:
   - Ra = fz² / (32 × r) — ideal geometric roughness
   - Compare theoretical vs actual — if actual >> theoretical, there's a problem

2. Contributing factors ranked:
   - Tool wear (inspect: flank wear > 0.15mm?)
   - Built-up edge (wrong speed for material?)
   - Vibration (micro-chatter in finish zone)
   - Wrong tool geometry (nose radius, helix, coating)
   - Coolant delivery (reaching the cut zone?)

### Tolerance Diagnosis:
1. Thermal growth calculation:
   - Material CTE × temperature rise × dimension length
   - Machine thermal growth at current warm-up state
   - Coolant temperature stability

2. Tool deflection at current cutting forces:
   - Force calculation from speeds/feeds
   - Deflection from cantilever model
   - Compare deflection to tolerance band

3. Machine geometric accuracy:
   - Positioning repeatability spec vs tolerance required
   - Backlash compensation status
   - Ball screw thermal compensation

### Tool Failure Diagnosis:
1. `/wear-analysis` — predicted vs actual tool life:
   - If failing early: check speed, chip load, depth
   - Flank wear rate → running too fast?
   - Crater wear rate → running too hot?
   - Chipping → interrupted cut, wrong grade?

2. Cutting force analysis:
   - Forces at current parameters vs tool rating
   - Impact loading (entry/exit conditions)
   - Chip evacuation adequacy

## Phase 3: Ranked Prescriptions
For each root cause, prescribe fixes ranked by:
- **Probability**: How likely this IS the cause (based on physics)
- **Ease**: How easy to implement (adjust parameter vs buy new tool vs fixture change)
- **Risk**: Could this fix make things worse?

```
DIAGNOSIS — [Symptom Description]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Confidence: [HIGH/MEDIUM/LOW]

ROOT CAUSES (ranked by probability):
  #  | Cause                    | Prob | Fix                          | Effort
  1  | [cause]                  | [X]% | [fix description]            | [EASY/MOD/HARD]
  2  | [cause]                  | [X]% | [fix description]            | [EASY/MOD/HARD]
  3  | [cause]                  | [X]% | [fix description]            | [EASY/MOD/HARD]

IMMEDIATE ACTIONS (try these first — zero cost):
  1. [parameter change — exact values]
  2. [check/verify something]
  3. [adjust setting]

IF THAT DOESN'T WORK (low cost):
  1. [tool change recommendation]
  2. [fixture modification]
  3. [program change]

LAST RESORT (higher cost but guaranteed):
  1. [different strategy/approach]
  2. [different machine]
```

## Phase 4: Parameter Corrections
For the most likely root cause, calculate exact corrected parameters:

1. Run `ultimateSpeedFeedEngine.calculate()` with corrected inputs:
   - Adjusted for the identified problem
   - Conservative margin for first correction attempt

2. `/auto-speed-feed` — generate corrected program (if program path provided):
   - Apply corrections to specific operations
   - Keep unaffected operations unchanged

3. Before/after comparison:
   ```
   PARAMETER CORRECTIONS
   ━━━━━━━━━━━━━━━━━━━━
   Parameter      | Current  | Corrected | Reason
   RPM            | [X]      | [X]       | [stability lobe / speed adjustment]
   Feed rate      | [X]      | [X]       | [chip load correction]
   DOC (ap)       | [X]      | [X]       | [deflection / stability]
   Stepover (ae)  | [X]      | [X]       | [engagement ratio]
   Coolant        | [X]      | [X]       | [pressure / type change]
   ```

## Phase 5: Prevention Plan
Don't just fix the symptom — prevent recurrence:

1. **Root cause elimination**:
   - If thermal: recommend warm-up procedure or compensation
   - If tool wear: adjust replacement schedule (`/tool-life-max`)
   - If setup: add to pre-flight checklist (`/first-part-right`)

2. **Monitoring recommendations**:
   - What to watch for early warning signs
   - Spindle load thresholds for this operation
   - SPC control limits for critical dimensions

3. **Knowledge capture**:
   - Save as tribal tip for this material/operation combo
   - Update process parameters in job file
   - Document in shop floor log

## Output Summary
```
SHOP DOCTOR — [Symptom]
========================
Material:    [workpiece]
Operation:   [what was being done]
Severity:    [CRITICAL/MAJOR/MINOR]

DIAGNOSIS:   [most likely root cause] ([X]% confidence)
FIX:         [specific action with exact values]
EFFORT:      [EASY — parameter change / MOD — tool/fixture / HARD — strategy change]

CORRECTED PARAMETERS:
  RPM: [X] → [X] | Feed: [X] → [X] | DOC: [X] → [X]

EXPECTED RESULT:
  [what should improve and by how much]

PREVENTION:
  [how to prevent this from happening again]

TIME TO FIX: ~[X] minutes (vs [X] hours typical diagnosis)
```

## Key Engines Used
UltimateSpeedFeedEngine, AdvancedCuttingPhysicsEngine, AdvancedWearPhysicsEngine,
MachineGeometricAccuracyEngine, ProcessCapabilityEngine, CoolantDynamicsEngine,
ConstitutiveModelEngine, MotionDynamicsProfileEngine, TribalKnowledgeEngine
