You are entering audit mode for PRISM completed tasks. Your job is to review, verify, find gaps, and enhance work that was already marked complete in the roadmap. This is a quality-assurance pass that runs independently from new feature development.

## Input
Arguments: $ARGUMENTS

## Step 1: Parse Arguments

Check the arguments:
- If empty: show all completed milestones grouped by track, let user pick one to audit
- If `list`: show completed milestones summary with audit status (audited vs unaudited)
- If `scan`: quick-scan all completed milestones for obvious gaps (missing files, broken imports, TS errors)
- If a milestone ID (e.g., `S1-MS1`, `L3-P0-MS1`): audit that specific milestone
- If a unit ID (e.g., `S3-MS1-P0-U01`): audit that specific unit only
- If `report`: generate a consolidated audit report from all previous audit findings

## Step 2: Load Completed Tasks Index

Read `C:/PRISM/mcp-server/data/roadmap-index.json` and extract all milestones where `status == "complete"`.

For each completed milestone, note:
- `id`, `title`, `track`, `total_units`, `completed_units`, `envelope_path`

Also check if an audit record exists at `C:/PRISM/state/audits/{milestoneId}/audit-summary.json`. If it does, this milestone has been previously audited — note the audit date and findings count.

Group completed milestones by track:
- **S-track** (S0-S4): System setup and SFC calculator
- **L-track** (L0-L10): Layered architecture build-out
- **QA-track**: Quality audit milestones
- **REM-track**: Remediation milestones
- **DA/P0/R-track**: Design, planning, initial phases
- **CC-track**: Cross-cutting concerns

Present as:
```
## Completed Milestones (57 total)

### S-Track: System & SFC (X milestones)
| Milestone | Title | Units | Last Audited |
|-----------|-------|-------|--------------|
| S0-MS1    | System Health Verification | 11 | Never |

### L-Track: Architecture (X milestones)
...

Unaudited: X milestones
Previously audited: X milestones
```

## Step 3: Audit Protocol

When auditing a milestone, perform these checks in order:

### 3a. Structural Integrity
- Read the milestone envelope from `C:/PRISM/mcp-server/data/milestones/`
- Verify all `deliverables[].path` files actually exist on disk
- Verify all `files` referenced in units exist
- Check that `completed_units` count matches reality

### 3b. Code Quality
- For each source file the milestone touched, check:
  - No TypeScript errors (run `npx tsc --noEmit` on affected files if practical, or grep for known error patterns)
  - No `any` type abuse (more than 3 `any` casts in a single file is a flag)
  - No TODO/FIXME/HACK comments left behind
  - No console.log debugging statements left in production code
  - Proper error handling (no swallowed catches, no bare `throw`)

### 3c. Wiring Verification
- If the milestone created an engine: is it exposed via a dispatcher action?
- If it created a dispatcher: is it registered in `src/tools/dispatchers/index.ts`?
- If it created a schema: is it imported where needed?
- If it created a service: is it used by at least one dispatcher or engine?
- Cross-reference against `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` — is the new component documented?

### 3d. Functional Gaps
- Read the unit's `exit_conditions` from the envelope — are they actually satisfied?
- Read the unit's `steps` — were all steps completed?
- Look for partial implementations: functions that exist but are never called, switch cases with TODO, empty method bodies

### 3e. Enhancement Opportunities
- Identify performance improvements (unnecessary loops, missing caching, redundant file reads)
- Identify safety improvements (missing validation, unchecked array access, division by zero risks)
- Identify documentation gaps (complex logic without comments, missing JSDoc on public APIs)
- Identify test gaps (critical calculations with no test coverage)

## Step 4: Record Findings

For each finding, classify it:
- **CRITICAL**: Broken functionality, data corruption risk, safety calculation error
- **MAJOR**: Missing wiring, incomplete implementation, significant gap
- **MINOR**: Code quality, style, documentation, minor enhancement
- **ENHANCEMENT**: Nice-to-have improvement, optimization opportunity

Save the audit to `C:/PRISM/state/audits/{milestoneId}/audit-summary.json`:
```json
{
  "milestone_id": "<id>",
  "audited_at": "<ISO timestamp>",
  "audited_by": "claude-audit",
  "findings": [
    {
      "id": "F-001",
      "severity": "MAJOR",
      "category": "wiring",
      "file": "src/engines/SomeEngine.ts",
      "description": "Engine method not exposed via any dispatcher action",
      "recommendation": "Add action to calcDispatcher or create dedicated dispatcher",
      "auto_fixable": true
    }
  ],
  "summary": {
    "critical": 0,
    "major": 2,
    "minor": 5,
    "enhancement": 3,
    "total": 10
  },
  "files_checked": ["list of files examined"],
  "pass": true
}
```

## Step 5: Fix or Defer

After presenting findings to the user:
- **CRITICAL findings**: Fix immediately in this session
- **MAJOR findings**: Ask user — fix now or create a remediation unit?
- **MINOR/ENHANCEMENT**: Log for future work unless user wants them fixed now

For any fixes applied:
1. Make the code change
2. Update the audit-summary.json with `"fixed": true` on the finding
3. Verify TypeScript compilation passes
4. Update CURRENT_POSITION.md with audit results

## Step 6: Auto-Fix Mode

If the user passes `fix` as an additional argument (e.g., `/audit-task S1-MS1 fix`), automatically fix all CRITICAL and MAJOR findings without asking, and present a summary of changes made.

For MINOR and ENHANCEMENT findings in auto-fix mode, fix only if the fix is trivial (< 5 lines changed) and risk-free.

## Step 7: Count Drift Check

After completing an audit, run the automated count drift checker:
```bash
cd C:/PRISM/mcp-server && bash state/SYS-MS3/count-drift-check.sh
```

This verifies that CLAUDE.md and MEMORY.md counts (dispatchers, engines, algorithms, milestones) match filesystem reality. If drift is detected, update the affected documentation files.

## Step 8: Persist Key Findings
After completing the audit, persist critical discoveries to session memory:
1. If any CRITICAL or MAJOR findings: use `/remember` to save a one-line summary per finding
   - Example: `/remember fix turningDispatcher dead wiring to SteadyRest.place`
2. Update MEMORY.md audit counts if they've changed
3. This ensures findings survive session boundaries and compaction

## Audit Scope Tips

When choosing what to audit, prioritize:
1. **Milestones never audited** over previously audited ones
2. **REM and QA track milestones** (these fixed bugs — verify the fixes stuck)
3. **L-track milestones** with high unit counts (more surface area for issues)
4. **Old milestones** (S0, S1) that were built before later patterns were established
