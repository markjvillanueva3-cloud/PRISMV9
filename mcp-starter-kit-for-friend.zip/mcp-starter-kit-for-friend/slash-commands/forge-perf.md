# Forge Perf — Performance Profiling + Optimization Autopilot

You are running a specialized autopilot pipeline focused on profiling the PRISM system, identifying performance bottlenecks, implementing optimizations, and benchmarking improvements.

## Args: $ARGUMENTS
- Empty: full profile — analyze startup, runtime, and memory across the system
- `startup`: focus on session/bridge startup time
- `bridge`: focus on CAD bridge latency
- `tokens`: focus on token usage and context efficiency
- `memory`: focus on memory usage and leaks
- `build`: focus on build/compile time
- `tests`: focus on test suite execution time
- `[file-path]`: profile a specific module
- `list`: just identify bottlenecks without fixing any

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** for performance analysis.
- Consider every applicable profiling model, statistical method, queueing theory, and optimization algorithm.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- **Completeness > Speed.** A missed optimization opportunity compounds over every session.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.

## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE-COMPLEX (profiling requires measurement + analysis + targeted optimization)
2. Domain: Performance Optimization + Systems Architecture
3. Roles: Performance Optimization Specialist + Principal Systems Architect
4. Model: OPUS (optimization requires understanding system-wide effects)
5. Effort: HIGH

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Performance Profiling

### 3A: Measure Baselines
Establish current performance metrics:

**Startup Performance:**
1. Time `npm run build` from clean state
2. Time CAD bridge startup (`bridge.py` → ready signal)
3. Time Python imports (CadQuery, ezdxf, numpy, OCP)
4. Time TypeScript MCP server startup
5. Time session context loading

**Runtime Performance:**
1. Time key engine calculations (force, speed, safety scoring)
2. Time dispatcher action round-trips
3. Time registry lookups (materials, tools)
4. Time CAD operations (create, validate, export)
5. Time JSON-RPC bridge round-trips

**Test Suite Performance:**
1. Time `npm test` full suite
2. Time `pytest` full suite
3. Identify the slowest 10 tests
4. Check for unnecessary I/O in tests

**Token/Context Performance:**
1. Estimate tokens per typical session
2. Identify the largest context contributors
3. Check hook output compression effectiveness
4. Measure MEMORY.md / CLAUDE.md sizes

**Memory Usage:**
1. Python process memory after CadQuery import
2. Node.js process memory under load
3. Solid store memory with MAX_SOLIDS objects
4. Registry data memory footprint

```
PERFORMANCE BASELINE
====================
Startup:
  npm build:       [X]s
  CAD bridge:      [X]s (target: <3s)
  Python imports:  [X]s
  MCP server:      [X]s

Runtime (avg):
  Engine calc:     [X]ms
  Dispatcher RTT:  [X]ms
  Registry lookup: [X]ms
  CAD operation:   [X]ms
  Bridge RPC:      [X]ms

Tests:
  MCP suite:       [X]s ([N] tests)
  CAD suite:       [X]s ([N] tests)
  Slowest test:    [name] — [X]s

Tokens:
  Session avg:     ~[N]K tokens
  Context load:    ~[N]K tokens
  MEMORY.md:       [N] lines

Memory:
  Python process:  [X]MB
  Node process:    [X]MB
```

### 3B: Identify Bottlenecks
Rank issues by impact:
- **Startup blockers**: What takes the most time during initialization?
- **Hot paths**: What runs most frequently? Where is time spent?
- **Memory hogs**: What uses the most memory? Any leaks?
- **Token waste**: What generates excessive output? Redundant context?
- **I/O bottlenecks**: Unnecessary file reads, synchronous operations, missing caches

```
BOTTLENECK ANALYSIS
===================
Rank | Location              | Type     | Impact | Current | Target  | Effort
-----|----------------------|----------|--------|---------|---------|-------
  1  | CadQuery import      | startup  | HIGH   | 2.5s    | <0.5s   | HIGH
  2  | material registry    | runtime  | MED    | 150ms   | <20ms   | LOW
  ...
```

If args = `list`, stop here.

## Phase 4: Optimize
For each bottleneck (highest impact first):

### 4A: Analyze the Bottleneck
1. Read the relevant code
2. Understand WHY it's slow (algorithmic, I/O, dependency, configuration)
3. Identify optimization options:
   - **Caching**: Can results be cached? (memory cache, file cache, lazy init)
   - **Lazy loading**: Can initialization be deferred until first use?
   - **Parallelization**: Can operations run concurrently?
   - **Algorithm change**: Is there a faster algorithm?
   - **Data structure change**: Is there a more efficient structure?
   - **Elimination**: Can the operation be removed entirely?

### 4B: Implement the Optimization
1. Make the minimal change that addresses the bottleneck
2. Preserve correctness — optimization must not change behavior
3. Add comments explaining the optimization rationale
4. Ensure the optimization is maintainable

### 4C: Measure Improvement
1. Re-run the same benchmark as baseline
2. Calculate improvement: `(before - after) / before * 100`
3. Verify no regression in other metrics

### 4D: Validate
1. Run `npm run build` — must pass
2. Run tests — must pass with zero regression
3. Run CAD tests if CAD code was changed
4. Verify the optimization doesn't introduce race conditions or memory issues

## Phase 5: Token Optimization (if applicable)
Special focus on reducing Claude Code token costs:

### 5A: Context Efficiency
1. Review MEMORY.md — can it be more concise?
2. Review CLAUDE.md files — redundant instructions?
3. Review hook output — can compression be improved?
4. Review tool output — are results being truncated appropriately?

### 5B: Hook Optimization
1. Check pretooluse hooks — are they blocking unnecessarily?
2. Check posttooluse hooks — are they processing too much output?
3. Check output compression rules — can thresholds be tightened?

### 5C: Session Optimization
1. Can context loading be lazy?
2. Can file reads be cached within a session?
3. Can tool calls be batched or parallelized?

## Phase 6: Forge Postflight (`/forge-postflight perf` protocol)
Run the shared integration protocol for performance optimizations:
1. **Gate 1 — DSL**: CONDITIONAL — if structural changes were made (lazy loading, caching), verify DSL compliance is preserved
2. **Gate 2 — Matrix**: SKIP (perf optimizations don't create new components)
3. **Gate 3 — Trace**: CONDITIONAL — if wiring was restructured (lazy imports, deferred init), verify chains still connect
4. **Gate 4 — Sync**: RUN — verify no count drift from file reorganization
5. **Gate 5 — Memory**: RUN — if significant perf improvements achieved, note metrics in MEMORY.md
6. **Gate 6 — Hookify**: SKIP (perf changes don't need autofire rules)

Report the postflight results before proceeding to commit.

## Phase 7: Auto-Commit (`/auto-commit` protocol)
1. Stage optimization changes
2. Commit: `perf(scope): optimize [N] bottlenecks — [summary] [FORGE-PERF]`
3. Report the commit

## Summary Report
```
FORGE PERF COMPLETE
===================
Profiled:      [N] dimensions
Bottlenecks:   [N] identified
Optimized:     [N] bottlenecks

Improvements:
  [metric-1]:  [before] → [after] ([X]% faster)
  [metric-2]:  [before] → [after] ([X]% reduction)
  ...

Build:         PASS
Tests:         [N] passing (0 regression)
Committed:     [commit hash]

Performance Summary:
  Startup:     [X]s → [Y]s ([Z]% faster)
  Runtime:     [X]ms avg → [Y]ms avg ([Z]% faster)
  Memory:      [X]MB → [Y]MB ([Z]% reduction)
  Tokens:      ~[X]K → ~[Y]K per session ([Z]% savings)

Next: /forge-perf [focus] for deeper optimization, /forge-tests to verify coverage
```

## Error Handling
- **Measurement variance**: Run benchmarks 3x, take median
- **Optimization breaks tests**: Revert and try a different approach
- **Marginal improvement**: If <5% gain, skip unless the change is very simple
- **Context budget**: Apply the highest-impact optimization only, report remaining opportunities

## Safety Rails
- Never sacrifice correctness for speed
- Never remove safety checks for performance
- Always measure before AND after
- Never optimize without running the full test suite
- Keep optimizations simple and maintainable
- Document why an optimization works (not just what it does)
- Never introduce race conditions or thread-safety issues
- Atomic writes must remain atomic — never "optimize" away safety
