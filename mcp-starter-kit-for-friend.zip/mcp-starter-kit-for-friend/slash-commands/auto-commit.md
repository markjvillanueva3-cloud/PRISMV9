# Auto-Commit — Automatic Git Commits

You are enabling auto-commit mode. After each significant code change, automatically create a well-formatted git commit. This keeps the git history granular and makes rollback easy.

## Args: $ARGUMENTS
- Empty: activate auto-commit for current session
- `off`: deactivate auto-commit
- `now`: create a commit right now for all pending changes
- `squash`: squash recent auto-commits into one meaningful commit

## When Active: Auto-Commit Protocol

After completing any of these actions, automatically run the commit flow:
- Creating or modifying a source file (`.ts`, `.js`, `.json`, `.md` in PRISM)
- Fixing a bug or applying a fix
- Completing a roadmap unit step
- Adding a new engine, dispatcher, algorithm, or registry entry
- Updating documentation or configuration

### Commit Flow
1. Run `git status` in `C:/PRISM/` to see what changed
2. Stage only the relevant files (not unrelated changes)
2b. Run `/de-sloppify staged` — polish staged files before committing (removes debug output, fixes import order). Skip if docs/config-only commit.
3. Generate a commit message following this convention:
   - **New feature**: `feat(scope): description`
   - **Bug fix**: `fix(scope): description`
   - **Refactor**: `refactor(scope): description`
   - **Documentation**: `docs(scope): description`
   - **Test**: `test(scope): description`
   - **Build/config**: `chore(scope): description`
   - **Roadmap**: `roadmap(milestone-id): description`
4. Scope should be the system area: `engines`, `dispatchers`, `safety`, `roadmap`, `hooks`, `docs`, etc.
5. Create the commit
6. Report briefly: `Committed: [short message] ([N] files)`

### Batching Rules
- Don't commit after every single line change — batch related changes
- A "significant change" means: a complete function, a fixed bug, a finished step, a new file
- If multiple related files changed together, commit them as one unit
- If you're in the middle of a multi-step change, wait until the logical unit is complete

## /auto-commit now
Immediately commit all pending changes:
1. `git status` to see everything
2. Review changes and group by logical unit
3. Create one or more commits as appropriate
4. Report what was committed

## /auto-commit squash
Combine recent auto-commits into a single meaningful commit:
1. `git log --oneline -20` to see recent history
2. Identify the auto-commit cluster (consecutive auto-commits for the same task)
3. Interactive rebase to squash them
4. Write a comprehensive commit message covering all changes
5. Report the squashed result

## Activation Confirmation
```
AUTO-COMMIT: ACTIVE
===================
Trigger:  After each significant code change
Convention: conventional commits (feat/fix/refactor/docs/test/chore)
Scope:    PRISM project (C:/PRISM/)
Batching: Logical units, not individual lines

Working. Commits will happen automatically.
```
