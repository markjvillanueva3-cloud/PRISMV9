# Feasibility Check — Can This Part Actually Be Machined?

Run the Machining Feasibility Intelligence Stack against a part's operation sequence. Checks: tool accessibility, workholding viability, rigidity degradation, force capability, sequence feasibility, datum integrity, and dead-end detection.

## Args: $ARGUMENTS
- Empty: interactive mode — prompt for part details
- `"<description>"`: quick check with part description
- `sequence`: check a specific operation sequence
- `full`: run all 8 feasibility engines with Monte Carlo risk

## Execution

1. **Initialize WorkpieceState** — Create stock from dimensions:
   ```
   Engine: WorkpieceStateEngine.initialize({ length, width, height })
   ```

2. **Run Feasibility Stack** — For each operation in sequence:
   - AccessibilityAnalysisEngine: tool reach, holder clearance, corner radius, approach angle
   - WorkholdingViabilityEngine: grip force vs cutting force, clamping area degradation
   - RigidityDegradationEngine: wall stiffness, natural frequency, chatter onset
   - ForceCapabilityEngine: power/torque limits, deflection, thermal growth
   - SequenceFeasibilityEngine: dead-end detection, backtracking search

3. **Report**:
   ```
   FEASIBILITY CHECK
   ==================
   Part:         [description]
   Operations:   [N]

   ACCESSIBILITY:  [PASS/WARN/FAIL]
     [details per feature]

   WORKHOLDING:    [PASS/WARN/FAIL]
     Grip force:   [X]N vs required [Y]N (SF=[Z])
     Clamping area: [X]% remaining

   RIGIDITY:       [PASS/WARN/FAIL]
     Min wall:     [X]mm at [location]
     Nat freq:     [X]Hz (chatter risk: [Y]%)

   FORCE:          [PASS/WARN/FAIL]
     Power util:   [X]%
     Max deflection: [X]µm

   SEQUENCE:       [PASS/WARN/FAIL]
     Dead-ends:    [N] detected
     Valid orders: [N] found

   DATUM INTEGRITY: [PASS/WARN/FAIL]
     [which datums compromised and when]

   OVERALL:        [FEASIBLE / MARGINAL / NOT FEASIBLE]
   CONFIDENCE:     [X]%
   ```

## Engines Used
- WorkpieceStateEngine (IPW tracking, surface catalog, wall detection)
- AccessibilityAnalysisEngine (tool reach, holder collision, corner radius)
- WorkholdingViabilityEngine (grip, vacuum seal, datum integrity)
- RigidityDegradationEngine (wall/floor stiffness, natural frequency)
- ForceCapabilityEngine (power, torque, deflection, thermal, wear)
- SequenceFeasibilityEngine (forward simulation, backtracking)
- FeasibilityAnalysisEngine (integrated analysis)
- SetupTransitionEngine (flip/re-fixture verification)
- PredictiveFailureEngine (Monte Carlo success probability)
