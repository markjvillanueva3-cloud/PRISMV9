---
name: wedm-troubleshoot
description: Wire EDM troubleshooting and wire break diagnosis
version: 1.0.0
engines:
  - WEDMFeedbackCalibrationEngine
  - WireEDMDeepReasoningEngine
  - WEDMNeuralTrainingEngine
  - TribalKnowledgeEngine
actions:
  - wedm_predict_wire_break
  - wedm_plan_break_recovery
  - wedm_reason_diagnose
  - wedm_get_recommendation
hooks:
  - hook_wedm_tension_safety
  - hook_wedm_learning_trigger
triggers:
  - "wire break"
  - "wedm problem"
  - "troubleshoot edm"
  - "wire keeps breaking"
---

# /wedm-troubleshoot — Wire Break Diagnosis and Recovery

Diagnose Wire EDM problems and wire breaks:
- Root cause analysis
- Tribal knowledge matching
- Recovery strategies
- Parameter adjustments

## Usage

```
/wedm-troubleshoot <problem> [options]
```

## Arguments

- `problem` — Description of the issue
- `--symptoms` — List of observed symptoms
- `--material` — Workpiece material
- `--thickness` — Section thickness at break point
- `--params` — Current E-code or parameters
- `--location` — Where in the cut (corner, straight, entry, etc.)

## Common Problems

| Problem | Typical Causes | Quick Fix |
|---------|---------------|-----------|
| Wire break - corner | Excessive feed, debris | Reduce feed 20%, check flushing |
| Wire break - thick section | Power too high, poor flushing | Add skim pass, improve flush |
| Wire break - entry | Wrong approach, tension | Use pilot hole, reduce tension |
| Poor surface finish | Wrong E-code, worn guides | Check guides, adjust offset |
| Dimensional drift | Thermal, wire wear | Let stabilize, check tension |
| Taper error | UV compensation, wire lag | Adjust UV angle, slow feed |

## Diagnostic Flow

1. **Symptom Analysis** → Match to known patterns
2. **Tribal Knowledge Search** → 107 WEDM tips
3. **Causal Reasoning** → `wedm_reason_diagnose`
4. **Parameter Check** → Compare to optimal
5. **Recommendations** → Ranked by confidence

## Output

```json
{
  "diagnosis": {
    "primary_cause": "Insufficient flushing in 2\" thick section",
    "confidence": 0.87,
    "evidence": [
      "Break location in thick section",
      "Normal parameters for material",
      "No guide wear indicated"
    ]
  },
  "recommendations": [
    {
      "action": "Increase upper flushing pressure to 8 kg/cm²",
      "priority": 1,
      "source": "tribal_tip_47"
    },
    {
      "action": "Add intermediate skim pass before finish",
      "priority": 2,
      "source": "jm_die_pattern"
    },
    {
      "action": "Reduce ON time by 10%",
      "priority": 3,
      "source": "neural_model"
    }
  ],
  "related_tips": [
    "TIP-047: Thick sections need aggressive upper flush",
    "TIP-023: D2 over 1.5\" needs extra skims"
  ]
}
```

## Examples

```bash
# Wire break diagnosis
/wedm-troubleshoot "wire keeps breaking in corners"

# With context
/wedm-troubleshoot "wire break" --material D2 --thickness 50 --location corner

# Surface finish issue
/wedm-troubleshoot "Ra too rough, getting 1.2 instead of 0.8" --params E1234

# General diagnosis
/wedm-troubleshoot --symptoms "breaks every 10 minutes, only on internal features"
```

## Tribal Knowledge Integration

Searches 107 WEDM-specific tips including:
- Wire breakage prevention (23 tips)
- Surface finish optimization (18 tips)
- Thick section strategies (12 tips)
- Flushing techniques (14 tips)

## Learning Loop

When diagnosis leads to successful fix:
1. `hook_wedm_learning_trigger` fires
2. `WEDMFeedbackCalibrationEngine` updates models
3. Pattern added to knowledge base

## Leverages

- `WireEDMDeepReasoningEngine` (1,081 LOC) — Causal analysis
- `WEDMNeuralTrainingEngine` (2,436 LOC) — Predictive models
- `wedm-knowledge-tips.ts` — 107 curated tips
