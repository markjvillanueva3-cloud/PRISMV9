---
name: wedm-batch
description: Wire EDM batch programming and optimization
version: 1.0.0
engines:
  - WEDMBatchProgramAnalyzerEngine
  - WEDMSchedulingEngine
  - WEDMProgramOptimizerEngine
actions:
  - wedm_batch_analyze
  - wedm_reserve_machine
  - wedm_check_availability
hooks:
  - hook_wedm_batch_deps
  - hook_wedm_schedule_conflict
triggers:
  - "batch wedm"
  - "multiple edm parts"
  - "wedm schedule"
---

# /wedm-batch — Batch Wire EDM Programming

Optimize and schedule multiple Wire EDM jobs:
- Batch analysis and grouping
- Wire change optimization
- Schedule generation
- Dependency tracking

## Usage

```
/wedm-batch <parts> [options]
```

## Arguments

- `parts` — List of part files or directory
- `--group-by` — Grouping strategy (material|thickness|wire|customer)
- `--optimize` — Optimization goal (time|wire|changeover)
- `--schedule` — Generate schedule
- `--machine` — Target machine

## Optimization Strategies

| Strategy | Optimizes | Tradeoff |
|----------|-----------|----------|
| `time` | Total cycle time | More wire changes |
| `wire` | Wire consumption | Longer setup |
| `changeover` | Fewest setups | Suboptimal sequence |

## Grouping Logic

1. **Material** — Same material runs together (thermal stability)
2. **Thickness** — Similar thickness reduces parameter changes
3. **Wire** — Same wire diameter avoids threading
4. **Customer** — Customer batches for shipping

## Output

```json
{
  "batch_plan": {
    "total_parts": 15,
    "groups": [
      {
        "name": "D2_25mm_brass025",
        "parts": ["part1.nc", "part2.nc", "part3.nc"],
        "estimated_time_min": 180,
        "wire_type": "Brass 0.25mm",
        "setup_time_min": 15
      }
    ],
    "total_time_min": 540,
    "wire_changes": 2,
    "changeovers": 4
  },
  "schedule": {
    "start": "2026-04-16T08:00:00",
    "end": "2026-04-16T17:00:00",
    "machine": "Mitsubishi FA-20S"
  },
  "savings": {
    "time_saved_min": 45,
    "wire_saved_m": 12,
    "changeovers_avoided": 3
  }
}
```

## Examples

```bash
# Analyze directory of parts
/wedm-batch ./todays_jobs/

# Optimize for wire usage
/wedm-batch parts/*.dxf --optimize wire

# Group by customer and schedule
/wedm-batch jobs/ --group-by customer --schedule

# Specific machine
/wedm-batch queue/ --machine "FA-20S" --schedule
```

## Dependency Handling

`hook_wedm_batch_deps` checks for:
- Circular dependencies
- Missing prerequisites
- Conflicting requirements

## Schedule Conflicts

`hook_wedm_schedule_conflict` prevents:
- Double-booking machine
- Overlapping reservations
- Unrealistic timelines

## Leverages

- `WEDMBatchProgramAnalyzerEngine` — Batch analysis
- `WEDMSchedulingEngine` — Schedule optimization
- TSP algorithms for sequencing
