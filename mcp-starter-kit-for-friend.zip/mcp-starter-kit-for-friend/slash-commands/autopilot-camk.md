# Autopilot CAMK+SCI — CAM Kernel & Scientific Validation Pipeline

Autonomous development pipeline for the CAMK (CAM Kernel Pipeline) and SCI (Scientific Validation) roadmap tracks. Picks the next pending unit from CAMK-MS0 through CAMK-MS3 and SCI-MS0 through SCI-MS3, executes it, commits, scrutinizes, and registers.

## Args: $ARGUMENTS
- Empty: auto-pick next pending unit (CAMK first, then SCI)
- `camk`: only work CAMK track units
- `sci`: only work SCI track units
- `[milestone-id]`: work specific milestone (e.g., `CAMK-MS0`, `SCI-MS1`)
- `[milestone-id]/[unit-id]`: work specific unit (e.g., `CAMK-MS0/U01`)
- `status`: show progress dashboard without executing
- `no-commit`: dry run without committing

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** before concluding any analysis or implementation.
- Consider every applicable model, formula, algorithm, and combination — including novel cross-domain approaches.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing coverage before building new.
- **Completeness > Speed.** A missed mathematical model is a permanent capability gap.

## Track Overview

### CAMK — CAM Kernel Pipeline (4 milestones, 20 units)
Closes the geometry-to-G-code gap. Transforms novel algorithms from parameter engines into complete CNC program generators.

| Milestone | Title | Units | Focus |
|-----------|-------|-------|-------|
| CAMK-MS0 | Feature-to-Toolpath Bridge | 5 | FeatureToZone, AlgorithmSelector, CutterContact, StepoverOptimization, ToolAxisOptimization |
| CAMK-MS1 | Novel Algorithm to G-Code | 5 | SegmentInterpolator, PostProcessorBridge, ProgramStructure, GCodeVerification, EndToEndPipeline |
| CAMK-MS2 | Simulation & Verification | 5 | ForceSimulation, VoxelStock, CollisionIntegration, SurfaceFinishPredictor, CycleTimeAccuracy |
| CAMK-MS3 | Multi-Operation Orchestration | 5 | RestMachining, OperationSequencer, TransitionPath, AdaptiveRefinement, MultiSetupPlanner |

### SCI — Scientific Validation (4 milestones, 20 units)
Closes the sensor-to-adaptation gap and provides scientific validation of all novel algorithms.

| Milestone | Title | Units | Focus |
|-----------|-------|-------|-------|
| SCI-MS0 | Sensor Integration | 5 | SensorDataSchema, SensorSimulator, SensorFusion (EKF), AnomalyDetection, DispatcherActions |
| SCI-MS1 | Adaptive Control | 5 | AdaptiveFeedControl (PID), AdaptiveSpindleControl (SSV), BayesianAdaptive, ToolLifeAdaptive, DigitalTwinSync |
| SCI-MS2 | Validation Framework | 5 | PredictionValidation, Calibration (LM), BenchmarkSuite, UncertaintyQuantification (Sobol), ContinuousImprovement |
| SCI-MS3 | Exhaustive Math Coverage | 5 | StochasticProcess (Markov/Wiener), InformationTheory (Shannon/KL), OptimalControl (MPC/LQR), GraphTheory (TSP), FuzzyNeural (ANFIS) |

## Execution Protocol

### Phase 0: Load Context
1. Read `C:/PRISM/mcp-server/data/roadmap-index.json` for milestone status
2. Load relevant milestone envelope from `data/milestones/CAMK-*.json` or `SCI-*.json`
3. Find next pending unit (respect dependencies: CAMK-MS0 before MS1, SCI-MS0 before MS1)

#
## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config
```
SMART CONFIG — CAMK+SCI
Role:        ENGINE BUILDER
Model:       OPUS
Effort:      HIGH
Track:       [CAMK|SCI]
Milestone:   [id] — [title]
Unit:        [id] — [title]
```

### Phase 2: Toolkit Selection
Map unit to relevant existing PRISM components:
- Novel toolpath engines: NovelToolpathEngine, NovelToolpathAlgorithmsExt, CrossCamNovelAlgorithms
- Existing engines: ToolpathGenerationEngine, PostProcessorEngine, CollisionEngine, VoxelStockEngine
- Dispatchers: toolpathDispatcher (novel_compute, extended_compute, crosscam_compute)
- Registries: ToolpathStrategyRegistry (762+ strategies)
- Physics: FormulaRegistry (499 formulas), Kienzle/Taylor/Johnson-Cook models

### Phase 3: Execute Unit
Per unit:
1. Create the engine file in `src/engines/`
2. Implement with real physics/math (no stubs)
3. Export from `src/engines/index.ts`
4. Wire to appropriate dispatcher
5. Add Zod schema if new actions
6. Write unit tests (minimum 5 per engine)
7. Verify exit conditions from milestone envelope

### Phase 4: Build & Test Gate
```bash
npx tsc --noEmit  # Must pass (0 new errors)
npx vitest run src/__tests__/[new-test-file].test.ts  # All passing
```

### Phase 5: Commit
Stage only files for this unit. Commit message format:
```
feat(camk|sci): [engine-name] — [one-line description] [CAMK-MSx/Uy]
```

### Phase 6: Scrutinize
Check for: TODO/FIXME, `any` types, missing error handling, magic numbers, physics formula accuracy.

### Phase 7: Register
Add new engine to MASTER_INDEX. Update MEMORY.md milestone progress.

### Phase 8: Progress Report
```
CAMK+SCI PROGRESS — [unit-id] — [title]
Track:     [CAMK|SCI] | Milestone: [x]/[y] units done
Engine:    [name] | Lines: [N] | Tests: [N] passing
Physics:   [models used]
Wiring:    [dispatcher actions added]
Build:     PASS | Tests: PASS
Next:      [next unit id and title]
```

## Dependencies
- CAMK-MS0 has no dependencies (can start immediately)
- CAMK-MS1 depends on CAMK-MS0
- CAMK-MS2 depends on CAMK-MS1
- CAMK-MS3 depends on CAMK-MS2
- SCI-MS0 has no dependencies (can start immediately, parallel with CAMK)
- SCI-MS1 depends on SCI-MS0
- SCI-MS2 depends on SCI-MS1
- SCI-MS3 depends on SCI-MS2

## Safety Rails
- Never skip build/test gates
- Never commit secrets or credentials
- Never force-push
- All physics formulas must cite source (textbook/paper)
- Engines must use real math kernels, not stubs
- Integration with existing novel algorithms must not break 45 existing tests
