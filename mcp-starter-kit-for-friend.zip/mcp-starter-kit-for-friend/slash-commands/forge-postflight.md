# Forge Postflight — Shared Integration Protocol

You are running the post-creation integration protocol that ensures any artifacts produced by a forge command are properly wired, indexed, DSL-compliant, and synced across the system. This protocol is called by all forge-family commands after their creation phase.

**This command is designed to be called by other forge commands, not typically invoked standalone.** But standalone invocation is supported for post-hoc integration of artifacts that were created without postflight.

## Args: $ARGUMENTS
- Empty: auto-detect what was created in this session by scanning recent file changes
- `skills`: postflight for newly created skills (command files)
- `hooks`: postflight for newly created hooks (hookify rules or shell scripts)
- `engines`: postflight for newly created engines (TypeScript engine files)
- `tests`: postflight for newly created test files
- `safety`: postflight for safety chain modifications
- `debug`: postflight for debug fixes
- `perf`: postflight for performance optimizations
- `materials`: postflight for materials database changes
- `[file-path ...]`: postflight for specific files

## Postflight Checklist

The postflight runs through 6 integration gates. Each gate is conditional — it only runs if the artifact type requires it. Gates that don't apply are reported as `SKIP — [reason]`.

---

### Gate 1: DSL Compliance (`/check-dsl` protocol)
**Applies to:** engines, dispatchers, algorithms, hooks (PRISM code hooks), safety fixes, debug fixes
**Skips for:** skills (markdown only), materials (data only), perf (if no structural changes), tests (test code)

Check all created/modified `.ts` files against PRISM DSL patterns:
1. **AtomicValue compliance** — engines must return `{value, unit, uncertainty, source}`, not raw numbers
2. **Action schema** — dispatcher actions must have name, description, parameters, handler
3. **Parameter normalization** — inputs must be normalized before engine calls
4. **Safety integration** — safety-relevant outputs must feed S(x) scoring
5. **Hook registration** — PRISM hooks must follow `HookDefinition` pattern
6. **Cadence signatures** — cadence functions must follow standard signature

Report violations with file:line and suggested fix. If CRITICAL violations exist, flag for immediate fix before proceeding.

---

### Gate 2: Matrix Registration (`/addtomatrix` protocol)
**Applies to:** engines, dispatchers, algorithms, hooks (PRISM hooks), cadences, registries
**Skips for:** skills (command files), tests, materials (data), perf, debug (unless new component created)

For any new PRISM components created:
1. Scan for new files in: `src/engines/`, `src/tools/dispatchers/`, `src/algorithms/`, `src/hooks/`, `src/cadences/`
2. For each new file:
   - Add to `MASTER_INDEX_COMPACT.md` in the appropriate section
   - Register in code registry (`dispatchers/index.ts`, `AlgorithmRegistry`, etc.)
   - Verify wiring: dispatcher → engine → algorithm chain
3. Update MASTER_INDEX component counts
4. Report: `Registered [N] new products in matrix`

If no new components, report: `SKIP — no new PRISM components to register`

---

### Gate 3: Wiring Verification (`/trace` protocol)
**Applies to:** engines, dispatchers, algorithms, safety modifications
**Skips for:** skills, hooks (Claude Code hooks), tests, materials, perf (unless wiring changed)

For any new or modified wiring:
1. Trace downstream: does the new component connect to its intended consumers?
2. Trace upstream: is it reachable from a dispatcher action?
3. Check for orphans: did we create something that nothing calls?
4. Check for broken links: did we break existing wiring?

Report:
```
WIRING CHECK
  New components:    [N]
  Fully wired:       [N]
  Orphans:           [N] — [list]
  Broken links:      [N] — [list]
```

---

### Gate 4: System Sync (`/sync` protocol — counts subset)
**Applies to:** ALL forge outputs (always run)

After any forge operation, verify system consistency:
1. **Count check**: Compare documented counts in MEMORY.md against reality
   - Skills: count files in `~/.claude/commands/` vs MEMORY.md stated count
   - Hooks: count rules in hookify config + settings.json vs MEMORY.md stated count
   - Engines: count files in `src/engines/` vs MEMORY.md stated count
   - Milestones: verify roadmap-index.json counts
2. **Drift detection**: If any count drifts >0, fix the documentation
3. **CLAUDE.md staleness**: If engine/dispatcher/action counts changed, flag CLAUDE.md files for update

Report:
```
SYNC CHECK
  Skills:     [N] on disk, [N] documented — [MATCH/FIX]
  Hooks:      [N] on disk, [N] documented — [MATCH/FIX]
  Engines:    [N] on disk, [N] documented — [MATCH/FIX]
  CLAUDE.md:  [CURRENT/STALE — N files need update]
```

---

### Gate 5: MEMORY.md Update
**Applies to:** ALL forge outputs (always run)

Update `~/.claude/projects/*/memory/MEMORY.md` with:
1. **New artifact inventory**: add new skills/hooks/engines to the appropriate section
2. **Updated counts**: correct any drifted counts found in Gate 4
3. **Cross-references**: note what each new artifact chains with
4. **Keep it concise**: MEMORY.md is loaded every session — don't bloat it

---

### Gate 6: Hookify Autofire Integration
**Applies to:** skills (new commands benefit from autofire triggers), engines (may need quality hooks)
**Skips for:** hooks (self-referential), tests, materials, perf, debug, safety

For new skills:
1. Evaluate if the skill should have an autofire hookify rule (userpromptsubmit trigger)
2. If yes, define the trigger phrases and create the rule
3. Register the rule in hookify config

For new engines:
1. Evaluate if the engine needs a quality hook (e.g., posttooluse check for AtomicValue compliance)
2. If yes, create a hookify rule or integrate into posttooluse-unified

---

## Applicability Matrix

| Gate | Skills | Hooks | Engines | Tests | Safety | Debug | Perf | Materials | Audit | Drift | Types | Wiring | Deps | Cleanup | Docs | Schema | Metrics |
|------|--------|-------|---------|-------|--------|-------|------|-----------|-------|-------|-------|--------|------|---------|------|--------|---------|
| 1. DSL | SKIP | PARTIAL | **RUN** | SKIP | **RUN** | **RUN** | COND | SKIP | SKIP | SKIP | COND | COND | SKIP | SKIP | SKIP | SKIP | SKIP |
| 2. Matrix | SKIP | PARTIAL | **RUN** | SKIP | COND | COND | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | COND | SKIP | COND | SKIP |
| 3. Trace | SKIP | SKIP | **RUN** | SKIP | **RUN** | **RUN** | COND | SKIP | SKIP | SKIP | SKIP | **RUN** | SKIP | SKIP | SKIP | SKIP | SKIP |
| 4. Sync | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** |
| 5. MEMORY | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** | **RUN** |
| 6. Hookify | **RUN** | SKIP | **RUN** | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP | SKIP |

`CONDITIONAL` = only runs if that forge command created/modified relevant PRISM components
`PARTIAL` = runs a subset of the gate's checks

## Postflight Report
```
FORGE POSTFLIGHT
================
Artifact Type: [skills/hooks/engines/etc.]
Artifacts:     [N] created/modified

Gate 1 — DSL:      [PASS / N violations / SKIP]
Gate 2 — Matrix:   [N registered / SKIP]
Gate 3 — Trace:    [WIRED / N orphans / SKIP]
Gate 4 — Sync:     [MATCH / N drifts fixed]
Gate 5 — Memory:   [UPDATED / NO CHANGES]
Gate 6 — Hookify:  [N rules created / SKIP]

Integration: [COMPLETE / N ISSUES]
```

## Error Handling
- **DSL violation found**: Report but don't block — forge commands fix their own DSL issues. Flag for the calling forge command to address.
- **Matrix registration fails**: The file might not follow naming conventions — report the issue.
- **Trace finds orphans**: Report but don't block — orphans may be intentional (utility engines, helper hooks).
- **Sync drift detected**: Auto-fix counts in MEMORY.md. For CLAUDE.md, report files needing update.
- **Hookify rule conflict**: Merge with existing rule rather than creating a duplicate.

## Safety Rails
- Never modify source code — postflight is read-only analysis + documentation updates only
- Never delete artifacts — only register, index, and document them
- Never overwrite MEMORY.md without reading it first
- Sync fixes are limited to count corrections — never restructure MEMORY.md
- Hookify rules created here default to SUGGEST mode, not BLOCK

## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
