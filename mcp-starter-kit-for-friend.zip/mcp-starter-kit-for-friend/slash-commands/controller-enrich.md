# Controller Enrich — Machine Controller Knowledge Pipeline

Systematically learn every machine controller in the PRISM database.
Generates tribal knowledge tips, engine capabilities, and hooks for each controller family.

## Controller Families (deduplicated from 910 machines, 48 brands)

### Tier 1 — High-volume controllers (used by 5+ brands)
1. **Fanuc 0i-MF/MF Plus** — DN Solutions, Feeler, Hardinge, Hartford, Leadwell, Quaser, YCM, AWEA, Toyoda, Hyundai WIA
2. **Fanuc 31i-B/B5/B5 Plus** — DMG MORI, DN Solutions, Matsuura, OKK, Toyoda, Yasda, FANUC, Star, Tsugami, Nakamura-Tome, Mitsui Seiki
3. **Fanuc 0i-TF/TF Plus** — Hardinge, Hyundai WIA, Leadwell, Citizen
4. **Siemens SINUMERIK 840D sl** — DMG MORI, Chiron, Cincinnati, GROB, Heller, Index, Spinner, EMAG
5. **Siemens SINUMERIK ONE** — DMG MORI (next-gen)
6. **Siemens SINUMERIK 828D** — Spinner (mid-range)
7. **Heidenhain TNC 640** — Hermle, Soraluce, Kern
8. **Heidenhain iTNC 530** — Hermle (legacy)

### Tier 2 — OEM-specific controllers
9. **Haas NGC** — Haas (all models)
10. **Mazak MAZATROL SmoothAi/X/G/Ez** — Mazak (all models)
11. **Okuma OSP-P300/P500 (MA/SA/LA/L/S variants)** — Okuma (all models)
12. **Hurco WinMax / WinMax Lathe** — Hurco (all models)
13. **Makino Professional 6 / Hyper-i** — Makino (all models)
14. **Brother CNC-C00** — Brother (all models)
15. **Fidia C40 / C40 Vision / C40 Compact** — Fidia (all models)
16. **Citizen Cincom M70 / Mitsubishi M70V** — Citizen swiss lathes
17. **Sodick LN Professional** — Sodick EDM
18. **Datron next** — DATRON high-speed micro mills
19. **Fadal CNC** — Fadal legacy VMCs
20. **Traub TX8i-s V8** — Traub swiss/turn-mills
21. **Mitsubishi M80/M800/M850W** — MHI, Citizen
22. **Arumatik-Mi / Mi 5X** — Kitamura

## Pipeline per Controller Family

### Step 1 — Web Research (knowledge gathering)
For each controller, search for:
- Official programming manual / G-code reference
- Unique G-codes and M-codes not shared with other controllers
- Macro programming capabilities (custom variables, parametric)
- High-speed machining features (look-ahead, acceleration profiles)
- Tool management features (tool life, sister tools, breakage detection)
- Probing cycles and work offset management
- Conversational programming features
- Network/DNC capabilities
- Safety features (safe zones, door interlocks, axis clamping)

### Step 2 — Generate Tribal Knowledge Tips
Create tips in the format:
```
{
  id: "ctrl-NNN",
  category: "controller",
  subcategory: "[controller_family]",
  title: "[specific feature or best practice]",
  content: "[detailed explanation with G-codes]",
  applies_to: { controllers: ["list"], machines: ["list"] },
  tags: ["controller", "g-code", "programming"]
}
```
Target: 5-10 tips per controller family covering:
- Unique/proprietary G-codes
- HSM optimization settings
- Macro programming patterns
- Common gotchas and workarounds
- Best practices for specific operations

### Step 3 — Update CONTROLLER_FEATURES in machine-enrichment-catalog.ts
Add any missing controller feature sets to the CONTROLLER_FEATURES array.

### Step 4 — Generate POST_DB entries
For controllers not yet in POST_DB_PROFILES, create entries with:
- G-code dialect mapping
- Modal group assignments
- Coolant codes
- Work offset format
- Tool change sequence

## Execution Order
Process Tier 1 first (highest impact, most machines affected), then Tier 2.
For each family: research → tips → controller features → POST DB → verify build.

## Output
After completion, report:
- Tips generated per controller family
- CONTROLLER_FEATURES entries added
- POST_DB_PROFILES entries added
- Total knowledge base growth

## Key Files
- `C:/PRISM/mcp-server/src/data/machine-enrichment-catalog.ts` — CONTROLLER_FEATURES + POST_DB
- `C:/PRISM/mcp-server/data/knowledge/` — tribal knowledge tips
- `C:/PRISM/mcp-server/src/data/machine-profiles-catalog.ts` — controller field reference
- `C:/PRISM/mcp-server/src/data/machine-profiles-catalog-ext2.ts` — 679 machines with controllers

$ARGUMENTS
