---
name: wedm-controller
description: Wire EDM machine and controller selection
version: 1.0.0
engines:
  - EDMMaterialMachineWireEngine
  - EDMPostProcessGCodeEngine
  - WEDMMachineTechDataEngine
actions:
  - wedm_select_machine
  - wedm_select_wire
  - wedm_machine_uv_travel
  - wedm_full_selection
hooks:
  - hook_wedm_ecode_consistency
triggers:
  - "which wire edm"
  - "select machine"
  - "wedm controller"
  - "e-code family"
---

# /wedm-controller — Machine and Controller Selection

Select the optimal Wire EDM machine and controller configuration:
- Machine capability matching
- Wire type recommendation
- E-code family selection
- Controller dialect (G-code flavor)

## Usage

```
/wedm-controller [options]
```

## Arguments

- `--material` — Workpiece material
- `--thickness` — Workpiece thickness in mm
- `--size` — Part envelope (LxWxH in mm)
- `--taper` — Required taper angle in degrees
- `--ra-target` — Target surface finish Ra in µm
- `--shop` — Shop profile (default: jm-die)

## Supported Controllers

| Brand | Dialects | E-code Format |
|-------|----------|---------------|
| **Mitsubishi** | FA, MV, MP series | E0001-E9999 |
| **Fanuc** | α-C, α-iC, Robocut | E + 4 digits |
| **Sodick** | VL, SL, AG series | C + 3 digits |
| **Makino** | U3, U6, EDAF | M + 4 digits |
| **AgieCharmilles** | CUT series | AC + 3 digits |
| **Custom** | User-defined | Configurable |

## Selection Criteria

| Factor | Weight | Source |
|--------|--------|--------|
| UV travel for taper | 0.25 | Machine specs |
| Thickness capacity | 0.20 | Machine specs |
| Ra capability | 0.20 | E-code database |
| Wire compatibility | 0.15 | Wire registry |
| Shop availability | 0.20 | ShopConfigurationEngine |

## Output

```json
{
  "recommended_machine": "Mitsubishi FA-20S Advance",
  "controller": "Mitsubishi FA",
  "ecode_family": "H175 (fine finish)",
  "wire": {
    "type": "Hard Brass",
    "diameter_mm": 0.25,
    "brand": "Bedra Broncocut"
  },
  "capabilities": {
    "max_thickness_mm": 400,
    "max_taper_deg": 30,
    "xy_travel_mm": [400, 300],
    "uv_travel_mm": [120, 120]
  },
  "alternatives": [
    {"machine": "Sodick VL600Q", "score": 0.89},
    {"machine": "Fanuc Robocut α-C600iB", "score": 0.85}
  ]
}
```

## Examples

```bash
# Basic selection
/wedm-controller --material D2 --thickness 30

# Taper-specific
/wedm-controller --material A2 --thickness 25 --taper 15

# Fine finish requirement
/wedm-controller --material WC-10Co --ra-target 0.2

# Full selection with part size
/wedm-controller --material M2 --size 200x150x50 --taper 5
```

## JM Die Shop Configuration

Default shop profile includes:
- Mitsubishi FA-20S (primary)
- 2 Mitsubishi sinker EDMs
- Wire inventory: Brass 0.20, 0.25, 0.30mm
- Specialty: Zinc-coated for carbide

## Leverages

- `EDMMaterialMachineWireEngine` (1,753 LOC)
- `WEDMMachineTechDataEngine` — Controller specifications
- `ShopConfigurationEngine` — JM Die 21-machine inventory
