# Bash Optimize — Convert Repetitive Bash Commands into Token-Saving Automations

You are analyzing recent Bash tool usage in this session to identify patterns that waste tokens, then building skills, scripts, hooks, or stop hooks to eliminate that waste permanently.

## Args: $ARGUMENTS
- Empty: full analysis — scan session, find patterns, build automations
- `scan`: analyze only — show waste patterns without building anything
- `hooks`: focus on PreToolUse hook rules (deny/rewrite/hint)
- `scripts`: focus on standalone shell/python scripts to replace multi-step bash sequences
- `skills`: focus on slash commands that encapsulate common bash workflows
- `stop-hooks`: focus on stop hook checks for incomplete bash-driven work
- `[pattern]`: target a specific bash pattern (e.g., "grep -r as any", "vitest run", "esbuild")

## Phase 1: Session Bash Audit

Scan the conversation for all Bash tool calls. For each, extract:
- The command string
- Whether output was large (>50 lines / >2K tokens estimated)
- Whether it was repeated (same or similar command run multiple times)
- Whether a dedicated tool could have done it (Read/Grep/Glob/Edit/Write)
- Whether it was part of a multi-step sequence (chained with &&, or sequential calls)
- Whether the output was actually used vs ignored

Classify each into waste categories:
| Category | Description | Fix Type |
|----------|-------------|----------|
| `repeat` | Same/similar command run 2+ times | Hook (dedup) or Script |
| `verbose` | Output >50 lines, most ignored | Hook (rewrite with \| head/tail) |
| `multi-step` | 3+ sequential bash calls forming one workflow | Skill or Script |
| `wrong-tool` | Could use Read/Grep/Glob/Edit instead | Hook (deny+redirect) |
| `boilerplate` | cd + setup + command pattern repeated | Script with defaults |
| `count-check` | Counting things (wc -l, grep -c) for status | Skill (compact output) |
| `build-test` | Build or test commands with large output | Hook (cap output) |

Output:
```
BASH TOKEN AUDIT
================
Total bash calls this session: [N]
Estimated tokens consumed: ~[N]K
Waste patterns found: [N]

Pattern                          | Count | Est. Tokens | Category    | Fix
---------------------------------|-------|-------------|-------------|------------------
[command pattern]                | [N]   | ~[N]K       | [category]  | [hook/skill/script]
...

Top 3 optimization targets:
1. [pattern] — saves ~[N]K tokens/session via [fix type]
2. ...
3. ...
```

If args = `scan`, stop here.

## Phase 2: Design Automations

For each optimization target, design the right automation:

### 2A: Hook Rules (for deny/rewrite/dedup patterns)
Best for: single-command patterns that should be blocked, rewritten, or deduplicated.

Design as additions to `~/.claude/hooks/pretooluse-unified.sh`:
- **Deny rules**: redirect to dedicated tools or block wasteful patterns
- **Rewrite rules**: cap output, add flags, pipe through head/tail
- **Dedup rules**: track command hashes, block re-runs within N seconds
- **Hint rules**: warn about better alternatives without blocking

Template:
```bash
# --- [CATEGORY]: [description] ---
[[ "$COMMAND" =~ [pattern] ]] && deny|rewrite|hint "[message]"
```

For dedup rules with tracker files:
```bash
if [[ "$COMMAND" =~ [pattern] ]]; then
  _KEY=$(echo -n "$COMMAND" | md5sum 2>/dev/null | cut -d' ' -f1)
  _TRACKER="/tmp/claude-[name]-${_KEY:-nokey}"
  if [ -f "$_TRACKER" ]; then
    _AGE=$(( $(date +%s) - $(stat -c %Y "$_TRACKER" 2>/dev/null || echo 0) ))
    [ "$_AGE" -lt [N] ] 2>/dev/null && deny "TOKEN SAVE: This ran ${_AGE}s ago. Use previous results."
  fi
  touch "$_TRACKER" 2>/dev/null
fi
```

### 2B: Scripts (for multi-step bash sequences)
Best for: 3+ commands that always run together, especially with cd + setup patterns.

Create as executable bash scripts in `~/.claude/hooks/lib/` or `C:/PRISM/scripts/`:
- Accept arguments for variable parts
- Include sensible defaults (working directory, output caps)
- Output compact, structured results
- Exit with meaningful codes

Template:
```bash
#!/bin/bash
# [name].sh — [description]
# Usage: [name].sh [args]
# Saves: ~[N]K tokens vs raw bash equivalent

cd /c/PRISM/mcp-server || exit 1
[commands with compact output]
```

### 2C: Skills / Slash Commands (for workflow patterns)
Best for: complex multi-tool workflows that combine bash + read + grep + edit.

Create as `.md` files in `~/.claude/commands/`:
- Encapsulate the full workflow with structured output
- Set token budgets for output
- Chain with existing skills where appropriate

### 2D: Stop Hooks (for bash-driven incomplete work)
Best for: detecting when bash-heavy workflows leave unfinished state.

Add checks to `~/.claude/hooks/stop-completion-check.sh`:
- Detect tracker files indicating in-progress work
- Warn about background tasks still running
- Flag uncommitted changes from bash-driven edits

## Phase 3: Build

For each designed automation:

1. **Read the target file** before editing (hook scripts, command files)
2. **Add the new rules/scripts/commands** using Edit tool for existing files, Write for new files
3. **Verify syntax**: `bash -n [script]` for shell scripts
4. **Test hooks**: Simulate the pattern to confirm deny/rewrite/hint works
5. **Register**: Update MEMORY.md hook counts if hooks were added

## Phase 4: Report

```
BASH OPTIMIZE RESULTS
=====================
Automations built: [N]
  Hooks:    [N] ([N] deny, [N] rewrite, [N] dedup, [N] hint)
  Scripts:  [N]
  Skills:   [N]
  Stop:     [N]

Estimated savings: ~[N]K tokens/session

Details:
  [type] [name]: [description] — saves ~[N]K/session
  ...

New hook rules added to pretooluse-unified.sh: [list]
New scripts created: [list]
New commands created: [list]

To verify: run the bash patterns that triggered these and confirm they get caught.
```

## Output Rules
- Keep total output under 800 tokens
- Focus on actionable results, not analysis
- Prioritize by token savings (biggest wins first)
- Never create automations for one-off commands — only recurring patterns
- Test every hook rule with `bash -n` before declaring done
- If a pattern is already covered by existing hooks, skip it and note "already handled"

## Existing Infrastructure (do not duplicate)
- `pretooluse-unified.sh` already handles: grep→Grep, cat→Read, find→Glob, curl→WebFetch, sed/awk→Edit, echo redirect→Write, git dedup (30s), build/test dedup (60s), install dedup (120s), output capping for npm/git/pip/docker/sqlite
- `posttooluse-unified.sh` already handles: syntax checks, output compression (5K-20K caps), build result tracking
- Existing skills: `/test`, `/health`, `/status`, `/counts`, `/waste-report`, `/hook-stats`
