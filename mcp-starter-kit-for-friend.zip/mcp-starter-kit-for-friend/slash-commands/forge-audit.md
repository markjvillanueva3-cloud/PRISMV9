# Forge Audit — Codebase Quality Scan Autopilot

Comprehensive quality scan across PRISM. Designed for background execution — produces structured findings report.

## Args: $ARGUMENTS
- Empty: full audit (all source files)
- `[subsystem]`: focus on engines/dispatchers/algorithms/safety/hooks/cad
- `[file-path]`: audit specific file or directory
- `quick`: top-level counts only, no line-level findings
- `critical`: only CRITICAL and MAJOR findings


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Config
Smart: Senior Code Quality Engineer | SONNET | MEDIUM. YOLO mode active.

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when auditing engines and algorithms.
- Flag any engine missing applicable physics models, statistical methods, or scientific formulas.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for completeness gaps.
- **Completeness > Speed.** A missed mathematical model is a permanent capability gap.

## Scope Selection
- **Full**: `[PRISM_PATH]/mcp-server/src/**/*.ts` (exclude `__tests__`, `node_modules`, `dist`) — get PRISM_PATH from `/prism-paths`
- **Subsystem**: Filter to relevant `src/` subdirectory
- **Quick**: Sample 20 files from each major directory

## Quality Rules

**CRITICAL (Safety):** Division without zero-check, unchecked array access, S(x) bypass, `as any`/`as unknown as T`, missing null checks on external data, `eval()`/`Function()`, hardcoded credentials, `writeFileSync` without atomic wrapper, raw `JSON.parse` without try/catch

**MAJOR (Implementation Gaps):** TODO/FIXME/HACK/XXX, empty catch blocks, missing async error handling, placeholder implementations (`throw "Not implemented"`, `return {} as T`), switch without default, unused imports, >5 parameters, Promise chains without `.catch()`

**MAJOR (DSL Compliance):** Engine `.compute()` returning raw numbers (not AtomicValue), dispatcher missing required fields, missing parameter normalization, safety outputs not feeding S(x)

**MINOR (Code Smells):** `any` types (flag if >3/file), console.log in non-test code, magic numbers, commented-out code (>3 lines), functions >50 lines, nesting >3 levels, duplicate string literals (>3 occurrences)

## Report Format
```
FORGE AUDIT REPORT — Scope: [scope] | Files: [N] | Duration: [X]s
CRITICAL ([N]): [file:line] [description] ...
MAJOR ([N]):    [file:line] [description] ...
MINOR ([N]):    [grouped by type with counts]
WORST FILES:    [top 5 by finding density]
QUALITY SCORES: [per-subsystem] = 100 - (CRITICAL*10 + MAJOR*3 + MINOR*1)
```

For each CRITICAL: include one-line fix suggestion. For MAJOR: group by type, suggest batch fix.

## Postflight
Gates 1-3,6: SKIP (read-only). Gate 4: verify counts. Gate 5: update MEMORY.md.
Auto-commit only if auto-fixes applied: `fix(quality): auto-fix [N] issues [FORGE-AUDIT]`

## Safety Rails
READ-ONLY unless auto-fix requested. Never suppress CRITICALs. Never auto-fix safety-critical files. Always build+test after auto-fixes.
