# Read Plan — Optimal File Reading Strategy

Plan the most token-efficient way to read a set of files.

## Args
$ARGUMENTS — file paths or glob patterns to read

## Steps
1. For each target file, determine optimal read strategy:
   - **full**: Small file (<200 lines), read entirely
   - **offset**: Large file, read specific section with offset/limit
   - **grep**: Very large file, use Grep for specific content
   - **digest**: Use contextDigestEngine for summary only
   - **skip**: Already read recently, use cached content

2. Consider:
   - File size (check with Bash `wc -l` if unknown)
   - Whether file was recently read (check hooks)
   - Whether only specific functions/classes are needed
   - PRISM known large files (index.ts, catalogs, etc.)

3. Output plan:
```
READ PLAN — [N] files, ~[N]K estimated tokens
══════════════════════════════════════════════
[file] → [strategy] ([reason]) ~[N] tokens
...

Total: ~[N]K tokens (vs ~[N]K naive full-read = [pct]% savings)
```

4. Execute the plan if user confirms, or just show the plan.
