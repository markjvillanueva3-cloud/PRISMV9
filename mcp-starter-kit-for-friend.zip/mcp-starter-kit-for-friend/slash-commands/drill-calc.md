# Drill Calc — Quick Drilling Parameter Calculator

One-stop drilling calculator combining speed/feed, peck optimization, breakthrough force, and cycle time. Designed for quick shop-floor answers.

## Args: $ARGUMENTS
- Empty: interactive mode — prompt for inputs
- `[diameter] [depth] [material]`: quick calc (e.g., `10 50 steel`, `6.8 30 stainless`)
- `tap [thread-size]`: calculate tap drill size + drilling params (e.g., `tap M10x1.5`)
- `deep [diameter] [depth] [material]`: deep hole focus (L/D > 5)
- `chart [material]`: show speed/feed chart for common drill sizes

## Phase 1: Smart Config
```
SMART CONFIG
Role:   Manufacturing Process Expert
Model:  HAIKU
Effort: LOW
Reason: Quick calculation using existing engines, no code changes
```

## Phase 2: Gather Inputs
From args or interactively:
- **Drill diameter** (mm)
- **Hole depth** (mm)
- **Material** (steel, stainless, aluminum, titanium, cast iron, inconel, copper, brass)
- **Drill type** (default: carbide_twist)
- **Coolant** (TSC available? default: no)
- **Machine max RPM** (optional, for speed limiting)

## Phase 3: Calculate

### 3A: Speed & Feed
Use `prism_calc action:speed_feed` or reference tables:
| Material | Vc (m/min) | fn (mm/rev) per diameter range |
|----------|-----------|-------------------------------|
| Steel | 70-100 | 0.08-0.25 (scales with dia) |
| Stainless | 40-60 | 0.06-0.18 |
| Aluminum | 150-250 | 0.10-0.30 |
| Titanium | 30-50 | 0.05-0.15 |
| Cast Iron | 60-90 | 0.10-0.25 |
| Inconel | 15-25 | 0.04-0.10 |

Feed per rev scales with drill diameter: fn ≈ 0.01 × D^0.6 (baseline for steel)

### 3B: RPM & Feed Rate
```
RPM = (Vc × 1000) / (π × D)
Feed Rate = fn × RPM (mm/min)
```
If machine max RPM provided, cap RPM and note reduced Vc.

### 3C: Peck Optimization (if L/D > 3)
Call PeckDrillingOptimizationEngine:
```
prism_calc action:peck_drill_optimize params:{
  drill_diameter: D, hole_depth: L, material: mat,
  drill_type: type, cutting_speed: Vc, feed_per_rev: fn,
  coolant_through_spindle: tsc
}
```

### 3D: Breakthrough Force (if applicable)
Call DrillBreakthroughForceEngine:
```
prism_calc action:drill_breakthrough params:{
  drill_diameter: D, material: mat, feed_per_rev: fn,
  cutting_speed: Vc
}
```

### 3E: Cycle Time
```
Cutting time = L / (fn × RPM) minutes
+ Rapid approach (5mm at rapid)
+ Peck retract time (if pecking)
+ Rapid retract
```

## Phase 4: Output
```
DRILL CALC
==========
Drill:     Ø[D]mm [type]
Hole:      [L]mm deep (L/D = [ratio])
Material:  [material]
Coolant:   [TSC/flood/none]

PARAMETERS
----------
Vc:        [X] m/min
RPM:       [X]
Feed/rev:  [X] mm/rev
Feed rate: [X] mm/min

PECKING (L/D = [X])
-------------------
Strategy:  [full_retract/chip_break/continuous]
Peck depth: [X] mm
Pecks:     [N]
Retract:   [X] mm

CYCLE TIME
----------
Cutting:   [X] sec
Pecking:   [X] sec (retract overhead)
Total:     [X] sec per hole

BREAKTHROUGH
-----------
Peak force: [X] N
Torque:    [X] N·m

RECOMMENDATIONS
---------------
- [recommendation 1]
- [recommendation 2]
```

### For `tap` mode:
Also calculate:
- Tap drill size (minor diameter - allowance)
- Thread percentage (typically 65-75%)
- Tapping speed (typically 50% of drilling Vc)
- Tapping torque from TappingTorqueEngine

### For `chart` mode:
Output a speed/feed table for common drill sizes (1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20mm) in the specified material.

## Error Handling
- Unknown material: default to steel, warn user
- Diameter > 50mm: suggest indexable insert drill
- L/D > 20: strongly recommend gun drill
- Missing depth: assume through-hole, ask for thickness
