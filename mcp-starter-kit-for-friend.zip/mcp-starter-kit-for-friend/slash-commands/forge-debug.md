# Forge Debug — Structured Debugging Pipeline

You are running a structured debugging pipeline that takes a bug report, error message, or unexpected behavior and systematically traces through the system to identify root cause, implement a fix, and write a regression test. No guessing — trace the evidence.

## Args: $ARGUMENTS
- `[error message or description]`: the bug to investigate
- `[file-path]`: start investigation from a specific file
- `[test-name]`: a failing test to debug
- Empty: **MASTER_INDEX Sweep** — fall back to systematic audit (see Phase 0 below)

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when diagnosing root causes.
- Consider every applicable diagnostic model, statistical test, and analytical method before concluding.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- **Completeness > Speed.** A missed root cause means the bug returns.

## Phase 0: MASTER_INDEX Sweep (when no args provided)

When `$ARGUMENTS` is empty, instead of asking what to debug, run a systematic audit of the codebase using the MASTER_INDEX as the map:

### 0A: Load the MASTER_INDEX
Read `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` (~735 tokens — NOT the 5,000-token MASTER_INDEX.md).

### 0B: Priority Queue — Development Capability Impact
Audit components in this order (highest impact first):

| Priority | Category | Components | Why First |
|----------|----------|------------|-----------|
| P0 | Core Calculations | calcDispatcher, ManufacturingCalculations, AdvancedCalculations, ToolpathCalculations | Foundation — all outputs depend on these |
| P1 | Safety Stack | safetyDispatcher, CoolantValidationEngine, SpindleProtectionEngine, ToolBreakageEngine, CollisionDetectionEngine | Safety-critical — blocks production |
| P2 | Data Layer | dataDispatcher, registries (Material, Machine, Tool, Alarm, Formula) | Feeds all calculations |
| P3 | Intelligence | intelligenceDispatcher (489 actions), IntelligenceEngine, DecisionTreeEngine, InferenceChainEngine | 46% of all actions |
| P4 | CAD/CAM/Toolpath | cadDispatcher, camDispatcher, toolpathDispatcher, PostProcessorEngine, GCodeTemplateEngine | Core manufacturing dev tools |
| P5 | Quality/Validation | validationDispatcher, qualityDispatcher, ProductEngine, ToleranceEngine | Output quality gates |
| P6 | Session/Context | sessionDispatcher, contextDispatcher, MemoryGraphEngine | Session reliability |
| P7 | Process Engines | threadDispatcher, turningDispatcher, fiveAxisDispatcher, edmDispatcher, grindingDispatcher | Process-specific |
| P8 | Orchestration | orchestrationDispatcher, SwarmExecutor, AgentExecutor, ATCS | Multi-agent coordination |
| P9 | Infrastructure | hookDispatcher, EventBus, HookEngine, CampaignEngine, ExportEngine | Supporting systems |

### 0C: Per-Component Debug Protocol
For each component in priority order:
1. **Read** the dispatcher/engine source file completely
2. **Scan** for: dead code, unreachable branches, wrong formulas, missing validation, swallowed errors, off-by-one, unit mismatches, division-by-zero, type coercion traps
3. **Cross-reference** against MASTER_INDEX counts (action count matches registered actions?)
4. **Check wiring**: does the dispatcher actually call the engine it claims to use?
5. **If bug found** → enter Phase 2+ (Triage → Fix → Test → Commit) for that bug, then return here and continue sweep
6. **If clean** → note as verified and move to next component

### 0D: Progress Tracking
Use TaskCreate to track which MASTER_INDEX sections have been audited. Mark each component as:
- `pending` — not yet examined
- `in_progress` — currently auditing
- `completed` — audited, clean or bugs fixed

### 0E: Sweep Summary
After completing a priority tier (or when context budget runs low), output:
```
MASTER_INDEX SWEEP — P[N] [Category] COMPLETE
=============================================
Components audited: [N]
Bugs found:         [N] (CRITICAL: [N], MAJOR: [N], MINOR: [N])
Bugs fixed:         [N]
Tests added:        [N]
Components clean:   [list]
Open issues:        [list with file:line]

Next: P[N+1] [Category] — [N] components remaining
```

Continue to Phase 1 only when a specific bug is being investigated within the sweep.

---


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` -- loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` -- zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` -- resolve E0001->path instantly (1,865 indexed files)


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE-COMPLEX (debugging requires systematic reasoning)
2. Domain: Determined by the bug's location (auto-detected)
3. Roles: Senior QA & Reliability Engineer + domain-specific role
4. Model: OPUS (debugging requires deep reasoning about causality)
5. Effort: HIGH

## Phase 2: Triage — Understand the Symptom

### 2A: Capture the Bug
Document what's known:
```
BUG TRIAGE
==========
Symptom:     [what's happening]
Expected:    [what should happen]
Source:      [error message / user report / test failure]
Severity:    [CRITICAL / MAJOR / MINOR]
Frequency:   [always / intermittent / once]
Since:       [when did it start / unknown]
```

### 2B: Reproduce
1. If a test failure: run the specific test and capture the full error output
2. If a runtime error: identify the reproduction steps
3. If an error message: search the codebase for where it's thrown
4. Capture the full stack trace if available

### 2C: Scope Assessment
- Is this a single-file bug or cross-module?
- Is this a logic error, data error, configuration error, or environment error?
- Does this affect production safety? (If yes, escalate severity)

## Phase 3: Investigation — Trace the Evidence

### 3A: Error Origin
1. Find where the error is thrown/generated in the source code
2. Read that file and understand the function's purpose
3. Identify the condition that triggers the error

### 3B: Call Chain Trace
Work backwards through the call chain:
1. What called this function?
2. What data was passed in?
3. Where did that data come from?
4. At what point did the data become invalid / unexpected?

### 3C: State Analysis
Check the system state at the point of failure:
- What are the input values?
- What are the intermediate values?
- What's the environment state (config, OS, versions)?
- Has anything changed recently? (check git log for related files)

### 3D: Hypothesis Formation
Based on evidence, form 1-3 hypotheses:
```
HYPOTHESES
==========
H1: [description] — Evidence: [what supports this]
H2: [description] — Evidence: [what supports this]
H3: [description] — Evidence: [what supports this]

Most likely: H[N] — Confidence: [HIGH/MEDIUM/LOW]
```

### 3E: Hypothesis Testing
For each hypothesis (most likely first):
1. Identify what would prove/disprove it
2. Read the relevant code
3. Check if the evidence matches
4. If confirmed → proceed to fix
5. If disproven → move to next hypothesis

### 3F: Root Cause Confirmation
```
ROOT CAUSE
==========
Location:    [file:line]
Type:        [logic / data / config / environment / dependency]
Description: [clear explanation of why the bug occurs]
Evidence:    [what proves this is the root cause]
Impact:      [what else might be affected by the same root cause]
```

## Phase 4: Fix — Implement the Solution

### 4A: Design the Fix
Before writing code:
1. What's the minimal change that fixes the root cause?
2. Does this fix introduce any new edge cases?
3. Does this fix affect any other code paths?
4. Is there a risk of regression in related functionality?

### 4B: Implement
1. Read the affected file(s) completely
2. Make the minimal, targeted fix
3. Add inline comments only if the fix is non-obvious
4. Do NOT refactor surrounding code — fix the bug only

### 4C: Verify the Fix
1. If there's a failing test: run it — it should now pass
2. Run the full test suite — no regressions
3. Run `npm run build` — must pass
4. If the bug was in Python code: run pytest as well

## Phase 5: Regression Test — Prevent Recurrence

### 5A: Write the Test
Create a test that:
1. Reproduces the original bug (would fail without the fix)
2. Verifies the fix works correctly
3. Tests related edge cases discovered during investigation
4. Uses descriptive names: `it('should not [bug description] when [condition]')`

### 5B: Validate the Test
1. The test should PASS with the fix applied
2. Mentally verify: would this test have FAILED before the fix?
3. Run the full suite to confirm no conflicts

## Phase 6: Forge Postflight (`/forge-postflight debug` protocol)
Run the shared integration protocol for debug fixes:
1. **Gate 1 — DSL**: RUN — verify the fix follows PRISM DSL patterns (especially if modifying engine/dispatcher code)
2. **Gate 2 — Matrix**: CONDITIONAL — if the fix created new components, register in MASTER_INDEX
3. **Gate 3 — Trace**: RUN — verify the fix didn't break any wiring chains (trace the modified component)
4. **Gate 4 — Sync**: RUN — if the fix resolved a known finding, update counts
5. **Gate 5 — Memory**: RUN — update MEMORY.md if a critical fix was applied (add to "Critical Fixes Applied" section)
6. **Gate 6 — Hookify**: SKIP (debug fixes don't need autofire rules)

Report the postflight results before proceeding to commit.

## Phase 7: Auto-Commit (`/auto-commit` protocol)
1. Stage the fix and the regression test
2. Commit: `fix(scope): [root cause summary] [FORGE-DEBUG]`
3. Report the commit

## Summary Report
```
FORGE DEBUG COMPLETE
====================
Bug:           [symptom summary]
Root Cause:    [file:line] — [description]
Type:          [logic / data / config / environment / dependency]
Fix:           [what was changed]
Test:          [test file] — [N] new tests
Hypotheses:    [N] formed, H[X] confirmed
Investigation: [N] files read, [N] traces followed
Build:         PASS
Tests:         [N] passing (0 regression)
Committed:     [commit hash]

Investigation Timeline:
  1. [symptom captured]
  2. [error origin found at file:line]
  3. [call chain traced through N functions]
  4. [root cause identified]
  5. [fix applied]
  6. [regression test written]

Lessons Learned:
  [1-2 sentences about what pattern caused this bug and how to prevent similar ones]

Next: /forge-tests for broader coverage, /forge-safety if safety-related
```

## Error Handling
- **Can't reproduce**: Document the conditions, check environment differences, ask for more details
- **Multiple root causes**: Fix the primary one, log the others as separate bugs
- **Fix breaks other tests**: The fix is wrong or incomplete — re-investigate
- **Root cause is in a dependency**: Document the issue, implement a workaround, note the upstream bug
- **Context budget**: Document findings so far, commit the investigation notes, pick up in next session

## Safety Rails
- Never apply a fix without understanding the root cause
- Never suppress errors to make tests pass
- Never modify tests to match buggy behavior
- Always run the full test suite after a fix
- If the bug is safety-related, apply maximum scrutiny to the fix
- Document the root cause even if the fix is simple — prevention matters
