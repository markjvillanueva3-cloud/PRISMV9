---
effort: high
maxTurns: 30
---

# Forge Triple — Engines + Skills + Hooks Pipeline

This profile-side command is only a launcher.
The canonical PRISM `/forge-triple` command lives in the repo at `H:/PRISM/.claude/commands/forge-triple.md`.

## Rule

When working in `H:\PRISM`, follow the repo command exactly instead of maintaining a separate profile-side forge-triple protocol.

## Canonical Source

- `H:/PRISM/.claude/commands/forge-triple.md`
