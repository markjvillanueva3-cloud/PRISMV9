# Action Search — Dispatcher Action Discovery

You are searching across PRISM's 1260+ dispatcher actions to find the right action for a given task, discover what a dispatcher offers, or find unwired/orphaned actions. With 50 dispatchers, finding the right entry point is the first challenge of any PRISM operation.

## Args: $ARGUMENTS
- `[keyword]`: search all dispatcher actions by keyword (e.g., `thermal`, `tool_wear`, `sfc`)
- `dispatcher [name]`: list all actions for a specific dispatcher (e.g., `dispatcher safety`)
- `count`: show action counts per dispatcher
- `unwired`: find actions defined but missing handlers or engine connections
- `map`: show dispatcher → action category map (high-level overview)
- Empty: show search usage and dispatcher list


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Step 1: Parse Query

### Keyword Search (`/action-search thermal`)
1. Grep all `*Dispatcher.ts` files in `C:/PRISM/mcp-server/src/tools/dispatchers/` for the keyword
2. Match against:
   - Action name arrays (e.g., `"thermal_update"`, `"thermal_status"`)
   - Action descriptions in comments or Zod schemas
   - Handler function names
3. For each match, extract: dispatcher name, action name, which sub-engine/group it belongs to
4. Present:
```
ACTION SEARCH: "thermal"
=========================
Found [N] actions across [N] dispatchers:

machineLiveDispatcher:
  thermal_update     — Update thermal compensation data
  thermal_status     — Get current thermal status

safetyDispatcher:
  check_thermal_limits — Verify thermal safety boundaries

calculatorDispatcher:
  thermal_calc       — Calculate thermal expansion effects

Tip: /trace [action-name] to see full wiring chain
```

### Dispatcher Detail (`/action-search dispatcher safety`)
1. Read the specified dispatcher file
2. Extract ALL action name arrays/sets
3. Group by sub-engine or category
4. Show total count and list:
```
DISPATCHER: safetyDispatcher
==============================
Location: src/tools/dispatchers/safetyDispatcher.ts
Actions:  [N] total

  Collision Detection (8):
    check_toolpath_collision, validate_rapid_moves, check_fixture_clearance,
    calculate_safe_approach, detect_near_miss, generate_collision_report,
    validate_tool_clearance, check_5axis_head_clearance

  Safety Scoring (6):
    calculate_safety_score, get_safety_report, ...

  Cross-Field Physics (4):
    ...

Schemas: [Zod schema file if exists]
```

### Count (`/action-search count`)
1. For each dispatcher file, count action definitions
2. Sort by count (descending)
3. Present:
```
DISPATCHER ACTION COUNTS
=========================
Dispatcher              | Actions | Sub-engines
------------------------|---------|------------
intelligenceDispatcher  |    50   | 5 (core hub)
productDispatcher       |    40   | 4
machineLiveDispatcher   |    40   | 4
safetyDispatcher        |    32   | 4
...
TOTAL                   |  1260   | 50 dispatchers
```

### Unwired (`/action-search unwired`)
1. For each dispatcher, extract action names from const arrays
2. Check if each action has a corresponding handler in the switch/if chain
3. Check if the handler calls an actual engine method
4. Report actions that are:
   - Defined in array but no handler (dead declaration)
   - Handler exists but returns stub/placeholder
   - Handler calls an engine method that doesn't exist
```
UNWIRED ACTIONS
===============
[N] actions found without proper wiring:

  [dispatcher]::[action] — [reason: no handler / stub / missing engine method]
  ...

Fix: /forge-engines to create missing engine implementations
```

### Map (`/action-search map`)
High-level overview of all dispatchers grouped by domain:
```
DISPATCHER MAP
==============
CNC Core:     turning, grinding, threading, fiveAxis, toolpath, cam
Materials:    product (materials sub-engine), calculator
Safety:       safety, compliance, guard
Quality:      quality, validation
Integration:  integration, bridge, export
Intelligence: intelligence (hub), diagnosis, knowledgeExt
System:       session, context, memory, auth, hook, telemetry
Machine:      machineLive, scheduling
CAD:          cad, autonomous
Orchestration: orchestration
```

## Step 2: Present Results
- For keyword search: group by dispatcher, show action names + brief description
- For dispatcher detail: show ALL actions grouped by sub-engine
- For count: sorted table
- For unwired: actionable list with fix suggestions
- For map: domain-grouped overview

## Error Handling
- **No matches**: "No actions matching '[keyword]'. Try broader terms or /action-search map for overview."
- **Dispatcher not found**: "No dispatcher named '[name]'. Available: [list]"
- **Pattern too broad**: If >50 matches, "Too many results ([N]). Narrow your search or add a dispatcher filter."

## Chaining
- Discovery flow: `/action-search [keyword]` → find action → `/trace [action]` → see full chain
- Development flow: `/action-search unwired` → find gaps → `/forge-engines` → create handlers
- Understanding flow: `/action-search map` → pick domain → `/action-search dispatcher [name]` → dive in
- Pairs with: `/trace` (wiring chain), `/scope` (impact analysis), `/forge-engines` (create engines)
