# Machine ROI — Which Machine Should Run Which Jobs for Maximum Profit

Most shops assign jobs to machines based on habit or availability, not profitability. A $500K 5-axis running simple 3-axis work is burning money. A manual mill doing work a VMC could do 10× faster is leaving money on the table. This command matches every job to its most profitable machine.

**Value**: Moving 3 jobs to their optimal machines typically saves $500-2,000/month in machine time. Identifying underutilized expensive machines and filling them properly = $2,000-10,000/month recovered capacity.

## Args:
- Job + machine options (e.g., "part123, Haas VF-2 vs DMG MORI 5-axis vs Mazak QTN")
- `shop-wide`: analyze all active jobs across all machines
- `utilization`: focus on machine utilization and capacity planning
- `justify [machine]`: build ROI case for purchasing a specific machine

## Phase 1: Machine Capability Mapping
For each available machine:

1. `/machine-check` — get machine specs and limits:
   - Max RPM, power, torque curves
   - Axis travel, rapid rates
   - Tool changer capacity and change time
   - Accuracy class and positioning repeatability

2. Calculate effective hourly rate:
   - Machine cost (lease/depreciation + maintenance + power)
   - Operator cost (loaded rate, skill level required)
   - Overhead allocation
   - **True cost per minute of spindle time**

3. Map capability envelope:
   - Materials this machine handles well
   - Feature complexity (3-axis features vs 5-axis required)
   - Tolerance capability (what Cpk can it achieve?)
   - Batch size sweet spot (setup time vs cycle time)

## Phase 2: Job-Machine Matching
For each job, on each candidate machine:

1. Run `ultimateSpeedFeedEngine.calculate()` with machine-specific limits:
   - Optimal speeds/feeds constrained by THIS machine's power/RPM/torque
   - Cycle time estimate on THIS machine

2. `/cycle-time-crush` (quick mode) — estimated cycle time:
   - Cutting time at machine-optimal parameters
   - Tool change time (machine-specific)
   - Rapid traverse time (machine-specific rapid rates)

3. Calculate per-part economics:
   ```
   Machine: [name]
   Cycle time:        [X] min
   Machine cost:      $[X] ([X] min × $[rate]/min)
   Setup (amortized):  $[X] (setup time / batch size)
   Tool cost:          $[X] (tool life at these parameters)
   TOTAL per part:     $[X]
   ```

## Phase 3: Profitability Matrix

```
JOB-MACHINE PROFITABILITY MATRIX
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
               | Machine A    | Machine B    | Machine C    | BEST
Job 1          | $[X]/part    | $[X]/part    | $[X]/part    | [winner]
Job 2          | $[X]/part    | $[X]/part    | N/A (can't)  | [winner]
Job 3          | $[X]/part    | $[X]/part    | $[X]/part    | [winner]
...

CURRENT ASSIGNMENT vs OPTIMAL:
  Job 1: [current machine] → [optimal machine] = $[X] saved/part
  Job 2: [no change needed]
  Job 3: [current machine] → [optimal machine] = $[X] saved/part

MONTHLY IMPACT: $[X] saved by reassigning [N] jobs
```

## Phase 4: Utilization Analysis (if `utilization` flag)

1. **Current machine utilization**:
   - Hours available per month (shifts × days)
   - Hours currently scheduled
   - Hours in setup vs cutting vs idle
   - Utilization % per machine

2. **Capacity optimization**:
   - Which machines have open capacity?
   - Which are bottlenecks?
   - What additional jobs could fill underutilized machines?
   - Revenue per machine-hour for each machine

3. **Scheduling recommendations**:
   - Batch similar setups on same machine (reduce setup time)
   - Run lights-out capable jobs on overnight shifts
   - Queue priority based on margin per machine-hour

## Phase 5: Machine Purchase Justification (if `justify` flag)

1. **What work moves to the new machine**:
   - Jobs currently running suboptimally on existing machines
   - Jobs currently outsourced that could come in-house
   - New work categories the machine enables (5-axis, mill-turn, etc.)

2. **ROI calculation**:
   ```
   MACHINE PURCHASE ROI — [Machine Name]
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Purchase price:    $[X]
   Annual cost:       $[X] (depreciation + maintenance + power)

   Revenue gained:
     Jobs moved from slower machines:  $[X]/year
     Outsourced work brought in-house: $[X]/year
     New work enabled:                 $[X]/year
     Freed capacity on other machines: $[X]/year
   TOTAL annual benefit:               $[X]/year

   Payback period:    [X] months
   5-year ROI:        [X]%
   ```

## Output Summary
```
MACHINE ROI — [Job/Shop Description]
======================================
Machines analyzed:  [N]
Jobs analyzed:      [N]

OPTIMAL ASSIGNMENTS:
  Job          | Best Machine     | $/Part | vs Current
  [job1]       | [machine]        | $[X]   | -$[X] ([X]% less)
  [job2]       | [machine]        | $[X]   | no change
  ...

MONTHLY SAVINGS: $[X] from [N] job reassignments
ANNUAL SAVINGS:  $[X]

UTILIZATION (current → optimized):
  [Machine A]: [X]% → [X]%
  [Machine B]: [X]% → [X]%

BOTTLENECK: [machine] — consider overtime/second shift/purchase

TOP RECOMMENDATION: [single most impactful change]
```

## Key Engines Used
UltimateSpeedFeedEngine, CycleTimeEstimatorEngine, MachineProfileEngine,
MachineGeometricAccuracyEngine, ProcessCapabilityEngine, SustainabilityLCAEngine
