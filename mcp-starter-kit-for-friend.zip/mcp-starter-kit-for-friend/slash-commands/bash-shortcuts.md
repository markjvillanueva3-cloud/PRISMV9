# Bash Shortcuts — Quick Reference for Token-Saving Scripts

List all available PRISM bash shortcut scripts that replace verbose multi-step commands.

## Args: $ARGUMENTS
- Empty: list all shortcuts with usage
- `[name]`: show detailed usage for a specific shortcut
- `add [name] [description]`: create a new shortcut script

## Steps

### List Mode (default)
Display all scripts in `~/.claude/hooks/lib/prism-*.sh`:

```
BASH SHORTCUTS
==============
Script              | Description                        | Usage
--------------------|------------------------------------|-----------------------------------------
prism-scan.sh       | Pattern counting in PRISM source   | bash ~/.claude/hooks/lib/prism-scan.sh "<pattern>" [scope]
prism-build.sh      | PRISM esbuild (compact output)     | bash ~/.claude/hooks/lib/prism-build.sh
[additional scripts discovered dynamically]

Scopes for prism-scan.sh: all, src, tests, engines, tools, hooks, detail

Instead of:  cd /c/PRISM/mcp-server && grep -r "TODO" src/ --include="*.ts" | wc -l
Use:         bash ~/.claude/hooks/lib/prism-scan.sh "TODO"

Instead of:  cd /c/PRISM/mcp-server && node node_modules/esbuild/bin/esbuild ...
Use:         bash ~/.claude/hooks/lib/prism-build.sh
```

Also scan `C:/PRISM/scripts/` for Python scripts and list those organized by category.

### Detail Mode
For a specific script:
1. Read the script file
2. Show: description, usage, arguments, examples, estimated token savings

### Add Mode
Create a new shortcut:
1. Create `~/.claude/hooks/lib/prism-[name].sh` with proper template
2. Make executable
3. Verify syntax with `bash -n`
4. Optionally add a hint hook in pretooluse-unified.sh to suggest it

## Output Rules
- Keep output under 300 tokens for list mode
- Focus on practical usage, not implementation details
