# Forge Metrics — Codebase Metrics Dashboard

You are running a specialized autopilot pipeline that computes codebase health metrics across the PRISM project — complexity scores, coupling analysis, file size distribution, and trend tracking. Designed to run in the **background** — produces a metrics dashboard.

## Args: $ARGUMENTS
- Empty: full metrics — all dimensions
- `complexity`: only cyclomatic/cognitive complexity
- `coupling`: only coupling and dependency analysis
- `size`: only file/function size analysis
- `trends`: compare current metrics to last saved baseline
- `[subsystem]`: scope to dispatchers, engines, algorithms, hooks
- `quick`: top-level summary only


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` -- loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` -- zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` -- resolve E0001->path instantly (1,865 indexed files)


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: LOW-MODERATE (metric calculation is formulaic)
2. Domain: Software Metrics + Code Quality
3. Roles: Software Metrics Analyst + Quality Engineer
4. Model: SONNET (computation, not creative)
5. Effort: LOW

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Metrics Collection

### 3A: Size Metrics
For each source file:
- **LOC**: Lines of code (excluding blank/comment)
- **Functions**: Count of functions/methods
- **Exports**: Count of exported symbols
- **Classes**: Count of class definitions

Aggregate:
- Total LOC across project
- Average/median file size
- Top 10 largest files
- Top 10 longest functions
- Files per directory (distribution)
- File count by type (.ts, .py, .json, .md, .sh)

### 3B: Complexity Metrics
For each function:
- **Cyclomatic complexity**: Count decision points (if, else, case, &&, ||, ?:, catch)
- **Nesting depth**: Maximum indent level
- **Parameter count**: Number of function parameters
- **Cognitive complexity**: Weighted by nesting (deeper = higher weight)

Aggregate:
- Average complexity per subsystem
- Top 10 most complex functions
- Complexity distribution (simple/moderate/complex/very complex)
- Functions exceeding thresholds: complexity >10, nesting >4, params >5

### 3C: Coupling Metrics
For each file:
- **Afferent coupling (Ca)**: How many other files import this file
- **Efferent coupling (Ce)**: How many files this file imports
- **Instability (I)**: Ce / (Ca + Ce) — 0 = maximally stable, 1 = maximally unstable
- **Fan-in/Fan-out ratio**: imports received vs imports made

Aggregate:
- Coupling matrix by subsystem
- Most depended-on files (highest Ca)
- Most dependent files (highest Ce)
- Coupling between subsystem pairs
- Hub files (high Ca AND high Ce — potential god objects)

### 3D: Cohesion Metrics
For each class/module:
- **LCOM** (Lack of Cohesion of Methods): Do methods use shared state?
- **Single Responsibility indicator**: Does file handle multiple concerns?
- Estimated by: number of distinct "clusters" of functions that share imports

### 3E: PRISM-Specific Metrics
- **Dispatcher action density**: actions per dispatcher (avg, min, max)
- **Engine method count**: compute methods per engine
- **Hook coverage**: hooks per dispatcher (safety coverage)
- **Test ratio**: test files per source file
- **Registry completeness**: registered / actual components
- **Safety chain coverage**: safety-validated dispatchers / total dispatchers

## Phase 4: Metrics Dashboard

```
FORGE METRICS DASHBOARD
========================
Project:    PRISM v9 MCP Server
Snapshot:   [date]

SIZE
----
Total LOC:        [N] (src only)
Source files:     [N] .ts files
Test files:       [N] .test.ts files
Avg file size:    [N] lines (median: [M])
Largest files:
  1. [file] — [N] lines
  2. [file] — [N] lines
  3. [file] — [N] lines

COMPLEXITY
----------
Avg complexity:   [N] (target: <10)
Max complexity:   [N] in [file:function]
Distribution:
  Simple (<5):      [N]% of functions
  Moderate (5-10):  [N]%
  Complex (10-20):  [N]%
  Very Complex (>20): [N]%
Hotspots:
  1. [file:function] — complexity [N], nesting [M]
  2. [file:function] — complexity [N], nesting [M]
  3. [file:function] — complexity [N], nesting [M]

COUPLING
--------
Avg imports/file:  [N]
Hub files (high Ca+Ce):
  1. [file] — Ca:[N] Ce:[M] I:[X]
  2. [file] — Ca:[N] Ce:[M] I:[X]
Subsystem coupling:
  dispatchers ↔ engines:     [N] connections
  engines ↔ algorithms:      [N] connections
  utils ↔ everything:        [N] connections

PRISM SPECIFIC
--------------
Dispatchers:      [N] (avg [M] actions each)
Engines:          [N] (avg [M] methods each)
Actions:          [N] total
Test ratio:       [N] test files / [M] source files = [X]%
Safety coverage:  [N]% dispatchers have safety hooks

HEALTH SCORES (0-100)
---------------------
Size:         [score] (files within size limits)
Complexity:   [score] (functions within complexity limits)
Coupling:     [score] (low coupling, high cohesion)
Coverage:     [score] (test + doc + safety coverage)
OVERALL:      [score]
```

### 4B: Trend Comparison (if baseline exists)
Compare to saved baseline at `C:/PRISM/state/metrics-baseline.json`:
```
TRENDS (vs [baseline_date]):
  LOC:         [N] → [M] ([+/-X], [+/-Y]%)
  Complexity:  [N] → [M] ([+/-X])
  Coupling:    [N] → [M] ([+/-X])
  Files:       [N] → [M] ([+/-X])
  Health:      [N] → [M] ([+/-X])
```

### 4C: Save Baseline
Save current metrics to `C:/PRISM/state/metrics-baseline.json` for future comparison.

## Phase 5: Forge Postflight (`/forge-postflight metrics`)
1. **Gate 1 — DSL**: SKIP
2. **Gate 2 — Matrix**: SKIP
3. **Gate 3 — Trace**: SKIP
4. **Gate 4 — Sync**: RUN — verify component counts match metrics
5. **Gate 5 — Memory**: RUN — update MEMORY.md with health scores
6. **Gate 6 — Hookify**: SKIP

## Phase 6: Auto-Commit
If baseline was saved:
`chore(metrics): update metrics baseline — health [score]/100 [FORGE-METRICS]`

## Summary Report
```
FORGE METRICS COMPLETE
======================
Scanned:     [N] files, [M] functions
LOC:         [N] total
Complexity:  [avg] avg, [max] max
Coupling:    [avg] avg imports
Health:      [score]/100 overall
Trend:       [improving/stable/declining] vs baseline
Next:        Fix complexity hotspots, then /forge-metrics trends
```

## Error Handling
- **Large files**: Estimate complexity from control flow keywords, don't parse AST
- **Python files**: Use simpler LOC + function count metrics
- **No baseline**: First run creates baseline, skip trend comparison
- **Context budget**: Run quick mode (subsystem totals only)

## Safety Rails
- This is READ-ONLY — never modify source code
- Metrics are informational — don't auto-fix based on thresholds
- Baseline saves are additive (append to history, don't overwrite)
- Never expose internal metrics externally (no telemetry)
- Complexity thresholds are guidelines, not mandates
