# Blueprint Read — Engineering Drawing OCR & Analysis

Extract manufacturing data from engineering drawings/blueprints. Parses dimensions, GD&T, title blocks, notes, and optionally generates an instant quote.

## Args: $ARGUMENTS
- File path: analyze a specific drawing (PDF, image, or pre-extracted text)
  Example: `/blueprint-read C:/Parts/bracket-001.pdf`
- `quote`: extract AND generate quote from drawing
  Example: `/blueprint-read C:/Parts/bracket-001.pdf quote`
- `inspect`: extract AND generate inspection plan
- `setup`: extract AND generate setup sheet
- `compare <rev1> <rev2>`: compare two drawing revisions

## Pipeline

```
Drawing (PDF/image)
  → pdf_ingestion.py (PyMuPDF + Tesseract OCR fallback)
  → BlueprintOCREngine.analyzeBlueprint()
    → Dimensions (linear, diameter, radius, angular, thread, chamfer)
    → GD&T frames (14 symbols: flatness, position, runout, etc.)
    → Title block (part number, revision, material, finish)
    → Notes (process notes, material callouts, hardness specs)
  → BlueprintToQuoteBridgeEngine (if quote mode)
    → QuoteEstimatorEngine.estimate()
```

## Dispatcher Actions Used
- `blueprint_extract` (qualityDispatcher) — core extraction
- `blueprint_setup_sheet` (qualityDispatcher) — setup sheet generation
- `blueprint_inspection_plan` (qualityDispatcher) — inspection plan
- `blueprint_compare_revisions` (qualityDispatcher) — revision comparison
- `blueprint_dxf_dimensions` (qualityDispatcher) — DXF dimension extraction
- `blueprint_to_quote` (businessDispatcher) — drawing → instant quote
- `blueprint_resolve_material` (businessDispatcher) — material identification

## Output Format

```
BLUEPRINT ANALYSIS
==================
Part: [part_number] Rev [revision]
Material: [material] | Finish: [finish]
Drawing Size: [size] | Scale: [scale]

DIMENSIONS ([N] extracted):
  [type] [nominal] ±[tolerance] [unit] — [location_hint]
  ...

GD&T ([N] frames):
  [symbol] [tolerance] [datum_refs] — [feature_type]
  ...

NOTES:
  - [note1]
  - [note2]

MANUFACTURING ASSESSMENT:
  Complexity: [low/medium/high]
  Tight tolerances: [N] features below ±0.05mm
  Critical GD&T: [N] position/profile callouts
  Secondary ops: [list if detected]
```

## When to Use
- Customer sends a drawing and wants a quote
- Setting up a new job from a print
- Creating an inspection plan
- Comparing drawing revisions for changes
- Extracting dimensions for CNC programming

## Prerequisites
- For PDF text extraction: PyMuPDF (`pip install pymupdf`)
- For scanned drawings: Tesseract OCR (`pip install pytesseract` + Tesseract binary)
- For DXF: `blueprint_dxf_dimensions` action
