# Smart Route — Find the most token-efficient path for any query

Given the user's intent below, use ToolRouterEngine to find the best route.

## Steps
1. Import and call `toolRouterEngine.route("$ARGUMENTS")`
2. If a "direct" route is found, execute it immediately using the recommended engine
3. If a "dispatcher" route is found, call the dispatcher with the recommended action
4. Show: route taken, target engine/dispatcher, result, estimated tokens saved

## Output Format
```
ROUTE: [direct|dispatcher] → [target].[action]
TOKENS: ~[N] (saved ~[N] vs full dispatcher chain)
RESULT: [compact result]
```

If no route matches, fall back in this order:
1. `fileSystemNavigatorEngine.navigate({ topic: "$ARGUMENTS" })` — zero-IO directory routing (25 domain routes)
2. `codeSystemIndexEngine.search("$ARGUMENTS")` — shortcode lookup across 1,865 files
3. `DispatcherMapEngine.searchActions()` — find relevant dispatcher actions
4. As last resort: Grep with targeted path from navigator results
