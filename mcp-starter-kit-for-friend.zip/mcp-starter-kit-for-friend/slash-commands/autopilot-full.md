# Autopilot Full — Maximum Autonomous Development Pipeline

The ultimate PRISM development command. Assesses the entire system, identifies ALL opportunities for growth, generates new roadmap milestones, executes work, learns from every available source, forges new components, tests exhaustively, and leaves the system stronger than it found it. One command to do everything.

This is `/autopilot` + `/forge-triple` + `/learn-everything` + `/system-audit` + `/release-ready` + `/rgs` combined into a single autonomous mega-pipeline with intelligent phase ordering and cross-phase feedback loops.

## Args: $ARGUMENTS
- Empty: full autonomous cycle (all phases)
- `assess`: Phase 1-3 only — assess + plan, don't execute
- `learn`: focus on knowledge acquisition phases
- `forge`: focus on component generation phases
- `execute`: focus on roadmap execution phases
- `ship`: focus on quality + release phases
- `[topic]`: focus all phases on a specific domain (e.g., "speed-feed", "cam", "tooling")
- `no-commit`: dry run — do everything but don't commit
- `sprint=<N>`: limit to N hours of estimated work

## MASTER PROTOCOL
Every phase follows these non-negotiable rules:
1. **YOLO Mode**: Zero proceed questions, autonomous decisions, parallel operations, auto-fix errors (3 attempts). Safety rails always enforced.
2. **Build Gate**: `npm run build` must pass after every code-generating phase. Failures block forward progress until fixed.
3. **Test Gate**: `npm test` must pass with 0 regressions after every code-generating phase.
4. **Memory Protocol**: Update MEMORY.md with new counts/capabilities after significant changes.
5. **Commit Protocol**: Atomic commits per logical unit of work. Never batch unrelated changes.
6. **Thoroughness over Speed**: Missing content is a permanent loss. Never skim, skip, or dismiss.
7. **Smart Config (/smart) — EVERY PHASE**: Each phase MUST begin with a `/smart`-style config line re-evaluating role/model/effort for that phase's specific requirements:
   ```
   PHASE [N]: [Name] — Smart: [ROLE(s)] | [OPUS/SONNET/HAIKU] | [HIGH/MEDIUM/LOW]
   ```
   This is non-negotiable. Phase complexity determines model tier. Phase domain determines role(s).

## EXHAUSTIVE SCIENCE LAW — ENFORCED IN EVERY PHASE (HARD RULE)
This is not optional guidance. It is a **blocking gate enforced at every phase transition**.

### The Law
- **Exhaust ALL mathematical, statistical, and scientific possibilities** before concluding ANY analysis, implementation, gap assessment, test design, knowledge extraction, or component generation.
- Consider every applicable model, formula, algorithm, and combination — including novel cross-domain approaches.
- **"Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.** Vague claims like "we already handle this" are REJECTED.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing coverage before building or skipping anything.
- **Completeness > Speed.** A missed mathematical model is a permanent capability gap. A skipped statistical method is a competitive weakness.

### Per-Phase Enforcement Checklist
At the END of every phase, before proceeding, answer these questions:

**Phase 1 (Assessment)**:
- Did I check ALL diagnostic dimensions (build, tests, drift, wiring, quality, types, dead code)?
- Did I identify ALL broken mathematical/statistical invariants?

**Phase 2 (Gap Analysis)**:
- For EVERY formula in the 499-formula registry: is there a corresponding engine? If not, why not?
- For EVERY algorithm in the 52-algorithm registry: are there sufficient tests?
- For EVERY physics model (Kienzle, Taylor, Merchant, J-C, Loewen-Shaw, Oxley, etc.): is it tested across ALL applicable materials?
- For EVERY statistical method (Monte Carlo, Cp/Cpk, Pareto, Sobol, Bayesian, bootstrap, SPRT, PCA, Hotelling T², HMM): is it implemented AND tested?
- What cross-domain combinations are untried? (e.g., thermal + wear + economics, stability + surface finish + force)
- What ISO/ASME/DIN standards are unimplemented?
- What novel mathematical approaches from recent literature are missing?

**Phase 3 (Planning)**:
- Does the plan cover ALL identified gaps, not just the easy ones?
- Are mathematical/statistical gaps prioritized equally with feature gaps?
- Is the plan ordered to maximize scientific coverage per session?

**Phase 4 (Knowledge Acquisition)**:
- For EVERY PDF: did I extract ALL formulas, parameter tables, and empirical data?
- For EVERY knowledge item: did I check if it introduces a new mathematical model not yet in PRISM?
- Did I cross-reference extracted knowledge against ALL 31 physics models and 5 statistical methods?
- Did I check for mathematical relationships between extracted parameters (correlations, regressions, empirical fits)?
- Are there machine learning / AI models in the literature that could enhance predictions?

**Phase 5 (Forge — Component Generation)**:
- For EVERY new engine: does it implement ALL relevant physics models, not just the primary one?
- For EVERY new engine: does it include statistical uncertainty quantification?
- For EVERY new engine: does it cross-reference with related engines for consistency?
- For EVERY new algorithm: is the mathematical derivation complete with all edge cases?
- For EVERY new formula: are units verified, dimensional analysis correct, and boundary conditions defined?
- Did I consider: stochastic variants, sensitivity analysis, multi-objective optimization, Bayesian approaches, information-theoretic metrics?
- Did I check for: differential equation models, finite element approximations, empirical correlation opportunities, dimensional analysis (Buckingham Pi)?

**Phase 6 (Roadmap Execution)**:
- For EVERY unit: are ALL mathematical prerequisites satisfied?
- For EVERY implementation: is the science exhaustive or are there known gaps being deferred?
- For EVERY test: does it validate mathematical correctness, not just code execution?

**Phase 7 (Testing)**:
- For EVERY physics model: is it tested with at least 3 different materials?
- For EVERY statistical method: is it tested with known analytical solutions?
- For EVERY formula: is dimensional consistency verified?
- For EVERY engine: are boundary conditions, edge cases, and degenerate inputs tested?
- Are cross-model consistency checks in place (e.g., Merchant vs Lee-Shaffer should agree within bounds)?
- Are numerical stability tests present (very small/large inputs, near-zero denominators)?
- Are regression pins in place to prevent silent degradation?

**Phase 8 (Registration)**:
- Are ALL new mathematical models documented with provenance (paper, standard, derivation)?
- Are ALL formula variables defined with units and valid ranges?
- Is the formula registry updated for every new mathematical relationship?

**Phase 9 (Quality Gate)**:
- Final science audit: are there ANY mathematical models mentioned in engine comments/docs that lack tests?
- Final statistics audit: are there ANY statistical methods referenced but not validated?
- Final formula audit: does the formula count match what's actually implemented?

### Violation Response
If ANY phase is found to have skipped mathematical/statistical/scientific possibilities:
1. **STOP** — do not proceed to the next phase
2. **LIST** the specific models/methods/formulas that were skipped
3. **IMPLEMENT** the missing coverage before continuing
4. **LOG** the gap in the phase report as a "SCIENCE DEBT" item

---

## PHASE 0: BOOTSTRAP (30 seconds)
**Smart Config**: Role=Full-Stack Manufacturing + Systems Architect | Model=OPUS | Effort=MAXIMUM

1. `/prism-paths` → load PATH_INDEX.md (~400 tokens)
2. Read MEMORY.md for session memory
3. Read SYSTEM_INVENTORY.md for current capabilities
4. Read roadmap-index.json for milestone status
5. Output bootstrap card:
```
AUTOPILOT-FULL INITIALIZED
Mode:       [full/assess/learn/forge/execute/ship]
Focus:      [topic or "all domains"]
System:     [N] engines | [N] algorithms | [N] hooks | [N] tests
Milestones: [N]/[N] complete
Sprint:     [unlimited or N hours]
```

---

## PHASE 1: SYSTEM ASSESSMENT (2-3 min)
**Goal**: Understand exactly where the system is right now.
**Science Gate**: Identify ALL broken mathematical/statistical invariants. Check every diagnostic dimension.

Run in parallel:
1. **Health Check** (`/health`):
   - Build status, test count, dependency health
   - Flag any broken state that must be fixed first
2. **Registry Audit** (`/forge-drift quick`):
   - Engine count: code vs MASTER_INDEX
   - Algorithm count: code vs registry
   - Hook count: code vs docs
   - Flag drift for Phase 8 repair
3. **Wiring Check** (`/forge-wiring orphans`):
   - Orphan engines (exist but unwired to dispatchers)
   - Phantom actions (in schema but no engine)
   - Flag for Phase 5 repair
4. **Code Quality** (`/forge-audit quick`):
   - CRITICAL / MAJOR / MINOR findings
   - CRITICALs must be fixed before new work

Output:
```
PHASE 1: SYSTEM ASSESSMENT
Build:      [PASS/FAIL]
Tests:      [N] passing / [N] failing
Drift:      [N] mismatches
Orphans:    [N] unwired engines
Quality:    [N] CRIT / [N] MAJ / [N] MIN
Blockers:   [list or "none"]
```

**Gate**: If build fails or CRITICALs exist → fix them NOW before proceeding.

---

## PHASE 2: GAP ANALYSIS (3-5 min)
**Goal**: Identify every opportunity for system growth.
**Science Gate**: Cross-reference ALL 499 formulas, 880+ engines, 52 algorithms, 31 physics models, 5+ statistical methods. Every formula without an engine = gap. Every model without a multi-material test = gap. Every statistical method without validation = gap.

### 2A: Engine Gap Analysis
1. Read MASTER_INDEX_COMPACT.md engine inventory
2. Cross-reference against:
   - PRISM's 499 formulas → which formulas lack a dedicated engine?
   - 52 algorithms → which need companion engines?
   - Industry standards (ISO, ASME, DIN) → which are unimplemented?
   - Cross-domain synthesis → what novel combinations are possible?
3. Score each gap: impact (H/M/L) × complexity (S/M/L/XL) × novelty

### 2B: Test Gap Analysis (`/forge-tests scan`)
1. Which engines lack tests?
2. Which engines have <3 tests (insufficient coverage)?
3. Which physics models are untested?
4. Which edge cases are uncovered?

### 2C: Knowledge Gap Analysis
1. Scan `C:/PRISM/CATALOGS/` for unprocessed PDFs
2. Check learning-registry.json for unlearned sources
3. Identify manufacturer catalogs not yet extracted
4. Check tribal knowledge coverage per CAM system:
   - hyperMILL: [N] tips (target: 120+)
   - Mastercam: [N] tips (target: 120+)
   - SolidCAM: [N] tips (target: 120+)
   - Fusion 360: [N] tips (target: 120+)
   - Siemens NX: [N] tips (target: 120+)

### 2D: Skill Gap Analysis
1. Which engine capabilities lack a slash command?
2. Which common workflows require multiple commands that could be combined?
3. Which user-facing features are missing?

### 2E: Hook Gap Analysis (`/forge-safety scan`)
1. Which safety-critical operations lack hooks?
2. Which common mistakes aren't caught?
3. Which token-waste patterns aren't automated?

### 2F: Roadmap Gap Analysis
1. All milestones complete? → Need new milestones
2. Which tracks need continuation?
3. What customer-facing features are missing?

Output:
```
PHASE 2: GAP ANALYSIS
Engine gaps:      [N] (H:[N] M:[N] L:[N])
Test gaps:        [N] engines undertested
Knowledge gaps:   [N] unprocessed sources
Skill gaps:       [N] missing commands
Hook gaps:        [N] safety/efficiency opportunities
Roadmap gaps:     [N] tracks need new milestones

TOP 10 OPPORTUNITIES (ranked by impact × feasibility):
1. [description] — [type] — [impact]
...
```

---

## PHASE 3: STRATEGIC PLANNING (2-3 min)
**Goal**: Prioritize and plan the work for this session.
**Science Gate**: Plan must cover ALL identified math/stats/science gaps — not just easy ones. Mathematical gaps get equal priority with feature gaps. Order plan to maximize scientific coverage per session.

### 3A: Priority Matrix
Rank all gaps into a priority matrix:
| Priority | Criteria |
|----------|----------|
| P0-CRITICAL | Broken functionality, test failures, security issues |
| P1-HIGH | Customer-visible features, major capability gaps |
| P2-MEDIUM | Coverage improvements, test gaps, knowledge enrichment |
| P3-LOW | Polish, minor improvements, documentation |

### 3B: Session Plan
Based on sprint budget and priorities:
1. Estimate token cost per work item
2. Select work items that fit within budget
3. Order by: dependencies → priority → efficiency (batch similar work)
4. Identify parallel opportunities

### 3C: Generate Roadmap Milestones (`/rgs generate`)
For any P1+ gaps that form coherent tracks:
1. Run the 7-stage RGS pipeline
2. Generate milestone envelopes
3. Register in roadmap-index.json
4. These become available for Phase 6 execution

Output:
```
PHASE 3: SESSION PLAN
Sprint budget:   [N] items | ~[N] tokens estimated
New milestones:  [N] generated

EXECUTION ORDER:
  [1] [P0] Fix: [description]
  [2] [P1] Learn: [description]
  [3] [P1] Forge: [description]
  [4] [P2] Test: [description]
  ...
```

If args = `assess`, **STOP HERE** and present the full plan for user review.

---

## PHASE 4: KNOWLEDGE ACQUISITION (10-20 min)
**Goal**: Learn from every available unprocessed source.
**Science Gate**: Extract ALL formulas, parameter tables, empirical data from every source. Cross-reference against all 31 physics models and 5+ statistical methods. Check for new mathematical models not yet in PRISM. Identify correlations, regressions, empirical fits, and ML/AI model opportunities.

### 4A: PDF Learning (`/pdf-learn --batch`)
For each unprocessed PDF in knowledge store:
1. Ingest → classify → extract → bridge → generate components
2. Focus on: parameter tables, formulas, tribal tips, procedures
3. Auto-write components (tips → TribalKnowledgeEngine, engines → src/engines/)

### 4B: Web Learning
For knowledge gaps identified in Phase 2:
1. Search for authoritative sources (manufacturer sites, research papers)
2. Extract: cutting parameters, material data, CAM tips
3. Generate tribal tips and formulas

### 4C: Video Learning (`/video-learn --batch`)
For any queued videos in the watchlist:
1. FFmpeg → Whisper → Vision → Knowledge Fusion
2. Extract: techniques, parameters, visual knowledge

### 4D: Catalog Enrichment
For manufacturer catalogs not yet fully extracted:
1. `/tool-enrich` — new tools from unprocessed catalogs
2. `/machine-enrich` — new machine profiles
3. `/controller-enrich` — controller tips and codes

### 4E: CAM Knowledge Enrichment
For CAM systems below 120 tips:
1. Search for documentation, tutorials, best practices
2. Generate tips to close the gap toward parity with hyperMILL (117 tips)
3. Focus on: unique features, advanced strategies, post-processor quirks

**Build + Test Gate after Phase 4**

Output:
```
PHASE 4: KNOWLEDGE ACQUIRED
PDFs processed:     [N] ([N] components)
Web sources:        [N] ([N] components)
Videos processed:   [N] ([N] components)
Tools enriched:     [N] new
Machines enriched:  [N] new
Tips added:         [N] to TribalKnowledgeEngine
Build: PASS | Tests: [N] passing
Commits: [N]
```

---

## PHASE 5: FORGE — COMPONENT GENERATION (15-30 min)
**Goal**: Build every engine, algorithm, hook, skill, and formula identified in Phase 2.
**Science Gate**: Every new engine must implement ALL relevant physics models (not just the primary). Every new engine must include statistical uncertainty quantification. Every new algorithm must have complete mathematical derivation with edge cases. Consider: stochastic variants, sensitivity analysis, multi-objective optimization, Bayesian approaches, information-theoretic metrics, differential equation models, FEM approximations, empirical correlations, dimensional analysis (Buckingham Pi).

### 5A: Fix Blockers (P0)
From Phase 1 findings:
1. Fix all CRITICAL code quality issues
2. Wire orphan engines to dispatchers
3. Resolve phantom actions
4. Commit fixes

### 5B: Forge Engines (`/forge-engines`)
For each high-priority engine gap:
1. Design engine with full physics backing
2. Implement with proper types, JSDoc, error handling
3. Wire to appropriate dispatcher
4. Write tests (minimum 3 per engine)
5. Register in MASTER_INDEX

### 5C: Forge Algorithms
For identified algorithm gaps:
1. Implement with mathematical rigor
2. Include provenance (formula source, paper reference)
3. Wire and test

### 5D: Forge Hooks (`/forge-hooks`)
For safety and efficiency gaps:
1. Design hook rules (block/warn/autofire)
2. Add to appropriate hook scripts
3. Test hook behavior
4. Register

### 5E: Forge Skills (`/forge-skills`)
For missing slash commands:
1. Design skill flow
2. Create .md file in commands directory
3. Verify activation

### 5F: Forge Formulas
For physics models lacking formula registry entries:
1. Add to FORMULA_REGISTRY.json
2. Include: equation, variables, units, domain, source

**Build + Test Gate after Phase 5**

Output:
```
PHASE 5: COMPONENTS FORGED
Engines:     [N] created, [N] wired
Algorithms:  [N] created
Hooks:       [N] created/modified
Skills:      [N] created
Formulas:    [N] registered
Blockers:    [N] fixed
Build: PASS | Tests: [N] passing (+[N] new)
Commits: [N]
```

---

## PHASE 6: ROADMAP EXECUTION (15-30 min)
**Goal**: Execute pending roadmap units.
**Science Gate**: Every unit implementation must satisfy ALL mathematical prerequisites. Every implementation must be scientifically exhaustive — no known gaps deferred without explicit SCIENCE DEBT logging. Every test must validate mathematical correctness, not just code execution.

### 6A: Check for Pending Units
1. Read roadmap-index.json for incomplete milestones
2. If new milestones were generated in Phase 3, start those
3. If existing milestones have pending units, continue those

### 6B: Execute Units (`/autopilot` or `/autopilot-camk`)
For each pending unit (priority order):
1. Claim unit (atomic claim)
2. Load steps and exit conditions
3. Execute each step — **applying Exhaustive Science Law to every implementation**
4. Verify exit conditions — **including mathematical completeness check**
5. Scrutinize (`/scrutinize`) — **flag any missing physics/stats models**
6. Fix findings
7. Commit
8. Update milestone envelope

### 6C: Cross-Domain Units
For units that span multiple tracks:
1. Identify dependency chain
2. Execute in topological order
3. Verify cross-track integration
4. **Verify cross-domain mathematical consistency** (e.g., force models agree across cutting/thermal/wear domains)

**Build + Test Gate after Phase 6**

Output:
```
PHASE 6: ROADMAP EXECUTED
Units completed:    [N]/[N] attempted
Milestones:         [N] advanced ([N] completed)
Scrutiny findings:  [N] fixed
Science debt:       [N] items logged (0 = ideal)
Build: PASS | Tests: [N] passing
Commits: [N]
```

---

## PHASE 7: EXHAUSTIVE TESTING (5-10 min)
**Goal**: Prove everything works — mathematically, statistically, and scientifically.
**Science Gate**: Every physics model tested with ≥3 materials. Every statistical method tested against known analytical solutions. Every formula dimensionally verified. Every engine tested at boundary conditions, edge cases, and degenerate inputs. Cross-model consistency checks enforced. Numerical stability validated. Regression pins prevent silent degradation.

### 7A: Full Test Suite
```bash
cd /c/PRISM/mcp-server && npx vitest run
```
All tests must pass. Zero regressions.

### 7B: Speed/Feed Gauntlet (`/test-speed-feed`)
All 401 tests (76 core + 206 R1 + 119 R2):
- 31 physics models validated across multiple materials
- 15 materials covered with cross-material physics checks
- 7 operations, 7 strategies with combinatorial coverage
- 5 statistical methods validated against analytical solutions
- Mathematical invariants verified (Vc=πDn/1000, Vf=fz·z·n, force resultants)
- Performance: <50ms single, 100 in <2s

### 7C: New Component Tests — Science-First
Run tests specifically for components created in this session:
- Every new engine has ≥3 tests **including at least 1 mathematical correctness test** (known input → verified analytical output)
- Every new algorithm has ≥2 tests **including boundary condition and degenerate input tests**
- Every new formula has **dimensional analysis verification** (units in → units out)
- Every new hook has validation
- **Cross-engine consistency**: if two engines compute related quantities (e.g., force and power), verify F×v=P relationship

### 7D: Integration Verification
1. Build passes with 0 errors
2. No new `any` types introduced
3. No new TODO/FIXME in committed code
4. All new exports properly indexed
5. **No mathematical models referenced in comments/docs that lack corresponding tests**

### 7E: Science Coverage Audit
After all tests pass, audit for gaps:
1. List every physics model name mentioned in engine source → verify each has ≥1 test
2. List every statistical method mentioned → verify each has ≥1 validation test
3. List every formula in FormulaRegistry → verify each has dimensional consistency check
4. **Output SCIENCE COVERAGE score**: (tested models / total models) × 100%

Output:
```
PHASE 7: TESTING COMPLETE
Backend:          [N] passed / [N] failed
Speed/Feed:       401/401 passed ([N]ms)
New tests:        [N] added this session
Integration:      [PASS/FAIL]
Science coverage: [N]% ([N]/[N] models tested)
Math invariants:  [N] verified
```

---

## PHASE 8: REGISTRATION & DOCUMENTATION (3-5 min)
**Goal**: Update every registry, index, and document.
**Science Gate**: ALL new mathematical models documented with provenance (paper, standard, derivation). ALL formula variables defined with units and valid ranges. Formula registry updated for every new mathematical relationship. No undocumented physics.

### 8A: Matrix Registration (`/addtomatrix`)
For every new component:
1. Add engines to MASTER_INDEX_COMPACT.md — **include physics models implemented**
2. Add algorithms to algorithm registry — **include mathematical basis**
3. Add hooks to hook documentation
4. Verify wiring completeness

### 8B: Documentation Sync (`/update-all-docs`)
1. Update MASTER_INDEX_COMPACT.md with new counts
2. Update SYSTEM_INVENTORY.md
3. Update SLASH_COMMANDS.md if new commands created
4. Update PATH_INDEX.md if new paths created
5. Verify doc score maintained
6. **Update formula count if new formulas registered**

### 8C: Memory Update
Update MEMORY.md with:
- New engine/algorithm/hook counts
- New capabilities added — **specifically listing new physics models and statistical methods**
- New tribal knowledge counts
- Test count changes
- Session accomplishments
- **Science coverage percentage**

### 8D: Registry Drift Check (`/forge-drift`)
Verify all registries match code — zero drift tolerance.
**Include formula registry drift check** — code references vs registry entries.

### 8E: State Files
1. Update CURRENT_STATE.json
2. Update roadmap-index.json completion counts
3. Clean up claim files for completed units

Commit all doc/registry updates.

Output:
```
PHASE 8: REGISTERED & DOCUMENTED
MASTER_INDEX: updated ([N] new entries)
Docs updated: [N] files
Memory:       updated
Drift:        [ZERO/N mismatches]
Formulas:     [N] total ([N] new)
Commits:      [N]
```

---

## PHASE 9: QUALITY GATE (2-3 min)
**Goal**: Final verification that the system is release-ready — technically AND scientifically.
**Science Gate**: FINAL AUDIT — Are there ANY mathematical models in engine comments/docs that lack tests? ANY statistical methods referenced but not validated? Does the formula count match what's implemented? Any SCIENCE DEBT items from earlier phases still unresolved?

1. **Build**: `npm run build` — 0 errors
2. **Tests**: Full suite — 0 failures
3. **Drift**: Zero registry mismatches
4. **Types**: No new `any` types
5. **Quality**: No CRITICAL findings
6. **Docs**: All indices current
7. **Science Completeness**: ALL models tested, ALL formulas registered, ALL methods validated
8. **Science Debt**: ZERO unresolved items (or explicitly documented with justification)

If ALL pass → system is ship-ready.
If ANY fail → report what needs manual attention.
**If science debt > 0 → list each item with the specific model/method/formula and what's needed.**

---

## FINAL REPORT

```
╔══════════════════════════════════════════════════════════════╗
║              AUTOPILOT-FULL COMPLETE                         ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  SYSTEM GROWTH                                               ║
║  ─────────────                                               ║
║  Engines:      [old] → [new] (+[N])                          ║
║  Algorithms:   [old] → [new] (+[N])                          ║
║  Hooks:        [old] → [new] (+[N])                          ║
║  Tests:        [old] → [new] (+[N])                          ║
║  Formulas:     [old] → [new] (+[N])                          ║
║  Actions:      [old] → [new] (+[N])                          ║
║  Skills:       [old] → [new] (+[N])                          ║
║  Tips:         [old] → [new] (+[N])                          ║
║                                                              ║
║  KNOWLEDGE ACQUIRED                                          ║
║  ──────────────────                                          ║
║  PDFs learned:     [N]                                       ║
║  Videos learned:   [N]                                       ║
║  Tools enriched:   [N]                                       ║
║  Machines enriched:[N]                                       ║
║                                                              ║
║  ROADMAP PROGRESS                                            ║
║  ────────────────                                            ║
║  Milestones generated: [N]                                   ║
║  Units completed:      [N]                                   ║
║  Milestones completed: [N]                                   ║
║                                                              ║
║  QUALITY                                                     ║
║  ───────                                                     ║
║  Build:     PASS                                             ║
║  Tests:     [N] passing (0 failures)                         ║
║  Drift:     ZERO                                             ║
║  Findings:  [N] CRIT / [N] MAJ / [N] MIN                    ║
║                                                              ║
║  SESSION STATS                                               ║
║  ─────────────                                               ║
║  Commits:        [N]                                         ║
║  Files modified:  [N]                                        ║
║  Files created:   [N]                                        ║
║  Duration:        ~[N] min                                   ║
║                                                              ║
║  SCIENCE                                                     ║
║  ───────                                                     ║
║  Coverage:    [N]% models tested                             ║
║  Invariants:  [N] mathematical checks passed                 ║
║  Formulas:    [N] registered ([N] new)                       ║
║  Debt:        [N] items (0 = ideal)                          ║
║                                                              ║
║  VERDICT: [SHIP-READY / NEEDS-WORK]                          ║
║  Next: /autopilot-full or /release-ready                     ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
```

---

## PHASE DEPENDENCY MAP (with Science Gates)
```
Phase 0 (Bootstrap)
  ↓
Phase 1 (Assessment) ←── fix blockers before continuing
  ↓ ⚛ SCIENCE GATE: all diagnostic dimensions checked?
Phase 2 (Gap Analysis)
  ↓ ⚛ SCIENCE GATE: 499 formulas × 880+ engines cross-referenced?
Phase 3 (Planning) ←── STOP here if mode=assess
  ↓ ⚛ SCIENCE GATE: math/stats gaps prioritized equally?
Phase 4 (Learn) ──────→ feeds Phase 5 with new knowledge
  ↓ ⚛ SCIENCE GATE: all formulas extracted? new models identified?
Phase 5 (Forge) ──────→ feeds Phase 6 with new components
  ↓ ⚛ SCIENCE GATE: all relevant physics implemented? uncertainty included?
Phase 6 (Execute) ────→ uses components from Phase 5
  ↓ ⚛ SCIENCE GATE: math prerequisites met? cross-domain consistency?
Phase 7 (Test) ───────→ validates everything
  ↓ ⚛ SCIENCE GATE: all models tested ≥3 materials? invariants verified?
Phase 8 (Register) ──→ documents everything
  ↓ ⚛ SCIENCE GATE: all models documented with provenance? formulas registered?
Phase 9 (Quality Gate) → final verdict
  ⚛ FINAL SCIENCE AUDIT: zero debt? 100% coverage? all methods validated?
```

## CROSS-PHASE FEEDBACK LOOPS
- Phase 4 (Learn) discoveries → feed Phase 5 (Forge) with new engine ideas
- Phase 5 (Forge) new engines → become available for Phase 6 (Execute) roadmap units
- Phase 6 (Execute) findings → may trigger Phase 5 (Forge) for missing components
- Phase 7 (Test) failures → loop back to Phase 5 (Forge) to fix
- Phase 8 (Register) drift → loop back to fix mismatches

## CONTEXT MANAGEMENT
- If context window exceeds 70% → run `/compact` and save state
- If context exceeds 85% → save progress, commit, report remaining work
- Save PHASE_STATE.json after each phase for recovery via `resume`
- Each phase outputs a compact summary (not raw tool output)

## ERROR HANDLING
- **Build failure**: Stop. Fix. Re-run build. If 3 attempts fail → revert and skip.
- **Test regression**: Fix regression. Re-run from Phase 7.
- **Claim conflict**: Skip unit, pick next available.
- **Context exhaustion**: Commit what's done, save state, report remaining.
- **Network failure**: Skip web/video learning, proceed with local sources.
- **Phase timeout**: Complete current item, skip to next phase.

## SAFETY RAILS (always enforced)
- Never skip build/test gates
- Never commit secrets or API keys
- Never force-push
- Never bypass safety hooks S(x)
- Never create stubs or placeholder implementations
- Never overwrite existing files without reading first
- All generated code includes provenance
- All hooks default to mode: "warning" (never "blocking" from auto-generation)

## ENGINES & TOOLS UTILIZED
**Assessment**: SystemSnapshotEngine, ContextIntegrityEngine, WasteDetectorEngine
**Learning**: VideoLearningEngine, DocumentLearningDispatcher, ToolCatalogEngine, MaterialDatabaseEngine
**Forging**: All 880+ engines as reference, FormulaRegistry, ToolpathStrategyRegistry
**Testing**: UltimateSpeedFeedEngine (31 models), all test infrastructure
**Registration**: MASTER_INDEX, SYSTEM_INVENTORY, all registries
**Quality**: GCodeSafetyAnalyzerEngine, ProcessCapabilityEngine, StatisticalProcessMonitoringEngine

## SKILLS CHAINED
`/prism-paths` → `/health` → `/forge-drift` → `/forge-wiring` → `/forge-audit` →
`/forge-tests scan` → `/forge-safety scan` → `/rgs` → `/pdf-learn` → `/video-learn` →
`/tool-enrich` → `/machine-enrich` → `/controller-enrich` → `/forge-engines` →
`/forge-hooks` → `/forge-skills` → `/autopilot` → `/autopilot-camk` → `/test` →
`/test-speed-feed` → `/scrutinize` → `/addtomatrix` → `/update-all-docs` →
`/forge-drift` → `/release-ready`

## HOOKS LEVERAGED
- pretooluse-unified: file routing, safety guards, dedup, output capping
- posttooluse-unified: syntax checks, compression, anti-regression
- auto-approve: read-only tools, safe writes, agent delegation
- stop-completion-check: ensure no incomplete work left behind
- task-completed-chain: post-completion registration cascade

## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
