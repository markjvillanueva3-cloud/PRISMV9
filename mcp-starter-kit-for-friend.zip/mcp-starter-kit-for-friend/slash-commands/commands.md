# List All Available Slash Commands

You are listing all slash commands available in this environment. Scan both user-level and project-level command directories, then present them in an organized table.

## Directories to Scan
1. `C:\Users\Admin.DIGITALSTORM-PC\.claude\commands\` — User-level (always available)
2. `C:\PRISM\.claude\commands\` — PRISM project-level (available in PRISM context)

## How to Present

### User-Level Commands (Always Available)
Read each `.md` file in the user commands directory. Extract the first heading or first meaningful line as the description. Present as:

| Command | Description |
|---------|-------------|
| `/smart` | Intelligent auto-configuration with model/effort selection |
| `/pick-task` | Claim a task from the PRISM RGS roadmap |
| `/audit-task` | Audit, fix, and enhance completed milestones |
| `/commands` | This command — list all available commands |
| `/startup` | Session initialization macro |
| `/ship` | End-of-unit completion checklist |
| `/health` | Quick system health check |
| `/sync` | Synchronize system state and fix drift |

### PRISM Project Commands
Group by subdirectory. For each subdirectory, list the commands with brief descriptions extracted from file headings:

- **analysis/** — Performance reports, bottleneck detection, token efficiency
- **automation/** — Auto-agents, self-healing, session memory, smart spawn
- **github/** — PR management, code review, issue tracking, release management
- **hooks/** — Hook setup, pre/post task hooks, session hooks
- **monitoring/** — Agent metrics, swarm monitoring, real-time views
- **optimization/** — Cache management, parallel execution, topology
- **sparc/** — Full SPARC methodology commands (architect, coder, debugger, etc.)
- **Root** — scrutinize, continue-roadmap, generate-roadmap, smart

### Also Mention Available Skills (Plugin-Based)
List the skills that appear in the skill registry (these trigger automatically but can also be invoked with `/skill-name`):
- `/hookify` — Create hook rules from conversation analysis
- `/hookify:list` — List all hookify rules
- `/simplify` — Review changed code for quality
- `/skill-creator` — Create or improve skills
- And any others detected in the session

## Footer
```
Tip: Type "/" in the terminal to see autocomplete suggestions.
User commands: ~/.claude/commands/ (always loaded)
PRISM commands: C:\PRISM\.claude\commands\ (project context)
```
