# System Audit — Complete PRISM System Health Check

Full system verification: build status, code quality, registry drift, wiring validation, type coverage, dead code scan, and metrics dashboard. Run before releases or after major changes.

## Args:
- Empty: full audit (all phases)
- `quick`: build + test + drift only
- `pre-release`: full audit + doc sync + test gauntlet

## Phase 1: Build & Test Status
1. `/health` — full system health check
   - `npm run build` — TypeScript compilation (0 errors required)
   - `npm test` — full test suite (0 failures required)
   - Test count verification against expected
   - Build artifact size check

## Phase 2: Code Quality Scan
1. `/forge-audit` — codebase quality scan
   - TODO/FIXME/HACK markers
   - Placeholder implementations
   - `any` type usage
   - Magic numbers
   - Missing error handling
   - Dead imports
   - Classify: CRITICAL / MAJOR / MINOR

## Phase 3: Registry Drift Detection
1. `/forge-drift` — verify registries match code
   - Engine count in MASTER_INDEX vs actual files
   - Algorithm count vs registry
   - Hook count vs hook scripts
   - Formula count vs JSON files
   - Dispatcher action count vs schema files
   - Flag any mismatches

## Phase 4: Wiring Validation
1. `/forge-wiring` — architecture wiring check
   - Every engine wired to at least one dispatcher
   - No orphan engines (exist but unwired)
   - No phantom actions (in schema but no engine)
   - Dispatcher→engine→action chain integrity

## Phase 5: Type Coverage
1. `/forge-types` — TypeScript type analysis
   - `any` type count and locations
   - Missing return type annotations
   - Untyped function parameters
   - Generic type usage opportunities

## Phase 6: Dead Code Detection
1. `/forge-cleanup` — unused code scan
   - Unreferenced exports
   - Unused imports
   - Dead files (not imported anywhere)
   - Commented-out code blocks
   - Obsolete test files

## Phase 7: Metrics Dashboard
1. `/counts` — live system metrics
   - Engine count, algorithm count, hook count
   - Test count, formula count, action count
   - Material count, tool count, machine count
   - Lines of code, file count

## Output Summary
```
SYSTEM AUDIT COMPLETE
======================
Build:     [PASS/FAIL] ([N] errors)
Tests:     [N] passing / [N] failing / [N] total
Duration:  [N]ms

Code Quality:
  CRITICAL: [N]  |  MAJOR: [N]  |  MINOR: [N]

Registry Drift:
  Engines:     [code] vs [index] — [MATCH/DRIFT]
  Algorithms:  [code] vs [index] — [MATCH/DRIFT]
  Hooks:       [code] vs [index] — [MATCH/DRIFT]
  Formulas:    [code] vs [index] — [MATCH/DRIFT]
  Actions:     [code] vs [schema] — [MATCH/DRIFT]

Wiring:
  Orphan engines:    [N]
  Phantom actions:   [N]
  Broken chains:     [N]

Types:
  `any` count:       [N]
  Missing returns:   [N]
  Coverage:          [N]%

Dead Code:
  Unused exports:    [N]
  Dead files:        [N]
  Dead imports:      [N]

SYSTEM METRICS:
  Engines: [N] | Algorithms: [N] | Hooks: [N]
  Tests: [N]   | Formulas: [N]   | Actions: [N]
  Materials: [N] | Tools: [N]    | Machines: [N]

VERDICT: [SHIP-READY / NEEDS-WORK / BLOCKED]
  [list of blocking issues if any]
```

## Key Engines Used
All diagnostic engines — no manufacturing engines needed.
Build system, test runner, registry validators, type checker.
