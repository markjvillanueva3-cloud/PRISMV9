# Forge Schema — JSON Schema Validator & Generator

You are running a specialized autopilot pipeline that validates JSON files against their schemas, detects schema violations, and optionally generates missing schemas for PRISM's configuration and registry files. Designed to run in the **background**.

## Args: $ARGUMENTS
- Empty: full scan — validate all JSON files, find unschema'd files
- `registries`: only validate registry JSON files
- `milestones`: only validate milestone envelope files
- `config`: only validate config/settings files
- `state`: only validate state/checkpoint files
- `generate`: generate missing schemas (non-background)
- `quick`: count violations only

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL schema validation possibilities** — every field, constraint, and relationship.
- Check every action schema for completeness against its engine's actual parameter requirements.
- "Schema complete" claims REQUIRE citing specific field coverage.
- **Completeness > Speed.** A missing schema field means silent data loss.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (schema design requires domain knowledge)
2. Domain: Data Modeling + Configuration Management
3. Roles: Data Schema Architect + Configuration Engineer
4. Model: SONNET (validation) / OPUS (generation — schema design needs reasoning)
5. Effort: MEDIUM

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Schema Inventory

### 3A: Catalog JSON Files
Glob all JSON files in PRISM:
- `C:/PRISM/registries/*.json` — registry files
- `C:/PRISM/mcp-server/data/milestones/*.json` — milestone envelopes
- `C:/PRISM/mcp-server/data/*.json` — roadmap index, other data
- `C:/PRISM/config/*.json` — configuration files
- `C:/PRISM/state/*.json` — state files
- `C:/PRISM/schemas/*.json` — existing schema definitions
- `C:/PRISM/*.json` — root-level JSON files

### 3B: Existing Schema Check
For each JSON file category:
1. Does a schema exist in `C:/PRISM/schemas/`?
2. If yes: validate all files of that type against the schema
3. If no: analyze file structure and flag as UNSCHEMA'D

### 3C: Structure Validation
For files without formal schemas, do structural checks:

**Registries:**
- Each entry has required fields (name, type/category, path/file)
- No duplicate entries (by name or by path)
- Referenced files actually exist on disk
- Consistent field naming across entries

**Milestone Envelopes:**
- Required fields: id, title, status, units, track
- Unit entries have: id, title, status, steps
- Status values are valid (pending, active, complete, blocked)
- IDs follow naming convention (TRACK-MSn)

**Roadmap Index:**
- Version field present and valid semver
- All milestone IDs in index exist as envelope files
- Completed counts match unit statuses in envelopes
- No orphaned milestones

**Config Files:**
- Valid JSON (no trailing commas, correct quoting)
- No sensitive data (API keys, passwords, tokens)
- Paths reference existing files/directories
- No duplicate keys

### 3D: Cross-File Consistency
Check inter-file references:
1. Registry entries reference valid source files
2. Milestone IDs are unique across all envelopes
3. Roadmap index entries match envelope files
4. Config paths point to real files

## Phase 4: Schema Report

```
FORGE SCHEMA REPORT
====================
JSON files:   [N] scanned
With schema:  [M] validated against schema
No schema:    [X] files need schemas

VALIDATION RESULTS:
  PASS:       [N] files
  FAIL:       [M] files
    - [file]: [violation description]
    ...

STRUCTURAL ISSUES:
  Missing fields:     [N] instances
    - [file]: missing [field]
  Duplicate entries:  [N]
    - [file]: duplicate [key]
  Broken references:  [N]
    - [file]: references [path] — not found
  Invalid values:     [N]
    - [file]: [field] = [value] — expected [valid values]

CROSS-FILE:
  Orphaned envelopes: [N]
  Missing envelopes:  [N]
  ID conflicts:       [N]

SCHEMA COVERAGE: [X]% of JSON file types have schemas
INTEGRITY SCORE: [N]/100
```

## Phase 5: Generate Mode (only if args include `generate`)
For each unschema'd file category:
1. Analyze 3+ sample files to infer structure
2. Design JSON Schema (draft-07) covering all observed fields
3. Mark required vs optional fields
4. Add enum constraints for known value sets
5. Write schema to `C:/PRISM/schemas/[category]-schema.json`
6. Validate all files against the new schema

## Phase 6: Forge Postflight (`/forge-postflight schema`)
1. **Gate 1 — DSL**: SKIP
2. **Gate 2 — Matrix**: CONDITIONAL — if new schemas created, register
3. **Gate 3 — Trace**: SKIP
4. **Gate 4 — Sync**: RUN — verify file counts
5. **Gate 5 — Memory**: RUN — update MEMORY.md with schema coverage
6. **Gate 6 — Hookify**: SKIP

## Phase 7: Auto-Commit (generate mode only)
`feat(schema): add [N] JSON schemas for [categories] [FORGE-SCHEMA]`

## Summary Report
```
FORGE SCHEMA COMPLETE
=====================
Scanned:     [N] JSON files
Validated:   [M] against schemas
Violations:  [X] found
Generated:   [N] schemas (or "report only")
Coverage:    [Y]% file types have schemas
Integrity:   [score]/100
Next:        /forge-schema generate for missing schemas
```

## Error Handling
- **Malformed JSON**: Report parse error location, don't attempt schema validation
- **No sample files**: Can't generate schema for empty categories
- **Schema too strict**: If >50% of files fail, schema is probably wrong — widen constraints

## Safety Rails
- READ-ONLY by default — never modify JSON data files
- Generated schemas should be permissive enough to pass all existing valid files
- Never delete or modify milestone envelopes
- Never modify registry entries — only report violations
- Schema generation uses existing files as ground truth
