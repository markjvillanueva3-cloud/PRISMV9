# Forge MCP Wire — Full MCP Server Integration Wiring Pipeline

You are running an exhaustive integration wiring pipeline across the entire PRISM MCP server. This command audits, maps, and wires every dispatcher, engine, algorithm, hook, schema, and action — ensuring 100% of the system's capabilities are exposed through MCP tools with proper validation, hooks, and safety coverage.

## Args: $ARGUMENTS
- Empty: full pipeline — audit → map → wire → test → register (all dispatchers)
- `audit`: Phase 1-2 only — produce wiring integrity report without modifications
- `[dispatcher]`: focus on a specific dispatcher (e.g., `calcDispatcher`, `pfpDispatcher`)
- `stubs`: wire all 0-action stub dispatchers only
- `f-features`: wire F1-F8 feature suite only
- `schemas`: audit and regenerate action schemas from engine types
- `engines [batch]`: wire unwired engines in batches of 20 (e.g., `engines 1`, `engines 2`)
- `quick`: count-level gap report only

## EXHAUSTIVE WIRING LAW (HARD RULE)
- **Every engine MUST be reachable via at least one dispatcher action.**
- **Every dispatcher action MUST call at least one engine method.**
- **Every action MUST have a validated Zod schema in its ACTION_*_SCHEMAS.**
- **Every safety-critical action MUST be covered by pre/post-calculation hooks.**
- "Fully wired" claims REQUIRE citing: dispatcher file, action name, engine import, schema file.
- Completeness > Speed. An unwired engine is a dead capability. A missing schema is a runtime crash.

## Phase 0: Bootstrap
1. Load system map via `/digest-all` (~1100 tokens)
2. Read MEMORY.md for current wiring state
3. Read `C:/PRISM/mcp-server/data/docs/DISPATCHER_DIGEST.md` for dispatcher inventory
4. Read `C:/PRISM/mcp-server/data/docs/ENGINE_DIGEST.md` for engine inventory

Output bootstrap card:
```
FORGE MCP-WIRE INITIALIZED
===========================
Mode:         [full/audit/stubs/f-features/schemas/engines]
Dispatchers:  [N] total ([N] wired, [N] stubs)
Engines:      [N] total ([N] wired, [N] unwired)
Actions:      [N] total
Schemas:      [N] files
Target:       100% engine wiring, 100% schema coverage
```

## Phase 1: Full MCP Wiring Audit

### 1A: Dispatcher Inventory
Scan `C:/PRISM/mcp-server/src/tools/dispatchers/`:
- Glob all `*Dispatcher.ts` / `*dispatcher.ts`
- For each: count switch cases (actions), count engine imports, count schema validations
- Classify: FULL (>10 actions), PARTIAL (1-10 actions), STUB (0 actions), MISSING (no file)

### 1B: Engine-to-Dispatcher Map
For every engine in `C:/PRISM/mcp-server/src/engines/`:
- Grep for engine name across all dispatcher files
- Record: which dispatcher(s) import it, which action(s) call it
- Flag ORPHAN if no dispatcher imports it
- Flag PARTIAL if imported but not all public methods are exposed

### 1C: Schema Completeness Audit
For every dispatcher with actions:
- Read its `ACTION_*_SCHEMAS` object from `src/schemas/`
- Compare action list (switch cases) vs schema keys
- Flag MISSING_SCHEMA for actions without validation
- Flag DRIFT for schemas that don't match engine input types

### 1D: Hook Coverage Audit
For every dispatcher registered in `src/index.ts`:
- Verify it's wrapped by the universal auto-hook proxy (lines 373-407)
- For calc-category dispatchers: verify Λ(x)/Φ(x) safety validation
- Check pre/post-calculation hook chains exist
- Flag UNHOOKED for any dispatcher bypassing the proxy

### 1E: F-Feature Exposure Audit
Check each F1-F8 feature against its dispatcher:
| Feature | Dispatcher | Expected Actions | Current |
|---------|------------|-----------------|---------|
| F1 PFP | pfpDispatcher | predict_failure, risk_score, maintenance_schedule, anomaly_detect, health_index, trend_analyze | 0 |
| F2 Memory | memoryDispatcher | store_context, recall_context, graph_query, session_link, knowledge_map, prune_stale | 0 |
| F3 Telemetry | telemetryDispatcher | log_event, query_metrics, usage_report, performance_trace, cost_track, alert_config, export | 0 |
| F4 NL Hooks | nlHookDispatcher | (already 8 actions) | 8 |
| F5 Multi-Tenant | tenantDispatcher | create_tenant, switch_tenant, config_tenant, quota_check, isolate_data | 0 |
| F6 Bridge | bridgeDispatcher | cross_dispatch, map_action, sync_state, translate_params, chain_tools | 0 |
| F7 Compliance | complianceDispatcher | check_standard, audit_trail, cert_verify, deviation_report, iso_validate, regulatory_scan | 0 |
| F8 (reserved) | — | — | — |

### 1F: Registration Audit
Verify every dispatcher is:
1. Imported in `src/index.ts`
2. Called via `register*Dispatcher(server)` within the proxy-wrapped section
3. Listed in DISPATCHER_DIGEST.md with correct action count
4. Has a corresponding schema file in `src/schemas/`

Output:
```
PHASE 1: MCP WIRING AUDIT
===========================
Dispatchers:  [N] FULL / [N] PARTIAL / [N] STUB / [N] MISSING
Engines:      [N] wired / [N] orphaned / [N] partial
Schemas:      [N] complete / [N] missing / [N] drifted
Hooks:        [N] covered / [N] unhooked
F-Features:   [N]/8 exposed ([N] actions total)
Registration: [N]/[N] properly registered

TOP GAPS:
  1. [dispatcher] — [N] engines importable, [N] actions missing
  2. [engine] — exported [N] methods, [N] unwired
  ...
```

## Phase 2: Wiring Plan Generation

### 2A: Priority Matrix
Rank all gaps by impact:
| Priority | Criteria |
|----------|----------|
| P0 | Broken wiring (import exists but action fails) |
| P1 | F-Feature stubs (F1-F8 with 0 actions — user-visible gaps) |
| P2 | High-value orphan engines (>5 public methods, physics-backed) |
| P3 | Schema gaps (actions without validation — runtime crash risk) |
| P4 | Partial wiring (engine imported but only 1-2 methods exposed) |
| P5 | Minor gaps (utility engines, internal-only engines) |

### 2B: Batch Plan
Group wiring work into executable batches:
- **Batch S**: Stub dispatchers (wire 0→N actions for each stub)
- **Batch F**: F-Features (wire F1-F8 engines to their dispatchers)
- **Batch E1-EN**: Engine batches (20 engines per batch, grouped by domain)
- **Batch V**: Schema validation (generate missing schemas)
- **Batch H**: Hook gaps (add missing hook coverage)

For each batch, estimate:
- Files to modify
- Actions to add
- Tests to write
- Approximate LOC

Output batch plan for user approval before executing.

## Phase 3: Execute Wiring

### 3A: Wire Stub Dispatchers
For each 0-action dispatcher:
1. Read the dispatcher file to understand its domain
2. Find engines in that domain (grep for related imports in the dispatcher or nearby engines)
3. For each engine:
   a. Read engine file → extract public methods with their parameter types
   b. Create action name following convention: `domain_verb_noun` (e.g., `pfp_predict_failure`)
   c. Add lazy-load `getEngine()` case
   d. Add `switch` case calling engine method
   e. Create Zod schema in `src/schemas/<Dispatcher>ActionSchemas.ts`
4. Update action count in dispatcher's `ACTIONS` array/enum
5. Build + verify

### 3B: Wire Orphan Engines
For each orphan engine (no dispatcher import):
1. Classify engine domain → select target dispatcher
2. Read engine → extract public methods
3. Add imports + getEngine() + switch cases to target dispatcher
4. Create schemas if missing
5. If no suitable dispatcher exists → create new dispatcher following pattern:
   ```typescript
   // Lazy-loaded engines
   let _engineName: any;
   async function getEngine(name: string): Promise<any> { ... }

   export function registerNewDispatcher(server: any): void {
     server.tool("prism_domain", "description",
       { action: z.enum(ACTIONS), params: z.record(z.any()) },
       async ({ action, params }) => { ... }
     );
   }
   ```
6. Register new dispatcher in `src/index.ts` within proxy section

### 3C: Wire F-Feature Actions
For each F1-F8 feature with 0 actions:
1. Find the feature's engine(s) — check `src/engines/` and `synergyIntegration.ts`
2. Design 5-8 actions per feature covering full API surface
3. Implement switch cases with proper engine delegation
4. Create comprehensive Zod schemas
5. Ensure hook coverage (F1 PFP especially needs safety hooks)

### 3D: Schema Generation
For each action missing a schema:
1. Read the engine method signature
2. Generate Zod schema matching input parameters
3. Include: required fields, optional fields with defaults, enums for constrained values
4. Add to appropriate `src/schemas/*ActionSchemas.ts`
5. Verify validation works by checking dispatcher's `validateActionParams()` call

### 3E: Hook Wiring
For each unhooked dispatcher:
1. Verify it's inside the proxy-wrapped section in `src/index.ts`
2. If calc-category → add to `AUTO_HOOK_CONFIG.calcTools`
3. For safety-critical domains → add specific pre-calculation hooks
4. Verify hook chain works

**Build + Test Gate after each batch**

## Phase 4: Verification

### 4A: Build Gate
```bash
cd /c/PRISM/mcp-server && npm run build
```
Must: 0 errors, 0 new `any` types.

### 4B: Wiring Integrity
Re-run Phase 1 audit in quick mode:
- All stubs resolved? (0 remaining)
- All orphan engines wired? (0 remaining)
- All schemas present? (0 missing)
- All hooks active? (0 gaps)

### 4C: Action Count Verification
Cross-check totals:
- Sum all dispatcher action counts
- Compare against known total in MEMORY.md
- Verify DISPATCHER_DIGEST.md matches code

### 4D: Test Validation
```bash
cd /c/PRISM/mcp-server && npx vitest run --reporter=verbose 2>&1 | tail -20
```
- 0 regressions
- New actions should have at least smoke tests

## Phase 5: Registration & Documentation

### 5A: Update DISPATCHER_DIGEST.md
For every modified dispatcher:
- Update action count
- Add new action names to the listing

### 5B: Update SYSTEM_INVENTORY.md
- New total action count
- New total wired engine count
- F-Feature coverage update

### 5C: Update MEMORY.md
- New dispatcher/action/engine counts
- F-Feature status
- Wiring coverage percentage

### 5D: Commit
Atomic commits per logical batch:
- `feat(wiring): wire [N] engines to [dispatcher] — [N] new actions [FORGE-MCP-WIRE]`
- `feat(f-features): implement F1 PFP dispatcher with [N] actions [FORGE-MCP-WIRE]`
- `fix(schemas): add missing validation for [N] actions [FORGE-MCP-WIRE]`

## Final Report
```
FORGE MCP-WIRE COMPLETE
========================
BEFORE → AFTER
Dispatchers:  [N] wired → [N] wired (+[N])
Actions:      [N] → [N] (+[N])
Engines:      [N] wired → [N] wired (+[N])
Orphans:      [N] → [N] (-[N])
F-Features:   [N]/8 → [N]/8 (+[N])
Schemas:      [N]% → [N]% coverage
Hooks:        [N]% → [N]% coverage

Build:     PASS
Tests:     [N] passing (+[N] new)
Commits:   [N]

Remaining: [list or "ZERO — 100% wired"]
Next:      /forge-wiring quick (verify) or /forge-app-wire (UI layer)
```

## Safety Rails
- READ-ONLY in `audit` mode — never modify source code
- Never remove engine files — only add wiring
- Never modify existing action behavior — only add new actions
- New actions default to `mode: "warning"` for hooks
- All new schemas must be tested against at least one valid input
- Build + test gate after every batch (never skip)
- Never bypass the auto-hook proxy — all new dispatchers go inside the wrapped section

## Context Management
- If context > 70% → `/compact quick`, save batch progress
- Process engines in batches of 20 to control context
- Use DSL shortcodes in all output (E####, D##, A##, T####)

## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`.

## Skills Chained
`/digest-all` → `/forge-wiring orphans` → `/action-search` → `/forge-engines` →
`/forge-schema` → `/forge-safety scan` → `/test` → `/forge-drift` →
`/addtomatrix` → `/update-all-docs`

## Error Handling
- **Import resolution failure**: Log engine name, skip, continue
- **Schema generation failure**: Create minimal z.record(z.any()) placeholder, flag for manual review
- **Build failure**: Revert last batch, diagnose, fix, retry (max 3)
- **Context exhaustion**: Commit completed batches, save state, report remaining
