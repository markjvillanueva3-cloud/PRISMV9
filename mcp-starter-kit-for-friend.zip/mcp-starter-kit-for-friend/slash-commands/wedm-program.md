---
name: wedm-program
description: Complete Wire EDM program generation from drawing to G-code
version: 1.0.0
engines:
  - WEDMCompleteOrchestrationEngine
  - EDMDrawingInterpretationEngine
  - EDMFeasibilityEngine
  - EDMMaterialMachineWireEngine
  - EDMToolpathStrategyEngine
  - EDMPostProcessGCodeEngine
actions:
  - wedm_parse_geometry
  - wedm_interpret_drawing
  - wedm_assess_feasibility
  - wedm_select_machine
  - wedm_select_wire
  - wedm_generate_toolpath
  - wedm_plan_passes
  - wedm_optimize_params
  - wedm_generate_gcode
  - wedm_generate_setup_sheet
  - wedm_verify_quality
  - wedm_full_documentation
hooks:
  - hook_wedm_gcode_injection
  - hook_wedm_ecode_consistency
  - hook_wedm_taper_limits
triggers:
  - "wire edm program"
  - "wedm program"
  - "generate wire edm"
  - "edm from drawing"
---

# /wedm-program — Complete Wire EDM Program Generation

Generate a complete Wire EDM program from drawing to G-code, including:
- Geometry parsing and feature recognition
- Feasibility assessment
- Machine and wire selection
- Toolpath generation with optimized sequencing
- Multi-pass planning (rough → skim)
- G-code generation for target controller
- Setup sheet and documentation

## Usage

```
/wedm-program <drawing_path> [options]
```

## Arguments

- `drawing_path` — Path to DXF, STEP, or image file
- `--controller` — Target controller (mitsubishi|fanuc|sodick|makino|agie|custom)
- `--material` — Workpiece material (default: auto-detect or prompt)
- `--thickness` — Workpiece thickness in mm
- `--ra-target` — Target surface finish Ra in µm (default: 0.8)
- `--tolerance` — Dimensional tolerance in mm (default: ±0.01)
- `--customer` — JM Die customer name for pattern matching
- `--dry-run` — Show plan without generating files

## Workflow

1. **Parse Geometry** → `wedm_parse_geometry` + `wedm_interpret_drawing`
2. **Assess Feasibility** → `wedm_assess_feasibility` (blocks if not feasible)
3. **Select Machine/Wire** → `wedm_select_machine` + `wedm_select_wire`
4. **Generate Toolpath** → `wedm_generate_toolpath` + `wedm_plan_passes`
5. **Optimize Parameters** → `wedm_optimize_params` (Klocke Ra, Kunieda MRR)
6. **Generate G-code** → `wedm_generate_gcode` (controller-specific)
7. **Create Documentation** → `wedm_generate_setup_sheet` + `wedm_full_documentation`
8. **Quality Gate** → `wedm_verify_quality`

## Examples

```bash
# Basic usage
/wedm-program H:/PRISM/JM\ DIE/drawings/part-123.dxf

# Specify controller and material
/wedm-program part.step --controller mitsubishi --material D2 --thickness 25

# JM Die customer with pattern matching
/wedm-program punch.dxf --customer ALCOA --ra-target 0.4

# Dry run to see plan
/wedm-program complex-die.dxf --dry-run
```

## Output

- `<part>_<controller>.NC` — G-code file
- `<part>_setup.pdf` — Setup sheet with parameters
- `<part>_report.json` — Full analysis report

## Safety Hooks

- `hook_wedm_gcode_injection` — Blocks malicious G-code patterns
- `hook_wedm_ecode_consistency` — Validates E-code matches machine
- `hook_wedm_taper_limits` — Validates UV angles within machine limits

## Leverages

- 119 WEDM engines in PRISM
- 256 WEDM dispatcher actions
- 107 tribal tips from wedm-knowledge-tips.ts
- 2,500+ JM Die WEDM programs for pattern matching
