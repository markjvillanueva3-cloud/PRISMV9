---
name: wedm-feasibility
description: Wire EDM feasibility assessment for parts and features
version: 1.0.0
engines:
  - EDMFeasibilityEngine
  - EDMDrawingInterpretationEngine
  - EDMMaterialMachineWireEngine
  - WEDMCalculatorAIEngine
actions:
  - wedm_parse_geometry
  - wedm_assess_feasibility
  - wedm_check_conductivity
  - wedm_estimate_time
hooks:
  - hook_wedm_ood_detector
triggers:
  - "wedm feasibility"
  - "can we wire edm"
  - "edm this part"
  - "is this feasible"
---

# /wedm-feasibility — Wire EDM Feasibility Assessment

Assess whether a part can be Wire EDM machined, including:
- Electrical conductivity check
- Geometry accessibility analysis
- Minimum feature size validation
- Thickness/taper capability
- Time and cost estimate

## Usage

```
/wedm-feasibility <input> [options]
```

## Arguments

- `input` — Drawing path, material name, or part description
- `--material` — Override material (default: auto-detect)
- `--thickness` — Workpiece thickness in mm
- `--min-radius` — Minimum internal radius in mm
- `--taper` — Maximum taper angle in degrees
- `--detail` — Show detailed analysis

## Workflow

1. **Parse Input** → Geometry from file or description
2. **Check Conductivity** → `wedm_check_conductivity` (blocks non-conductive)
3. **Analyze Geometry** → Feature extraction, accessibility
4. **Assess Feasibility** → `wedm_assess_feasibility`
5. **Estimate Time/Cost** → `wedm_estimate_time`

## Feasibility Criteria

| Criterion | Requirement | Check |
|-----------|-------------|-------|
| Conductivity | >1 S/m | Material database |
| Min corner radius | >wire_dia/2 + 0.02mm | Geometry analysis |
| Thickness | ≤machine_max (typically 400mm) | Machine capability |
| Taper angle | ≤machine_UV (typically ±30°) | UV travel check |
| Start holes | Accessible | Path planning |

## Output

```json
{
  "feasible": true,
  "confidence": 0.92,
  "warnings": ["Tight corner at feature F3 - recommend 0.15mm radius"],
  "estimated_time_min": 45,
  "estimated_cost_usd": 125,
  "recommended_machine": "Mitsubishi FA-20S",
  "recommended_wire": "Brass 0.25mm"
}
```

## Examples

```bash
# Check a drawing
/wedm-feasibility part.dxf

# Check material conductivity
/wedm-feasibility --material "tungsten carbide 10% Co"

# Detailed analysis
/wedm-feasibility complex.step --thickness 50 --detail

# Quick check with description
/wedm-feasibility "D2 punch, 1 inch thick, 0.5mm internal corners"
```

## Blocking Conditions

- Non-conductive material (ceramics, plastics without metallization)
- Features smaller than minimum wire capability
- Thickness exceeds machine capacity
- No accessible start hole location

## Leverages

- `EDMFeasibilityEngine` (938 LOC) — Core feasibility logic
- `EDMMaterialMachineWireEngine` (1,753 LOC) — Material/machine matching
- Conductivity database for 6,372 materials
