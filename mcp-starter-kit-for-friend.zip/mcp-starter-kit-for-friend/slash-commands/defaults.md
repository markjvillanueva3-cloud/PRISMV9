# Defaults — Smart machining parameter defaults

Get instant recommended starting parameters for any material + tool combination.

## Usage
- `/defaults 6061 0.5"` — defaults for 6061 aluminum, 0.5" end mill
- `/defaults titanium 0.25" 4fl finishing` — titanium finishing with 4-flute
- `/defaults steel 0.375" hss` — steel with HSS tooling

## Steps
1. Parse $ARGUMENTS for: material, tool diameter, flutes (default 3), tool material (default carbide), operation
2. Call smartDefaultsEngine.getDefaults(material, diameter, flutes, toolMaterial, operation)
3. Also call smartDefaultsEngine.oneLiner() for compact format
4. Display RPM, feed, DOC, WOC, coolant recommendation
