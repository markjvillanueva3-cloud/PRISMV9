# G-Code — Quick G-code snippet generator

Generate common G-code snippets with parameter fill-in.

## Usage
- `/gcode list` — show all available snippets
- `/gcode tool_change tool_number=5 rpm=8000` — generate tool change
- `/gcode drill_peck x=1.0 y=2.0 depth=-0.75 peck_depth=0.1 retract=0.1 clearance=1.0 feed=5 tool_number=3`
- `/gcode search drill` — find drill-related snippets

## Steps
1. If "list" → call gCodeSnippetEngine.list()
2. If "search" → call gCodeSnippetEngine.search(query)
3. Otherwise parse snippet ID and params from $ARGUMENTS
4. Call gCodeSnippetEngine.fill(id, params)
5. Display the generated G-code
