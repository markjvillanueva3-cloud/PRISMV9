# Forge Learn — Continuous Learning Pipeline Orchestrator

You are running a meta-pipeline that chains learning engines with forge engines to create a closed-loop continuous improvement system. This connects the **ingestion** layer (video-learn, pdf-learn) with the **creation** layer (forge-engines, forge-skills, forge-hooks) through the **knowledge bridge**, so that every piece of learned knowledge automatically becomes a candidate for new PRISM components, wired into dispatchers, tested, and committed.

**The key insight:** PRISM already learns knowledge (CC-MS1/MS2/MS5/EXT-MS0) and already forges components (forge-triple). This pipeline **closes the loop** between them.

## Args: $ARGUMENTS
- Empty: run the full learn → analyze → forge cycle
- `video <URL>`: learn from a specific video, then forge derived components
- `pdf <path>`: learn from a document, then forge derived components
- `batch <dir>`: learn from all docs in a directory, then forge
- `analyze`: skip learning, analyze existing learned knowledge for forge candidates
- `forge-only`: skip learning + analysis, run forge-triple with learning-informed gap prioritization
- `status`: show learning pipeline status (registry stats, DB sizes, pending forge candidates)
- `--dry-run`: run analysis but don't create components
- `--max-learn=<N>`: limit learning sources processed (default: 3)
- `--max-forge=<N>`: limit forge components created (default: 5)
- `--domain=<cad|cam|shop|auto>`: focus on a domain

## THOROUGHNESS + EXHAUSTIVE SCIENCE LAW (HARD RULES — apply to every phase)
- **NEVER skim, skip, or dismiss content without deep reading.** Every source gets a full assessment.
- **Exhaust ALL mathematical, statistical, and scientific possibilities** — every applicable model, formula, algorithm, and combination including novel cross-domain approaches.
- "Low novelty" / "already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/tip — name it or extract it.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing coverage before building new.
- Before committing: "Did I extract EVERYTHING useful? Did I exhaust every math/science angle?"
- **Completeness > Speed.** Missing content or a missed mathematical model is a permanent capability gap.
- When analyzing gaps: check ALL file types in every ZIP (HTML, text, XML, JSON, CSV, code), not just PDFs.

## Phase 0: Load Path Index
Read `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` (~735 tokens) for system map. Use ENGINE_DIGEST.md for engine listings, DISPATCHER_DIGEST.md for dispatcher/action listings. Do NOT Glob/Grep to explore — digest files have everything.md` from the active path's `mcp-server/data/docs/` — all file paths in ~400 tokens. Never waste tokens running Glob/Grep to locate known files.


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` — loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` — zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` — resolve E0001→path instantly (1,865 indexed files)
- `ENGINE_DIGEST.md` — 880 engines with 1-line descriptions if you need engine-level detail
- `DISPATCHER_DIGEST.md` — 66 dispatchers with action counts if you need action routing


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config
```
SMART CONFIG
Role:   Manufacturing Process Expert + Senior TypeScript Engineer + Knowledge Engineer
Model:  OPUS
Effort: HIGH
Reason: Continuous learning pipeline requires deep domain knowledge, engineering precision, and cross-system integration
```

## Phase 2: YOLO Mode
Activate maximum velocity — autonomous decisions, continuous flow, no proceed questions. The learning pipeline is designed to be fully automated.

## Phase 3: Learning Intake

### 3A: Registry Status Check
1. Read `C:/PRISM/mcp-server/data/video-learned/learning-registry.json` — count total videos processed, last run date
2. Read `C:/PRISM/cad-engine/data/cam_strategies/strategy_db.json` — count strategies, materials covered
3. Read `C:/PRISM/cad-engine/data/cam_strategies/tool_rationale_kb.json` — count rationale entries
4. Read `C:/PRISM/cad-engine/data/cam_strategies/operation_sequences.json` — count sequence patterns
5. Report learning pipeline status:
```
LEARNING STATUS
===============
Videos processed:    [N] (last: [date])
Documents processed: [N] (last: [date])
Strategy DB:         [N] strategies, [M] materials, [K] machines
Tool Rationale KB:   [N] entries across [M] materials
Op Sequences:        [N] patterns, [M] categories
```

If args = `status`, stop here.

### 3B: Source Selection
Based on args:
- **Empty**: Search for high-value unprocessed sources:
  1. Check if there are queued/suggested URLs in `state/learning_queue.json` (if exists)
  2. Identify thin domains in strategy DB (materials/operations with <3 sources)
  3. Suggest search queries to fill gaps (e.g., "titanium 5-axis milling" if titanium has 0 sources)
  4. Use WebSearch to find top YouTube tutorials for thin domains
  5. Select up to `--max-learn` sources
- **`video <URL>`**: Use provided URL
- **`pdf <path>`**: Use provided path
- **`batch <dir>`**: Glob directory for PDF/MD/TXT files
- **`analyze`**: Skip to Phase 4
- **`forge-only`**: Skip to Phase 5

### 3C: Execute Learning Pipeline
For each selected source:

**For videos:**
1. Run `/video-learn <URL> --max-components=10` protocol (Phases 1-8)
2. Capture the `BridgeResult` — the `ComponentSpec[]` output
3. Track: what component types were generated, what domain, what confidence levels

**For documents:**
1. Run `/pdf-learn <path> --max-components=10` protocol (Phases 1-8)
2. Capture the `BridgeResult`
3. Track same metrics

**Important:** Let the existing pipeline handle all ingestion, extraction, bridge, and generation. This phase is orchestration, not reimplementation.

### 3D: Aggregate Learning Results
After all sources are processed:
1. Reload strategy_db.json — what new consensus parameters emerged?
2. Reload tool_rationale_kb.json — what new rationale was captured?
3. Reload operation_sequences.json — what new patterns were learned?
4. Count new ComponentSpecs by type (engines, algorithms, hooks, skills, formulas, tips)
5. Report:
```
LEARNING INTAKE COMPLETE
========================
Sources processed: [N] videos, [M] documents
New strategies:    [N] (total: [T])
New rationale:     [N] entries
New sequences:     [N] patterns
Components written: [E] engines, [A] algorithms, [H] hooks, [S] skills, [F] formulas, [T] tips
```

## Phase 4: Learning-Informed Gap Analysis

This is the **key innovation** — using learned knowledge to prioritize forge candidates.

### 4A: Strategy-to-Engine Mapping
Analyze the strategy DB for operations that PRISM can learn about but can't calculate:
1. Read `strategy_db.json` — get all unique `operation_type` + `material_class` combos
2. For each combo, check if PRISM has a corresponding engine:
   - `adaptive` + `aluminum` → does a HighSpeedAdaptiveEngine exist? Does it handle aluminum?
   - `turning_rough` + `steel` → does TurningForceEngine handle steel roughing?
   - `drilling` + `titanium` → does a DrillForceEngine exist?
3. Score each gap:
   - **Source count** from strategy DB (more sources = more reliable knowledge = higher priority)
   - **Consensus confidence** (higher = stronger data for engine design)
   - **Physics validation score** from recommender (if validation fails, an engine would help)
   - **Material coverage** (if we have strategy data for 5 materials but engine only handles 2)
4. Output ranked list:
```
LEARNING-INFORMED ENGINE GAPS
=============================
Rank | Operation+Material          | Sources | Confidence | Engine Status  | Priority
-----|----------------------------|---------|------------|----------------|--------
  1  | adaptive + titanium        | 5       | 0.85       | NO ENGINE      | CRITICAL
  2  | grinding_surface + steel   | 3       | 0.78       | PARTIAL (no Vc)| HIGH
  3  | turning_finish + aluminum  | 4       | 0.90       | EXISTS         | LOW
```

### 4B: Rationale-to-Algorithm Mapping
Analyze tool rationale KB for decision patterns that could become algorithms:
1. Group rationale entries by material + operation + tool_attribute
2. If 3+ sources agree on a recommendation → candidate for a ToolSelectionAlgorithm
3. If counter_rationale exists → candidate for a ConditionalSelectionAlgorithm
4. Example: "3-flute for aluminum adaptive" (5 sources, 0.92 confidence) → FluteSelectorAlgorithm

### 4C: Sequence-to-Workflow Mapping
Analyze operation sequences for automation candidates:
1. Patterns with frequency ≥ 3 → candidate for a ProcessPlanningEngine
2. Patterns with tool_change_count > 2 → candidate for a ToolChangeOptimizer
3. Common sub-sequences → candidate for a SequenceTemplateEngine

### 4D: Component-to-Forge Mapping
From the components written by the learning pipeline:
1. **New engines** written by component_writer → need dispatcher wiring + tests (→ forge-engines wiring phase)
2. **New algorithms** → need engine integration (→ forge-engines integration phase)
3. **New hooks** → need hookify rule registration (→ forge-hooks)
4. **New skills** → need autofire rules (→ forge-hooks)
5. **New formulas** → need FormulaRegistry wiring + potential engine creation (→ forge-engines)

Output combined priority list:
```
FORGE CANDIDATES (Learning-Informed)
=====================================
Source        | Candidate                    | Type    | Evidence  | Priority
--------------|------------------------------|---------|-----------|--------
strategy_db   | TitaniumAdaptiveEngine       | Engine  | 5 sources | CRITICAL
rationale_kb  | FluteSelectorAlgorithm       | Algo    | 3 entries | HIGH
sequences     | ProcessPlanningEngine        | Engine  | 4 patterns| HIGH
component     | Wire NewSafetyHook           | Hook    | 1 spec    | MEDIUM
component     | Wire NewFormula to registry  | Formula | 2 specs   | MEDIUM
```

If args = `--dry-run` or `analyze`, output the report and stop here.

## Phase 5: Forge Cycle

### 5A: Forge Engines (Learning-Informed)
Instead of running standard forge-engines gap analysis, use the **learning-informed priority list** from Phase 4:
1. Take top N engine candidates from the combined list
2. For each candidate, the strategy DB provides:
   - Consensus parameters (known-good values for test cases!)
   - Material-specific ranges (for physics validation bounds)
   - Source count and confidence (for uncertainty estimation)
3. Follow `/forge-engines` Phase 4-7 protocol:
   - Design engine using learned data as reference values
   - Implement with AtomicValue return format
   - Wire to appropriate dispatcher
   - Write tests using strategy DB consensus as expected values
   - Build + test
4. Key advantage: **test cases come from real-world data**, not theoretical calculations

### 5B: Forge Integration Wiring
For components written by the learning pipeline that need integration:
1. **Engines from component_writer**: Add to `index.ts` exports, wire to dispatcher
2. **Formulas**: Register in FormulaRegistry at `data/formulas/`
3. **Hooks**: Register in hookify config or unified hook scripts
4. **Skills**: Create autofire rules in hookify
5. Build + test after each integration

### 5C: Forge Skills (Learning-Informed)
If the learning pipeline revealed new domains or capabilities:
1. Does the new knowledge warrant a domain-specific query skill?
   - e.g., "We now have 10 grinding strategies" → `/grinding-advisor` skill
2. Does the strategy recommender need a user-facing command?
   - e.g., `/recommend-strategy <operation> <material>` skill
3. Follow `/forge-skills` protocol for creation

### 5D: Forge Hooks (Learning-Informed)
If new safety knowledge was learned:
1. New safety warnings → hookify block/warn rules
2. New quality constraints → posttooluse validation rules
3. New process requirements → pretooluse routing rules

## Phase 6: Feedback Loop Registration

### 6A: Update Strategy DB Validation Bounds
If new engines were created with physics models:
1. Extract the engine's validation bounds
2. Compare with `strategy_recommend.py` physics bounds (`_SURFACE_SPEED_RANGES`, `_FEED_PER_TOOTH_RANGES`, `_DOC_FRACTION_LIMITS`)
3. If engine has tighter/better bounds → update recommender bounds
4. This creates a positive feedback loop: learn → build engine → improve validation → better recommendations

### 6B: Update Forge Gap Database
Save the learning-informed gap analysis to `state/forge-learn/gap_analysis.json`:
```json
{
  "last_updated": "ISO timestamp",
  "engine_gaps": [...],
  "algorithm_gaps": [...],
  "integration_gaps": [...],
  "next_priority": "description of highest-priority unfilled gap"
}
```
This persists across sessions so `/forge-engines` can use learning-informed priorities even when run standalone.

### 6C: Queue Next Learning Targets
Based on remaining gaps, save search suggestions to `state/forge-learn/learning_queue.json`:
```json
{
  "suggested_searches": [
    {"query": "titanium 5-axis adaptive milling tutorial", "reason": "0 sources for titanium adaptive", "priority": "HIGH"},
    {"query": "surface grinding speeds feeds steel", "reason": "grinding domain thin", "priority": "MEDIUM"}
  ],
  "suggested_courses": ["mit:2.008", "mit:2.810"],
  "thin_domains": ["grinding", "turning_thread", "5-axis"]
}
```

## Phase 7: Build + Test Gate
1. `npm run build` — must pass (0 new errors)
2. `npm test` — must pass (0 regression)
3. `cd cad-engine && pytest` — must pass
4. If any fail: fix, re-test, report

## Phase 8: Auto-Commit
Stage all changes from the forge cycle (not the learning intake — that was already committed by /video-learn or /pdf-learn):
```
feat(forge-learn): create [N] components from learned knowledge [FORGE-LEARN]

Learning sources: [N] videos, [M] documents
Engines created: [list]
Algorithms created: [list]
Integration wiring: [N] connections
```

## Phase 9: Summary Report
```
FORGE LEARN COMPLETE
====================
LEARNING:
  Sources:       [N] videos, [M] documents processed
  Strategies:    [N] new ([T] total, [M] materials)
  Rationale:     [N] new entries
  Sequences:     [N] new patterns

GAP ANALYSIS:
  Engine gaps:   [N] identified ([M] critical)
  Algo gaps:     [N] identified
  Integration:   [N] unwired components

FORGE CYCLE:
  Engines:       [N] created (from learned data)
  Algorithms:    [N] created
  Wiring:        [N] connections made
  Skills:        [N] created
  Hooks:         [N] created

FEEDBACK:
  Validation bounds updated: [Y/N]
  Gap DB persisted: [Y/N]
  Learning queue: [N] suggestions saved

BUILD: PASS | TESTS: [N] passing | COMMITS: [N]

Continuous Improvement Score:
  Knowledge → Components: [N] specs → [M] built ([X]% conversion)
  Strategy coverage: [N] op+material combos with consensus data
  Engine coverage:   [M] of those have matching engines ([Y]%)

Next: /forge-learn (run again with new sources)
      /forge-learn analyze (re-analyze without new learning)
      /forge-learn status (check current state)
```

## Error Handling
- **No new sources found**: Report current state, suggest manual URL/path input
- **Learning pipeline failure**: Log error, continue with any successful sources
- **Forge failure**: Complete current item, commit what's done, report remaining
- **Build/test failure**: Fix before committing, revert if unfixable
- **Context budget**: Complete current phase, commit, report remaining work
- **API rate limit**: Switch to offline extraction, continue with regex-based extraction

## Safety Rails
- Never overwrite existing engines — only create new ones or extend
- Never modify existing physics validation bounds without source evidence
- All forge-created components carry provenance linking back to learning source
- Learning-generated test cases include source video/document ID in comments
- Hooks from learned safety knowledge always start in WARN mode
- Never auto-delete learned data — append only to strategy DBs
- Component generation caps: max 5 engines, 3 algorithms, 3 hooks per run (prevent sprawl)
