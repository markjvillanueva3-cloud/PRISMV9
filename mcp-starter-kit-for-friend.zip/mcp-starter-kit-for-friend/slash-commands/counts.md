# Counts — Live System Metrics (No Cache)

Run live filesystem counts and compare against documented values. Detects drift.

## What to do:
1. Run these commands in parallel (all are fast):
   - `ls C:/PRISM/mcp-server/src/engines/*.ts | grep -v index | wc -l` → engines
   - `ls C:/PRISM/mcp-server/src/tools/dispatchers/*.ts | wc -l` → dispatchers
   - `grep -roh 'case "[^"]*"' C:/PRISM/mcp-server/src/tools/dispatchers/*.ts | wc -l` → actions
   - `ls C:/PRISM/mcp-server/src/algorithms/*.ts | grep -v index | wc -l` → algorithms
   - `ls C:/PRISM/mcp-server/src/registries/*.ts | grep -v index | wc -l` → registries
   - `ls C:/PRISM/mcp-server/src/__tests__/*.test.ts | wc -l` → test files

2. Output compact table:
```
LIVE COUNTS
├─ Engines:     [N]
├─ Dispatchers: [N]
├─ Actions:     [N]
├─ Algorithms:  [N]
├─ Registries:  [N]
└─ Test Files:  [N]
```

3. If MEMORY.md counts differ from live, flag drift:
```
DRIFT: engines MEMORY=[old] LIVE=[new] Δ[diff]
```

4. Optionally regenerate quick-ref.json by running:
   `bash C:/PRISM/mcp-server/scripts/generate-quick-ref.sh`
