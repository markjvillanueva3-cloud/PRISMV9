# Remember — Structured Memory Persistence

You are saving knowledge to persistent memory in the most token-efficient way possible. This command ensures every memory write is intentional, deduplicated, correctly routed, and minimally sized. Use this instead of ad-hoc memory writes.

## Args: $ARGUMENTS
- `[text]`: save the specified insight/fact/preference (e.g., `remember always use vitest not jest`)
- `fact [text]`: save a verified technical fact
- `pref [text]`: save a user preference
- `fix [text]`: save a critical fix or pattern (adds to "Critical Fixes Applied" section)
- `result [text]`: save a milestone result or achievement
- `audit`: analyze MEMORY.md for stale, duplicate, or bloated entries and suggest cleanup
- Empty: interactive — ask what to remember

## Step 1: Analyze the Input
Parse what the user wants to save:
- Classify: is this a fact, preference, fix, result, convention, or pattern?
- Determine target section in MEMORY.md or target topic file
- Extract the core insight — compress verbose descriptions to essentials

## Step 2: Deduplication Check
Read the target memory file(s) before writing:
1. Read MEMORY.md fully
2. Read relevant topic files in `~/.claude/projects/*/memory/`
3. Search for the key terms from the new memory
4. If an existing entry covers the same topic:
   - **Exact duplicate**: reject — "Already remembered: [existing entry at line N]"
   - **Partial overlap**: update the existing entry instead of adding a new one
   - **Related but different**: proceed with the new entry, note the related one

## Step 3: Route to Correct Location
Determine where this memory belongs:

| Type | Destination | Rule |
|------|------------|------|
| Hook/tooling info | MEMORY.md → Hook System section | Keep concise, use bullet format |
| PRISM counts/stats | MEMORY.md → PRISM v9 section | Update existing lines, don't add new |
| Critical fix | MEMORY.md → Critical Fixes section | One-line format with em-dash |
| Materials data | MEMORY.md → Materials section | Update, don't expand |
| CAD/CAM data | MEMORY.md → CC-MS0 section | Update, don't expand |
| User preference | MEMORY.md → User Preferences section | Concise bullet |
| Detailed patterns | `memory/debugging-patterns.md` | When too detailed for MEMORY.md |
| Audit findings | `memory/prism-audit-findings.md` | Detailed findings |
| New topic area | `memory/[topic].md` + link in MEMORY.md | Only if >3 related facts |

## Step 4: Compress to Minimum Tokens
Before writing, apply compression rules:
1. **Remove filler words**: "I noticed that" → just state the fact
2. **Use symbols**: → instead of "leads to", + instead of "and also"
3. **Use em-dash format**: `**Label** — concise description` (matches existing style)
4. **Abbreviate known terms**: TypeScript→TS, dispatcher→disp, MASTER_INDEX→MI
5. **One line per fact**: multi-sentence entries → single-line bullets
6. **Numbers over words**: "one hundred thirty seven" → "137"

Target: each new memory entry should be ≤120 characters

## Step 5: Size Check
After preparing the write:
1. Count current MEMORY.md lines
2. If adding would exceed 200 lines:
   - Identify the least-valuable existing entry to remove or compress
   - Or extract a large section to a topic file
   - Then add the new entry
3. Report: "MEMORY.md: [N]/200 lines ([X]% after write)"

## Step 6: Write
1. Edit MEMORY.md (or topic file) using the Edit tool
2. Verify the write succeeded
3. Report what was saved and where

## Report
```
REMEMBERED
==========
Type:     [fact/pref/fix/result/convention]
Saved to: [MEMORY.md section / topic-file.md]
Entry:    [the compressed entry]
Dedup:    [NEW / UPDATED existing / REJECTED duplicate]
Size:     MEMORY.md [N]/200 lines ([X]%)
```

## Audit Mode (`/remember audit`)
Scan MEMORY.md for optimization opportunities:
1. **Stale entries**: facts that are no longer relevant (completed milestones with excessive detail)
2. **Duplicates**: same information stated in multiple sections
3. **Verbose entries**: entries >120 chars that could be compressed
4. **Extractable sections**: sections >10 lines that should move to topic files
5. **Missing entries**: important session knowledge not yet persisted

Report:
```
MEMORY AUDIT
============
Lines:         [N]/200 ([X]%)
Stale:         [N] entries could be removed
Duplicates:    [N] entries appear in multiple places
Verbose:       [N] entries could be compressed
Extractable:   [N] sections should move to topic files
Missing:       [N] important facts not yet saved

Potential savings: [N] lines → [M] lines ([X]% reduction)
Run /slim to apply optimizations
```

## Error Handling
- **MEMORY.md not found**: check `~/.claude/projects/` path structure
- **Duplicate rejected**: show the existing entry — user can force with `remember --force [text]`
- **Size limit hit**: suggest extraction or compression before adding
- **Topic file missing**: create it and add link to MEMORY.md

## Chaining
- Natural flow: learn something → `/remember` → saved for next session
- Pairs with: `/slim` (trim what's bloated), `/context` (check overall budget)
- Fed by: `/ship` (completion results), `/forge-debug` (fix patterns), `/audit-task` (findings)
