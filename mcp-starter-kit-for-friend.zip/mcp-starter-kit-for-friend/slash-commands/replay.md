# Replay — Session context reconstruction

Quickly reconstruct what was being worked on without reading transcripts.

## Steps
1. Use sessionReplayEngine.getReplayContext()
2. Show: last commit, active area, modified files, suggested next steps
3. Check sessionReplayEngine.getWorkingSet() for uncommitted work

## Output Format
```
SESSION REPLAY
==============
Last: [hash] "[message]" ([time ago])
Area: [active area]
Files: [N] changed
Working: [staged/modified/untracked counts]
Next: [suggested steps]
```
