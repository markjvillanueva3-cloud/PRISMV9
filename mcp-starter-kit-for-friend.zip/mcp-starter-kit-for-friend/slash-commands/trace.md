# Trace — Wiring Chain Tracer

You are tracing the full wiring chain for a PRISM component — from dispatcher action through engine to algorithm and safety hooks. This reveals how components connect, identifies broken or missing links, and helps understand the system architecture.

## Args: $ARGUMENTS
- `[engine-name]`: trace FROM an engine (e.g., `trace KienzleEngine`)
- `[dispatcher-name]`: trace FROM a dispatcher (e.g., `trace calcDispatcher`)
- `[action-name]`: trace FROM an action name (e.g., `trace calculate_cutting_forces`)
- `[algorithm-name]`: trace FROM an algorithm (e.g., `trace KienzleForcesAlgorithm`)
- `up [name]`: trace UPSTREAM — who calls this component?
- `down [name]`: trace DOWNSTREAM — what does this component call?
- `full [name]`: trace both directions (default if no direction specified)
- `orphans`: find components with no wiring (no callers or no callees)
- `map [dispatcher]`: show ALL actions and their engine mappings for a dispatcher


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Step 1: Identify the Component
Based on args, locate the target component:

### Engine
Search `C:/PRISM/mcp-server/src/engines/` for file matching the name.
Read the file to find: class name, exported functions, imports, what it calls.

### Dispatcher
Search `C:/PRISM/mcp-server/src/tools/dispatchers/` for file matching the name.
Read the file to find: all action definitions, which engines each action calls.

### Action
Search all dispatcher files for the action name string.
Find which dispatcher owns it and which engine it invokes.

### Algorithm
Search `C:/PRISM/mcp-server/src/algorithms/` and `AlgorithmRegistry` for the name.
Find which engines call this algorithm.

## Step 2: Trace Downstream (what does it call?)
Starting from the component, follow the call chain:

```
Dispatcher → Action → Engine → Algorithm → Sub-engines
                  ↘ Safety hooks (if safety-relevant)
                  ↘ Validation (crossFieldPhysics, materialSanity)
```

For each link:
- Read the source file
- Find import statements and function calls
- Follow to the next component
- Stop when reaching leaf nodes (raw calculations, external APIs, registry lookups)

## Step 3: Trace Upstream (who calls it?)
Search for references to the component:

- For engines: grep all dispatchers for the engine's class/function name
- For algorithms: grep all engines for the algorithm name
- For dispatchers: grep orchestration files, other dispatchers for cross-dispatcher calls
- For actions: grep for the action name in tests, docs, and other dispatchers

## Step 4: Check Wiring Health
For each link in the chain, verify:
- **Import exists:** The importing file actually imports the target
- **Target exists:** The imported file/function exists on disk
- **Export matches:** The export name matches what's being imported
- **No dead code:** The imported function is actually called (not just imported)
- **Safety integration:** Safety-relevant components connect to SafetyEngine/safetyDispatcher

## Step 5: Report

### Chain View (default)
```
TRACE: [component name]
========================
Direction: [UP/DOWN/FULL]

DOWNSTREAM (what it calls):
  [component] (dispatcher)
    → [action_name] → [EngineName].calculate()
      → [AlgorithmName].compute()
        → [raw calculation / registry lookup]
      → SafetyEngine.evaluate() [if applicable]
    → [action_name_2] → [EngineName2].process()

UPSTREAM (who calls it):
  ← [CallerDispatcher].[action] calls this
  ← [TestFile].test() tests this
  ← [OtherEngine].helper() delegates to this

WIRING HEALTH:
  Links checked:  [N]
  Healthy:        [N]
  Broken:         [N] — [details]
  Dead imports:   [N] — [details]
  Missing safety: [N] — [details]

Status: [FULLY WIRED / N ISSUES]
```

### Map View (`/trace map calcDispatcher`)
```
DISPATCHER MAP: calcDispatcher
==============================
Actions: [N] total

  calculate_cutting_forces
    → KienzleEngine.calculate()
    → SafetyEngine.evaluate()
    Status: WIRED

  calculate_power_consumption
    → PowerEngine.calculate()
    Status: WIRED

  estimate_tool_life
    → ToolLifeEngine.predict()
    → SafetyEngine.evaluate()
    Status: WIRED

  [action_with_no_engine]
    → (NO ENGINE FOUND)
    Status: BROKEN
```

### Orphan Report (`/trace orphans`)
```
ORPHAN REPORT
=============
Engines with no dispatcher caller: [N]
  - [EngineName] (src/engines/EngineName.ts)
  - ...

Dispatchers with unwired actions: [N]
  - [dispatcherName].[actionName]
  - ...

Algorithms with no engine caller: [N]
  - [AlgorithmName]
  - ...

Total orphans: [N]
```

## Error Handling
- **Component not found:** "No component matching '[name]' found. Did you mean: [suggestions from fuzzy match]?"
- **Circular reference:** Detect and report cycles: "Circular wiring detected: A → B → C → A"
- **Too many results:** If tracing from a very connected component, limit depth to 4 levels and note truncation

## Chaining
- After `/trace orphans`: fix broken wiring → `/test` → `/auto-commit`
- Feeds into: `/check-dsl` (verify DSL compliance of wired components)
- Feeds into: `/addtomatrix` (register newly wired components)
- Related: SYS-MS4 (engine wiring audit — completed, found 64 dead exports)
