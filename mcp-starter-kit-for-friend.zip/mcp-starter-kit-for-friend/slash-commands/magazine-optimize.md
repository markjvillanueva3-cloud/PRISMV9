# Magazine Optimize — CNC Tool Magazine Layout Optimizer

Optimize tool magazine slot assignments, minimize tool change time, and plan sister tool strategies.

## Args: $ARGUMENTS
- Empty: run with defaults (chain magazine, 15 tools, 120 slots)
- `turret 8`: turret magazine with 8 tools
- `chain 40 sister`: chain magazine, 40 tools, sister tool analysis
- `rack 100 sequence 1,5,1,5,2,10`: specify tool sequence

## Steps

1. Parse args for magazine_type, tools_required, sister_tool_enabled, program_tool_sequence
2. Call `toolMagazineOptimizationEngine.calculate()` with parsed input
3. Display results:
   - Total change time and time saved vs sequential
   - Magazine utilization %
   - Optimal slot assignment (top 10 most-used tools)
   - Sister tool slots needed (if enabled)
   - Throughput gain %
4. Show recommendations

## Output Format

```
MAGAZINE OPTIMIZATION
=====================
Type: [magazine_type] | Slots: [total] | Tools: [N]
Strategy: [strategy]

Change Time:  [total_change_time_s] s (saved [time_saved] s vs sequential)
Throughput:   +[gain]% improvement
Utilization:  [pct]%
Tool Changes: [N] in program

Sister Tools: [N] extra slots needed
Slot Map:     T1→S[n], T2→S[n], ...

Recommendations:
- [rec1]
- [rec2]
```
