# Formula Browse — PRISM Formula Explorer

You are browsing PRISM's 490+ formulas. Each formula has a unique ID (e.g., F-KIENZLE-001), domain, category, equation (LaTeX + plain text), parameters, validation rules, and consumer tracking. Use this to find the right formula for a calculation, compare formulas, audit coverage, or understand formula parameters.

## Args: $ARGUMENTS
- Empty: list all formulas grouped by domain
- `[formula-id]`: inspect a specific formula (e.g., `F-KIENZLE-001`)
- `domain [name]`: list formulas in a domain (physics, manufacturing, thermal, etc.)
- `category [name]`: list formulas in a category (cutting_force, tool_life, power, etc.)
- `search [keyword]`: search formulas by name, equation, or parameter
- `consumers [engine-name]`: find formulas consumed by a specific engine
- `stats`: show formula distribution statistics
- `orphans`: find formulas not consumed by any engine

## Formula Architecture
```
FormulaRegistry.ts (main registry)
├── BUILT_IN_FORMULAS (20 hardcoded)
├── FORMULA_REGISTRY.json (490 total)
├── 12 source modules (PRISM_*.js)
└── Indexed by: domain × category × consumer
```

### Key Files
- `C:/PRISM/mcp-server/src/registries/FormulaRegistry.ts` — main registry with search APIs
- `C:/PRISM/mcp-server/data/FORMULA_REGISTRY.json` — full formula database
- Source modules: `PRISM_MFG_PHYSICS.js`, `PRISM_FORCE_LOOKUP.js`, `PRISM_THERMAL_*.js`, etc.

### Formula Structure
Each formula contains:
- `formula_id`: Unique ID (F-{DOMAIN}-{NNN})
- `name`, `description`: Human-readable info
- `domain`: physics, manufacturing, ai_ml, optimization, quality, calculator, thermal, tool_life
- `category`: cutting_force, tool_life, power, quality, dynamics, resource_allocation, etc.
- `equation`: LaTeX representation
- `equation_plain`: Plain text representation
- `parameters[]`: Input/output params with name, symbol, unit, range, default
- `validation`: required_inputs, output_range, constraints, safety_checks
- `consumers[]`: Engines/tools that use this formula
- `references[]`: Academic/industrial references

## Step 1: Parse Query and Execute

### List All (`/formula-browse`)
1. Read FormulaRegistry.ts to get built-in formulas
2. Read FORMULA_REGISTRY.json for full catalog (use head/sampling if large)
3. Group by domain and present:
```
PRISM FORMULAS (490+)
=====================
Domain            | Count | Example IDs
------------------|-------|---------------------------
physics           |  [N]  | F-KIENZLE-001, F-MERCHANT-001
manufacturing     |  [N]  | F-MRR-001, F-CHIPTHK-001
thermal           |  [N]  | F-THERMAL-001, F-JAEGER-001
tool_life         |  [N]  | F-TAYLOR-001, F-USUI-001
optimization      |  [N]  | F-PSI-001, F-OMEGA-001
calculator        |   9   | F-CALC-001 through F-CALC-009
quality           |  [N]  | ...
ai_ml             |  [N]  | ...
Total: [N] formulas across [N] domains
```

### Inspect Specific (`/formula-browse F-KIENZLE-001`)
1. Find the formula by ID (fuzzy match on partial IDs)
2. Present:
```
FORMULA: F-KIENZLE-001 — Kienzle Cutting Force
================================================
Domain:    physics
Category:  cutting_force
Source:    PRISM_MFG_PHYSICS.js

Equation (LaTeX):
  F_c = k_{c1.1} \cdot h^{1-m_c} \cdot b \cdot a_p

Equation (Plain):
  Fc = kc1.1 * h^(1-mc) * b * ap

Parameters:
  INPUT   kc11  [N/mm²]  Specific cutting force (range: 500-5000)
  INPUT   mc    [-]      Material exponent (range: 0.1-0.5)
  INPUT   h     [mm]     Chip thickness (range: 0.01-5.0)
  INPUT   b     [mm]     Width of cut
  INPUT   ap    [mm]     Depth of cut
  OUTPUT  Fc    [N]      Main cutting force

Validation:
  Required: kc11, mc, h, b, ap
  Constraints: h > 0, kc11 > 0
  Safety: CRITICAL — force calculation affects machine limits

Consumers: [engines/tools that use this formula]
References: Kienzle, O. (1952) "Die Bestimmung von Kräften..."
```

### Search (`/formula-browse search deflection`)
1. Search formula names, equations, parameter names, and descriptions
2. Return matching formulas with relevance ranking

### Stats (`/formula-browse stats`)
```
FORMULA STATISTICS
==================
Total Formulas:    [N]
By Domain:         [domain: count pairs]
By Category:       [category: count pairs]
With Consumers:    [N] ([%] coverage)
Orphan Formulas:   [N] (no consumer)
With Safety:       [N] (have safety_checks)
With References:   [N] (have academic references)
```

### Orphans (`/formula-browse orphans`)
Find formulas not consumed by any engine:
1. Check each formula's `consumers[]` array
2. List any with empty consumers
```
ORPHAN FORMULAS
===============
[formula_id] — [name] (domain: [domain])
...
Total: [N] formulas with no consumer
```

## Error Handling
- **Formula not found**: "No formula matching '[id]'. Try `/formula-browse search [keyword]`"
- **Domain not found**: "Unknown domain '[name]'. Domains: physics, manufacturing, thermal, ..."
- **Registry file missing**: "CRITICAL — FormulaRegistry.ts not found."
- **Large result set**: Paginate to 20 per page, suggest domain/category filter

## Chaining
- Discovery: `/formula-browse` → find formula → `/formula-browse [id]` → understand params
- Validation: `/formula-browse orphans` → find unused → `/forge-cleanup` → evaluate removal
- Development: `/formula-browse domain physics` → identify gap → `/forge-engines` → implement
- Safety: `/formula-browse search safety` → audit safety-critical formulas → `/safety-audit`
- Pairs with: `/algorithm-inspect` (algorithms use formulas), `/registry-browse formula` (registry view), `/action-search` (find actions using formulas)
