# Test Speed Feed — Exhaustive UltimateSpeedFeedEngine Gauntlet

Run the comprehensive test gauntlet that proves out every capability of the UltimateSpeedFeedEngine — all 31 physics models, 5 statistical methods, 15 materials, 7 operations, 7 strategies, and 401 assertions across 3 test files.

## Args:
- Empty: run ALL tests (401 total — R1 breadth + R2 depth)
- `quick`: run only the core 76 tests (original test file)
- `r1`: run R1 breadth gauntlet (206 tests)
- `r2`: run R2 depth gauntlet (119 tests)
- `[section]`: run a specific section (e.g., "materials", "physics", "statistics", "scenarios")

## Execution

### Full Suite (default)
```bash
cd /c/PRISM/mcp-server && npx vitest run src/__tests__/ultimate-speed-feed.test.ts src/__tests__/ultimate-speed-feed-gauntlet.test.ts src/__tests__/ultimate-speed-feed-gauntlet-r2.test.ts
```

### Quick Mode
```bash
cd /c/PRISM/mcp-server && npx vitest run src/__tests__/ultimate-speed-feed.test.ts
```

### R1 Only (breadth)
```bash
cd /c/PRISM/mcp-server && npx vitest run src/__tests__/ultimate-speed-feed-gauntlet.test.ts
```

### R2 Only (depth)
```bash
cd /c/PRISM/mcp-server && npx vitest run src/__tests__/ultimate-speed-feed-gauntlet-r2.test.ts
```

### Section Filter
```bash
cd /c/PRISM/mcp-server && npx vitest run src/__tests__/ultimate-speed-feed-gauntlet.test.ts src/__tests__/ultimate-speed-feed-gauntlet-r2.test.ts -t "Gauntlet.*[Section]"
```

## Coverage Map — R1 (Breadth: 206 tests)

| Category | Tests | Coverage |
|----------|-------|---------|
| Materials | 20 | All 15 materials + aliases + ordering |
| ISO Groups | 7 | All 6 groups + speed ordering |
| Operations | 12 | milling, turning, drilling, tapping, reaming, boring, thread_milling |
| Strategies | 12 | conventional, adaptive, trochoidal, hsm, hpc, plunge, slot |
| Cut Types | 5 | roughing, semi_finishing, finishing |
| Tool Materials | 9 | carbide, hss, cermet, ceramic, cbn, pcd |
| Coolants | 9 | flood, mist, mql, air_blast, dry, through_tool, cryogenic |
| Optimization | 6 | tool_life, productivity, surface_finish, balanced |
| Physics Models | 50+ | All 31 models with multi-material validation |
| Statistics | 18 | MC uncertainty, Cp/Cpk, Pareto, sensitivity, confidence |
| Cross-Model | 6 | Merchant/Lee-Shaffer, Kienzle/Merchant, Taylor/Archard |
| Invariants | 8 | Vc=piDn/1000, Vf=fz*z*n, MRR, force resultant |
| Real-World | 10 | Al pocket, Ti 5-axis, Inconel slot, D2 die, SS trochoidal |
| Edge Cases | 12 | Empty input, unknown material, micro/large tools |
| Utilities | 7 | listMaterials, listStrategies, getMaterialProfile, quick, stats |
| Formulas | 2 | All model names in provenance |
| Sweeps | 3 | Hardness, diameter RPM, engagement CTF |

## Coverage Map — R2 (Depth: 119 tests)

| Category | Tests | Coverage |
|----------|-------|---------|
| Determinism | 2 | 10-iteration stability, field order independence |
| Performance | 4 | <50ms single, <50ms full, 100-in-2s, compare<200ms |
| Multi-Variable | 8 | hardness+rigidity, micro+finishing, runout+Ra, cryo+inconel |
| Coating/Geometry | 5 | helix angle, corner radius, coatings, stickout L^3, flutes |
| Customer Workflows | 10 | 7075 speed, power check, Inconel life, Ra prediction, cost/part |
| Regression Pins | 5 | Baseline ranges for steel/al/ti/inconel, stats stability |
| Output Completeness | 8 | All fields typed, forces, thermal, wear, alternatives, formulas |
| Comparison Accuracy | 2 | compareAcrossMaterials matches individual, ordering correct |
| Units Consistency | 5 | m/min, RPM, mm/tooth, N, Nm, C, kW, min, um |
| Cross-Material Physics | 5 | SCE ordering, thermal ordering, heat partition, J-C, chip type |
| Strategy x Material | 15 | 5 materials x 3 strategies matrix |
| Warnings | 4 | Fire risk, hardened warning, unknown material, no false warnings |
| Input Sensitivity | 3 | RPM proportionality, hardness sensitivity, CTF sensitivity |
| Alias Resolution | 38 | Every known alias -> correct ISO group |

## Report Format
After running, summarize:
```
SPEED FEED GAUNTLET: [PASS/FAIL]
Tests: [N] passed / [N] failed / [N] total
  Core:    76 tests
  R1:     206 tests (breadth)
  R2:     119 tests (depth)
Duration: [N]ms
Coverage: 31 physics models, 5 stats, 15 materials, 7 ops, 7 strategies, 38 aliases
```
