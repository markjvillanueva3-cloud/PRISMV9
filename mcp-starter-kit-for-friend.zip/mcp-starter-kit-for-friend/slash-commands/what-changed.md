# What Changed — Recent Activity Snapshot

You are generating a compact "what's new" report for PRISM. Show recent commits, changed files, and any drift from documented counts. Fast and compact.

## Args: $ARGUMENTS
- Empty: last 20 commits + diff stats + count comparison
- `today`: only today's commits
- `week`: last 7 days of commits
- `[N]`: last N commits (e.g., `/what-changed 5`)

## Step 1: Recent Commits
Run from `C:/PRISM/mcp-server/`:
```
git log --oneline -20 --format="%h %ad %s" --date=short
```
If args is a number N, use `-N` instead of `-20`.
If args is `today`, add `--since=midnight`.
If args is `week`, add `--since="7 days ago"`.

## Step 2: Changed Files Summary
Run from `C:/PRISM/mcp-server/`:
```
git diff --stat HEAD~10
```
Show the summary line (files changed, insertions, deletions).

## Step 3: Count Drift Detection
Get current live counts (run in parallel):
1. `ls src/engines/*.ts 2>/dev/null | grep -v index | grep -v test | grep -v spec | wc -l`
2. `ls src/tools/dispatchers/*Dispatcher.ts 2>/dev/null | wc -l`
3. `ls src/algorithms/*.ts 2>/dev/null | grep -v index | grep -v test | wc -l`
4. `ls data/milestones/*.json 2>/dev/null | wc -l`

Compare against MEMORY.md documented counts (Engines: 375, Dispatchers: 54, Algorithms: 52, Milestones: 96).
Flag any differences.

## Step 4: Uncommitted Work
Run from `C:/PRISM/mcp-server/`:
```
git status --short | head -10
```

## Output Format
```
WHAT CHANGED
├─ Recent Commits (last [N]):
│    [hash] [date] [message]
│    [hash] [date] [message]
│    ... (show all)
│
├─ Diff Stats (last 10 commits):
│    [N] files changed, [N] insertions(+), [N] deletions(-)
│    Top changed: [list top 3 files by changes]
│
├─ Count Drift:
│    Engines:     [live] vs [documented] [OK/DRIFT +N]
│    Dispatchers: [live] vs [documented] [OK/DRIFT +N]
│    Algorithms:  [live] vs [documented] [OK/DRIFT +N]
│    Milestones:  [live] vs [documented] [OK/DRIFT +N]
│
└─ Uncommitted: [N files or "working tree clean"]
```

Keep it compact. No commentary beyond the card.
