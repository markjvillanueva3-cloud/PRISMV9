# Forge Cleanup — Dead Code & File Detector

You are running a specialized autopilot pipeline that identifies dead code, unused files, orphaned tests, stale state files, and other cleanup candidates across the PRISM project. Designed to run in the **background** — produces a cleanup report with safe deletion candidates.

## Args: $ARGUMENTS
- Empty: full cleanup scan — all categories
- `dead-code`: only find unreachable/dead code within files
- `dead-files`: only find files with no imports/references
- `stale`: only find stale state/snapshot/temp files
- `tests`: only find orphaned test files (test for deleted source)
- `quick`: count-level summary only
- `apply`: actually delete confirmed dead files (interactive, NOT background)


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` -- loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` -- zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` -- resolve E0001->path instantly (1,865 indexed files)


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (import graph analysis, reference tracking)
2. Domain: Code Maintenance + Systems Hygiene
3. Roles: Senior Maintenance Engineer + Codebase Hygienist
4. Model: SONNET (systematic scanning)
5. Effort: MEDIUM

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Cleanup Scan

### 3A: Dead Files (no imports anywhere)
For each source file in `C:/PRISM/mcp-server/src/`:
1. Get the file's exported symbols
2. Grep entire codebase for imports of this file
3. Check if file is referenced in any registry, config, or index
4. Check if file is an entry point (index.ts, main.ts, CLI entry)
5. If no references found → candidate for deletion

Exclude from analysis:
- `index.ts` files (barrel exports)
- Type definition files (`*.d.ts`)
- Test files (handled separately in 3D)
- Config files (tsconfig, jest.config, etc.)

### 3B: Dead Code Within Files
For each source file, look for:
- Exported functions/classes never imported elsewhere
- Private methods never called within the class
- Unreachable code after return/throw/break
- Unused variables (const/let assigned but never read)
- Dead branches: `if (false)`, `if (0)`, conditions that are always true/false
- Commented-out function bodies (>10 lines of comments that look like code)

### 3C: Stale State & Temp Files
Check these directories:
- `C:/PRISM/state/` — snapshots older than 30 days
- `C:/PRISM/state/snapshots/` — old checkpoint files
- `C:/PRISM/mcp-server/data/claims/` — stale claim files
- `C:/PRISM/audits/` — old audit reports
- `C:/tmp/` — PRISM temp files older than 24 hours
- Root directory — stray files that don't belong (loose .json, .md, .ts)

### 3D: Orphaned Tests
For each test file in `C:/PRISM/mcp-server/src/__tests__/`:
1. Derive expected source file from test name (e.g., `foo.test.ts` → `foo.ts`)
2. Check if source file exists
3. If source was deleted but test remains → orphaned test
4. Also check: test imports that reference deleted modules

### 3E: Empty & Near-Empty Files
- Files with only imports and no exports or logic (<5 meaningful lines)
- Files that are just re-exports of a single other file (could be inlined)
- Empty directories

### 3F: Duplicate Code Detection
Quick duplicate scan:
- Files with >80% content similarity (possible copy-paste)
- Functions with identical bodies in different files
- Repeated utility patterns that should be in shared utils

## Phase 4: Cleanup Report

```
FORGE CLEANUP REPORT
====================
Scanned:    [N] source files, [M] test files, [X] state files

DEAD FILES ([N]):
  HIGH CONFIDENCE (0 imports, 0 references):
    - [file] — [size]KB, last modified [date]
    ...
  MEDIUM CONFIDENCE (only referenced in tests):
    - [file] — [size]KB, test-only references
    ...

DEAD CODE ([N] blocks across [M] files):
  Unused exports:     [N] functions/classes
    - [file:line] [export name] — 0 imports found
  Unreachable code:   [N] blocks
    - [file:line] — dead branch after [return/throw]
  Dead variables:     [N]
    - [file:line] [variable name] — assigned, never read

STALE FILES ([N]):
  State snapshots >30d:  [N] files, [X]KB total
  Stale claims:          [N] files
  Temp files:            [N] files
  Stray root files:      [N] files

ORPHANED TESTS ([N]):
  - [test file] — source [expected file] not found
  ...

EMPTY/TRIVIAL FILES ([N]):
  - [file] — [reason: empty/re-export only/imports only]
  ...

DUPLICATES ([N] pairs):
  - [file1] ↔ [file2] — [similarity]% similar
  ...

RECLAIMABLE SPACE: ~[X]KB across [N] candidates
CLEANUP SCORE: [N]% clean ([M] issues)
```

## Phase 5: Forge Postflight (`/forge-postflight cleanup`)
1. **Gate 1 — DSL**: SKIP (cleanup is read-only by default)
2. **Gate 2 — Matrix**: CONDITIONAL — if dead files were in MASTER_INDEX, flag for removal
3. **Gate 3 — Trace**: SKIP (no wiring changes)
4. **Gate 4 — Sync**: RUN — verify counts after cleanup
5. **Gate 5 — Memory**: RUN — update MEMORY.md with cleanup score
6. **Gate 6 — Hookify**: SKIP

## Phase 6: Auto-Commit (apply mode only)
`chore(cleanup): remove [N] dead files, [M] stale artifacts [FORGE-CLEANUP]`

## Summary Report
```
FORGE CLEANUP COMPLETE
======================
Scanned:     [N] files
Dead files:  [N] candidates
Dead code:   [N] blocks in [M] files
Stale:       [N] files ([X]KB reclaimable)
Orphaned:    [N] test files
Deleted:     [N] (or "report only")
Cleanliness: [score]%
Next:        /forge-cleanup apply to delete confirmed dead files
```

## Error Handling
- **Import resolution ambiguous**: Mark as LOW confidence, don't flag as dead
- **Dynamic imports**: Assume file is used if any dynamic import pattern exists
- **Registry references**: Check all registries before marking file as dead
- **Context budget**: Run dead-files only (smallest scan scope)

## Safety Rails
- READ-ONLY by default — never delete files without explicit `apply` arg
- Never delete safety-critical files regardless of reference count
- Never delete files that are less than 7 days old (may be in-progress work)
- In apply mode: create backup branch before deleting, run tests after
- Require HIGH CONFIDENCE classification before deletion
- Never delete registry files, config files, or documentation
- Flag but never auto-delete test files — they may test internal behavior
