# Forge Drift — Registry & Documentation Drift Detector

You are running a specialized autopilot pipeline that detects drift between PRISM's registries, MASTER_INDEX, actual source code, and documentation. This is designed to run in the **background** — it cross-references multiple truth sources and reports mismatches.

## Args: $ARGUMENTS
- Empty: full drift scan — all registries, indexes, docs, and code
- `registry`: only check registry files vs source code
- `docs`: only check documentation vs actual counts
- `master-index`: only check MASTER_INDEX_COMPACT.md vs actual files on disk
- `roadmap`: only check roadmap-index.json vs milestone envelopes
- `quick`: fast mode — count-level checks only (no content diffing)

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when detecting drift.
- Cross-reference every registry, index, and source file — no sampling shortcuts.
- "No drift" claims REQUIRE citing specific counts and cross-checks.
- **Completeness > Speed.** Undetected drift compounds into system-wide inconsistency.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (cross-referencing, not creative design)
2. Domain: Systems Architecture + Data Integrity
3. Roles: Systems Integrity Auditor + Configuration Manager
4. Model: SONNET (systematic comparison, not complex reasoning)
5. Effort: MEDIUM

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Drift Detection

### 3A: Truth Source Inventory
Catalog all truth sources in PRISM:

**Registries** (`C:/PRISM/registries/`):
- `dispatcher-registry.json` — lists all dispatchers
- `engine-registry.json` — lists all engines
- `algorithm-registry.json` — lists all algorithms
- `hook-registry.json` — lists all hooks
- `cadence-registry.json` — lists all cadences
- Other registry files (glob `*.json` in registries/)

**Indexes**:
- `MASTER_INDEX_COMPACT.md` — comprehensive product catalog
- `mcp-server/data/roadmap-index.json` — milestone tracker (v5.3.0, 94 milestones)

**Documentation**:
- `CLAUDE.md` files (root, mcp-server/, cad-engine/)
- `MEMORY.md` — session memory with counts
- `docs/` directory — architecture docs

**Source Code**:
- `mcp-server/src/tools/dispatchers/` — actual dispatcher files
- `mcp-server/src/engines/` — actual engine files
- `mcp-server/src/algorithms/` — actual algorithm files
- `mcp-server/src/hooks/` — actual hook files

### 3B: Count Drift Detection
For each artifact type, compare counts across sources:

```
ARTIFACT        | Registry | MASTER_INDEX | Source | CLAUDE.md | MEMORY.md
----------------|----------|-------------|--------|-----------|----------
Dispatchers     |    ?     |      ?      |   ?    |     ?     |    ?
Engines         |    ?     |      ?      |   ?    |     ?     |    ?
Algorithms      |    ?     |      ?      |   ?    |     ?     |    ?
Hooks           |    ?     |      ?      |   ?    |     ?     |    ?
Cadences        |    ?     |      ?      |   ?    |     ?     |    ?
Actions         |    —     |      ?      |   ?    |     ?     |    ?
```

Flag any row where values disagree. Use source code as ground truth.

### 3C: Content Drift Detection (full mode only)
For each dispatcher/engine in source code:
1. Is it listed in its registry? If not → DRIFT: unregistered
2. Is it in MASTER_INDEX? If not → DRIFT: unindexed
3. Does the registry entry match the source? (name, path, category)

For each registry entry:
1. Does the source file exist? If not → DRIFT: phantom entry
2. Is the file actively wired (imported/used)? If not → DRIFT: dead registration

### 3D: Roadmap Drift
1. Count milestone envelope files in `mcp-server/data/milestones/`
2. Compare to entries in `roadmap-index.json`
3. Check: any envelopes missing from index? Any index entries without envelopes?
4. Check: completed milestone counts match between MEMORY.md and roadmap-index

### 3E: Documentation Drift
1. Check counts in CLAUDE.md vs actual (dispatchers, engines, actions, milestones)
2. Check counts in MEMORY.md vs actual
3. Check: are safety-critical notes still accurate?
4. Check: are file paths mentioned in docs still valid?

## Phase 4: Drift Report

### 4A: Structured Report
```
FORGE DRIFT REPORT
==================
Scope:      [full / registry / docs / master-index / roadmap]
Sources:    [N] truth sources compared
Scan time:  [X]s

COUNT DRIFT:
  [artifact type]: [source1]=[N] vs [source2]=[M] (delta: [+/-X])
  ...

CONTENT DRIFT:
  UNREGISTERED (in source but not registry):
    - [file] — missing from [registry]
  PHANTOM (in registry but not source):
    - [registry entry] — file not found at [path]
  UNINDEXED (in source but not MASTER_INDEX):
    - [file] — not in MASTER_INDEX.md
  DEAD (registered but not wired):
    - [file] — in registry but no imports found

ROADMAP DRIFT:
  Missing envelopes: [list]
  Extra envelopes:   [list]
  Count mismatch:    [details]

DOC DRIFT:
  [doc file]: [field]=[stated] vs actual=[real]
  ...

DRIFT SCORE: [N]% aligned ([M] total checks, [X] drifted)
```

### 4B: Fix Recommendations
For each drift, suggest the fix:
- Unregistered: "Add to [registry] and MASTER_INDEX"
- Phantom: "Remove from [registry]"
- Count mismatch: "Update [doc] to reflect [correct count]"
- Missing envelope: "Create envelope or remove from index"

## Phase 5: Forge Postflight (`/forge-postflight drift`)
1. **Gate 1 — DSL**: SKIP (drift is read-only)
2. **Gate 2 — Matrix**: SKIP (no new products)
3. **Gate 3 — Trace**: SKIP (no wiring changes)
4. **Gate 4 — Sync**: RUN — use drift findings to verify sync state
5. **Gate 5 — Memory**: RUN — update MEMORY.md with drift score
6. **Gate 6 — Hookify**: SKIP

## Phase 6: Auto-Commit
Only if documentation was updated to fix drift:
`fix(drift): sync [N] drifted counts across [sources] [FORGE-DRIFT]`

## Summary Report
```
FORGE DRIFT COMPLETE
====================
Sources:    [N] compared
Checks:     [M] performed
Aligned:    [X]% ([Y] drifted)
Fixed:      [N] doc counts (or "none — report only")
Worst:      [source] ([N] drifts)
Next:       /sync to auto-fix, or fix manually
```

## Error Handling
- **Registry file missing**: Report as finding, don't fail
- **Source directory empty**: Flag as CRITICAL — possible path misconfiguration
- **Context budget**: Run in quick mode (counts only) if low on context
- **Circular drift**: If A says 45 and B says 47, use source code glob as tiebreaker

## Safety Rails
- This is primarily READ-ONLY — only fix documentation counts, never modify source code
- Never delete registry entries or source files based on drift detection
- Never modify MASTER_INDEX without explicit user instruction
- Report findings accurately — don't auto-fix structural mismatches
- Source code file count is always the ground truth tiebreaker
