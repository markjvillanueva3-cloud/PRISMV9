# PRISM Paths — Quick Reference

Output both PRISM data paths for easy access:

- **Active**: `C:/PRISM`
- **Archive**: `C:/PRISM_ARCHIVE_2026-02-01`

Use these paths when searching for formulas, databases, scientific data, PDFs, catalogs, or any PRISM resources.
