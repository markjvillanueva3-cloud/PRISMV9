# Ergo Check — CNC Workstation Ergonomic Assessment

Evaluate workstation ergonomics using RULA, REBA, and NIOSH lifting equation. Get actionable recommendations for worker safety.

## Args: $ARGUMENTS
- Empty: run with defaults (machine_loading task, 175cm worker)
- `deburring 165cm 2kg`: deburring task, 165cm worker, 2kg load
- `material_handling 180cm 25kg`: heavy material handling scenario
- `inspection standing:90`: part inspection with 90% standing

## Steps

1. Parse args for task, worker_height_cm, load_weight_kg, standing_pct, etc.
2. Call `ergonomicWorkstationEngine.calculate()` with parsed input
3. Display results with risk color coding:
   - RULA score (1-7) with action level
   - REBA score (1-15) with risk level
   - NIOSH RWL and Lifting Index
   - End-of-shift fatigue prediction
   - Optimal workstation height
4. Show all recommendations

## Output Format

```
ERGONOMIC ASSESSMENT
====================
Task: [task] | Worker: [height]cm | Load: [weight]kg

Posture Risk:  [risk_level]
RULA Score:    [score]/7 — [action_level]
REBA Score:    [score]/15 — [risk_description]

Lifting:
  RWL:            [rwl] kg (max recommended)
  Lifting Index:  [LI] ([safe/caution/danger])

Fatigue:
  End-of-shift:   [pct]%
  Breaks needed:  [N] per shift

Workstation:
  Current height:  [current] cm
  Optimal height:  [optimal] cm ([adjust_direction])

Recommendations:
- [rec1]
- [rec2]
```

## Risk Thresholds
- RULA 1-2: Acceptable | 3-4: Investigate | 5-6: Change soon | 7: Immediate action
- REBA 1-3: Negligible | 4-7: Low-Medium | 8-10: High | 11+: Very High
- Lifting Index <1.0: Safe | 1.0-2.0: Caution | >2.0: Danger
