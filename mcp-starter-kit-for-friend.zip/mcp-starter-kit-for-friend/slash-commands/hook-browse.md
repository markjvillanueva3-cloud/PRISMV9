# Hook Browse — PRISM Hook Explorer

You are browsing PRISM's 220 hooks (NOT Claude hooks — these are the MCP server's internal hook system). Hooks span 17 modules covering enforcement, safety, manufacturing, cognitive, recovery, orchestration, and more. Each hook has a phase, category, mode (blocking/warning/logging/silent), priority, and handler. Use this to understand what hooks exist, find blocking hooks, audit enforcement, or discover hook coverage gaps.

## Args: $ARGUMENTS
- Empty: list all 220 hooks grouped by module
- `[hook-id]`: inspect a specific hook
- `module [name]`: list hooks in a module (enforcement, safety, manufacturing, etc.)
- `blocking`: list all blocking-mode hooks (can stop execution)
- `critical`: list all critical-priority hooks
- `category [name]`: list hooks by category (system, cognitive, law, process, data, agent)
- `search [keyword]`: search hooks by name, description, or tag
- `stats`: show hook distribution statistics
- `phases`: list all hook execution phases

## Hook Architecture
```
hooks/index.ts (master index, 220 total)
├── 17 specialized modules
├── HookExecutor.ts (phase-chain enforcement, blocking-capable)
├── HookEngine.ts (EventEmitter async pub/sub)
└── hookBridge.ts (TypeScript + cognitive hook bridge)
```

### Modules (17):
| Module | Count | Focus |
|--------|-------|-------|
| EnforcementHooks.ts | 17 | Anti-regression, safety gates, quality validation |
| SafetyQualityHooks.ts | 20 | Spindle, collision, workholding, SPC |
| SpecialtyManufacturingHooks.ts | 20 | Turning, 5-axis, EDM, grinding |
| LifecycleHooks.ts | 14 | Session mgmt, checkpoints, context pressure |
| CrossReferenceHooks.ts | 12 | Integrity, compatibility, batch operations |
| ObservabilityHooks.ts | 11 | Performance, usage, audit logging |
| AutomationHooks.ts | 11 | Indexing, cache, backup, sync |
| CognitiveHooks.ts | 10 | Bayesian patterns, learning updates |
| ManufacturingHooks.ts | 9 | Force, thermal, deflection, MRR monitoring |
| RecoveryHooks.ts | 9 | Circuit breaker, retry, rollback |
| AdvancedManufacturingHooks.ts | 8 | Chip, chatter, power, G-code validation |
| SchemaHooks.ts | 7 | Version control, deprecation, migration |
| AgentHooks.ts | 7 | Agent tier selection, cost, escalation |
| OrchestrationHooks.ts | 7 | Swarm patterns, pipeline, consensus |
| CadenceDefinitions.ts | 6 | Core scheduled cadences |
| SpecialtyCadences.ts | 6 | PASS2 automation cadences (M97-M102) |
| ControllerHooks.ts | 5 | FANUC, SIEMENS, HAAS controller validation |

### Hook Structure
Each hook implements `HookDefinition`:
- `id`: Unique identifier (e.g., "enforcement-antiregression-001")
- `name`, `description`: Human-readable info
- `phase`: When it runs (pre/post file/material/machine/quality/session/agent ops)
- `event`: Event pattern it responds to
- `category`: enforcement, cognitive, law, process, data, agent, external, validation
- `mode`: **blocking** (stops execution), **warning** (logs, continues), **logging** (silent log), **silent** (no output)
- `priority`: critical, high, normal, low, background
- `order`: Execution order within priority
- `enabled`: Active/inactive state
- `tags[]`: Discipline-specific labels
- `handler`: Execution function receiving HookContext

## Step 1: Parse Query and Execute

### List All (`/hook-browse`)
1. Read `src/hooks/index.ts` for the master hook list
2. Group by module, show counts and modes:
```
PRISM HOOKS (220)
=================
Module                         | Count | Blocking | Warning | Logging
-------------------------------|-------|----------|---------|--------
SafetyQualityHooks             |    20 |        5 |       4 |      11
SpecialtyManufacturingHooks    |    20 |        3 |       8 |       9
EnforcementHooks               |    17 |        6 |       5 |       6
LifecycleHooks                 |    14 |        2 |       4 |       8
CrossReferenceHooks            |    12 |        1 |       3 |       8
...
Total: 220 hooks ([N] blocking, [N] warning, [N] logging, [N] silent)
```

### Blocking Hooks (`/hook-browse blocking`)
List all hooks that can STOP execution:
```
BLOCKING HOOKS
==============
[id] — [name]
  Module: [module], Priority: [priority]
  Condition: [what triggers the block]
  ...
Total: [N] blocking hooks
```

### Critical Priority (`/hook-browse critical`)
List all critical-priority hooks regardless of mode:
```
CRITICAL HOOKS
==============
[id] — [name] (mode: [blocking/warning/logging])
  Module: [module]
  Phase: [phase]
  ...
Total: [N] critical hooks
```

### Module Detail (`/hook-browse module enforcement`)
1. Read the specific module file (e.g., EnforcementHooks.ts)
2. List each hook with its key attributes:
```
ENFORCEMENT HOOKS (17)
======================
#  | ID                              | Mode     | Priority | Phase
---|----------------------------------|----------|----------|------------------
 1 | enforcement-antiregression-001   | blocking | critical | post-calculation
 2 | enforcement-safety-gate-001      | blocking | critical | pre-output
...
```

### Inspect Specific (`/hook-browse enforcement-antiregression-001`)
1. Find the hook by ID (fuzzy match)
2. Read its source to extract full details:
```
HOOK: enforcement-antiregression-001
====================================
Name:       Anti-Regression Gate
Module:     EnforcementHooks.ts
Category:   law
Mode:       BLOCKING
Priority:   critical
Phase:      post-calculation
Event:      calculation-complete

Description:
  Prevents regression in safety-critical calculations. Compares new
  results against baseline. Blocks if quality drops below threshold.

Conditions:
  - Triggers on: calculation-complete events
  - Checks: result quality vs stored baseline
  - Blocks when: quality score < 0.95 of baseline

Tags: [enforcement, safety, regression, quality]
Enabled: true
```

### Stats (`/hook-browse stats`)
```
HOOK STATISTICS
===============
Total Hooks:     220
By Mode:         blocking: [N], warning: [N], logging: [N], silent: [N]
By Priority:     critical: [N], high: [N], normal: [N], low: [N], background: [N]
By Category:     enforcement: [N], cognitive: [N], process: [N], ...
Enabled:         [N] ([%])
Disabled:        [N] ([%])
```

### Search (`/hook-browse search spindle`)
Search hook names, descriptions, tags, and event patterns for keyword matches.

### Phases (`/hook-browse phases`)
List all 88+ hook execution phases with which hooks fire at each phase.

## Error Handling
- **Hook not found**: "No hook matching '[id]'. Try `/hook-browse search [keyword]`"
- **Module not found**: "Unknown module '[name]'. Modules: enforcement, safety, manufacturing, ..."
- **File missing**: "Hook module file not found at expected path."

## Chaining
- Discovery: `/hook-browse` → overview → `/hook-browse module [name]` → inspect module
- Safety: `/hook-browse blocking` → list blockers → `/safety-audit` → verify coverage
- Debugging: `/hook-browse search [event]` → find hooks for event → understand enforcement
- Development: `/hook-browse stats` → find gaps → `/forge-hooks` → create new hooks
- Pairs with: `/safety-audit` (safety chain), `/algorithm-inspect` (algorithms hooks protect), `/trace` (wiring including hooks), `/hook-profile` (Claude hook overhead, different system)
