# Learn Everything — Exhaustive Knowledge Acquisition Pipeline

Maximize PRISM's knowledge from all available sources: PDFs, videos, web content, controller manuals, tool catalogs, and machine specs. Scans every source type and converts findings into PRISM components.

## Args:
- Empty: scan all knowledge sources and process unlearned content
- `pdfs`: focus on PDF library only
- `videos`: focus on video sources only
- `web`: focus on web-based learning
- `[domain]`: focus on specific domain (e.g., "cam", "tooling", "materials")

## Phase 1: Knowledge Inventory
1. Scan existing knowledge sources:
   - `C:/PRISM/cad-engine/knowledge_store/` — PDF knowledge store
   - `C:/PRISM/mcp-server/data/video-learned/` — video learning registry
   - `C:/PRISM/cad-engine/data/` — raw data files (PDFs, manuals)
   - Check `_registry.json` and `learning-registry.json` for already-processed items
2. Identify unprocessed sources:
   - New PDFs not in registry
   - New videos not yet transcribed
   - Updated manuals (newer versions available)

## Phase 2: PDF Learning
1. `/pdf-learn` — batch process all unlearned PDFs
   - Technical manuals, handbooks, academic papers
   - Tool manufacturer catalogs
   - Machine manuals
   - CAM software documentation
   - Standards (ISO, ASME, DIN)
2. Extract: formulas, parameter tables, procedures, tribal knowledge
3. Generate components per PDF

## Phase 3: Video Learning
1. `/video-learn` — process all unlearned videos
   - Machining tutorial videos
   - CAM software walkthroughs
   - Manufacturing process demonstrations
   - Tool application videos
2. Extract: techniques, parameters, visual knowledge, tips

## Phase 4: Controller Enrichment
1. `/controller-enrich` — expand controller knowledge
   - New controller models not yet covered
   - G-code/M-code differences between controllers
   - Controller-specific features and limitations
   - Custom macro capabilities

## Phase 5: Tool Enrichment
1. `/tool-enrich` — expand tool database
   - New manufacturer catalogs
   - Updated tool specifications
   - New tool types and geometries
   - Application recommendations from manufacturers

## Phase 6: Machine Enrichment
1. `/machine-enrich` — expand machine database
   - New machine models
   - Updated specifications
   - Kinematic data for 5-axis machines
   - Controller assignments

## Phase 7: Cross-Reference & Synthesis
1. Cross-reference findings across all sources:
   - Do PDF parameters match video demonstrations?
   - Do tool catalog specs align with machining results?
   - Do machine limits match controller capabilities?
2. Generate cross-domain components:
   - New engines from combined knowledge
   - New tribal tips from correlated findings
   - Updated formulas from validated data

## Output Summary
```
LEARN EVERYTHING COMPLETE
==========================
Sources Processed:
  PDFs:         [N] new ([N] total in library)
  Videos:       [N] new ([N] total)
  Controllers:  [N] enriched ([N] total tips)
  Tools:        [N] enriched ([N] total in catalog)
  Machines:     [N] enriched ([N] total profiles)

Components Generated:
  Tribal tips:  [N]
  Engines:      [N]
  Algorithms:   [N]
  Hooks:        [N]
  Formulas:     [N]
  Skills:       [N]
  TOTAL:        [N] new PRISM components

Knowledge Coverage:
  Materials:    [N] with full data
  Operations:   [N] with validated params
  CAM systems:  [N] with tips/strategies
  Controllers:  [N] with code references

Top Discoveries:
  1. [highest-value finding]
  2. [second highest]
  3. [third highest]

Build: PASS | Tests: [N] passing | Commits: [N]
```

## Key Engines Used
VideoLearningEngine, DocumentLearningDispatcher, ToolCatalogEngine,
MachineProfileEngine, MaterialDatabaseEngine, TribalKnowledgeEngine
