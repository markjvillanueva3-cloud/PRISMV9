# Waste Report — Token Waste Analysis Dashboard

Analyze the current session for token waste patterns and recommend optimizations.

## Steps
1. Review recent tool calls for waste patterns:
   - Duplicate reads (same file read multiple times)
   - Empty searches (Grep/Glob with 0 results)
   - Oversized outputs (tools returning way more than needed)
   - Wrong tool usage (Bash for cat/grep when Read/Grep exists)
   - Re-reads after edits (you already know the content)

2. Use WasteDetectorEngine concepts to categorize waste:
   - `unused-read`: file read but content not referenced
   - `empty-search`: search returned nothing useful
   - `duplicate-fetch`: same info fetched twice
   - `oversized-output`: more tokens than needed
   - `wrong-tool`: expensive tool when cheap one works

3. Output compact report:
```
WASTE REPORT
============
Total waste events: [N]
Estimated tokens wasted: ~[N]K
Top waste type: [type]

Events:
  [type] [tool] [detail] (~[N] tokens)
  ...

Recommendations:
  - [actionable suggestion]
  ...

Session efficiency: [N]% (lower = more waste)
```

4. Keep output under 500 tokens. Focus on actionable items only.
