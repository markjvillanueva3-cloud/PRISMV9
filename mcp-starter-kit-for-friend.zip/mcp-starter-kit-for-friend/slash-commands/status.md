# Status — Instant System Overview (<30 seconds, <100 tokens output)

You are generating an ultra-compact PRISM system snapshot. Do NOT read any large files (no SYSTEM_INVENTORY.md, no MASTER_INDEX.md). All data comes from filesystem counts and git. Complete fast.

## Args: $ARGUMENTS
- Empty: full status card
- `counts`: file counts only
- `git`: recent commits only
- `build`: build+test status only

## Step 1: Gather Counts (run ALL in parallel)
Run these bash commands simultaneously from `C:/PRISM/mcp-server/`:

1. `ls src/engines/*.ts 2>/dev/null | grep -v index | grep -v test | grep -v spec | wc -l` — engine count
2. `grep -l "export" src/engines/*.ts 2>/dev/null | wc -l` — exported engines
3. `ls src/tools/dispatchers/*Dispatcher.ts 2>/dev/null | wc -l` — dispatcher count
4. `grep -r "registerAction\|addAction" src/tools/dispatchers/ 2>/dev/null | wc -l` — action count (approx)
5. `ls src/algorithms/*.ts 2>/dev/null | grep -v index | grep -v test | wc -l` — algorithm count
6. `ls src/hooks/*.ts 2>/dev/null | grep -v index | grep -v test | wc -l` — hook count
7. `ls src/registries/*.ts 2>/dev/null | grep -v index | grep -v test | wc -l` — registry count
8. `ls data/milestones/*.json 2>/dev/null | wc -l` — milestone count
9. `grep -l '"status".*"complete"' data/milestones/*.json 2>/dev/null | wc -l` — completed milestones

## Step 2: Quick Test Count (skip if args = `counts` or `git`)
Run from `C:/PRISM/mcp-server/`:
`npx vitest run --pool=forks 2>&1 | tail -5`
Extract: tests passed, test files count. If this takes >15 seconds, skip and report "Tests: skipped (use /health for full check)".

## Step 3: Git Status
Run from `C:/PRISM/mcp-server/`:
1. `git log --oneline -5`
2. `git status --short | head -5`

## Step 4: Build Check (skip if args = `counts` or `git`)
Run from `C:/PRISM/mcp-server/`:
`npx tsc --noEmit 2>&1 | tail -3`
Report PASS or FAIL with error count.

## Output Format
Print EXACTLY this card format (fill in values, keep it tight):

```
PRISM STATUS
├─ Engines: [N] ([M] exported)
├─ Dispatchers: [N] | Actions: ~[N]
├─ Algorithms: [N] | Registries: [N]
├─ Hooks: [N] | Cadences: 103 | Formulas: 499
├─ Tests: [N] pass / [N] files
├─ Milestones: [N]/[N] complete
├─ Last 3 commits:
│    [hash] [msg]
│    [hash] [msg]
│    [hash] [msg]
├─ Uncommitted: [N files or "clean"]
└─ Health: [PASS/FAIL] BUILD | [PASS/FAIL] TESTS
```

Do NOT add commentary. Do NOT read documentation files. Just the card.

## Performance Target
- Total execution: <30 seconds
- Output: <100 tokens
- Tool calls: 4-6 bash commands (parallelized)
- Zero file reads of .md or .json docs
