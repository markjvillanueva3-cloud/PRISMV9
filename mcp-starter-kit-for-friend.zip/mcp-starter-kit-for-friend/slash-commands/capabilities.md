# Capabilities — Discover PRISM Tools at the Moment of Need

List every entry in `state/shared/CAPABILITY_INDEX.json` grouped by category.
Used for explicit discovery when the UserPromptSubmit reminder hook
(`capability-reminder.mjs`) hasn't fired but you want to see what's available.

## Args: $ARGUMENTS
- Empty: list all entries grouped by category
- `[category]`: filter to one category (token-efficiency, stale-data-trap,
  pre-creation-check, advanced-capability, domain-data, coordination, meta,
  discovery, slash-command-protocol, developer-flow, roadmap, file-moved)
- `[keyword]`: case-insensitive substring match against triggers + hints

## Protocol

1. **Read index**: load `H:/prism-agi-infra-a/state/shared/CAPABILITY_INDEX.json`
   (or `H:/prism/state/shared/CAPABILITY_INDEX.json` as fallback).

2. **Filter** per `$ARGUMENTS`:
   - no args → keep everything
   - arg matches a known category → filter `entry.category === arg`
   - otherwise → substring match on triggers + hint (case-insensitive)

3. **Group by category**, sort entries within a group by `priority` asc.

4. **Emit as compact markdown**:

```
# PRISM Capabilities — [N entries across M categories]

## token-efficiency (P=priority)
- **file-read-cache** (P1) — FileReadCache hook blocks duplicate Read...
  triggers: re-read, same file, look at that file
- **grep-result-cache** (P1) — GrepResultCache hook blocks duplicate Grep...
  triggers: same grep, re-grep, search again

## pre-creation-check
- **duplication-guard** (P0) — duplicationGuardEngine.checkBeforeCreating({...})
  triggers: create engine, new engine, new hook, add action
...
```

5. **Footer** with two pointers:
   - Auto-surfacing: `capability-reminder.mjs` (UserPromptSubmit hook)
   - Schema source: `state/shared/CAPABILITY_INDEX.json`

## Why this exists

Four categories of PRISM capability are easy to forget at the moment of need:

1. **Token-saving hooks** (FileReadCache, GrepResultCache, JsonStateSummarizer)
   — silent when working, invisible when forgotten.
2. **Stale-data traps** (CLAUDE.md counts that drift, archived files at old paths).
3. **Advanced engines** (PRISMCreativeReasoningEngine, prismSelfAwarenessEngine)
   buried among 2,000+ engines.
4. **Coordination hazards** (settings.json conflicts with 4 concurrent chats).

CAPABILITY_INDEX.json is the central registry. `capability-reminder.mjs`
surfaces hints automatically on trigger-phrase match; `/capabilities` is the
manual fallback — use when you suspect there's a tool you're not recalling.

## Maintenance

When you add a new capability that users should know about:
1. Add an entry to `state/shared/CAPABILITY_INDEX.json` with triggers + hint.
2. Bump `lastUpdated`.
3. Ensure `capability-reminder.mjs` is wired (see `AGI_INFRA_PHASE_A_WIRING.md`).

## Related

- `capability-reminder.mjs` — auto-surfacing UserPromptSubmit hook
- `ai-auto-command-router.mjs` — slash-command-focused sibling
- `AGI_INFRA_PHASE_A_WIRING.md` — hook settings patch
- Roadmap: `UNIVERSAL-SKILLS-SCRIPTS-HOOKS-PLAN-2026-04-15.md` (CAP-MS track)
