# Tool Select — Complete Tool Selection & Validation Pipeline

End-to-end tool selection: material identification, catalog search across 46,590 tools, speed/feed optimization for candidates, wear prediction, machine compatibility check, and cost-per-part comparison. From "what tool should I use?" to "here's the best option with full justification."

## Args:
- Material + operation description (e.g., "Inconel 718 finishing with 3xD reach")
- `compare`: side-by-side comparison of top 3 candidates
- `budget=<N>`: max tool cost constraint

## Phase 1: Material Identification
1. Parse input for material, operation type, feature geometry
2. `/material-lookup` — resolve ISO group, hardness, machinability rating
3. Identify critical constraints (reach, tolerance, surface finish)

## Phase 2: Tool Search
1. `/tool-catalog` — search 46,590 tools across 19 manufacturers
2. Filter by: material compatibility, diameter range, flute count, coating, reach
3. Check collision data (41,085 tools with collision profiles)
4. Score candidates on: geometry match, coating suitability, holder compatibility
5. Select top 3-5 candidates with primary + backup designations

## Phase 3: Speed/Feed Optimization
For each candidate tool:
1. Run `ultimateSpeedFeedEngine.calculate()` with full inputs
2. Get 3 alternatives per tool: conservative / balanced / aggressive
3. Include: forces, deflection, surface finish prediction, power requirements
4. Compare MRR across candidates at equivalent tool life

## Phase 4: Wear Analysis
1. `/wear-analysis` for each candidate:
   - Predicted tool life (minutes and parts)
   - Wear progression curve (break-in, steady, rapid)
   - Regrind economics (if applicable)
   - Failure mode prediction (flank, crater, notch, chipping)

## Phase 5: Machine Compatibility
1. `/machine-check` for each candidate:
   - Spindle speed range vs required RPM
   - Power/torque at recommended parameters
   - Holder/taper compatibility
   - Coolant delivery requirements

## Phase 6: Cost Analysis
1. `/estimate` cost per part for each candidate:
   - Tool cost amortized over predicted life
   - Cycle time comparison
   - Regrind savings (if applicable)
   - Total cost per part ranking

## Output Summary
```
TOOL SELECT COMPLETE — [Operation Description]
================================================
Material:     [name] (ISO [group], [hardness])
Operation:    [type] ([details])
Candidates:   [N] evaluated from [N] searched

RECOMMENDED: [Tool 1 — Manufacturer, Model, Specs]
  Speed/Feed: Vc [X] m/min, fz [X] mm/tooth
  Tool Life:  [X] min ([X] parts)
  Cost/Part:  $[X] (tool) + $[X] (time) = $[X] total
  Why:        [1-line justification]

BACKUP: [Tool 2 — Manufacturer, Model, Specs]
  ...

COMPARISON TABLE:
Tool          | Vc    | Life  | MRR    | Cost/Part | Score
[tool1]       | [X]   | [X]   | [X]    | $[X]      | [X]/100
[tool2]       | [X]   | [X]   | [X]    | $[X]      | [X]/100
[tool3]       | [X]   | [X]   | [X]    | $[X]      | [X]/100
```

## Key Engines Used
ToolCatalogEngine, UltimateSpeedFeedEngine, AdvancedWearPhysicsEngine,
MachineProfileEngine, CycleTimeEstimatorEngine, MaterialDatabaseEngine
