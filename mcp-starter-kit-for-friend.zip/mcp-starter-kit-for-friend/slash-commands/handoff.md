# Handoff — Session Continuity Protocol

You are creating a structured handoff document that captures everything the next session needs to resume work seamlessly. This is the PROACTIVE alternative to `precompact-save` (which only fires reactively on compaction). Use `/handoff` before ending a session, when context is getting heavy, or when switching major tasks.

## Args: $ARGUMENTS
- Empty: full handoff — capture everything
- `quick`: minimal handoff — just task state and next action (5 lines)
- `task`: handoff the current task only (active claim, progress, blockers)
- `session`: full session summary (what was done, decisions made, files touched)
- `resume`: generate a resume prompt that the next session can paste to instantly reload context
- `read`: read and display the last handoff (useful at session start)

## Step 1: Capture Current State

### 1A: Active Task
Check for active work:
- Read `C:/PRISM/state/ACTIVE_CLAIM.json` — what unit is claimed?
- Read `C:/PRISM/state/CURRENT_POSITION.md` — current milestone status
- Check for uncommitted git changes in `C:/PRISM/` — any unsaved work?
- Check TaskList for any in-progress tasks

### 1B: Session Context
Capture what happened this session:
- What milestone/unit was being worked on?
- What files were modified? (git diff --name-only)
- What decisions were made? (key choices that affect future work)
- What problems were encountered? (blockers, bugs found, workarounds)
- What was learned? (new patterns, important findings)

### 1C: System State
Capture system health:
- Build status (last known pass/fail)
- Test status (last known counts)
- Any open findings discovered this session
- MEMORY.md current size
- SVI / Psi: Read `C:/PRISM/state/shared/SVI-compact.md` — extract current SVI value, Psi %, trend, and any coverage alerts

## Step 2: Generate Handoff Document

### Full Handoff (`/handoff` or `/handoff session`)
Write to `C:/PRISM/state/HANDOFF.md`:
```markdown
# Session Handoff — [date] [time]

## What Was Done
- [1-3 bullet points of completed work]

## Current Task
- Milestone: [id] — [title]
- Unit: [id] — [title] ([status])
- Progress: [X]/[Y] steps complete
- Active claim: [YES/NO]

## Key Decisions
- [decision 1 — why this approach was chosen]
- [decision 2]

## Blockers / Issues
- [blocker 1 — what's needed to resolve]
- [or: NONE]

## Files Modified (uncommitted)
- [file1] — [what changed]
- [file2] — [what changed]
- [or: All committed]

## Next Actions (priority order)
1. [first thing to do next session]
2. [second thing]
3. [third thing]

## System State
- Build: [PASS/FAIL]
- Tests: [N] passing, [N] failing
- MEMORY.md: [N]/200 lines
- Findings: [N] CRITICAL, [N] MAJOR
- SVI: [value] | Psi: [N]% | Trend: [stable/growing/shrinking]

## Resume Command
Run at next session start: `/startup` then resume with:
> [1-2 sentence description of exactly where to pick up]
```

### Quick Handoff (`/handoff quick`)
Write a minimal 5-line handoff to `C:/PRISM/state/HANDOFF.md`:
```
HANDOFF: [date]
Task: [milestone-id] [unit-id] — [status]
Done: [what was completed]
Next: [immediate next action]
State: Build [P/F] | Tests [N/N] | [N] uncommitted files | Psi: [N]%
```

### Task Handoff (`/handoff task`)
Focus only on the active task:
```
TASK HANDOFF: [unit-id]
Step: [current step N/total]
Status: [what's done, what remains]
Blockers: [any blockers]
Files: [modified files]
Next: [exact next action]
```

### Resume Prompt (`/handoff resume`)
Generate a copy-pasteable prompt for the next session:
```
I'm resuming PRISM work. Last session I was working on [milestone-id] [unit-id] — [title].
I completed [what was done]. The next step is [next action].
Key context: [1-2 critical facts].
Modified files: [list]. Build: [status]. Tests: [status].
Please run /startup and then continue from [exact point].
```

### Read Last Handoff (`/handoff read`)
Read and display `C:/PRISM/state/HANDOFF.md`:
- If it exists: display contents
- If it doesn't exist: "No handoff found. This is a fresh session."
- If it's older than 24 hours: warn "Handoff is [N] hours old — may be stale"

## Step 3: Save to Disk
1. Write the handoff to `C:/PRISM/state/HANDOFF.md`
2. Also update `C:/PRISM/state/COMPACTION_SURVIVAL.json` with structured data (this is what `precompact-save` reads)
3. Optionally update MEMORY.md if significant new knowledge was generated this session

## Step 4: Report
```
HANDOFF SAVED
=============
File:     C:/PRISM/state/HANDOFF.md
Type:     [full/quick/task/resume]
Task:     [milestone-id] [unit-id] — [title]
Next:     [immediate next action]
Modified: [N] files ([N] uncommitted)

To resume: /startup → /handoff read → continue from [step]
```

## Error Handling
- **No active task**: create a general session handoff (what was explored, what was learned)
- **No git repo**: skip git-based file tracking, rely on TaskList and known state
- **HANDOFF.md already exists**: overwrite with timestamp (old handoff is stale by definition)
- **Can't write to state/**: fall back to writing to MEMORY.md "Last Session" section

## Chaining
- End of session: work → `/handoff` → close
- Context pressure: feeling heavy → `/handoff quick` → `/slim` → continue lighter
- Session start: `/startup` → `/handoff read` → instant context reload
- Before compaction: `/handoff` → context survives even if compaction drops history
- Pairs with: `/remember` (persistent facts), `/slim` (trim bloat), `/context` (diagnose budget)
