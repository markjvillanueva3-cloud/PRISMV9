# Smart — Auto-Configuration Protocol

## Input: $ARGUMENTS

Silently evaluate the prompt, then output config header before executing.

## Configuration Logic

**Complexity → Model:**
- SIMPLE (single-step, lookup, typo) → HAIKU
- MODERATE (multi-step, feature, debug, refactor) → SONNET
- COMPLEX (architecture, security, multi-system, novel algorithm) → OPUS
- Override to OPUS: security/safety-critical, precision calcs, >5 files

**Domain → Role:** Match to most specific: Senior TypeScript/Python Engineer, Manufacturing Process Expert, Principal Systems Architect, Senior Security Auditor, Data Scientist, Database Architect, API Specialist, Senior Frontend Engineer, Technical Doc Lead, Senior QA Engineer, Performance Specialist, Applied Math/Physics Expert, Strategic Business Analyst, Research Specialist. Combine for multi-domain (max 3).

**Effort:** MAX (roadmap, architecture, multi-system, scrutiny) | HIGH (deep research, edge cases, build/test verification) | MEDIUM (efficient implementation, brief explanation) | LOW (direct answer, minimal exploration)

## APPLY SETTINGS (MANDATORY — not just advisory)
After determining the configuration, ACTUALLY APPLY IT:

1. **Set effort level**: Tell the user to run `/effort [level]` if not already at the right level.
   Display: "Setting effort to [MAX/HIGH/MEDIUM/LOW]... Run `/effort max` if terminal shows different."
   NOTE: The effort level shown in the terminal status bar (bottom right) is the REAL setting.
   If /smart says MAX but terminal says medium, the terminal wins. User must `/effort max` manually.

2. **Set model**: If model change needed, suggest `/model [model-name]`.

## Output Header
```
SMART CONFIG
Role:   [role(s)]
Model:  [OPUS/SONNET/HAIKU] (claude-*-*)
Effort: [MAX/HIGH/MEDIUM/LOW]
Reason: [1 sentence]
Action: [what was actually set vs what user needs to manually set]
```

Execute at selected effort level. Bias toward action — don't ask clarifying questions unless genuinely ambiguous.

## IMPORTANT: /smart CANNOT programmatically change effort level
The effort level is a Claude Code CLI setting controlled by the user via `/effort` command.
/smart can RECOMMEND the level but the user must confirm via `/effort max` (or whichever level).
If the task clearly needs MAX effort (roadmap work, multi-agent scrutiny, architecture), TELL the user:
"This task needs MAX effort. Run `/effort max` if not already set."

## ENFORCEMENT HOOKS ACTIVE (automatic — no manual invocation needed)

The following hooks fire silently during every /smart session to enforce quality:

**Knowledge-First Building:**
- Before writing ANY engine: hook checks if domain-specific knowledge (tribal tips, playbook rules, formulas) was consulted. Lists exactly which databases to query for the detected domain.
- Before writing ANY engine: hook checks if ENGINE_DIGEST.md was read (prevents creating duplicate engines).

**Quality Gates:**
- After ANY engine write: blocks stub returns, inline physics constants, and fake data.
- After ANY test write: blocks || true, bare .includes(), and trivially-passing assertions.
- Tracks edit count — warns at 30, strongly warns at 60, blocks at 90 (context quality protection).
- Tracks engine edits since last /prism-review — warns at 3, strongly warns at 6.

**Compaction Gates:**
- Before /compact: checks for unwired engines, missing tests, skipped reviews.
- Before stop: checks for orphaned engines not wired to dispatchers.

**DESIGN PHILOSOPHY:** These hooks exist because instructions in roadmaps and slash commands are "hope-based" — they depend on Claude remembering and choosing to follow them. Hooks are enforcement-based — they fire automatically and BLOCK bad patterns regardless of what Claude "decides" to do. Every quality rule that matters has a corresponding enforcement hook.
