# Forge Video Watchlist — Machining Video Learning Pipeline

Systematically chip away at the PRISM Video Watchlist by watching, learning, and forging new components from machining videos. Each run processes a batch of videos from the priority queue, extracts knowledge, and pipes it through `/autopilot` + `/forge-triple` to exhaust all mathematical, statistical, and scientific possibilities.

## Args: $ARGUMENTS
- Empty: process next batch from Tier 1 (highest priority unwatched)
- `tier <1-4>`: process from a specific tier
- `category <N>`: process from a specific category (1-10)
- `topic <keyword>`: search watchlist for matching topics (e.g., "chatter", "titanium", "5-axis")
- `status`: show watchlist progress (watched/total per category)
- `next <N>`: show next N unwatched items (default: 10)
- `mark <line>`: mark a specific item as watched (by line content match)
- `--max=<N>`: limit items processed per run (default: 3)
- `--dry-run`: show what would be processed without executing
- `--search-only`: find videos via WebSearch but don't process yet
- `--forge-after`: run /forge-triple after all videos in batch are learned
- `--offline`: use pre-downloaded transcripts (CHEAPEST — skips all WebSearch/WebFetch)
- `prep`: run the 3-step offline pipeline: search URLs → download transcripts → pre-filter (zero API cost)
- `prep-urls <keyword>`: search YouTube for URLs matching keyword, save to url-list file
- `prep-download <url-file>`: batch download transcripts from URL list file
- `prep-filter`: pre-filter all downloaded transcripts to machining-relevant content

## TOKEN-SAVING ARCHITECTURE
Three bash scripts eliminate ~75% of API cost by doing heavy I/O offline:

```
ONLINE PATH ($4.50/video):
  WebSearch → WebFetch → Claude reads full transcript → extracts → forges

OFFLINE PATH ($0.80/video):
  1. bash watchlist-to-urls.sh <keyword>     # yt-dlp search, $0 API
  2. bash video-watchlist-batch.sh <url-file> # yt-dlp download, $0 API
  3. bash transcript-prefilter.sh <dir>       # grep filter 50-80%, $0 API
  4. Claude reads pre-filtered .filtered.txt  # 50-80% fewer input tokens
  5. Batch 5+ videos per Read call            # amortize overhead

Scripts at: ~/.claude/hooks/lib/
  - watchlist-to-urls.sh        → find YouTube URLs via yt-dlp search
  - video-watchlist-batch.sh    → download transcripts (VTT→text)
  - transcript-prefilter.sh     → grep machining keywords, reduce 50-80%
  - video-extract-compact.sh    → merge N filtered transcripts into one file
```

**Cost comparison for full 400-video watchlist:**
| Mode | Per Video | Total | Savings |
|------|-----------|-------|---------|
| Online (WebSearch) | ~$4.50 | ~$3,000 | baseline |
| Offline (pre-download) | ~$0.80 | ~$500 | 83% |
| Offline + batch 5 | ~$0.50 | ~$300 | 90% |

**With $90 budget:** Online = ~20 videos, Offline+batch = ~150-180 videos

## THOROUGHNESS LAW (HARD RULE)
- **NEVER skim, skip, or dismiss content without deep reading.** Every video gets full extraction.
- "Low novelty" / "already covered" claims REQUIRE citing the SPECIFIC existing engine/tip.
- **Exhaust ALL mathematical, statistical, and scientific possibilities** from each video.
- Before completing any video: "Did I extract EVERY formula, model, constant, and technique?"
- **Completeness > Speed.** Missing a cutting model or physics relationship is a permanent loss.

## Phase 0: Load Path Index
Read `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` (~735 tokens) for system map. Use ENGINE_DIGEST.md for engine listings, DISPATCHER_DIGEST.md for dispatcher/action listings. Do NOT Glob/Grep to explore — digest files have everything.md` from the active path's `mcp-server/data/docs/` — all file paths in ~400 tokens.


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` — loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` — zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` — resolve E0001→path instantly (1,865 indexed files)
- `ENGINE_DIGEST.md` — 880 engines with 1-line descriptions if you need engine-level detail
- `DISPATCHER_DIGEST.md` — 66 dispatchers with action counts if you need action routing

## Phase 1: Smart Config
```
SMART CONFIG
Role:   Manufacturing Process Expert + Cutting Science Researcher + Senior TypeScript Engineer
Model:  OPUS
Effort: HIGH
Reason: Video learning pipeline requires deep domain expertise to extract all mathematical/scientific content and translate it into PRISM engine enhancements
```

## Phase 2: YOLO Mode
Maximum velocity — autonomous decisions, continuous flow.

## Phase 3: Load Watchlist & Select Batch

### 3A: Read Current State
1. Read `C:/PRISM/mcp-server/data/docs/VIDEO_WATCHLIST.md`
2. Count: total items, `[x]` watched, `[ ]` unwatched, `[~]` partial
3. Identify current tier position (which tier has unwatched items)

### 3B: Handle Prep Commands (ZERO API cost)
If args start with `prep`:
- **`prep`**: Run all 3 steps sequentially:
  ```bash
  bash ~/.claude/hooks/lib/watchlist-to-urls.sh "speed feed"
  bash ~/.claude/hooks/lib/video-watchlist-batch.sh <url-file>
  bash ~/.claude/hooks/lib/transcript-prefilter.sh C:/PRISM/mcp-server/data/video-learned/transcripts
  ```
  Then stop — transcripts are ready for `--offline` processing.
- **`prep-urls <keyword>`**: Run `watchlist-to-urls.sh <keyword>` and stop.
- **`prep-download <url-file>`**: Run `video-watchlist-batch.sh <url-file>` and stop.
- **`prep-filter`**: Run `transcript-prefilter.sh` on transcript dir and stop.

### 3C: Select Items
Based on args:
- **Empty**: Take next `--max` items from highest-priority unwatched tier
- **`tier N`**: Take from specified tier
- **`category N`**: Take from specified category
- **`topic <keyword>`**: Grep watchlist for keyword, take matching items
- **`status`**: Report progress and stop
- **`next N`**: List next N items and stop

### 3D: Resolve Video Sources
**If `--offline` flag (PREFERRED — cheapest):**
1. Check `C:/PRISM/mcp-server/data/video-learned/transcripts/` for `.filtered.txt` files
2. If batch input exists, use `batch-extract-input.txt` (multiple videos in ONE read)
3. If only raw transcripts, run pre-filter first:
   ```bash
   bash ~/.claude/hooks/lib/transcript-prefilter.sh C:/PRISM/mcp-server/data/video-learned/transcripts
   bash ~/.claude/hooks/lib/video-extract-compact.sh C:/PRISM/mcp-server/data/video-learned/transcripts 5
   ```
4. Read the single batch file — extract all knowledge in ONE Claude read

**If online (no --offline flag):**
1. Use WebSearch to find the specific video/playlist on YouTube
2. Verify it matches the description (channel, topic, content type)
3. Prefer: official manufacturer channels > educational institutions > independent creators
4. If multiple candidates: pick highest view count + most recent
5. Record the URL

If args = `--search-only`, save found URLs back to watchlist and stop.

## Phase 4: Video Learning Pipeline

For each video in the batch:

### 4A: Execute /video-learn
Run `/video-learn <URL>` with full protocol:
- FFmpeg frame extraction (if local) or transcript extraction
- Content analysis for: formulas, constants, cutting models, techniques
- Knowledge fusion with existing PRISM data
- Component generation (engines, algorithms, formulas, tips, hooks)

### 4B: Deep Mathematical Extraction
After standard /video-learn, perform additional extraction focused on:

**Speed & Feed Models:**
- Any Vc, fz, ap, ae recommendations with material/tool context
- Chip load calculations and chip thinning factors
- Power/torque requirements and machine limit considerations
- Surface finish (Ra/Rz) predictions from parameters
- Tool life (Taylor) data points and curve fitting
- Specific cutting force (Kc) values by material

**Physics Models:**
- Force models (Merchant, Kienzle, oblique cutting)
- Temperature models (Jaeger, Loewen-Shaw, chip-tool interface)
- Wear models (Usui, Archard, Taylor extended)
- Deflection models (cantilever beam, Timoshenko)
- Stability models (stability lobes, regenerative chatter)
- Thermal models (heat partition, thermal softening)

**Statistical Models:**
- Process capability data (Cp, Cpk measurements)
- DOE results (Taguchi L-arrays, factor significance)
- Regression coefficients for empirical models
- Monte Carlo inputs (distribution parameters)

**CAM/Post-Processor Knowledge:**
- Toolpath strategy parameters and their effects
- Post-processor variable names and mappings
- Controller-specific G-code patterns
- Machine kinematic configurations

**Machining Playbook Rules (MachiningPlaybookEngine):**
For EVERY video, extract experiential knowledge as structured PlaybookRule entries:
- **Sequencing rules**: Operation ordering wisdom (face first, rough-before-finish, drill-before-pocket)
- **Anti-patterns**: Things to NEVER do (plunging flat endmills, conventional milling on CNC, flood coolant on carbide)
- **Setup strategy**: Fixture planning, Op 1→Op 2 transitions, soft jaws, workholding
- **Toolpath strategy**: When to use adaptive vs. traditional, Z-level vs. scallop, pencil tracing
- **Material tips**: Material-specific machining wisdom (stainless: never dwell; titanium: low speed high feed)
- **Thin wall/floor**: Alternating sides, reduced ap, wall support strategies
- **Hole making**: Peck drilling thresholds, thread mill vs. tap decisions
- **Thermal**: Stabilization between rough/finish, coolant strategy
- **Safety**: Prove-out procedures, collision avoidance

For each rule extracted, call `playbook_add_rule` via `prism_shop_practice` dispatcher with:
```json
{
  "id": "<CATEGORY_PREFIX>-<NNN>",
  "category": "<category>",
  "severity": "critical|important|recommended|tip",
  "title": "<short title>",
  "rule": "<the actual advice>",
  "reasoning": "<WHY — physics/experience behind it>",
  "conditions": [{"type": "always"} or specific conditions],
  "exceptions": ["when to break this rule"],
  "source": "<video channel — video title (URL)>"
}
```
**CRITICAL**: Do NOT dismiss a video as "low novelty" for playbook rules. Even basic videos teach best practices that belong in the playbook. Check existing rules with `playbook_lookup` before adding duplicates.

### 4C: Record Extracted Knowledge
For each video, produce:
```
VIDEO EXTRACTION REPORT
=======================
Source:     [channel] — [title]
URL:       [url]
Duration:  [minutes]
Category:  [watchlist category]

FORMULAS EXTRACTED: [N]
  - [formula name]: [equation] (context: [material/operation])
  ...

CONSTANTS EXTRACTED: [N]
  - [constant name]: [value] [units] (source: [manufacturer/textbook])
  ...

MODELS IDENTIFIED: [N]
  - [model name]: [type] (existing engine: [Y/N — which engine])
  ...

TECHNIQUES CAPTURED: [N]
  - [technique]: [description] (applicable to: [operations])
  ...

PLAYBOOK RULES EXTRACTED: [N]
  - [rule ID]: [title] (category: [category], severity: [severity])
  ...

PRISM GAPS IDENTIFIED: [N]
  - [gap]: [description] → target engine: [engine name]
  ...

NOVELTY SCORE: [0-100] (vs existing PRISM knowledge)
```

## Phase 5: Forge Cycle

### 5A: Aggregate Batch Results
After all videos in batch are processed:
1. Merge all extracted formulas → check against existing `data/formulas/`
2. Merge all constants → check against existing catalog data
3. Merge all models → check against existing engines
4. Identify NEW items not in PRISM

### 5B: Execute /forge-triple (if --forge-after or significant gaps found)
Run `/forge-triple` with learning-informed priorities:
1. **Engines**: Create/enhance engines for newly discovered models
   - New force models → enhance AdvancedCuttingMathEngine
   - New thermal models → enhance ToolpathThermalEngine
   - New wear models → enhance ToolWearCompensationEngine
   - New S/F data → enhance UltimateSpeedFeedEngine
   - New stability data → enhance NovelToolpathEngine (HRAF)
   - New post patterns → enhance PostProcessorEngine
   - New safety rules → enhance GCodeSafetyAnalyzerEngine
2. **Skills**: Create domain-specific query skills if new domain opened
3. **Hooks**: Create safety/validation hooks from learned constraints

### 5C: Execute /autopilot Extensions
For mathematical/statistical gaps:
1. Implement missing Taguchi arrays for new parameter combinations
2. Add missing material-specific Kienzle constants
3. Extend Taylor tool life curves with new data points
4. Add new Colding constants if discovered
5. Implement any new optimization algorithms (NSGA-II, simulated annealing variants)
6. Add new SPC rules or control chart types

## Phase 6: Update Watchlist
1. Read `VIDEO_WATCHLIST.md`
2. Mark processed items as `[x]` (or `[~]` if partially extracted)
3. Add notes on what was extracted per item
4. Write updated file

## Phase 7: Build + Test Gate
1. `npm run build` — 0 new errors
2. `npm test` — 0 regressions
3. `cd cad-engine && pytest` — 0 regressions
4. If fail: fix, re-test, report

## Phase 8: Auto-Commit
```
feat(forge-video-watchlist): process [N] videos from [category/tier]

Videos: [titles]
Formulas added: [N]
Constants added: [N]
Engine enhancements: [list]
New tips: [N]
Watchlist progress: [watched]/[total] ([%]%)
```

## Phase 9: Summary Report
```
FORGE VIDEO WATCHLIST — BATCH COMPLETE
=======================================
BATCH:
  Videos processed:  [N] from [category]
  Total duration:    [M] minutes of content

EXTRACTION:
  Formulas:    [N] new ([T] total in PRISM)
  Constants:   [N] new ([T] total)
  Models:      [N] identified ([M] new to PRISM)
  Techniques:  [N] captured
  Tips:        [N] new tribal knowledge entries

FORGE RESULTS:
  Engines enhanced: [list]
  Engines created:  [list]
  Algorithms added: [N]
  Skills created:   [N]
  Hooks created:    [N]
  Tests added:      [N]

WATCHLIST PROGRESS:
  Tier 1: [N]/[T] ([%]%)
  Tier 2: [N]/[T] ([%]%)
  Tier 3: [N]/[T] ([%]%)
  Tier 4: [N]/[T] ([%]%)
  Overall: [N]/[T] ([%]%)

MATHEMATICAL EXHAUSTIVENESS:
  Force models:      [N] in PRISM (target: 15+)
  Thermal models:    [N] in PRISM (target: 8+)
  Wear models:       [N] in PRISM (target: 6+)
  Statistical models: [N] in PRISM (target: 12+)
  Optimization algos: [N] in PRISM (target: 10+)
  Material constants: [N] in PRISM (target: 500+)

BUILD: PASS | TESTS: [N] passing | COMMITS: [N]

Next: /forge-video-watchlist          (continue with next batch)
      /forge-video-watchlist status   (check progress)
      /forge-video-watchlist tier 2   (jump to tier 2)
      /forge-video-watchlist topic titanium  (focus on titanium)
```

## Error Handling
- **Video unavailable**: Log, skip, mark `[!]` in watchlist, continue
- **No transcript/frames**: Fall back to WebSearch for written version of same content
- **Low novelty batch**: Still mark as watched, note "confirmed existing coverage"
- **Context budget**: Complete current video, commit, report remaining in batch
- **Build/test failure**: Fix before committing, revert if unfixable

## Safety Rails
- Never overwrite existing engine logic — only extend or add new methods
- All new formulas carry source provenance (video URL + timestamp)
- New constants validated against at least 2 sources before use in calculations
- Hooks from learned safety knowledge start in WARN mode
- Material-specific parameters must match ISO material group classifications
- Component generation caps: max 5 engines, 5 algorithms, 5 hooks per batch run
