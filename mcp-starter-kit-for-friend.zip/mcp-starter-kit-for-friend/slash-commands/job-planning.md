# Job Planning — End-to-End Manufacturing Job Planner

Complete job planning pipeline: feature recognition, operation sequencing, tool selection, cycle time, cost estimation, and machine assignment.

## Args: $ARGUMENTS
- Empty: interactive — prompt for part details
- `[material] [feature-list]`: quick plan (e.g., `aluminum "3 pockets, 8 holes, 2 slots"`)
- `quote:[quantity]`: include cost estimation for batch size
- `--schedule`: also assign machine and schedule

## Phase 1: Smart Config
1. Complexity: COMPLEX
2. Domain: Manufacturing Process Planning + Production Management
3. Roles: Manufacturing Process Expert + Production Engineer
4. Model: OPUS
5. Effort: HIGH

## Phase 2: Part Definition
1. **Material**: Look up via `prism_data → material_get`
2. **Features**: Parse feature list or prompt for:
   - Pockets (rectangular, circular, freeform) with dimensions
   - Holes (through, blind, threaded) with diameter and depth
   - Slots, bosses, contours, chamfers, fillets
   - Surface finish requirements (Ra values)
   - Tolerances (IT grades, GD&T)
3. **Stock**: Define billet/plate/bar dimensions
4. **Batch size**: For cost estimation

## Phase 3: Operation Planning
Call `prism_diagnosis → genplan_plan` or build manually:
1. **Feature-to-operation mapping** via `prism_cam → cam_strategy_recommend`:
   - Pocket → adaptive roughing + parallel finishing
   - Hole → center drill + peck drill (or tap/ream)
   - Slot → trochoidal milling
   - Surface → face mill + contour finish
2. **Setup planning**: Group operations by orientation/fixture
3. **Operation sequencing** via `prism_cam → sequence_operations`:
   - Roughing before finishing
   - Large tools before small
   - Minimize tool changes
4. **Tool selection** for each operation via `prism_data → tool_recommend`

## Phase 4: Parameter Calculation
For each operation:
1. Speeds and feeds via `prism_data → speed_feed_calc`
2. Cutting forces via `prism_intelligence → what_if`
3. Safety check via `prism_safety → validate`
4. MRR and power requirements

## Phase 5: Cycle Time Estimation
1. Call `prism_intelligence → cycle_time_estimate` per operation
2. Add non-cutting time: tool changes (8s each), rapid traverse, probing
3. Add setup time estimate per fixture change
4. Total: cutting + non-cutting + setup

## Phase 6: Cost Estimation (if quote mode)
1. **Material cost**: stock volume × density × price/kg
2. **Machine cost**: cycle time × machine hourly rate
3. **Tool cost**: tool wear/life × cost per edge
4. **Labor cost**: setup time × operator rate
5. **Overhead**: shop rate multiplier
6. Per-part and batch total

## Phase 7: Machine Assignment (if --schedule)
1. Call `prism_scheduling → machine_assign` with requirements (travel, spindle, controller)
2. Check machine availability
3. Call `prism_scheduling → job_schedule` for production slot

## Phase 8: Report
```
JOB PLAN — [Part Name]
=======================
Material:    [name] ([ISO group], [hardness])
Stock:       [type] [dimensions]
Features:    [N] total ([breakdown])
Setups:      [N]

OPERATION PLAN
──────────────
Setup 1: [fixture description]
  Op 10: Face mill      T01 Ø63 face mill    RPM [N]  F [N]  [time]
  Op 20: Rough pocket   T02 Ø10 endmill      RPM [N]  F [N]  [time]
  Op 30: Finish pocket  T03 Ø6 ballnose      RPM [N]  F [N]  [time]
  Op 40: Drill 8×Ø6.8  T04 Ø6.8 carbide     RPM [N]  F [N]  [time]
  Op 50: Tap 8×M8       T05 M8 spiral flute  RPM [N]  F [N]  [time]

TOOL LIST
─────────
[N] tools required

CYCLE TIME
──────────
Cutting:     [N] min
Non-cutting: [N] min
Setup:       [N] min
TOTAL:       [N] min

COST ESTIMATE (qty: [N])
────────────────────────
Material:  $[N]
Machine:   $[N]
Tooling:   $[N]
Labor:     $[N]
─────────────────
Per part:  $[N]
Batch:     $[N]

MACHINE: [assigned machine] (if --schedule)
SLOT:    [scheduled date/time]
```
