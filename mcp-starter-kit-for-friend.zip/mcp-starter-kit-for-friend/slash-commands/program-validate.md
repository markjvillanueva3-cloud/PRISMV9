# Program Validate — CNC G-Code Verification Pipeline

Validate G-code programs before submission to machine: syntax, safety, collisions, envelope, and optimization suggestions.

## Args: $ARGUMENTS
- `[file-path]`: validate a G-code file
- `--controller=[fanuc|haas|siemens|heidenhain|mazak|okuma]`: specify controller (auto-detect if omitted)
- `--strict`: treat warnings as errors
- `--optimize`: also run optimization pass
- `--envelope=[machine-name]`: check against machine travel limits

## Phase 1: Smart Config
1. Complexity: MODERATE
2. Domain: CNC Programming + Safety
3. Roles: CNC Programmer + Safety Engineer
4. Model: SONNET
5. Effort: MEDIUM

## Phase 2: Load and Parse
1. Read the G-code file
2. Auto-detect controller dialect from safe start block / program header:
   - O-number → Fanuc/Haas/Mazak
   - `%_N_` → Siemens
   - `BEGIN PGM` → Heidenhain
3. Count lines, tool changes, operations
4. Extract program metadata (program number, comments, date)

## Phase 3: Syntax Validation
Call `prism_cam → post_process` with validation mode or use GCodeValidationEngine:
1. **Modal state tracking**: G90/G91 (abs/inc), G17/18/19 (plane), G20/G21 (units)
2. **Tool change integrity**: T-word before M06, tool length offset (G43) after change
3. **Spindle validation**: M03/M04 before cutting, reasonable RPM range
4. **Feed rate**: No cutting without F-word, reasonable range for material
5. **Coolant**: M07/M08 before cutting ops, M09 at end
6. **Safe start block**: Must include G90 G80 G40 G49 G17

## Phase 4: Safety Checks
1. Call `prism_cam → collision_check_full` with parsed moves and machine bodies
2. **Rapid moves**: Check all G00 moves avoid stock/fixture bounds
3. **Clearance plane**: Verify retract heights above stock top
4. **Spindle overload**: Estimate cutting forces from feed/speed/DOC, check against machine power
5. **Tool breakage risk**: Check plunge feeds, pecking depth, chip evacuation
6. **Arc validation**: Check I/J/R consistency, radius bounds

## Phase 5: Envelope Check (if --envelope)
1. Load machine specs via `prism_data → machine_get`
2. Parse all axis positions (X, Y, Z, A, B, C)
3. Check against machine travel limits
4. Flag any over-travel with move number and coordinates

## Phase 6: Optimization (if --optimize)
1. Call `prism_cam → toolpath_simulate` for cycle time estimate
2. Identify redundant moves (consecutive rapids to same position)
3. Suggest feed rate improvements based on material/tool
4. Identify unnecessary dwells or tool changes
5. Calculate potential time savings

## Phase 7: Report
```
PROGRAM VALIDATION — [filename]
================================
Controller: [detected/specified]
Lines:      [N]
Tools:      [N]
Operations: [N]

SYNTAX          [PASS/FAIL]
  [✓/✗] Safe start block
  [✓/✗] Modal state consistency
  [✓/✗] Tool change sequence
  [✓/✗] Feed rate declarations
  [✓/✗] Spindle commands

SAFETY          [PASS/FAIL]
  [✓/✗] Rapid move safety
  [✓/✗] Clearance plane verification
  [✓/✗] Arc geometry valid
  [✓/✗] No collision detected
  Warnings: [N]

ENVELOPE        [PASS/FAIL/SKIPPED]
  X: [min]..[max] (limit: [machine limit])
  Y: [min]..[max]
  Z: [min]..[max]

OPTIMIZATION    [if requested]
  Current cycle time:  [N] sec
  Potential savings:   [N] sec ([%])
  Suggestions: [N]

VERDICT: [SAFE TO RUN / REVIEW REQUIRED / DO NOT RUN]
```
