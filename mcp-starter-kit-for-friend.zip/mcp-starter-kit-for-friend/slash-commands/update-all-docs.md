# Update All Documents

You are performing a comprehensive documentation refresh across the entire PRISM system. This ensures all docs, counts, references, and state files reflect the current reality of the codebase.

## Args: $ARGUMENTS
- Empty: update everything
- `counts`: update counts only (fast)
- `claude`: update CLAUDE.md files only
- `master`: update MASTER_INDEX_COMPACT.md only
- `position`: update CURRENT_POSITION.md only
- `memory`: update MEMORY.md only
- `dry-run`: show what would change without making changes

## Documents to Update

### 1. MASTER_INDEX_COMPACT.md (`C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md`)
- Count all dispatchers: `src/tools/dispatchers/*Dispatcher.ts`
- Count all engines: `src/engines/*.ts` (exclude index/test)
- Count all algorithms: `src/algorithms/*.ts`
- Count all hooks: from hook registry
- Count all cadences: `src/cadences/*.ts`
- Count all actions: sum from all dispatcher files
- Verify all listed products still exist on disk
- Add any products on disk that aren't listed
- Update the header summary counts

### 2. Root CLAUDE.md (`C:/PRISM/CLAUDE.md`)
- Update any milestone counts referenced
- Update any architecture counts (layers, dispatchers, engines)
- Verify all file path references are still valid
- Update the swarm/orchestration section if system changed

### 3. MCP Server CLAUDE.md (`C:/PRISM/mcp-server/CLAUDE.md`)
- Update: milestone count (X/Y complete)
- Update: dispatcher count
- Update: action count
- Update: engine count
- Update: algorithm count
- Update: test count
- Verify build command and output format

### 4. Engines CLAUDE.md (`C:/PRISM/mcp-server/src/engines/CLAUDE.md`)
- Update: total engine count
- Update: engine category breakdown
- Verify AtomicValue pattern documentation matches reality

### 5. Dispatchers CLAUDE.md (`C:/PRISM/mcp-server/src/tools/dispatchers/CLAUDE.md`)
- Update: total action count
- Update: dispatcher count
- Verify parameter normalization pattern documentation

### 6. CURRENT_POSITION.md (`C:/PRISM/state/CURRENT_POSITION.md`)
- Update: roadmap version
- Update: milestone completion counts (total, per-track)
- Update: available tracks table
- Update: open findings counts
- Refresh: last session notes

### 7. MEMORY.md (`~/.claude/projects/C--Windows-System32/memory/MEMORY.md`)
- Update: verified counts section
- Update: milestone counts
- Update: test suite count
- Update: slash command list if new ones were added
- Keep under 200 lines (truncation happens after that)

### 8. roadmap-index.json Header (`C:/PRISM/mcp-server/data/roadmap-index.json`)
- Recalculate: `total_milestones` from actual entries
- Recalculate: `completed_milestones` from entries with status "complete"
- Verify: version number

## Execution Protocol
1. **Gather ground truth**: Count everything from the filesystem and code
2. **Read each document**: Load current content
3. **Diff**: Compare stated values against ground truth
4. **Report drift**: Show what's wrong before fixing
```
DOCUMENT DRIFT REPORT
=====================
MASTER_INDEX_COMPACT.md:
  engines: says 74, actual 171 — STALE
  dispatchers: says 45, actual 45 — OK
  ...

mcp-server/CLAUDE.md:
  milestones: says 54/80, actual 61/90 — STALE
  actions: says 684, actual 1060 — STALE
  ...
```
5. **Fix**: Update each document with correct values
6. **Verify**: Re-read and confirm all values match
7. **Summary**:
```
DOCS UPDATED
=============
[N] documents updated
[N] values corrected
[N] documents were already current

All documents now reflect system reality.
```

## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
