# Bid to Win — Smart Competitive Quoting Pipeline

Most shops either leave money on the table (bid too low) or lose jobs (bid too high). This command finds the TRUE cost floor using physics, then positions your quote at the optimal price point considering market conditions, your shop's strengths, and competitive dynamics.

**Value**: Winning 2-3 more jobs/month at proper margins = $5,000-50,000+/month additional revenue. Avoiding underbids that lose money = survival.

## Args:
- Part description + quantity (e.g., "6061-T6 housing, 50 pcs, ±0.001")
- `competitive`: emphasize winning over margin
- `premium`: emphasize margin over winning (for complex/specialty work)
- `rush`: add rush pricing multipliers
- `repeat`: returning customer pricing

## Phase 1: True Cost Floor (Physics-Based)
Calculate the absolute minimum cost using physics — no padding, no guessing.

1. `/material-price` — current market material cost
   - Today's price per lb/kg (not catalog prices from 6 months ago)
   - Alloy surcharge if applicable
   - Minimum order quantity impact

2. `/stock-optimize` — optimal blank with minimum waste
   - Best standard size to minimize buy-to-fly
   - Nesting if multiple parts per blank

3. Run `ultimateSpeedFeedEngine.calculate()` for ALL operations:
   - Aggressive parameters = minimum possible cycle time
   - Power/torque verified against machine limits
   - This is the physics floor — no shop actually runs this fast

4. `/wear-analysis` — tool cost at aggressive parameters
   - Tool life at the physics floor
   - Cost per part (tool price ÷ parts per tool)

5. `/secondary-ops` — finishing costs at volume
   - Anodize, heat treat, plating at bulk rates
   - Inspection costs (CMM time, certifications)

**TRUE COST FLOOR**: material + minimum cycle time × rate + tools + secondary ops
This is what a perfectly optimized shop with zero overhead would charge.

## Phase 2: Realistic Cost Calculation
Add real-world factors:

1. **Practical cycle time** (balanced parameters, not aggressive):
   - 15-30% longer than physics floor
   - Accounts for: tool changes, deburring, measurement pauses

2. **Setup cost**:
   - Estimated setup time based on operation count and complexity
   - Fixture cost if custom workholding needed
   - Programming cost if new program needed

3. **Overhead allocation**:
   - Machine rate (includes rent, utilities, maintenance)
   - Labor rate (operator + programming)
   - Quality overhead (inspection, documentation)

4. **Risk premium**:
   - Material difficulty factor (titanium/Inconel = higher)
   - Tolerance tightness factor (±0.0001 = higher)
   - Complexity factor (5-axis, thin walls = higher)
   - First-article risk (new part = higher)

## Phase 3: Price Positioning
Determine optimal bid price:

### Cost Stack:
```
Material:           $[X] ([X]% of total)
Machining:          $[X] ([X]% — [X] min at $[rate]/hr)
Tooling:            $[X] ([X]%)
Setup (amortized):  $[X] ([X]%)
Secondary ops:      $[X] ([X]%)
Quality/inspection: $[X] ([X]%)
────────────────────────────────
COST:               $[X] per part
```

### Pricing Strategy:
| Strategy | Markup | Price/Part | Margin | When |
|----------|--------|-----------|--------|------|
| Floor (break-even) | 0% | $[X] | 0% | Never — but know this number |
| Competitive | 15-25% | $[X] | [X]% | Commodity work, price-sensitive customer |
| Standard | 30-45% | $[X] | [X]% | Normal work, fair market |
| Premium | 50-80% | $[X] | [X]% | Complex/tight tolerance/rush/specialty |
| Walk-away | — | <$[X] | <15% | Don't take the job below this |

### Price Breaks (standard markup):
| Quantity | Price/Part | Total | Setup% | Savings vs 1pc |
|----------|-----------|-------|--------|----------------|
| 1 | $[X] | $[X] | [X]% | baseline |
| 10 | $[X] | $[X] | [X]% | -[X]% |
| 50 | $[X] | $[X] | [X]% | -[X]% |
| 100 | $[X] | $[X] | [X]% | -[X]% |
| 500 | $[X] | $[X] | [X]% | -[X]% |

## Phase 4: DfM Feedback (Win the Relationship)
Even if you don't win the bid, useful DfM feedback builds trust for next time:

1. Identify design changes that would reduce cost:
   - Loosen tolerance where possible (±0.005 vs ±0.001 = 40% less)
   - Increase corner radii (standard tool vs special)
   - Eliminate unnecessary features
   - Suggest material alternatives
2. Quantify each suggestion: "If you change X, saves $Y per part"

## Output Summary
```
BID TO WIN — [Part Description]
==================================
Quantity:     [N] pcs
Material:     [name] ($[X]/lb)
Complexity:   [LOW/MEDIUM/HIGH]

COST ANALYSIS:
  Physics floor:     $[X]/part (theoretical minimum)
  Realistic cost:    $[X]/part (your shop, balanced params)

RECOMMENDED BID:
  Strategy:          [Competitive/Standard/Premium]
  Price per part:    $[X] at [N] qty
  Margin:            [X]%
  Walk-away below:   $[X] (15% margin floor)

PRICE BREAKS:
  1 pc: $[X] | 10: $[X] | 50: $[X] | 100: $[X] | 500: $[X]

COMPETITIVE EDGE:
  Your cycle time:   [X] min (optimized)
  Typical shop:      ~[X] min (estimated)
  Your advantage:    [X]% faster → $[X]/part cost advantage

DfM OPPORTUNITIES:
  [N] suggestions that could save customer $[X]/part total

WIN PROBABILITY: [HIGH/MEDIUM/LOW] at recommended price
```

## Key Engines Used
UltimateSpeedFeedEngine, CycleTimeEstimatorEngine, MaterialDatabaseEngine,
AdvancedWearPhysicsEngine, SustainabilityLCAEngine, ProcessCapabilityEngine
