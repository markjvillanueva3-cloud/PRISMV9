# Scripts — PRISM Script Manager

You are managing the Python scripts in the PRISM project. This command discovers, lists, runs, and validates scripts across all subdirectories of `C:/PRISM/scripts/`. It handles the correct Python path, WMI deadlock fix, and result capture.

## Args: $ARGUMENTS
- Empty: list all scripts organized by category
- `[name]`: find and run the named script (partial match supported)
- `run [name]`: explicit run mode
- `list`: list all scripts with line counts and descriptions
- `category [name]`: list scripts in a specific category (core, validation, audit, etc.)
- `validate`: syntax-check all scripts without running them
- `results [name]`: show cached results from last run
- `info [name]`: show script details (imports, functions, line count)

## Configuration
- **Python path**: `C:/Users/Admin.DIGITALSTORM-PC/AppData/Local/Programs/Python/Python312/python.exe`
- **Scripts root**: `C:/PRISM/scripts/`
- **WMI fix**: Required for scripts importing CadQuery or ezdxf (pre-populate `_platform._uname_cache`)

## Step 1: Discover Scripts
Scan `C:/PRISM/scripts/` recursively for `.py` files. Organize by directory:

```
PRISM SCRIPTS
=============
Category        | Scripts | Description
----------------|---------|------------------------------------------
core/           | [N]     | Infrastructure (logger, utils, state, MCP proxies)
validation/     | [N]     | Schema validation, physics consistency
extraction/     | [N]     | Monolith indexing, module extraction
audit/          | [N]     | Utilization reports, gap finding, schema checks
batch/          | [N]     | Batch processing, material enhancement
testing/        | [N]     | Test suites, regression, diagnostics
agents/         | [N]     | Agent definitions, orchestration
automation/     | [N]     | Templates, git management, cleanup
tools/          | [N]     | Tools database generation
Root            | [N]     | Standalone scripts (registry builder, etc.)
_archive/       | [N]     | Archived/superseded scripts
```

If args = `list` or empty, stop here.

## Step 2: Find Script
When running a specific script:
1. Search for exact filename match in `C:/PRISM/scripts/` (recursive)
2. If no exact match, try partial match (e.g., "accuracy" matches `materials_deep_accuracy_v2.py`)
3. If multiple matches, list them and ask which one
4. If no match, report: "No script matching '[name]'. Available: [suggestions]"

## Step 3: Analyze Script
Before running, quick-analyze the script:
1. Read first 50 lines for imports and docstring
2. Check for `__main__` guard
3. Identify dependencies (CadQuery, ezdxf, numpy, etc.)
4. Check if WMI fix is needed (imports platform, CadQuery, or ezdxf)
5. Estimate run time based on complexity

```
SCRIPT INFO: [filename]
  Path:         [full path]
  Lines:        [N]
  Category:     [directory]
  Dependencies: [list]
  WMI fix:      [NEEDED / NOT NEEDED]
  Runnable:     [YES — has __main__ / NO — library module]
```

If args = `info [name]`, stop here.

## Step 4: Run Script
Execute the script with proper configuration:
1. Set working directory to `C:/PRISM/scripts/`
2. Use the configured Python path
3. If WMI fix needed, set environment variables:
   ```
   COMPUTERNAME=%COMPUTERNAME%
   PROCESSOR_ARCHITECTURE=%PROCESSOR_ARCHITECTURE%
   ```
4. Run with timeout (default: 120s, materials scripts: 300s)
5. Capture stdout and stderr separately
6. Save results to `C:/PRISM/state/script_results/[name]_[timestamp].txt`

## Step 5: Report Results
```
SCRIPT RUN: [filename]
======================
Exit code:  [0 / non-zero]
Duration:   [N]s
Output:     [summary — first 20 lines or key metrics]

[If materials accuracy script]:
  Subcategory:  [X]% SUBCATEGORY_SPECIFIC
  Composition:  [X]% ([N]/[M])
  Errors:       [N]
  Baseline:     81.5% / 83.5% / 0 errors
  Regression:   [NONE / WARNING — describe]

Results saved: C:/PRISM/state/script_results/[name]_[timestamp].txt
```

## Validate Mode (`/scripts validate`)
Syntax-check all scripts without running:
1. For each `.py` file (excluding `_archive/`):
   - Run `python -m py_compile [file]`
   - Report: PASS or FAIL with error
2. Summary:
```
SCRIPT VALIDATION
=================
Checked:  [N] scripts
Passed:   [N]
Failed:   [N]
  - [file1]: [error]
  - [file2]: [error]
Skipped:  [N] (archived)
```

## Error Handling
- **Python not found**: Check configured path, suggest alternatives
- **Import error**: Report missing dependency and suggest `pip install`
- **WMI deadlock**: Apply the cache fix automatically (set env vars)
- **Timeout**: Kill process, report partial output, suggest longer timeout
- **Script has no __main__**: Report "This is a library module, not directly runnable"

## Known Scripts (baselines)
- `materials_deep_accuracy_v2.py` — Target: 81.5% subcategory, 83.5% composition, 0 errors
- `alloy_physical_properties_db.py` — Library: 415 alloys, ~4500 lines
- `alloy_compositions_db.py` — Library: 700+ compositions
- `regression_checker.py` — Runs regression suite against known baselines

## Chaining
- After materials work: `/scripts run accuracy` → verify no regression
- After engine changes: `/scripts run regression` → check for breaks
- Audit scripts: `/scripts validate` → ensure all scripts parse
- Pairs with: `/test` (TS/JS tests), `/health` (system overview), `/forge-materials` (materials pipeline)
