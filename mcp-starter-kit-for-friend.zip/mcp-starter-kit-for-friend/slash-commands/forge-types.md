# Forge Types — TypeScript Type Coverage Analyzer

You are running a specialized autopilot pipeline that analyzes TypeScript type coverage across the PRISM MCP server, identifies weak typing patterns, and optionally strengthens them. Designed to run in the **background** for analysis, with optional interactive fix mode.

## Args: $ARGUMENTS
- Empty: full scan — all source files for type coverage
- `[file-path]`: analyze a specific file
- `[subsystem]`: focus on dispatchers, engines, algorithms, hooks, utils, types
- `fix`: analyze AND apply type fixes (non-background — interactive)
- `report`: analysis only, no fixes (default, background-safe)
- `strict`: flag ALL `any` usage, not just excessive


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` -- loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` -- zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` -- resolve E0001->path instantly (1,865 indexed files)


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (`/smart` protocol)
1. Complexity: MODERATE (pattern matching + type inference)
2. Domain: TypeScript Engineering + Type System Design
3. Roles: Senior TypeScript Engineer + Type System Architect
4. Model: SONNET (systematic scanning) / OPUS (if `fix` mode — type design requires reasoning)
5. Effort: MEDIUM (report) / HIGH (fix)

## Phase 2: YOLO Mode (`/yolo-mode` protocol)
Activate maximum velocity — no proceed questions, autonomous decisions, continuous flow.

## Phase 3: Type Coverage Analysis

### 3A: Scan Source Files
Glob `C:/PRISM/mcp-server/src/**/*.ts` (exclude `__tests__`, `node_modules`, `dist`, `*.d.ts`)

For each file, extract:
- `any` type count (explicit `: any`, `as any`, `<any>`)
- `unknown` type count (good — shows intentional uncertainty)
- Return type annotations present vs missing
- Parameter type annotations present vs missing
- Type assertion count (`as T` patterns)
- Generic type usage count
- Interface/type alias definitions
- Function count (total and typed percentage)

### 3B: Weakness Classification

**CRITICAL — Type Safety Holes:**
- `as any` casts (bypass type checker entirely)
- `Function` type (untyped callable)
- `object` type without narrowing
- Return type `: any` on exported functions
- `@ts-ignore` / `@ts-expect-error` without justification comment

**MAJOR — Weak Typing:**
- Parameter `: any` (accept anything)
- Generic `T extends any` (unconstrained)
- `Record<string, any>` (unstructured data)
- Missing return types on exported functions
- Index signatures `[key: string]: any`

**MINOR — Type Improvement Opportunities:**
- `as T` assertions that could be type guards instead
- Inline types that could be extracted to interfaces
- Repeated type patterns that could use generics
- Optional chains (`?.`) that could use discriminated unions
- String literal types that could be enums

### 3C: Per-File Scoring
Type Coverage Score = `(typed_constructs / total_constructs) * 100`

Where constructs = function params + return types + variable declarations + property types

Classify files:
- **STRONG** (90-100%): Well-typed, minimal `any`
- **GOOD** (75-89%): Mostly typed, a few gaps
- **WEAK** (50-74%): Significant gaps, needs attention
- **POOR** (<50%): Heavily untyped, priority target

### 3D: Subsystem Rollup
Aggregate by directory:
```
SUBSYSTEM         | Files | Score | any | Assertions | Missing Returns
------------------|-------|-------|-----|------------|----------------
dispatchers/      |   45  |  72%  | 156 |     34     |      12
engines/          |  125  |  68%  | 243 |     67     |      45
algorithms/       |   50  |  81%  |  42 |     18     |       8
hooks/            |  220  |  74%  | 198 |     56     |      33
types/            |   --  | 100%  |   0 |      0     |       0
utils/            |   15  |  65%  |  34 |     12     |       9
TOTAL             |  455  |  72%  | 673 |    187     |     107
```

## Phase 4: Fix Mode (only if args include `fix`)

### 4A: Priority Fix Targets
Rank files by: `(any_count * 3 + missing_returns * 2 + assertions) / total_lines`

Take top 10 worst files.

### 4B: Type Inference
For each `any` in target files:
1. Trace the value's origin — what data flows into this variable?
2. Check if a type already exists in `src/types/` that fits
3. If not, design a minimal type that covers the actual usage
4. Replace `any` with the concrete type

### 4C: Return Type Addition
For exported functions missing return types:
1. Analyze all return paths
2. Infer the narrowest type that covers all paths
3. Add explicit return type annotation

### 4D: Validation
After fixes:
1. Run `npx tsc --noEmit` — must have zero NEW errors
2. Run `npm test` — all existing tests must still pass
3. Verify no behavioral changes — types are annotations, not runtime

## Phase 5: Forge Postflight (`/forge-postflight types`)
1. **Gate 1 — DSL**: CONDITIONAL — if engine return types were fixed, verify AtomicValue compliance
2. **Gate 2 — Matrix**: SKIP (no new products)
3. **Gate 3 — Trace**: SKIP (type changes don't affect wiring)
4. **Gate 4 — Sync**: RUN — update type coverage metrics
5. **Gate 5 — Memory**: RUN — update MEMORY.md with coverage scores
6. **Gate 6 — Hookify**: SKIP

## Phase 6: Auto-Commit (fix mode only)
`refactor(types): strengthen [N] type annotations across [subsystems] [FORGE-TYPES]`

## Summary Report
```
FORGE TYPES COMPLETE
====================
Scanned:    [N] files across [M] subsystems
Coverage:   [X]% overall (was [Y]%)
any count:  [N] total ([+/-M] from baseline)
CRITICAL:   [N] type safety holes
MAJOR:      [N] weak typing patterns
Fixed:      [N] types (or "report only")
Worst:      [file] ([score]% coverage, [N] any)
Next:       /forge-types fix to strengthen, or fix manually
```

## Error Handling
- **Build fails after fix**: Revert fix, report as "unfixable without refactoring"
- **Circular type dependencies**: Flag but don't fix — requires architectural decision
- **Context budget**: Run quick mode — top-level counts per subsystem only
- **Generic inference too complex**: Leave as `any` with a TODO comment explaining why

## Safety Rails
- In report mode: NEVER modify any files
- In fix mode: NEVER change runtime behavior — types are compile-time only
- Never remove `@ts-expect-error` without fixing the underlying error
- Never add `any` to fix type errors — that defeats the purpose
- Preserve all existing type narrowing and guards
- Safety-critical files get type additions but NEVER type changes
