# Engine Browse — PRISM Engine Explorer

Search, filter, and explore PRISM's 200+ calculation engines by domain, name, or capability.

## Args: $ARGUMENTS
- Empty: show engine inventory summary by domain
- `[search-term]`: search engines by name or keyword (e.g., `force`, `thermal`, `grinding`)
- `[domain]`: list engines in a domain (cutting, thermal, safety, material, tool, coolant, surface, machine, cad, workholding, edm, threading, process)
- `[engine-name]`: show detailed info for a specific engine (inputs, outputs, methods)
- `wired`: show only engines wired to dispatchers
- `unwired`: show only engines NOT wired to any dispatcher
- `count`: show engine count by domain


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config
```
SMART CONFIG
Role:   Systems Architect
Model:  HAIKU
Effort: LOW
Reason: Read-only exploration, no code changes
```

## Phase 2: Engine Discovery

### If empty args — Domain Summary
1. Glob `C:/PRISM/mcp-server/src/engines/*.ts` (exclude index.ts, reactiveChainBootstrap.ts) (PREFER: use ENGINE_DIGEST.md instead of Glob)
2. Categorize by keyword matching into domains:
   - **Cutting**: force, speed, feed, power, torque, chip, cutting, drill, tap, bore, mill, turn
   - **Thermal**: thermal, heat, cool, temperature, cryo
   - **Safety**: safety, collision, protection, breakage, spindle
   - **Material**: material, machinability, hardness, equivalence, tensile, microstructure
   - **Tool**: tool, wear, deflection, assembly, crib, holder
   - **Surface**: surface, finish, roughness, recast, white, shot, anodize, plating, passivation, masking
   - **Workholding**: workhold, chuck, clamp, fixture, vise, tombstone, magnetic, steady, tailstock, soft jaw
   - **EDM**: edm, electrode, wire, recast, micro_edm
   - **Threading**: thread, single_point, tap
   - **Machine**: kinematic, rtcp, singularity, tilt, envelope, oee, machine_select, probe
   - **CAD/CAM**: geometry, mesh, feature, stock, nesting, cad, cam, gcode, toolpath, post
   - **Process**: process, plan, batch, optimization, scheduling, cost, quote
   - **Other**: everything else (AI, auth, config, event, etc.)
3. Output:
```
PRISM ENGINE INVENTORY
======================
Domain         | Count | Examples
---------------|-------|------------------
Cutting        | [N]   | TurningForceEngine, DrillBreakthroughForceEngine, ...
Thermal        | [N]   | ThermalGrowthCompensationEngine, ...
...
TOTAL          | [N]   engines
```

### If search term — Keyword Search
1. Glob engines, filter filenames containing the search term (case-insensitive)
2. For each match, read first 10 lines to get the docstring summary
3. Output: name, file, 1-line description

### If domain — Domain List
1. Filter engines by domain keyword matching
2. For each, read first 5 lines for description
3. Output: name, description, line count

### If specific engine name — Detail View
1. Find the engine file
2. Read the full file
3. Extract: class name, exported types, public methods, constructor params
4. Check dispatcher wiring (grep dispatchers for engine import)
5. Check test coverage (grep tests for engine import)
6. Output:
```
ENGINE: [ClassName]
File:    [path] ([N] lines)
Domain:  [domain]
Methods: [list with signatures]
Types:   [exported interfaces/types]
Wired:   [dispatcher:action] or "UNWIRED"
Tests:   [test file] or "NO TESTS"
```

### If `wired` or `unwired`
1. Grep all dispatchers for engine imports
2. Cross-reference with full engine list
3. Output wired/unwired list with dispatcher mapping

## Output Format
Keep output concise — this is a browsing tool, not an audit. Use tables where possible.
