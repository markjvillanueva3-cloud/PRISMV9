# Token Budget — Check and optimize context usage

Analyze current context budget and suggest optimizations.

## Steps
1. Use OutputBudgetEngine.estimateTokens() on recent tool outputs
2. Check if any outputs exceeded the "compact" preset (1500 chars)
3. Suggest field filtering or array summarization for large results
4. Report: total estimated tokens used, top consumers, savings possible

## Output Format
```
CONTEXT BUDGET
==============
Estimated tokens used: [N]
Largest outputs: [list top 3]
Optimization: [suggestions]
```
