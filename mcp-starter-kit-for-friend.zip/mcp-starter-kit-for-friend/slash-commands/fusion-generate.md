# Fusion Generate — Create Parts in Fusion 360

Generate Fusion 360 Python API scripts from descriptions, or control Fusion 360 directly via the live bridge.

## Args: $ARGUMENTS
- A description of the part to create (natural language)
- Optional: `--parametric` (create user parameters for all dimensions)
- Optional: `--live` (send directly to Fusion 360 via PRISM Bridge add-in)
- Optional: `--from-video path.mp4` (extract from tutorial video)
- Optional: `--from-cadquery "cq.Workplane('XY').box(50,30,25)"` (convert CadQuery)

## Modes

### Mode 1: Script Generation (default)
Generates a complete Python script you paste into Fusion 360's script editor.
```
/fusion-generate Create a 50x30mm rectangle, extrude 25mm, fillet vertical edges 3mm
```
Output: A complete Python script with `run(context)`, try/except, unit conversion.

### Mode 2: Live Bridge (`--live`)
Sends commands directly to Fusion 360 in real-time (requires PRISM Bridge add-in running).
```
/fusion-generate --live Create a mounting bracket with 4 holes
```

### Mode 3: Video-to-Fusion 360 (`--from-video`)
Watch a tutorial video and generate the Fusion 360 script to reproduce it.
```
/fusion-generate --from-video tutorial.mp4
```

### Mode 4: CadQuery Conversion (`--from-cadquery`)
Convert existing CadQuery code to Fusion 360 API.

## Setup for Live Bridge

1. Copy `C:/PRISM/mcp-server/scripts/fusion360-addin/` to:
   `%APPDATA%/Autodesk/Autodesk Fusion 360/API/AddIns/PRISMBridge/`
2. In Fusion 360: Utilities → Add-Ins → PRISMBridge → Run
3. Server starts on http://localhost:18360
4. Use `--live` flag to send commands directly

## Execution

```
Smart: CAD ENGINEER + PYTHON ENGINEER | OPUS | HIGH
```

### Step 1: Parse Input
- If `--live`: check Fusion 360 bridge connection via GET /health
- If `--from-video`: run video action extraction pipeline
- If `--from-cadquery`: parse CadQuery script
- Otherwise: parse natural language description

### Step 2: Generate Actions
Use VideoActionExtractorEngine.classifyAction() on each parsed operation to create ExtractedAction[].

### Step 3: Generate Script or Execute Live
**Script mode:**
```typescript
const script = fusion360CodeGeneratorEngine.generateScript(actions, { parametric: hasFlag('--parametric') });
```
Display the script for user to paste into Fusion 360.

**Live mode:**
```typescript
const result = await fusion360LiveBridgeEngine.executeActions(actions);
```
Report real-time results from Fusion 360.

### Step 4: Verify
If live mode: call GET /geometry to report final geometry metrics.
If script mode: validate script and warn about potential issues.

## Examples

Simple box:
```
/fusion-generate box 50x30x25mm with 3mm fillets on vertical edges
```

Mounting bracket:
```
/fusion-generate Create a 100x60x8mm plate. Add four M6 through holes at corners (10mm from edges). Extrude two 30mm tall support ribs along the length, 5mm thick. Fillet all edges 1mm.
```

From video:
```
/fusion-generate --from-video C:/tutorials/bracket-tutorial.mp4 --parametric
```

## Engines Used
Fusion360CodeGeneratorEngine, Fusion360LiveBridgeEngine, VideoActionExtractorEngine,
VisionActionAnalyzerEngine (for video mode)
