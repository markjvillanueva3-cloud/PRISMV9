---
effort: high
maxTurns: 25
---

# PRISM Review — Dual-Perspective Multi-Role Code Review

Run PRISM-specific code review on recent changes. Dispatches specialized review agents SEQUENTIALLY (one at a time), each with a domain-appropriate role. Uses **dual-perspective rubric evaluation** where independent reviewers evaluate against identical criteria from `H:/prism/.claude/helpers/review-rubric.json`. Findings are merged via `H:/prism/.claude/helpers/review-merge.mjs`.

**Agent count: 3 (standard), 1 (quick).** Keep agent count low to avoid API rate limits. Physics agent uses `model: "sonnet"` (needs formula verification capability). Wiring + Test agents use `model: "haiku"` (sufficient for structural checks). If an agent spawn fails with a rate limit error, perform that review pass INLINE instead of retrying.

## Args: $ARGUMENTS
- Empty: review all uncommitted changes
- `[file-path]`: review a specific file or directory
- `[milestone-id]`: review all changes for a milestone
- `quick`: single-agent abbreviated review

## Step 1: Determine Review Scope
Same as /scrutinize: git diff, staged, specific file, or milestone changes.

## Step 2: Detect Domain
Analyze the files being reviewed to determine which DOMAIN the changes belong to:

```
DOMAIN DETECTION (by file path + content):
  PHYSICS:     src/engines/*Force*, *Thermal*, *Chatter*, *Deflection*, *Wear*, *Surface*,
               src/physics/*, src/algorithms/*, *Kienzle*, *Taylor*, *Johnson*
  CAM:         src/engines/*Toolpath*, *Strategy*, *CAM*, *Post*, *GCode*, *Program*
  BUSINESS:    src/engines/*Cost*, *Quote*, *ERP*, *Schedule*, *OEE*, *ROI*, *Price*,
               *Inventory*, *Order*, *Capacity*, *Planning*, *Budget*
  QUALITY:     src/engines/*SPC*, *Quality*, *Inspection*, *Measurement*, *Cpk*
  LEARNING:    src/engines/*Learn*, *Knowledge*, *Tribal*, *Playbook*, *Video*, *PDF*
  INFRA:       src/tools/dispatchers/*, src/registries/*, src/schemas/*, hooks/*
  FUSION:      src/engines/PhysicsFusion*, src/engines/plugins/*
  MIXED:       multiple domains detected
```

## Step 3: Select Review Roles (DOMAIN-ADAPTIVE, FLEXIBLE COUNT)
Based on detected domain and scope, determine how many agents to launch:

**Agent count heuristic (RATE-LIMIT SAFE):**
- Any scope: **3 agents max** (one per review dimension: domain, wiring, tests)
- Quick mode: **1 agent** (single inline pass)
- NEVER spawn more than 3 agents — API rate limits will cause failures
- ALL agents MUST use `model: "haiku"` parameter (higher rate limits, sufficient for review)

Select roles from domain pools below. For MIXED domains, combine roles from all detected domains:

### PHYSICS domain (pool of 5 — use 3-5 based on scope):
- **Senior CNC Machinist** (25yr): Shop floor reality, interrupted cuts, controller limits, novice blind spots
- **Manufacturing Physics PhD**: Formula correctness, convergence, dimensional analysis, published reference data
- **Numerical Methods Specialist**: Convergence math, adaptive relaxation, stochastic correctness, stability
- **Systems Architect**: Wiring, performance, state management, regression risk
- **Materials Scientist**: Material property accuracy, ISO group classification, thermal/mechanical coupling

### CAM domain (pool of 5):
- **CAM Applications Engineer**: Strategy selection, toolpath quality, post processor correctness, controller dialect
- **CNC Programmer** (production shop): Cycle time, tool life impact, G-code readability, machine compatibility
- **Post Processor Developer**: Controller-specific G/M codes, macro calls, canned cycle correctness
- **Systems Architect**: Wiring, dispatcher integration, MCP schema correctness
- **Tooling Engineer**: Tool selection impact on strategy, holder compatibility, crib management

### BUSINESS domain (pool of 5):
- **Shop Manager / Estimator**: Cost accuracy, quote competitiveness, real-world pricing, customer expectations
- **Manufacturing Accountant**: Overhead allocation, labor rates, depreciation, margin analysis, regulatory compliance
- **ERP Integration Specialist**: Data flow, inventory accuracy, scheduling constraints, MRP logic
- **Supply Chain Manager**: Lead times, vendor management, make-vs-buy, procurement workflow
- **Production Planner**: Capacity planning, job sequencing, bottleneck identification, shift scheduling

### QUALITY domain (pool of 5):
- **Quality Engineer (CMM/SPC)**: Measurement uncertainty, Cpk interpretation, gage R&R, ISO 9001 compliance
- **Metrology Specialist**: GD&T correctness, tolerance stack-up, datum reference frames
- **PPAP/APQP Specialist**: Process capability documentation, control plans, FMEA
- **NDT Technician**: Non-destructive testing applicability, inspection method selection
- **Systems Architect**: Data persistence, audit trail, traceability requirements

### LEARNING domain (pool of 4):
- **Senior Machinist / Instructor**: Is the tip accurate? Would you teach this to an apprentice?
- **Knowledge Management Specialist**: Categorization, searchability, conflict with existing tips
- **Curriculum Designer**: Learning path coherence, prerequisite chains, skill assessment
- **Systems Architect**: Registry integration, dedup, indexing

### INFRA domain (pool of 4):
- **API/Schema Architect**: Schema correctness, backward compatibility, MCP compliance
- **Test Engineer**: Coverage, edge cases, regression risk
- **Performance Engineer**: Token cost, latency, caching, memory pressure
- **DevOps/Hook Engineer**: Hook integration, enforcement correctness, settings.json wiring

### FUSION domain (pool of 5):
- **Senior CNC Machinist**: Shop floor reality for fused physics
- **Numerical Methods PhD**: Convergence, stability, stochastic correctness
- **Pipeline Architect**: Downstream flow, per-block variability, PostProcessor integration
- **Manufacturing Physics PhD**: Cross-domain coupling correctness, formula verification
- **UX Engineer**: Novice experience, progressive disclosure, actionable suggestions

### MIXED domain:
Select the most relevant roles from ALL detected domains. For cross-domain work (e.g., physics + business), combine pools. No upper limit — use as many as needed.

## Step 4: Launch Agents SEQUENTIALLY with rubric

**CRITICAL RATE LIMIT RULES:**
- Launch agents ONE AT A TIME, waiting for each to complete before starting the next
- Do NOT use `run_in_background: true` — parallel launches cause API rate limit errors
- Physics agent: `model: "sonnet"` (needs formula verification capability)
- Wiring + Test agents: `model: "haiku"` (sufficient for structural checks, higher rate limits)
- MAX 3 agents total — more than 3 reliably triggers rate limit errors
- If ANY agent fails with a rate limit error, perform that review pass INLINE (read files yourself and check the domain) instead of retrying

**Dual-Perspective Protocol:**
Each agent reviews INDEPENDENTLY against the SAME rubric. They must NOT see each other's findings until merge.

Each agent receives:
- The files to review (full content or diff)
- Their assigned ROLE and perspective
- The 7-dimension rubric from `H:/prism/.claude/helpers/review-rubric.json`: correctness, completeness, consistency, safety, performance, physics_accuracy, shop_acceptance
- Domain context (which part of the manufacturing/business stack this touches)
- Instructions to find CRITICAL/HIGH/MEDIUM/LOW findings from their role's viewpoint
- Explicit instruction: "Be HARSH. Find what a single-perspective reviewer would miss."
- **Output format requirement**: Each agent MUST return a JSON object matching the reviewer_output_schema from review-rubric.json:
  ```json
  {
    "reviewer_role": "physics|wiring|test",
    "files_reviewed": ["path1.ts", "path2.ts"],
    "dimensions": {
      "correctness": { "verdict": "PASS|WARN|FAIL", "notes": "..." },
      "completeness": { "verdict": "PASS|WARN|FAIL", "notes": "..." },
      "consistency": { "verdict": "PASS|WARN|FAIL", "notes": "..." },
      "safety": { "verdict": "PASS|WARN|FAIL", "notes": "..." },
      "performance": { "verdict": "PASS|WARN|FAIL", "notes": "..." },
      "physics_accuracy": { "verdict": "PASS|WARN|FAIL", "notes": "..." },
      "shop_acceptance": { "verdict": "PASS|WARN|FAIL", "notes": "..." }
    },
    "findings": [
      { "severity": "CRITICAL|HIGH|MEDIUM|LOW", "file": "path.ts", "line": 42, "dimension": "...", "description": "...", "suggested_fix": "..." }
    ],
    "overall_verdict": "PASS|FAIL"
  }
  ```
- For BUSINESS domain agents: include ERP workflow context, cost model assumptions, regulatory requirements
- For PHYSICS domain agents: include published reference data, canonical constants, convergence criteria

## Step 5: Merge Findings via Dual-Perspective Protocol

Use `review-merge.mjs` to consolidate findings. The merge logic applies:

1. **Deduplication**: Findings from different reviewers about the same file+line with >50% word overlap are merged into a single finding
2. **Disputed Findings Policy** (from review-rubric.json):
   - CRITICAL/HIGH: MUST FIX even if only 1 reviewer found it
   - MEDIUM (agreed by 2+): SHOULD FIX
   - MEDIUM (disputed, only 1): DEFER with written justification
   - LOW (agreed): OPTIONAL
   - LOW (disputed): IGNORE
3. **File Criticality Weights**: engine=10, dispatcher/schema=5, test=3, utility=2, docs=1
4. **Priority Score**: `file_weight * severity_weight` — findings sorted by this

Output the consolidated report:
```
PRISM REVIEW — Dual-Perspective Report
=======================================
Domain:   [detected domain(s)]
Agents:   [N] launched | Roles: [list all]
Scope:    [N] files reviewed

Findings by Role:
  [Role 1]: [N] CRITICAL, [N] HIGH, [N] MEDIUM, [N] LOW
  [Role 2]: [N] CRITICAL, [N] HIGH, [N] MEDIUM, [N] LOW

Merged Findings (deduplicated):
  MUST FIX:    [N]
  SHOULD FIX:  [N]
  DEFERRED:    [N]
  IGNORED:     [N]

Details (sorted by priority score):
  [severity] [resolution] [file:line] — [description] (flagged by: [reviewers])
  ...

Cross-Role Insights (found by 2+ independent reviewers):
  [description] — confirmed by [role1] AND [role2]

Dimensions Summary:
  correctness:      [PASS/WARN/FAIL]
  completeness:     [PASS/WARN/FAIL]
  consistency:      [PASS/WARN/FAIL]
  safety:           [PASS/WARN/FAIL]
  performance:      [PASS/WARN/FAIL]
  physics_accuracy: [PASS/WARN/FAIL]
  shop_acceptance:  [PASS/WARN/FAIL]

Verdict: [PASS / FAIL — N MUST-FIX findings]
```

## Step 6: Auto-Fix MUST-FIX Findings
Fix all CRITICAL and HIGH findings immediately. Re-run `npx tsc --noEmit` after fixes.

## Step 7: Reset Review Gate Counter (MANDATORY)
After review completes (regardless of pass/fail), run this command to reset the engine edit counter:
```bash
bash /h/prism/.claude/helpers/review-complete.sh
```
This prevents the review-gate.sh hook from blocking future engine edits.

## Step 8: Log Review to Audit Trail
Append the review report as a JSON line to `H:/prism/.claude/cache/PRISM_REVIEW_LOG.jsonl` for audit trail.

## Quick Mode (`/prism-review quick`)
Single agent review with the most relevant role for the domain. No team dispatch. Still uses rubric dimensions.

## Chaining
- In roadmap sessions: work → `/prism-review` (3-agent) → fix findings → `/compact`
- Before committing: `/prism-review staged` → fix → `/auto-commit`
- In /rgs generated sessions: encoded as "MULTI-ROLE SCRUTINY" step before EXIT GATE
