---
description: "Review quote accuracy — compare quoted vs actual costs, track win/loss, get calibration suggestions"
---

# Quote Review — Accuracy & Analytics Dashboard

Review quoting accuracy and get suggestions for improving estimates.

## What This Does
1. Pulls accuracy metrics: quoted vs actual cost variance by category
2. Shows conversion metrics: win rate, loss reasons, customer/material breakdowns
3. Displays estimator scores if multiple estimators
4. Generates calibration suggestions based on historical bias

## Actions Used
- `analytics_accuracy` — Cost and cycle time accuracy metrics
- `analytics_conversion` — Win/loss and conversion tracking
- `analytics_calibration` — Bias detection and adjustment suggestions

## Output Format
Present a dashboard with:

### Accuracy Summary
| Metric | Value |
|--------|-------|
| Quotes with actuals | N |
| Avg cost variance | X% |
| Within 5% accuracy | N/total |
| Within 10% accuracy | N/total |
| Avg quoted margin | X% |
| Avg actual margin | X% |
| Margin erosion | X% |

### Category-Level Accuracy
Table showing avg variance by: material, machining, setup, tooling, programming, inspection

### Conversion Metrics
- Win rate, loss reasons breakdown, by-customer and by-material win rates

### Calibration Suggestions
List any categories where estimates are consistently biased, with specific adjustment recommendations.

$ARGUMENTS
