# Plan-Build — Structured Planning Before Engine Creation

Plan first, build second. This command enters plan mode, creates a structured plan for what
you're about to build, saves it to state, then exits plan mode so you can build with direction.

The enforce-plan-before-build.py hook BLOCKS new engine creation (Write to src/engines/*.ts)
unless this command was run first. This ensures every new engine is built with clear intent.

## Args: $ARGUMENTS
- `[engine name or description]`: What you're about to build
- Empty: plan for the next unit in the current roadmap session

## Step 1: Enter Plan Mode
Think through the build BEFORE writing code:

### What to Build
- Engine name, purpose, and primary methods
- Input/output interfaces (TypeScript types)
- Which existing engines it needs to call (lazy-load pattern)
- Which dispatcher action it maps to

### Knowledge Sources to Consult FIRST
Read these BEFORE writing any code (enforcement hook verifies):
- TribalKnowledgeEngine: query for domain-specific tips
- MachiningPlaybookEngine: check for anti-patterns
- FormulaRegistry: find the RIGHT formula (don't reinvent)
- MaterialRegistry: material-specific properties
- ENGINE_DIGEST.md: verify this engine doesn't already exist
- Relevant tribal tip files (src/data/*-cam-tips.ts)
- Published data: Sandvik, Kennametal, Machinery's Handbook

### Machinist-Facing Output
What does the END USER see from this engine?
- G-code output with specific coordinates?
- Decision recommendation with alternatives?
- Cost breakdown with tradeoffs?
- Warning about a risk?
The answer shapes HOW you write the logic.

### Edge Cases and Materials
- What happens with exotic materials? (Inconel, titanium, composites)
- What happens with extreme dimensions? (very small, very large)
- What happens with missing input data?
- What happens at machine limits? (max RPM, max power)

### Wiring Targets
- Which dispatcher gets the action?
- Which pipeline engine calls this?
- What's the Zod schema for the action?

## Step 2: Save Plan
Write the plan to `C:/PRISM/state/active-plan.json`:
```json
{
  "date": "YYYY-MM-DD",
  "engine": "EngineName",
  "purpose": "one-line purpose",
  "methods": ["method1", "method2"],
  "knowledge_consulted": ["source1", "source2"],
  "machinist_output": "what user sees",
  "edge_cases": ["case1", "case2"],
  "wiring": {"dispatcher": "name", "action": "name"},
  "planned_at": "ISO timestamp"
}
```

## Step 3: Exit Plan Mode and Build
After the plan is saved:
1. The enforce-plan-before-build hook will ALLOW the Write
2. Consult the knowledge sources listed in the plan
3. Build the engine following the plan
4. Run the 4-LOOP (SCRUTINIZE → GAP FILL → TIE UP)
5. FORGE-TRIPLE: create hook + MCP action + skill

## For Autopilot Mode
In autopilot, /plan-build runs automatically before each new engine:
1. Auto-generate plan from roadmap unit description
2. Auto-save to active-plan.json
3. Auto-proceed to build
No user interaction needed — the plan is generated and recorded programmatically.

## Skip Conditions
Plan mode is NOT needed for:
- Editing existing engines (bug fixes, enhancements)
- Writing test files
- Wiring changes (dispatcher edits)
- Documentation changes
The hook only fires on NEW engine creation (Write to src/engines/*.ts).
