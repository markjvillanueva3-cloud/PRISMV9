# Setup Sheet Generate — CNC Job Setup Sheet Automation

Generate complete CNC setup sheets from job parameters: material, operations, tools, work offsets, and safety notes.

## Args: $ARGUMENTS
- Empty: interactive — prompt for material, machine, operations
- `[material] [operation]`: quick setup sheet (e.g., `aluminum pocket-mill`)
- `job:[job-id]`: generate from existing job definition
- `--pdf`: export PDF via prism_export

## Phase 1: Smart Config
1. Complexity: MODERATE
2. Domain: Manufacturing Process + CNC Programming
3. Roles: Manufacturing Process Expert + CNC Programmer
4. Model: SONNET
5. Effort: MEDIUM

## Phase 2: Gather Job Parameters
1. **Material**: Look up via `prism_data → material_get` (ISO group, kc1.1, hardness, density)
2. **Operations**: Define sequence (facing → roughing → finishing → drilling → tapping)
3. **Tools**: For each operation, call `prism_data → speed_feed_calc` to get recommended tools and parameters
4. **Machine**: Get machine specs via `prism_data → machine_get` (spindle power, max RPM, travel, controller)
5. **Workholding**: Determine fixture type (vise, chuck, vacuum, custom)

## Phase 3: Calculate Parameters
For each operation in sequence:
1. Call `prism_intelligence → setup_sheet` with material, tool, and operation data
2. Call `prism_cam → sequence_operations` to optimize operation order
3. Calculate speeds/feeds per operation: RPM, feed rate, DOC, WOC, MRR
4. Call `prism_safety → validate` to check spindle power, tool deflection, chatter risk
5. Call `prism_cam → clearance_plane` for safe Z height

## Phase 4: Generate Setup Sheet
Output a structured setup sheet with:

### Header
- Part name, material, stock dimensions, machine, fixture
- Date, programmer, revision

### Tool List Table
| T# | Tool Description | Dia | Flutes | Holder | Gauge Length |
|----|-----------------|-----|--------|--------|-------------|

### Operation Sequence Table
| Op# | Description | Tool | RPM | Feed | DOC | WOC | Coolant | Notes |
|-----|------------|------|-----|------|-----|-----|---------|-------|

### Work Offset Table
| Offset | X | Y | Z | Description |
|--------|---|---|---|-------------|

### Safety Notes
- Material-specific warnings (titanium fire risk, aluminum BUE, etc.)
- Tool deflection warnings if L/D > 4
- Chatter risk assessment
- Coolant requirements

### Cycle Time Estimate
- Per-operation breakdown
- Total estimated cycle time

## Phase 5: Export (optional)
If `--pdf` flag:
1. Call `prism_export → render_setup_sheet` with structured data
2. Save PDF to output directory
3. Report file path

## Output Format
```
SETUP SHEET — [Part Name]
==========================
Material:    [name] ([ISO group])
Machine:     [name] ([controller])
Stock:       [W x H x D] mm
Fixture:     [type]
Programmer:  [name]
Date:        [date]

TOOL LIST
─────────
[table]

OPERATIONS
──────────
[table]

WORK OFFSETS
────────────
[table]

SAFETY NOTES
─────────────
[warnings]

CYCLE TIME: [estimate]
```
