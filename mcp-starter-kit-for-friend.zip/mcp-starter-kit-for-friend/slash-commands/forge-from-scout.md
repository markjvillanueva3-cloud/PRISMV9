---
effort: high
maxTurns: 30
---

# Forge From Scout — Build Scouted Capabilities Into PRISM

Takes findings from `/scout` build queue, generates a roadmap via `/rgs`, then executes
with `/forge-triple` (engine + MCP action + skill + protective hook per item).

## Args: $ARGUMENTS
- Empty: build top 3 items from queue by ROI
- `[item-name]`: build specific item from queue
- `all`: build everything in queue (careful — may be large)
- `plan`: generate roadmap only, don't execute
- `status`: show build progress

## Step 1: Load Build Queue

Read `C:/PRISM/state/scout/build-queue.json`
Filter to status="queued", sort by ROI descending.
If empty: "No items in build queue. Run /scout first."

## Step 2: Check Prerequisites

For each item to build:
1. Check ENGINE_DIGEST.md — does something similar already exist?
2. Check MASTER_INDEX.md — any overlap with existing systems?
3. If overlap found: "SKIP [item] — already covered by [existing engine]"
4. If no overlap: proceed to roadmap generation

## Step 3: Generate Roadmap via /rgs

For each item, invoke /rgs generate with a brief derived from scout data:
```
Brief: Integrate [item.name] into PRISM
  Source: [item.source_url]
  Description: [item.description]
  Type: [mcp_server | plugin | feature | tool]
  Estimated effort: [item.effort]
  Integration point: [which dispatcher/pipeline it connects to]
```

/rgs generates:
- Knowledge source mapping (what existing engines to consult)
- Phase decomposition with session boundaries
- Unit population with exit criteria
- Forge-triple requirement per milestone

## Step 4: Execute Roadmap

For each generated milestone:
1. `/pick-task [unit-id]` — claim the unit
2. Build the integration:
   - For MCP servers: install, configure, wire to PRISM dispatcher
   - For plugins: install, test, document capabilities
   - For Claude features: update settings, create slash command, document
   - For tools: evaluate, adapt patterns, build PRISM engine wrapper
3. `/forge-triple` — generate for each milestone:
   - **Engine**: wrapper or adapter engine in src/engines/
   - **MCP Action**: wire to appropriate dispatcher with Zod schema
   - **Skill/Command**: slash command for user access
   - **Protective Hook**: enforcement hook to prevent degradation
4. Run tests — verify integration works
5. `/scrutinize` — quality review
6. Update build-queue.json status → "complete"
7. `/compact` after every 2-3 units

## Step 5: Update Registry

After building:
1. Run MASTER_INDEX regeneration (or add manually)
2. Update ENGINE_DIGEST.md with new engines
3. Update DISPATCHER_DIGEST.md if new actions added
4. Update SYSTEM-CAPABILITIES.md for Desktop Claude
5. Update backend-status.md

## Step 6: Report

```
FORGE-FROM-SCOUT COMPLETE
==========================
Items built: [N] of [N] attempted
New engines: [list]
New MCP actions: [list]
New skills: [list]
New hooks: [list]
Tests: [N] passing
Build queue remaining: [N] items

Updated: MASTER_INDEX, ENGINE_DIGEST, SYSTEM-CAPABILITIES
```

## Integration Points by Type

### MCP Server Integration Pattern:
```
1. npm install [package] (or clone repo)
2. Create adapter engine: src/engines/[Name]AdapterEngine.ts
3. Wire to dispatcher (usually bridgeDispatcher or new dedicated)
4. Add Zod schema for actions
5. Create /[name] slash command
6. Add to MCP server startup (src/index.ts if needed)
```

### Plugin Integration Pattern:
```
1. Install plugin to ~/.claude/plugins/
2. Test functionality
3. Create bridge engine if plugin exposes useful data
4. Document in SYSTEM-CAPABILITIES.md
```

### Claude Feature Integration Pattern:
```
1. Update claude --version if needed
2. Enable feature in settings.json
3. Create slash command wrapper if useful
4. Document in MEMORY.md and CLAUDE.md
5. Update project instructions for Desktop Claude
```

### AI Tool Pattern Integration:
```
1. Evaluate tool's approach/algorithm
2. Build PRISM-native engine implementing the pattern
3. Wire to appropriate dispatcher
4. Add to existing pipeline if it enhances workflow
5. Test against PRISM's manufacturing data
```

## Safety
- Never install unvetted npm packages without checking source
- MCP servers run with PRISM's auth — verify they don't bypass security
- New engines must pass enforcement hooks (stub detector, constants check)
- All integrations get /prism-review before merge

## Chaining
- Full pipeline: `/scout` → `/forge-from-scout`
- Automated weekly: `/loop 7d /scout` then manual `/forge-from-scout` on top picks
- Plan only: `/forge-from-scout plan` (generates roadmap, doesn't build)
