# Scope — Change Impact Analysis

You are analyzing the blast radius of a proposed change before any code is modified. Given a target component (file, engine, dispatcher, milestone), map everything that would be affected: downstream consumers, upstream providers, test coverage, safety chain involvement, and risk level. This is a read-only planning tool — it changes nothing.

## Args: $ARGUMENTS
- `[file-path]`: scope impact of changing a specific file
- `[engine-name]`: scope impact of changing an engine (e.g., `scope KienzleEngine`)
- `[dispatcher-name]`: scope impact of changing a dispatcher (e.g., `scope calcDispatcher`)
- `[milestone-id]`: scope the aggregate impact of all units in a milestone (e.g., `scope SYS-MS1`)
- `refactor [component]`: scope impact with emphasis on safe refactoring paths
- Empty: abort — "Specify what you want to scope: `/scope [component]`"


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Step 1: Identify the Target
Based on args, locate the component:
- **File path**: read the file, determine its type (engine, dispatcher, algorithm, hook, test, data)
- **Engine name**: search `C:/PRISM/mcp-server/src/engines/` for matching file
- **Dispatcher name**: search `C:/PRISM/mcp-server/src/tools/dispatchers/` for matching file
- **Milestone ID**: read the envelope, extract all units and their target files/components

## Step 2: Map Downstream Impact (what breaks if this changes?)

### 2A: Direct Consumers
- Grep for imports of this module across the codebase
- For engines: which dispatcher actions call this engine?
- For dispatchers: which orchestration or cross-dispatcher calls reference it?
- For algorithms: which engines use this algorithm?
- For data files: which engines/dispatchers read this data?

### 2B: Transitive Consumers
- For each direct consumer, recursively find THEIR consumers (max depth: 3)
- Build the consumer tree

### 2C: Test Coverage
- Which test files import or test this component?
- Which test files test components that DEPEND on this one?
- Estimate: if this changes, how many tests could break?

### 2D: Safety Chain
- Does this component participate in S(x) scoring?
- Does it produce safety-relevant output (forces, temperatures, tool life)?
- Does it feed SafetyEngine, CoolantValidationEngine, or SpindleProtectionEngine?
- If yes: safety impact = HIGH → extra caution required

## Step 3: Map Upstream Dependencies (what does this depend on?)

### 3A: Direct Dependencies
- What does this file import?
- What registries does it query?
- What external data does it load?

### 3B: Configuration Dependencies
- Does it read from constants.ts?
- Does it use environment variables?
- Does it depend on registry data (materials, tools, machines)?

## Step 4: Risk Assessment

Score the change risk:

| Factor | LOW | MEDIUM | HIGH |
|--------|-----|--------|------|
| Consumers | 0-2 | 3-10 | 11+ |
| Test coverage | >80% | 40-80% | <40% |
| Safety involvement | None | Indirect | Direct S(x) |
| Lines of code | <100 | 100-500 | 500+ |
| Action count (dispatchers) | 1-10 | 11-50 | 51+ |

Overall Risk = max(all factors)

## Step 5: Report

```
SCOPE ANALYSIS: [component name]
=================================
Type:          [engine/dispatcher/algorithm/hook/data]
File:          [path] ([N] lines)
Risk Level:    [LOW / MEDIUM / HIGH / CRITICAL]

DOWNSTREAM IMPACT (what breaks):
  Direct consumers:      [N] files
    - [file1] — [how it uses this component]
    - [file2] — [how it uses this component]
  Transitive consumers:  [N] files (depth 2-3)
  Tests affected:        [N] test files (~[M] test cases)
  Safety chain:          [YES — feeds S(x) / NO]

UPSTREAM DEPENDENCIES (what this needs):
  Direct imports:        [N] modules
    - [module1] — [what it provides]
    - [module2] — [what it provides]
  Registry data:         [list or NONE]
  Config:                [list or NONE]

CHANGE STRATEGY:
  Safe approach:
    1. [specific recommendation based on analysis]
    2. [test-first suggestion]
    3. [incremental steps if HIGH risk]

  Tests to run first:    [list specific test files]
  Tests to run after:    [list full suite or subset]
  Build verification:    [YES — always]

  Cautions:
    - [specific risk or gotcha based on wiring]
    - [specific risk from safety chain if applicable]
```

### Milestone Scope (`/scope SYS-MS1`)
For milestone-level scope, aggregate across all units:
```
MILESTONE SCOPE: SYS-MS1 — Mega-Dispatcher Decomposition
=========================================================
Units:        [N] total
Components:   [N] files potentially affected

Aggregate Impact:
  Dispatchers touched:   [N] (with ~[M] actions total)
  Engines affected:      [N]
  Tests at risk:         [N] test files (~[M] tests)
  Safety chain overlap:  [YES/NO]
  Risk Level:            [aggregate]

Per-Unit Breakdown:
  U01: [component] — Risk: [LOW/MED/HIGH], [N] consumers
  U02: [component] — Risk: [LOW/MED/HIGH], [N] consumers
  ...

Recommended Order: [which units to do first based on dependency/risk]
```

## Error Handling
- **Component not found**: "No component matching '[name]'. Did you mean: [fuzzy suggestions]?"
- **No args**: "Specify a target: `/scope calcDispatcher`, `/scope SYS-MS6`, or `/scope src/engines/KienzleEngine.ts`"
- **Massive blast radius**: If >50 consumers, warn: "This is a foundational component. Consider incremental refactoring."

## Chaining
- Before: `/milestone` → understand what to work on → `/scope` → understand impact
- After: `/scope` → informed decision → `/pick-task` → `/autopilot`
- Related: `/trace` (wiring health), `/findings` (known issues in affected components)
- Safety: if scope shows safety chain involvement → `/forge-safety` before modifying
