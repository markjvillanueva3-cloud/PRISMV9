---
name: wedm-jm-die
description: JM Die Company Wire EDM shop context and customer patterns
version: 1.0.0
engines:
  - ShopConfigurationEngine
  - PRISMSelfAwarenessEngine
  - WedmProgramIndexEngine
  - JMDieProgramAnalyzerEngine
actions:
  - wedm_get_recommendation
triggers:
  - "jm die wedm"
  - "our wire edm"
  - "shop wedm"
---

# /wedm-jm-die — JM Die Shop Context

Inject JM Die Company Wire EDM shop context:
- Machine inventory (Mitsubishi FA-20S)
- Customer-specific patterns
- Historical program analysis
- Material preferences

## Usage

```
/wedm-jm-die [customer] [options]
```

## Arguments

- `customer` — Optional customer name (ALCOA, ITW, Optimas, etc.)
- `--machine` — Focus on specific machine
- `--material` — Filter by material
- `--recent` — Show recent programs (last 30 days)

## JM Die WEDM Configuration

| Asset | Details |
|-------|---------|
| **Machine** | Mitsubishi FA-20S |
| **Controller** | Mitsubishi FA |
| **Wire Inventory** | Brass 0.20, 0.25, 0.30mm |
| **Specialty** | Zinc-coated for carbide |
| **Programs** | 2,500+ in archive |
| **Primary Materials** | D2, A2, M2, S7, carbide |

## Customer Patterns

When customer specified, returns:
- Typical tolerances
- Preferred E-codes
- Surface finish requirements
- Historical success rates
- Common part types

## Output

```json
{
  "shop": "JM Die Company",
  "wedm_machine": {
    "name": "Mitsubishi FA-20S",
    "controller": "Mitsubishi FA",
    "capabilities": {
      "xy_travel_mm": [400, 300],
      "uv_travel_mm": [120, 120],
      "max_thickness_mm": 400,
      "max_taper_deg": 30
    }
  },
  "customer_pattern": {
    "name": "ALCOA",
    "typical_tolerance_mm": 0.005,
    "typical_ra_um": 0.4,
    "preferred_ecode": "H175",
    "common_materials": ["A2", "D2"],
    "success_rate": 0.97,
    "program_count": 145
  },
  "recent_programs": [...]
}
```

## Examples

```bash
# General shop context
/wedm-jm-die

# Customer-specific
/wedm-jm-die ALCOA

# Filter by material
/wedm-jm-die --material D2

# Recent work
/wedm-jm-die --recent
```

## Integration

- Feeds into `/wedm-program` for pattern matching
- Provides defaults for `/wedm-controller`
- Enriches `/wedm-cost` estimates
