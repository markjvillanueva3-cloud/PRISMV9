---
effort: high
maxTurns: 10
---

# System Variability Index (SVI)

Compute and display the PRISM System Variability Index — a single number representing the total manufacturing intelligence state space.

## Args: $ARGUMENTS
- Empty or `show`: Display current SVI from state/shared/SVI-compact.md
- `compute`: Recompute SVI from live system state and display results
- `summary`: Show compact one-line summary

## What This Does

The SystemVariabilityIndexEngine tracks 13 subsystems (materials, tools, machines, formulas, algorithms, strategies, engines, dispatchers, actions, pipelines, dialects, tests, tribal_tips) and 9 pipeline reachability scores.

**SVI** = ∏(subsystem_variability) — the total combinatorial state space
**Ψ (Reachability)** = reachable_configurations / total_configurations — fraction of state space producing validated output

## Procedure

### If `compute`:
1. Call the devDispatcher with action `svi_compute`
2. Display the full report: SVI, Ψ, per-subsystem breakdown, pipeline reachability
3. Report trend (growing/stable/shrinking) and delta from previous computation

### If `show` or empty:
1. Read `C:/PRISM/state/shared/SVI-compact.md`
2. Display the dashboard

### If `summary`:
1. Call devDispatcher with action `svi_summary`
2. Display the compact text

## Always:
- Show the SVI display value and Ψ percentage
- If Ψ decreased since last computation, flag it as a REGRESSION
- Suggest actions to increase Ψ (wire registries, add formulas, connect strategies)
