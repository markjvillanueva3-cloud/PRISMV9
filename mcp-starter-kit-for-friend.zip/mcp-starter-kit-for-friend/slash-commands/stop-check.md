# Stop Check — Evaluate if a tool call should proceed

Check pending tool calls against budget, redundancy, and efficiency rules.

## Usage
- `/stop-check Read file_path=/src/foo.ts` — evaluate a Read call
- `/stop-check Grep pattern=export path=/src` — evaluate a Grep call
- `/stop-check rules` — list all stop condition rules

## Steps
1. Parse tool name and params from $ARGUMENTS
2. Build ContextState from current session (budget, recent files, etc.)
3. Call stopConditionEngine.evaluate(tool, params, ctx)
4. Display decision (allow/warn/block), reason, saving estimate, alternative
5. If "rules" → call getRuleNames() and list them
