---
effort: high
maxTurns: 30
---

# Autopilot — Full Development Cycle Pipeline

Complete PRISM development cycle: pick task → execute → commit → scrutinize → fix → register → verify → update docs. No manual intervention unless something fails.

## Args: $ARGUMENTS
- Empty: start from task selection
- `[unit-id]`: skip selection, claim directly
- `resume`: pick up from ACTIVE_CLAIM.json
- `no-commit`: skip auto-commit (for dry runs)

## FULL ENFORCEMENT CHAIN (20 hooks, 5 events — all fire automatically)

**PRE-LEVEL (4 hooks):**
- `enforce-knowledge-consult.py` → WARNS/BLOCKS engine writes without domain knowledge consultation (16 domains)
- `enforce-context-retention.py` → BLOCKS new engine creation without ENGINE_DIGEST.md read
- `enforce-plan-before-build.py` → BLOCKS new engine Write without /plan-build first
- Knowledge graph reminder → prefer codebase-memory-mcp over Grep/Glob

**POST-LEVEL (10 hooks):**
- `enforce-stub-detector.py` → BLOCKS placeholder returns in engines (command hook, silent on non-engines)
- `enforce-test-quality.py` → BLOCKS || true, trivial assertions in tests (command hook, silent on non-tests)
- `enforce-constants-check.py` → BLOCKS inline kc1.1/Taylor constants
- `enforce-unit-counter.py` → WARN@20, STRONG@40, BLOCK@60 edits + review/test gap tracking
- `enforce-knowledge-consult-mark.py` → Records domain consultation from reads
- `enforce-auto-compact.py` → Auto-triggers compaction at 20/40/55 edit thresholds
- **Physics agent** (Haiku) → Deep review: formula correctness, realism, knowledge utilization
- **Wiring agent** (Haiku) → MCP readiness, cross-engine consistency, reasoning trail

**COMPACT-LEVEL (4 hooks):**
- `enforce-review-gate.py` → Tests written? /prism-review run? Wiring verified?
- `enforce-wiring-gate.py` → Engine referenced by dispatcher or other engine?
- `enforce-forge-triple-output.py` → MCP action + skill + protective hook exist?
- **Session audit agent** (Haiku) → Completeness, 4-loop compliance, physics integrity

**POST-COMPACT (1):** `enforce-auto-continue.py` → /startup + /handoff read + resume
**STOP (1):** `enforce-wiring-gate.py` → Orphaned engines flagged

## AUTOPILOT PIPELINE FLOW (enforced, not optional)
```
/plan-build → consult knowledge → build → 4-LOOP (SCRUTINIZE → GAP FILL → TIE UP → VALIDATE) → forge-triple → /compact → /startup → next
     ↑                                                                              ↓
     └──────────────────────── auto-continuation loop ──────────────────────────────┘
```

Every unit follows this flow. Hooks enforce each step:
- /plan-build: plan-before-build hook BLOCKS without it
- Knowledge consultation: knowledge-consult hook WARNS/BLOCKS without it
- Build quality: stub detector + constants checker + physics agent BLOCK bad code
- 4-LOOP: review gate BLOCKS after 3 engine edits without /prism-review. LOOP 4 (VALIDATE) re-runs review on fixes to confirm findings decreased
- Forge-triple: forge-triple gate WARNS at compact if MCP action/skill/hook missing
- /compact: auto-compact hook triggers at edit thresholds
- /startup: auto-continue hook resumes from HANDOFF.md RESUME line

## Phase 0: Load Path Index
Read these files directly (do NOT Glob/Grep to explore):
1. `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` — full system map (~735 tokens)
2. `C:/PRISM/mcp-server/data/docs/ENGINE_DIGEST.md` — all engines with 1-line descriptions (for gap analysis)
3. `C:/PRISM/mcp-server/data/docs/DISPATCHER_DIGEST.md` — all dispatchers with action counts

**CRITICAL: Do NOT Glob src/engines/ to list engines — ENGINE_DIGEST.md already has them all. Do NOT read MASTER_INDEX.md (5,000 tokens) — use MASTER_INDEX_COMPACT.md (735 tokens).**


**Token-Efficient Navigation** (use instead of Glob/Grep):
- `/digest-all` — loads DIRECTORY_DIGEST + DSL_COMPACT + PATH_INDEX (~1100 tokens total)
- `/navigate <topic>` — zero-IO file routing via FileSystemNavigatorEngine (25 domain routes)
- `/code-index <shortcode>` — resolve E0001→path instantly (1,865 indexed files)
- `ENGINE_DIGEST.md` — 880 engines with 1-line descriptions if you need engine-level detail
- `DISPATCHER_DIGEST.md` — 66 dispatchers with action counts if you need action routing


## DSL Shortcode Output Rule (MANDATORY)
When referencing PRISM files in output, use DSL shortcodes to save tokens:
- `E####: EngineName` instead of `src/engines/EngineName.ts`
- `D##: DispatcherName` instead of `src/tools/dispatchers/DispatcherName.ts`
- `A##: AlgorithmName` instead of `src/algorithms/AlgorithmName.ts`
- `T####: TestName` instead of `src/__tests__/TestName.test.ts`
Resolve via `/code-index` or `codeSystemIndexEngine.resolve()`. Lookup via `.lookup(path)`.
## Phase 1: Smart Config (/smart applied to EVERY phase)
Output a SMART CONFIG header: Role, Model tier (OPUS/SONNET/HAIKU), Effort (HIGH/MEDIUM/LOW), 1-line reason.

**MANDATORY**: Every subsequent phase MUST begin with a `/smart`-style config line:
```
PHASE [N]: [Name] — Smart: [ROLE] | [MODEL] | [EFFORT]
```
This is non-negotiable. Each phase re-evaluates role/effort based on phase-specific requirements (e.g., Phase 4 Execute = HIGH effort, Phase 8 Add to Matrix = MEDIUM effort).

## Phase 2: Pick Task (`/pick-task`)
1. Read `roadmap-index.json` for incomplete milestones
2. Load envelopes, check claims for conflicts
3. Tier: **A** (MCP-Server/infra), **B** (PRISM domain), **C** (Debug/Optimize)
4. Claim unit (atomic mkdir + claim.json + ACTIVE_CLAIM.json)
5. Load steps and exit conditions

If args has unit ID → claim directly. If `resume` → reload from ACTIVE_CLAIM.json.

## Phase 2B: Toolkit Selection
Map unit's domain to relevant PRISM components. Output compact Toolkit Card:
```
TOOLKIT — [unit-id]
Skills:       [always: /test, /scrutinize, /check-dsl, /scope] + domain-specific
Engines:      [from MASTER_INDEX matching domain] ([N] relevant)
Formulas:     [from FormulaRegistry if physics/mfg]
Dispatchers:  [target dispatcher] ([N] actions)
Key Files:    [3-5 primary files]
```

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** before concluding any analysis or implementation.
- Consider every applicable model, formula, algorithm, and combination — including novel cross-domain approaches.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 880+ engines, 52 algorithms for existing coverage before building new.
- **Completeness > Speed.** A missed mathematical model is a permanent capability gap.

## Phase 3: YOLO Mode
Activate: autonomous decisions, immediate execution, zero proceed questions, parallel operations, auto-fix errors (3 attempts max). Safety rails remain enforced (hooks, S(x), build/test gates).

## Phase 3B: Background Analysis
Launch in parallel via Agent while Phase 4 executes:
1. `/forge-audit quick` — code quality scan
2. `/forge-drift quick` — registry count verification
3. `/forge-wiring orphans` — broken wiring check

Check results before Phase 5. Fix CRITICALs before committing.

## Phase 4: Execute the Unit
Per-step loop:
1. Output: `STEP [N]/[total] — [summary] | Smart: [ROLE] | [EFFORT]`
2. Execute step instruction
3. Verify completion
4. After all steps: verify exit conditions

## Phase 5: Auto-Commit
1. `git status` + `git diff` to review changes
2. Stage relevant files only (not unrelated changes)
3. Commit: `feat/fix/refactor(scope): description [UNIT-ID]`

## Phase 6: Scrutinize
1. Check modified files for: TODO/FIXME, placeholders, missing error handling, `any` types, magic numbers
2. `npm run build` — must pass (0 new errors)
3. `npm test` — must pass (0 regression)
4. List findings as CRITICAL / MAJOR / MINOR

## Phase 7: Apply Fixes
CRITICAL → fix immediately. MAJOR → fix now. MINOR → fix if <2min.
Re-run build + tests. Commit: `fix(scope): address scrutiny findings [unit-id]`

## Phase 8: Add to Matrix
Scan for new engines/dispatchers/algorithms/hooks/cadences. Register in MASTER_INDEX + code registries. Verify wiring. Skip if no new products.

## Phase 9: Check DSL
Verify: AtomicValue returns, action schemas, parameter normalization, safety integration, hook registration, schema compliance. Skip if no DSL-relevant changes.

## Phase 10: Update All Documents
Update: MASTER_INDEX, CLAUDE.md files, CURRENT_POSITION.md, MEMORY.md, roadmap-index.json, milestone envelope. Commit: `docs(scope): update for [unit-id]`

## Summary Report
```
AUTOPILOT COMPLETE — [unit-id] — [title]
Milestone: [X]/[Y] done | Commits: [N] | Scrutiny: [N] findings
Matrix: [N] products | DSL: [PASS] | Docs: [N] updated
Build: PASS | Tests: [N] passing | Exit: [N]/[N] met
Status: SUCCESS | Next: /autopilot or /forge
```

## Error Handling
- **Build failure**: Stop. Report error. Do not proceed past Phase 6.
- **Test regression**: Fix regression. Re-run from Phase 6.
- **Claim conflict**: Pick a different unit.
- **Context low**: Run `/compact`, ship what's done, report remaining.

## Safety Rails (always enforced)
Never skip build/test. Never commit secrets. Never force-push. Never bypass S(x). Never create stubs.
