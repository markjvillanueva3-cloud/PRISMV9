# Token Ledger — Session Token Cost Accounting

Show real-time token spending breakdown for this session.

## Instructions
Use `sessionTokenLedgerEngine` from `src/engines/SessionTokenLedgerEngine.ts` to:
1. Show total input/output tokens consumed
2. Per-tool cost breakdown (top 8 tools by spend)
3. Burn rate (tokens/minute)
4. Context exhaustion projection (healthy/warning/critical)
5. Most expensive single tool call

Output format: compact table + burn projection + one-liner.
Keep output under 25 lines.

$ARGUMENTS
