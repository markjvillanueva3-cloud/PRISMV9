# RGS — Roadmap Generation System

You are the unified entry point for the PRISM Roadmap Generation System. Based on the arguments, route to the appropriate RGS operation.

## Args: $ARGUMENTS
- Empty or `status`: Show roadmap status (milestone counts, completion, available tracks)
- `brainstorm [topic]`: Brainstorm improvements and generate milestone proposals
- `generate [brief]`: Generate a new milestone from a brief (runs the 10-stage pipeline)
- `continue [milestone-id]`: Continue executing a milestone from its current position
- `list`: List all milestones with status
- `plan [milestone-id]`: Show execution plan for a milestone without executing
- `utilize [topic]`: Search 576+ MCP actions for the right tool (routes to action_search)

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when brainstorming or generating milestones.
- Consider every applicable model, formula, algorithm, and combination — including novel cross-domain approaches.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/algorithm by name.
- Check PRISM's 499 formulas, 1,304+ engines, 60+ algorithms for existing coverage before proposing new work.
- **Completeness > Speed.** A missed mathematical model is a permanent capability gap.

## MCP FULL UTILIZATION PROTOCOL (MANDATORY — EVERY SESSION)

Every roadmap session MUST use the MCP server's full 576+ actions. Current utilization was ~3% — this protocol raises it to 40%+.

### Session Start (before ANY code work):
```
prism_session:context_boot           — Full context hydration from prior session
prism_session:dispatcher_map         — Discover all 79 dispatchers, 3,310+ actions (live count)
prism_session:memory_recall          — Load cross-session knowledge
prism_session:system_snapshot        — Capture baseline system state
prism_session:action_search "<goal>" — Find the right MCP action for this session's work
```

### During Work (every 5-10 tool calls):
```
prism_session:auto_checkpoint        — Save incremental state
prism_session:action_search "<need>" — Route intent to optimal dispatcher
prism_session:tool_route_best        — Let MCP recommend the best tool
prism_session:wip_capture            — Snapshot work-in-progress
```

### Session End / Pre-Compact:
```
prism_session:memory_save            — Persist cross-session knowledge
prism_session:system_snapshot        — Capture post-work state (diff against baseline)
prism_session:checkpoint_enhanced    — Detailed checkpoint with artifact list
```

### Plugin & Extension Utilization:
```
Vitest MCP:       mcp__vitest__run_tests, analyze_coverage, list_tests
ESLint MCP:       mcp__eslint__lint-files (TypeScript quality gate)
Taskmaster:       mcp__taskmaster-ai__get_tasks, next_task, set_task_status
Codebase Memory:  codebase-memory-mcp search_graph, trace_call_path
Excel MCP:        mcp__excel__excel_read_sheet (data import/validation)
```

### Feature Cascade Protocol:
```
SESSION_ARTIFACTS.json  — Tracks new engines/hooks/skills built per session (auto by PostCompact)
.compaction-survival.md — Preserves critical state across compaction boundaries
HANDOFF.md              — Per-agent state written on stop, read on startup
SVI-compact.md          — System health snapshot auto-generated pre-compact
MEMORY.md               — Shared memory auto-synced across sessions/machines
```

### Skill Utilization (use these, don't reinvent):
```
/forge-engines, /forge-wiring, /prism-review, /test, /physics-verify,
/forge-triple, /calibrate, /navigate, /playbook, /scrutinize, /trace,
/action-search, /action-help, /program-validate, /auto-speed-feed
```

## Route: status (default)
Read `H:/prism/mcp-server/data/roadmap-index.json` and present:
```
RGS STATUS
==========
Roadmap:  v[X.Y.Z] | [X]/[Y] milestones ([Z]%)
Tracks:   [list tracks with counts]

By Track:
  QA   — [X]/[Y] complete
  REM  — [X]/[Y] complete
  SYS  — [X]/[Y] complete
  S3   — [X]/[Y] complete
  ...

Unblocked Next:
  [milestone-id]  [title]  [track]  [status]
  ...
```

## Route: brainstorm
1. Read `H:/prism/state/CURRENT_POSITION.md` for context
2. Read the roadmap index to understand what's done and what's planned
3. If a topic is given, focus brainstorming on that area
4. If no topic, analyze system gaps holistically:
   - What QA findings remain unaddressed?
   - What system debt exists?
   - What user-facing features are next?
   - What automation opportunities exist?
5. Present 3-5 concrete milestone proposals with:
   - Title, track, estimated units, dependencies, rationale
6. Ask which to generate (or generate all)

## Route: generate
Execute the 10-stage RGS pipeline with ENFORCED quality standards:

### Stage 1: Brief Analysis
Parse the brief into structured form: domain, machine types, complexity, dependencies.

### Stage 2: Codebase Audit
Search existing assets — ENGINE_DIGEST.md (1,304+ engines), DISPATCHER_DIGEST.md (79 dispatchers),
FormulaRegistry (499 formulas), AlgorithmRegistry (60+ algorithms). Use knowledge graph
(search_graph, get_architecture) to find what already exists. NEVER propose building something
that already exists without citing the specific engine by name.

### Stage 3: Knowledge Source Mapping (MANDATORY)
For EVERY milestone being generated, identify ALL relevant knowledge sources:
```
ENGINES: [list every existing engine that's relevant — by name + line count]
TRIBAL KNOWLEDGE:
  - TribalKnowledgeEngine — query for domain-specific tips (3,700+ across 18 CAM systems)
  - MachiningPlaybookEngine — 296 rules, especially anti-patterns for this domain
  - src/data/*-cam-tips.ts — specific tip files for relevant CAM systems
  - controller-knowledge-tips.ts — if controller-specific
  - Academy courses — if educational content exists for this domain
FORMULAS:
  - FormulaRegistry — specific formulas needed (Kienzle, Taylor, Malkin, Sato, Schulz, Zeng-Kim, etc.)
  - src/physics/constants.ts — canonical constants that MUST be used (never inline)
  - Published data sources — Sandvik, Kennametal, Machinery's Handbook, manufacturer catalogs
REFERENCE:
  - EXTERNAL-REFERENCE-PROGRAMS-INDEX.md — matching reference programs
  - MachineRegistry — relevant machines from 910-machine database
  - MaterialRegistry — relevant materials from database
  - ToolCatalogEngine — relevant tools from 95,608-tool catalog
```
If knowledge sources can't be identified for a milestone, the milestone is UNDERSPECIFIED. Fix before proceeding.

### Stage 4: Scope Estimation
Classify complexity (S/M/L/XL). Calculate session count based on:
- 2-3 units per session MAX (for quality)
- /compact after every 3 units
- Each unit includes 4-loop overhead (SCRUTINIZE + GAP FILL + TIE UP)

### Stage 5: Phase Decomposition
Break into ordered phases with EXPLICIT session boundaries:
```
SESSION [N]: [title] (U-XXX01..U-XXX03)
  SMART CONFIG: Role=<role> + <specialist> | MODEL=<opus/sonnet/haiku> | EFFORT=<MAX/HIGH> | CONTEXT_BUDGET=<XX%>
  KNOWLEDGE: [per-session knowledge sources from Stage 3]
  INTENT: [what the machinist/user experiences after this session]
  SKILLS: [which /skills, /scripts to use]
  WORK:
    U-XXX01: [unit title]
      → 4-LOOP: BUILD → SCRUTINIZE → GAP FILL → TIE UP
      FILES_CREATED: [list]
      FILES_MODIFIED: [list]
      ABORT_CRITERIA: [>= 3 measurable]
      ROLLBACK: [specific git commands]
    U-XXX02: ...
  FORGE-TRIPLE: hook={name} + action=prism_{dispatcher}:{action} + skill=/{skill}
  EXIT GATE: ✓ [measurable criteria] | omega_floor >= 0.85 | SVI delta: +X%
  FEATURE CASCADE:
    NEW_HOOKS: [hook_name → protection_scope]
    NEW_ACTIONS: [dispatcher:action → consumer_intent]
    NEW_SKILLS: [/skill → trigger]
    AVAILABLE_TO: [downstream sessions]
  /compact checkpoint
```

### Stage 6: Unit Population
Fill all schema fields per unit. EVERY unit MUST have:
- Clear build description with U-{DOMAIN_PREFIX}{NN} naming (e.g., U-LTH01, U-MIL01)
- Knowledge sources to consult BEFORE building
- Exit criteria (not just "it compiles" — "machinist would accept this output")
- Rollback block (FILES_CREATED, FILES_MODIFIED, ABORT_CRITERIA, ROLLBACK_PROCEDURE)
- 4-LOOP gate explicitly stated
- Dependencies on prior units (Depends on: U-XXX01)

### Stage 7: Forge-Triple Requirement (MANDATORY)
For every milestone, define the FORGE-TRIPLE outputs:
```
FORGE-TRIPLE for [milestone]:
  PROTECTIVE HOOK: [what enforcement hook protects this new capability]
  MCP ACTION: [what dispatcher action makes this callable by PRISM app]
  SKILL/COMMAND: [what /slash command gives users access]
```
No milestone ships without all 3 outputs defined.

### Stage 8: Enforcement Integration (MANDATORY)
Document which enforcement hooks fire during this roadmap's execution:
- PRE-LEVEL: knowledge-consult, context-retention (verify domain sources read)
- POST-LEVEL: stub detector, test quality, constants checker, physics agent, wiring agent
- COMPACT-LEVEL: review gate, wiring gate, forge-triple gate, session audit agent
- POST-COMPACT: Feature Cascade (SESSION_ARTIFACTS.json auto-written)
These are AUTOMATIC — document them so the executor knows they're active.

### Stage 9: Dependency Resolution
Validate DAG, resolve references. Check that:
- No unit depends on something not yet built
- No circular dependencies
- Compaction points don't split dependent units
- Unit names use U-{DOMAIN_PREFIX}{NN} format (no bare U01)

### Stage 10: Output + 3-Loop Scrutinization
Write envelope to `data/milestones/{ID}.json`, update `roadmap-index.json`.

**3-LOOP POST-GENERATION SCRUTINY (MANDATORY):**

**Loop 1: Multi-Agent Review (10+ agents, parallel)**
Launch review agents with DISTINCT roles:
- Protocol Structure (SESSION blocks, field ordering)
- Unit Naming (U-XXX convention, domain prefixes, collision detection)
- SMART CONFIG (role/model/effort/context_budget completeness)
- Exit Gate Rigor (measurability, rollback, omega_floor, SVI delta)
- Forge-Triple (per-unit hook+action+skill declarations)
- Physics Rigor (canonical constants, safety gating)
- Feature Cascade (self-update mechanism, tool propagation)
- Dependency Graph (DAG consistency, no cycles)
- MCP Utilization (session actions referenced, plugins listed)
- Cross-Roadmap Coherence (authority, ownership, status consistency)
Each agent scores 0-100. Average must be >= 70 to proceed.

**Loop 2: Focused Fix**
Target the 3 worst-scoring dimensions from Loop 1. Launch deep-scrutiny agents to produce fixes. Apply fixes.

**Loop 3: Verification**
Re-score after fixes. All dimensions must be >= 60. If any < 60, iterate Loop 2.

### QUALITY STANDARD FOR ALL GENERATED ROADMAPS
Every roadmap generated by /rgs MUST include:
1. **MCP Full Utilization Protocol** (context_boot, dispatcher_map, memory_recall, auto_checkpoint, memory_save)
2. Per-session **SMART CONFIG** (role, model, effort, context_budget)
3. Per-session **KNOWLEDGE SOURCES** (engines, tribal, formulas, reference — multi-source)
4. Per-session **INTENT** (what the machinist experiences, not just what code does)
5. **4-LOOP** protocol per unit (BUILD → SCRUTINIZE → GAP FILL → TIE UP)
6. **FORGE-TRIPLE** per milestone (protective hook + MCP action + skill)
7. Per-unit **ROLLBACK BLOCK** (FILES_CREATED, FILES_MODIFIED, ABORT_CRITERIA, ROLLBACK_PROCEDURE)
8. Per-unit **EXIT GATE** with measurable criteria, omega_floor, SVI delta
9. **FEATURE CASCADE** block (NEW_HOOKS, NEW_ACTIONS, NEW_SKILLS, AVAILABLE_TO)
10. **/compact** every 3 units with compaction survival + Feature Cascade
11. **U-{PREFIX}{NN}** unit naming (no bare U01 — prevents collisions)
12. Enforcement hook documentation (which hooks are active)
13. SKILLS/SCRIPTS listing per session
14. Plugin utilization (Vitest MCP, ESLint MCP, Taskmaster, Codebase Memory)
15. No stub tolerance — enforcement hooks BLOCK placeholder code
16. **3-loop post-generation scrutiny** (10+ agents, average >= 70)

This is the standard established by CAMX-RESTRUCTURED-ROADMAP-v24.md, the 8 per-machine
comprehensive roadmaps, and the 20-agent scrutiny audit of 2026-03-30.

## Route: continue
Load the milestone envelope and execute units with FULL quality enforcement:

**MCP UTILIZATION AT SESSION START:**
```
prism_session:context_boot → dispatcher_map → memory_recall → system_snapshot → action_search "<goal>"
Read SESSION_ARTIFACTS.json for Feature Cascade (new engines/hooks/skills from prior sessions)
```

1. Find the first `not_started` or `in_progress` unit
2. Read KNOWLEDGE SOURCES for this milestone (from roadmap or envelope)
3. Consult tribal knowledge + playbook + formulas for the domain BEFORE building
4. Execute unit steps with specified tools
5. **4-LOOP per unit:**
   - LOOP 1 SCRUTINIZE: /prism-review + /scrutinize → fix findings
   - LOOP 2 GAP FILL: /test + /trace wiring + edge cases → fill gaps
   - LOOP 3 TIE UP: no TODOs, reasoning[], golden snapshot → polish
6. Verify exit conditions (measurable criteria, omega_floor, SVI delta)
7. Update envelope and index on completion
8. **Every 3 units: /compact (auto-triggered by hook) → /startup → continue**
9. **Every milestone complete: /forge-triple → generate protective hook + MCP action + skill**
10. Proceed to next unit or report completion

**MCP UTILIZATION DURING WORK (every 5-10 calls):**
```
prism_session:auto_checkpoint → action_search → tool_route_best → wip_capture
```

**MCP UTILIZATION AT SESSION END:**
```
prism_session:memory_save → system_snapshot → checkpoint_enhanced
PostCompact hook auto-writes SESSION_ARTIFACTS.json (Feature Cascade)
```

ENFORCEMENT HOOKS ACTIVE DURING EXECUTION:
  - Physics agent reviews every engine edit for formula correctness
  - Wiring agent reviews every engine for MCP readiness
  - Constants checker blocks inline physics values
  - Stub detector blocks placeholder returns
  - Test quality blocks || true and bare .includes()
  - Auto-compact fires at 15/25/35 edit thresholds
  - Forge-triple gate blocks compaction without hook + action + skill
  - Session audit agent reviews work before every compaction
  - PostCompact: Feature Cascade writes SESSION_ARTIFACTS.json for next session
  - SessionStart: reads Feature Cascade, reports live system counts + new capabilities

## Route: list
Read `H:/prism/mcp-server/data/roadmap-index.json` and show all milestones in a compact table:
```
ID        | Title                              | Track | Status       | Units
----------|--------------------------------------|-------|--------------|------
QA-MS0    | Audit Framework & Baseline           | QA    | complete     | 6/6
SYS-MS0   | CLAUDE.md Modular Architecture       | SYS   | not_started  | 0/6
...
```

## Route: plan
Load the milestone envelope and show the execution plan without running anything:
- All phases and units in order
- Dependencies between units
- Estimated sessions and token cost
- Which units can run in parallel
- MCP actions available for each unit's domain

## Route: utilize
Search 576+ MCP actions to find the right tool:
```
prism_session:action_search { query: "$ARGUMENTS" }
```
Returns matching dispatcher actions with descriptions and parameter hints.
