# Acquire Models — Automated CNC Machine 3D Model Finder

Search and download CNC machine STEP files from public sources using Playwright browser automation.

## Args: $ARGUMENTS
- Empty: search for all 650 missing machines (prioritized by popularity)
- `haas`: search Haas machines only
- `dmg`: search DMG MORI machines only
- `mazak`: search Mazak machines only
- `<manufacturer>`: search specific manufacturer
- `search-only`: find models but don't download (generates URL list)
- `status`: show current model coverage

## Execution

### Step 1: Identify Missing Models
Call MachineModelDownloaderEngine.getMissingMachines() to get prioritized list.

### Step 2: Search GrabCAD
For each missing machine (batch of 10):
1. Navigate to GrabCAD search URL via Playwright:
   ```
   https://grabcad.com/library?softwares=step-slash-iges&query=<manufacturer>+<model>
   ```
2. Take snapshot to find model cards
3. Record matching results with URLs

### Step 3: Attempt Downloads
For models found on GrabCAD:
1. Navigate to model page
2. Look for download button
3. If login required → record URL for manual download
4. If public → download STEP file to ~/.prism/machine-models/

### Step 4: Report Results
```
MODEL ACQUISITION RESULTS
===========================
Searched:    [N] machines
Found:       [N] models on GrabCAD
Downloaded:  [N] STEP files (public)
Login needed: [N] models (URLs saved)
Not found:   [N] machines

DOWNLOADED:
  [manufacturer] [model] → ~/.prism/machine-models/[id].step

NEED LOGIN (GrabCAD):
  [manufacturer] [model] → [URL]

NOT FOUND:
  [manufacturer] [model]

Coverage: [old]% → [new]% (3D models)
```

### Step 5: Save Results
Save all search results to ~/.prism/model-search-results.json for future reference.

## Engines Used
- MachineModelDownloaderEngine (search + download automation)
- MachineModelAcquisitionEngine (URL generation + planning)

## Notes
- GrabCAD search is public but download requires free account
- First run: search-only mode to see what's available
- After user creates GrabCAD account, can automate downloads via Playwright login
- STEP files saved to ~/.prism/machine-models/ (persistent across sessions)
