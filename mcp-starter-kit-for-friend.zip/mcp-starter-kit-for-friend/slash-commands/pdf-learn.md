# PDF Learn — Document to PRISM Components Pipeline

You are running a specialized pipeline that processes PDF files, technical manuals, MIT OpenCourseWare materials, academic papers, and text documents through the CC-EXT-MS0 document learning pipeline, extracts structured manufacturing knowledge, and forges new PRISM components (engines, algorithms, hooks, schemas, scripts, skills, tribal tips, formulas) to improve the app's capabilities.

This command chains document ingestion, AI-powered knowledge extraction, and component generation into one continuous flow — learning from real-world manufacturing literature and converting it into actionable PRISM intelligence.

## Args: $ARGUMENTS
- File path: process a specific document
  Example: `/pdf-learn C:/Papers/CNC_Machining_Handbook.pdf`
- Directory path: batch-process all PDFs/docs in a folder
  Example: `/pdf-learn C:/Papers/MIT_2_008/`
- MIT course ID: fetch and process MIT OCW materials
  Example: `/pdf-learn mit:2.008` (Manufacturing Processes)
  Example: `/pdf-learn mit:2.810` (Manufacturing Processes & Systems)
  Example: `/pdf-learn mit:2.72` (Elements of Mechanical Design)
- Search query: find relevant PDFs in the knowledge store
  Example: `/pdf-learn "titanium machining parameters"`
- `--dry-run`: run pipeline + extraction but do not generate components
- `--tips-only`: only generate TribalKnowledgeEngine tips (fastest, safest)
- `--max-components=<N>`: limit components generated (default: 5)
- `--domain=<cad|cam|shop|software|electronics|additive|auto>`: force domain classification (default: auto-detect)
- `--batch`: process all files without prompting per-file
- `--skip-existing`: skip documents already in the learning registry

## EXHAUSTIVE SCIENCE LAW (HARD RULE)
- **Exhaust ALL mathematical, statistical, and scientific possibilities** when extracting knowledge from documents.
- Extract every formula, model, empirical correlation, chart data point, and algorithm — no skipping.
- "Already covered" claims REQUIRE citing the SPECIFIC existing engine/formula/tip by name.
- Check PRISM's 499 formulas, 880+ engines, 204 tribal tips for existing coverage before dismissing content.
- **Completeness > Speed.** Every page may contain a model PRISM doesn't have yet.

## Known MIT OCW Course Library
These courses contain high-value manufacturing knowledge:
| Course ID | Title | Primary Domain | Key Topics |
|-----------|-------|---------------|------------|
| 2.008 | Design and Manufacturing II | cam/shop | Injection molding, casting, machining processes, tolerances |
| 2.810 | Manufacturing Processes and Systems | cam/multi | Process planning, CNC, fixtures, quality control |
| 2.72 | Elements of Mechanical Design | cad | Bearings, shafts, gears, structural design |
| 2.670 | Mechanical Engineering Tools | shop | Shop practices, measurement, GD&T |
| 2.71 | Optics | cad | Precision engineering, optical fabrication |
| 2.830 | Control of Manufacturing Processes | cam/shop | SPC, process capability, feedback control |
| 2.875 | Mechanical Assembly and Its Role in Product Development | cad/shop | DFA, tolerance stacking, assembly methods |
| 6.141 | Robotics: Science and Systems | multi | Robot kinematics (relevant to 5-axis) |

For MIT courses, download lecture notes, problem sets, and readings from OCW. Filter for PDF/text content that contains manufacturing-relevant material (skip pure math derivations, exam logistics, etc.).

## THOROUGHNESS LAW (HARD RULE — applies to every phase)
- **NEVER skim, skip, or dismiss content without deep reading.** Every source gets a full assessment.
- ZIPs with "0 PDFs" MUST be checked for HTML, text, XML, JSON, CSV, and code files.
- "Low novelty" / "already covered" claims REQUIRE citing the SPECIFIC existing engine/tip that covers it — name it or extract it.
- Before committing: "Did I read EVERY file? Did I extract EVERYTHING useful? Did I check non-PDF content?"
- When processing large documents (>100 pages): read the TOC + at least 3 representative sections before ANY novelty judgment.
- **Completeness > Speed.** Missing useful content is a permanent loss that degrades PRISM's value.
- Post-processor code, G-code templates, parameter tables, and controller-specific patterns are ALWAYS high-value for PRISM — never dismiss them.


## Phase 0: Load System Map
Use `/digest-all` (~1100 tokens) or `/navigate <topic>` for zero-IO file location before exploring with Glob/Grep.

## Phase 1: Smart Config + Input Validation

### 1A: Smart Configuration
```
SMART CONFIG
Role:   Manufacturing Process Expert + Senior TypeScript Engineer + Knowledge Engineer
Model:  OPUS
Effort: HIGH
Reason: Document learning requires deep domain knowledge for extraction + engineering skill for component generation
```

### 1B: Parse Input
Determine input type from `$ARGUMENTS`:
1. **File path** (ends with `.pdf`, `.md`, `.txt`, `.html`): Validate file exists, proceed to Phase 2
2. **Directory path** (no file extension, or ends with `/`): Scan for supported files (`.pdf`, `.md`, `.txt`, `.html`), list found documents, proceed to batch mode
3. **MIT course** (`mit:<course_id>`): Download course materials from OCW (use WebFetch for lecture notes pages), save to `C:/PRISM/cad-engine/data/mit_ocw/<course_id>/`, then batch-process
4. **Search query** (quoted string): Search knowledge store registry for matching documents
5. **Empty**: Print usage, list known MIT courses, and exit

### 1C: Validate Prerequisites
- Python available at `C:/Users/Admin.DIGITALSTORM-PC/AppData/Local/Programs/Python/Python312/python.exe`
- pypdf installed (`pip show pypdf`)
- ANTHROPIC_API_KEY: Auto-loaded from `C:/PRISM/mcp-server/.env` by the extraction modules. No manual export needed — the `_load_env_file()` in `knowledge_extract.py` handles this automatically.
- Knowledge store directory exists: `C:/PRISM/cad-engine/knowledge_store/`
- Output directory exists: `C:/PRISM/cad-engine/output/`

If prerequisites fail, report what's missing and suggest `--dry-run` as fallback.

**IMPORTANT — Extraction Mode Selection:**
- **Default: API extraction** (`extract_from_document`) — uses Claude API for high-quality structured extraction. Requires ANTHROPIC_API_KEY (auto-loaded from `.env`). This is the preferred path.
- **Fallback: Offline extraction** (`extract_from_document_offline`) — regex-based, no API calls. Use only when API key is unavailable or with `--offline` flag. Lower quality on formal documentation.

### 1D: Check Learning Registry
Load `C:/PRISM/cad-engine/knowledge_store/_registry.json` (document registry from documentLearningDispatcher).
Also check `C:/PRISM/mcp-server/data/video-learned/learning-registry.json` for the unified registry.
If the document was already processed, report what was generated and ask whether to re-process or skip (unless `--skip-existing` flag).

## Phase 2: Document Ingestion (CC-EXT-MS0 Pipeline)

Run the document ingestion pipeline from `C:/PRISM/cad-engine/src/`:

### 2A: Ingest
```python
from src.document_ingest import ingest_document
result = ingest_document(file_path, format_override=None)
```
Extract: DocumentIngestResult (full text, pages[], metadata: title, author, DOI, format, page_count)

### 2B: Classify Document Type
```python
from src.document_classify import classify_document
classification = classify_document(
    text=result.text, title=doc_title,
    has_doi=result.metadata.doi is not None,
    page_count=result.metadata.page_count,
)
```
Classify into: academic_paper, technical_manual, handbook, blog_article, notes, specification, other

### 2C: Domain Classification
Uses same weighted keyword scoring as video pipeline but adapted for document text.
Classify into CAD/CAM/SHOP/MULTI.

### 2D: Chunk Large Documents
Documents > 15 pages are split into overlapping chunks (15 pages/chunk, 1 page overlap).
Each chunk is processed independently, then results are merged with ID-based deduplication.

**Output per document:**
```
DOCUMENT INGESTED
  Title:      [title]
  Author:     [author or "Unknown"]
  Format:     [pdf/markdown/text/html]
  Pages:      [N]
  Doc Type:   [academic_paper/technical_manual/handbook/...]
  Domain:     [primary] (confidence: [N])
  DOI:        [doi or "None"]
  Chunks:     [N] (if > 15 pages)
```

### For Batch Mode (directory or MIT course):
Process each file sequentially. Report progress:
```
BATCH PROGRESS: [X]/[Y] documents
  Processing: [filename]
  ...
```

## Phase 3: Knowledge Extraction

### 3A: Full Pipeline Extraction (API mode — default)
```python
# API key auto-loads from C:/PRISM/mcp-server/.env — no manual export needed
from src.document_extract import extract_from_document
result = extract_from_document(
    file_path=path,
    title=title,
    force_domain=domain_override,
    document_id=doc_id,
)
```

This runs the complete pipeline: ingest → classify → domain-detect → chunk → Claude API extraction per-domain → deduplicate → validate → cross-link → compute stats.

### 3A-alt: Offline Extraction (fallback — use with `--offline` flag or when API unavailable)
```python
from src.document_extract import extract_from_document_offline
result = extract_from_document_offline(
    file_path=path,
    title=title,
    force_domain=domain_override,
    document_id=doc_id,
)
```
Regex-based extraction — works without API but lower quality on formal documentation.

### 3B: Domain-Specific Extraction
Based on classified domain, document-specific prompts are applied:

**CAD domain (document prompts) extract:**
- Features with page-level provenance (page_number, section_title)
- Design parameters with exact values and units from tables/text
- Constraint relationships described in academic notation
- Material properties cited in papers

**CAM domain (document prompts) extract:**
- Cutting parameter tables (speeds/feeds per material)
- Strategy comparisons from research studies
- Tool selection rationale with quantitative data
- Toolpath optimization methods with formulas

**SHOP domain (document prompts) extract:**
- Standard operating procedures (SOPs)
- Quality control methods (SPC, Cp/Cpk)
- Safety protocols with regulatory references
- Troubleshooting decision trees

### 3C: Academic Paper Special Handling
For `academic_paper` type documents:
- Extract experimental methodology and setup parameters
- Capture quantitative results (forces, temperatures, surface roughness, tool wear)
- Note statistical confidence intervals
- Flag novel findings vs. confirmation of known results
- Extract formulas with variable definitions

### 3D: Confidence Scoring (document-adapted)
Each extracted item gets a confidence score:
- Explicit with numeric values + citation: 0.95
- Explicit with numeric values: 0.85
- Described in methodology/procedure: 0.75
- Referenced in discussion/conclusion: 0.65
- Implied from context: 0.50
- Inferred from domain knowledge: 0.35

**Output:** Save to `C:/PRISM/cad-engine/output/<doc_id>/knowledge.json`

## Phase 4: Knowledge Bridge

Call `C:/PRISM/cad-engine/src/knowledge_bridge.py` to map knowledge to component specs.

### 4A: Classify Each Knowledge Item
| Knowledge Type | Document Examples | PRISM Target |
|---|---|---|
| Formulas/equations | Taylor tool life eq, Kienzle force model | Engine or Algorithm |
| Parameter tables | speeds/feeds chart, material properties table | Schema or Engine lookup |
| Safety warnings | "titanium fire risk above 400°C" | Hook (safety chain) |
| Decision rules | "for Inconel, reduce speed 50% from steel" | Engine or tribal tip |
| Step-by-step procedures | "setup procedure for 5-axis machining" | Skill (5+ steps) or Script |
| Experimental results | "optimal DOC for 6061-T6 was 2.5mm at 300 SFM" | TribalKnowledgeEngine tip |
| Design guidelines | "minimum wall thickness for CNC: 0.5mm" | TribalKnowledgeEngine tip |
| Process capability data | "Cp > 1.33 achieved with coolant at 8 bar" | Formula or Engine |

### 4B: Deduplicate Against PRISM Inventory
Before generating, check what already exists:
1. Read `C:/PRISM/mcp-server/data/docs/MASTER_INDEX_COMPACT.md` (~735 tokens — NOT the 5,000-token MASTER_INDEX.md). Check `TribalKnowledgeEngine.ts` KNOWLEDGE_BASE for existing tips
3. Check `data/formulas/*.json` for existing formula coverage
4. Score novelty: NEW (1.0), EXTENDS (0.6), DUPLICATE (0.0)
5. **Academic papers**: Higher novelty bonus (+0.1) for experimentally validated data

### 4C: Rank and Select ALL
Score: `(confidence * 2 + novelty * 3 + domain_value * 2) / complexity`
- Apply confidence gates per component type
- Academic sources get +0.1 confidence bonus for validated results
- **Default: generate ALL qualifying specs** (max_components=50). Use --max-components to limit.
- Items below confidence gate are downgraded to tribal tips (if >= 0.5) or skipped
- For batch mode, aggregate and deduplicate across all documents first

**Output:** Save to `C:/PRISM/cad-engine/output/<doc_id>/component_specs.json`

Report:
```
KNOWLEDGE BRIDGE
  Items extracted:    [N]
  After dedup:        [N] unique
  Component specs:    [N] selected
    Tribal tips:      [N]
    Engines:          [N]
    Algorithms:       [N]
    Hooks:            [N]
    Skills:           [N]
    Formulas:         [N]
    Other:            [N]
```

If `--dry-run`, stop here and print the specs.

## Phase 5: Component Generation + Auto-Write

**This phase is fully automatic.** All component types are generated and written to disk without manual intervention.

### 5A: Generate All Components
```python
from component_generator import generate_components
from component_writer import write_components

gen_result = generate_components(bridge_result.specs, doc_id)
write_result = write_components(gen_result, dry_run=is_dry_run)
```

The generator produces file contents for all 8 component types:
- **TypeScript**: engines, algorithms, hooks
- **Markdown**: skills (slash commands)
- **Python**: scripts
- **JSON**: schemas, formulas

Every generated component includes provenance: `source: "document:<doc_id>@page<N>"`

### 5B: Auto-Write to Disk
`C:/PRISM/cad-engine/src/component_writer.py` handles writing:
- **Tribal tips**: Appended to `TribalKnowledgeEngine.ts` KNOWLEDGE_BASE array
- **Engines**: New `.ts` files in `mcp-server/src/engines/`
- **Algorithms**: New `.ts` files in `mcp-server/src/algorithms/`
- **Hooks**: New `.ts` files in `mcp-server/src/hooks/`
- **Skills**: New `.md` files in `~/.claude/commands/`
- **Scripts**: New `.py` files in `scripts/`
- **Schemas/Formulas**: New `.json` files in data directories

Safety: Never overwrites existing files. Hooks always `mode: "warning"`. DOI citations in metadata when available.

### 5C: Refine Generated Code
After auto-write, review each generated TypeScript file and fill in domain-specific logic from extracted knowledge.

### 5D: Brainstorm Follow-Up Work
```python
from video_brainstorm import brainstorm_from_knowledge, generate_rgs_milestone, save_brainstorm

brainstorm = brainstorm_from_knowledge(knowledge, bridge_specs, doc_id, title, domain)
milestone = generate_rgs_milestone(brainstorm, doc_id, title, domain)
save_brainstorm(brainstorm, milestone, output_dir)
```

Analyzes gaps: missing component types, integration opportunities, quality enhancements.

### 5E: RGS Milestone Generation
If brainstorm produces 2+ high/medium-value ideas, auto-generate an RGS milestone envelope:
- Milestone ID: `DL-{DOMAIN}-{doc_id[:8]}`
- Saved to output dir (not auto-registered — use `/rgs register` to activate)

Report after Phase 5:
```
COMPONENT GENERATION
  Generated:     [N] components ([N] types)
  Written:       [N] new files
  Tips appended: [N] to TribalKnowledgeEngine
  Brainstorm:    [N] follow-up ideas
  RGS Milestone: [milestone-id or "none"]
```

## Phase 6: Registration

For each generated component:
1. **Engines/Algorithms**: Add to MASTER_INDEX_COMPACT.md, register in code
2. **Tribal tips**: No separate registration (embedded in TribalKnowledgeEngine)
3. **Hooks**: Register in hook registry
4. **Skills**: No matrix entry needed (command files auto-discovered)
5. **Formulas**: Add to FormulaRegistry index

## Phase 7: Verification

1. **TypeScript**: `npm run build` in `C:/PRISM/mcp-server/` — must pass
2. **Python tests**: `python -m pytest C:/PRISM/cad-engine/tests/` — must pass
3. **Full test suite**: `npm test` in `C:/PRISM/mcp-server/` — no regression
4. If any generated tests, run those specifically

If build fails: revert the failing component, report what went wrong, proceed with remaining components.

## Phase 8: Report + Commit

### Summary Report (single document)
```
PDF-LEARN COMPLETE
==================
Document:     [title] ([pages] pages)
Path:         [file_path]
Author:       [author]
Doc Type:     [academic_paper/technical_manual/handbook/...]
Domain:       [primary] (confidence: [N])
DOI:          [doi or "N/A"]

Extraction:
  Text:            [N] chars
  Chunks:          [N]
  Items extracted: [N]
  Unique:          [N] (post-dedup)
  Avg confidence:  [N]

Components Generated:
  Tribal tips:  [N] added to TribalKnowledgeEngine
  Engines:      [N] created
  Algorithms:   [N] created
  Hooks:        [N] created
  Formulas:     [N] registered
  Skills:       [N] created
  TOTAL:        [N] new PRISM components

Verification:
  Build:  PASS
  Tests:  [N] passing (0 regression)

Committed: [hash] feat(pdf-learn): [summary]

Next: /pdf-learn [another-file] or /forge to iterate on generated components
```

### Batch Summary Report
```
PDF-LEARN BATCH COMPLETE
========================
Documents:    [N] processed ([M] skipped)
Source:       [directory or mit:<course_id>]
Total Pages:  [N]

Per-Domain Breakdown:
  CAD:  [N] docs, [N] items
  CAM:  [N] docs, [N] items
  SHOP: [N] docs, [N] items

Components Generated (all docs combined):
  Tribal tips:  [N]
  Engines:      [N]
  Algorithms:   [N]
  Hooks:        [N]
  Formulas:     [N]
  Skills:       [N]
  TOTAL:        [N] new PRISM components

Top Findings:
  1. [highest-confidence finding from batch]
  2. [second highest]
  3. [third highest]

Verification:
  Build:  PASS
  Tests:  [N] passing (0 regression)

Committed: [hash] feat(pdf-learn): learn from [N] documents — [N] components
```

### Update Learning Registry
After successful verification, update both registries:
- `C:/PRISM/cad-engine/knowledge_store/_registry.json` (document registry)
- `C:/PRISM/mcp-server/data/video-learned/learning-registry.json` (unified learning registry via `learning_registry.py`)

Add a RunRecord with: document_id, title, author, domain, doc_type, extraction stats, components generated, component IDs, verification results, DOI if available.

### Auto-Commit
Stage all new/modified files and commit:
`feat(pdf-learn): learn from [doc-title] — [N] components [PDF-LEARN]`

## MIT OCW Fetching Protocol

When `mit:<course_id>` is provided:
1. Construct OCW URL: `https://ocw.mit.edu/courses/<course_id>-<slug>/`
2. Use WebFetch to get the course page, extract lecture notes / readings links
3. Download PDFs to `C:/PRISM/cad-engine/data/mit_ocw/<course_id>/`
4. Filter: skip syllabus, exam logistics, pure math — keep lecture notes, lab manuals, readings
5. Process each relevant PDF through the pipeline
6. Common slugs:
   - `2-008-design-and-manufacturing-ii-spring-2004`
   - `2-810-manufacturing-processes-and-systems-fall-2015`
   - `2-72-elements-of-mechanical-design-fall-2009`
   - `2-670-mechanical-engineering-tools-january-iap-2004`
   - `2-830j-control-of-manufacturing-processes-sma-6303-spring-2008`

If OCW download fails (network issues, changed URLs):
- Report error with URL attempted
- Suggest downloading manually and using file path mode
- Check if any PDFs already exist in the mit_ocw directory

## Error Handling
- **pypdf not found**: Print `pip install pypdf`, offer `--dry-run`
- **File not found**: Report error, list similar files in directory
- **Encrypted PDF**: Report "PDF is encrypted/password-protected — cannot extract text"
- **Empty extraction**: Report "insufficient manufacturing content — document may not be relevant"
- **Claude API rate limit**: Retry 3x with backoff, then skip extraction
- **Build failure after generation**: Revert failing files, report what failed, keep passing components
- **Context budget**: Save progress, compact, complete current document, report remaining
- **Batch too large (>20 docs)**: Process in batches of 10, commit between batches

## Safety Rails
- Never store API keys in generated files
- Never generate hooks with mode: "blocking" from document knowledge (use "warning")
- Generated engines must use registry lookups, not hardcoded constants
- All generated components carry provenance (doc_id + page number + DOI when available)
- Tribal tip confidence reflects extraction confidence (never set to 1.0)
- Build must pass before committing — revert if it doesn't
- Do not download copyrighted PDFs — only use MIT OCW (Creative Commons) or user-provided files
- Sanitize file paths before processing (no path traversal)

## Chaining
- **Upstream**: Can be called from `/autopilot` Phase 4 or `/forge` Phase 4
- **Downstream**: Generated engines feed `/forge-engines audit`, tips feed `/material-lookup`
- **Pairs with**: `/scrutinize` (review generated code), `/video-learn` (complementary source)
- **Pairs with**: `/forge-postflight` (full registration check after batch processing)
- **Data source**: `/pdf-learn` output feeds `/forge` for deeper iteration on any component
