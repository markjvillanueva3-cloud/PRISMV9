# PRISM Development Handoff: Multi-Instance MCP Coordination

## CONTEXT

PRISM Manufacturing Intelligence is consolidating all resources into a single MCP server to enable parallel development across multiple Claude web instances. Currently, dual folder chaos and local state files prevent concurrent work. This task adds atomic coordination primitives to the MCP server.

**Goal:** Enable 3-7 Claude instances to work simultaneously on different roadmap sessions without sync conflicts.

---

## ARCHITECTURE

```
Instance A          Instance B          Instance C
    │                   │                   │
    └───────────────────┼───────────────────┘
                        ▼
         ┌──────────────────────────────┐
         │     PRISM MCP SERVER         │
         │  ┌────────────────────────┐  │
         │  │   TaskCoordinator      │  │  ← Atomic task claim/release
         │  │   InstanceRegistry     │  │  ← Track active instances  
         │  │   ConflictResolver     │  │  ← Handle race conditions
         │  │   StateLockManager     │  │  ← Advisory file locks
         │  └────────────────────────┘  │
         │              │               │
         │  ┌───────────┴────────────┐  │
         │  │ state/                 │  │
         │  │ ├─ CURRENT_STATE.json  │  │
         │  │ ├─ ROADMAP_TRACKER.json│  │
         │  │ ├─ task_claims.json    │  │  ← NEW: Who owns what
         │  │ └─ instance_registry.json│ │  ← NEW: Active instances
         │  └────────────────────────┘  │
         └──────────────────────────────┘
```

---

## DELIVERABLES (8 items)

### Python Scripts (4)

| # | File | Path | Lines | Purpose |
|---|------|------|-------|---------|
| 1 | task_coordinator.py | C:\PRISM\scripts\core\ | ~200 | Atomic task claim/release with file locking |
| 2 | instance_registry.py | C:\PRISM\scripts\core\ | ~150 | Track active instances, heartbeat, cleanup |
| 3 | conflict_resolver.py | C:\PRISM\scripts\core\ | ~180 | Detect and resolve simultaneous writes |
| 4 | state_lock_manager.py | C:\PRISM\scripts\core\ | ~120 | Advisory locks on state files |

### MCP Tools (4)

| # | Tool Name | Purpose |
|---|-----------|---------|
| 5 | prism_task_claim | Atomically claim a roadmap session/task |
| 6 | prism_task_release | Release claimed task when complete |
| 7 | prism_instance_register | Register instance with heartbeat |
| 8 | prism_coordination_status | Show all active instances and their tasks |

---

## TECHNICAL SPECIFICATIONS

### TaskCoordinator.py

```python
"""
PRISM Task Coordinator v1.0
Provides atomic task claiming with file-based locking for multi-instance coordination.

Key Methods:
- claim_task(task_id, instance_id) -> ClaimResult
- release_task(task_id, instance_id) -> bool
- get_claimed_tasks() -> List[TaskClaim]
- is_task_available(task_id) -> bool
- force_release_stale(timeout_minutes=30) -> List[str]

File: C:\PRISM\state\task_claims.json
Lock: C:\PRISM\state\.task_claims.lock (advisory)

ClaimResult:
  - success: bool
  - task_id: str
  - instance_id: str
  - claimed_at: datetime
  - error: Optional[str]
"""

import json
import fcntl  # or msvcrt on Windows
import time
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional, List

CLAIMS_FILE = Path("C:/PRISM/state/task_claims.json")
LOCK_FILE = Path("C:/PRISM/state/.task_claims.lock")

@dataclass
class TaskClaim:
    task_id: str
    instance_id: str
    claimed_at: str
    heartbeat_at: str

@dataclass  
class ClaimResult:
    success: bool
    task_id: str
    instance_id: str
    claimed_at: Optional[str] = None
    error: Optional[str] = None

class TaskCoordinator:
    def __init__(self):
        self._ensure_files_exist()
    
    def _ensure_files_exist(self):
        CLAIMS_FILE.parent.mkdir(parents=True, exist_ok=True)
        if not CLAIMS_FILE.exists():
            CLAIMS_FILE.write_text('{"claims": {}, "history": []}')
    
    def _acquire_lock(self, timeout_sec=10):
        """Acquire advisory lock on claims file"""
        # Implementation varies by OS
        pass
    
    def _release_lock(self):
        """Release advisory lock"""
        pass
    
    def claim_task(self, task_id: str, instance_id: str) -> ClaimResult:
        """
        Atomically claim a task. Returns success if claimed, 
        or error if already claimed by another instance.
        """
        self._acquire_lock()
        try:
            data = json.loads(CLAIMS_FILE.read_text())
            
            # Check if already claimed
            if task_id in data["claims"]:
                existing = data["claims"][task_id]
                if existing["instance_id"] != instance_id:
                    return ClaimResult(
                        success=False,
                        task_id=task_id,
                        instance_id=instance_id,
                        error=f"Already claimed by {existing['instance_id']}"
                    )
            
            # Claim it
            now = datetime.utcnow().isoformat()
            data["claims"][task_id] = {
                "instance_id": instance_id,
                "claimed_at": now,
                "heartbeat_at": now
            }
            data["history"].append({
                "action": "claim",
                "task_id": task_id,
                "instance_id": instance_id,
                "timestamp": now
            })
            
            CLAIMS_FILE.write_text(json.dumps(data, indent=2))
            
            return ClaimResult(
                success=True,
                task_id=task_id,
                instance_id=instance_id,
                claimed_at=now
            )
        finally:
            self._release_lock()
    
    def release_task(self, task_id: str, instance_id: str) -> bool:
        """Release a claimed task. Only the owner can release."""
        self._acquire_lock()
        try:
            data = json.loads(CLAIMS_FILE.read_text())
            
            if task_id not in data["claims"]:
                return True  # Already released
            
            if data["claims"][task_id]["instance_id"] != instance_id:
                return False  # Not your task
            
            del data["claims"][task_id]
            data["history"].append({
                "action": "release",
                "task_id": task_id,
                "instance_id": instance_id,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            CLAIMS_FILE.write_text(json.dumps(data, indent=2))
            return True
        finally:
            self._release_lock()
    
    def heartbeat(self, task_id: str, instance_id: str) -> bool:
        """Update heartbeat timestamp for a claimed task."""
        pass
    
    def force_release_stale(self, timeout_minutes: int = 30) -> List[str]:
        """Release tasks with no heartbeat for timeout_minutes."""
        pass
    
    def get_available_tasks(self, all_tasks: List[str]) -> List[str]:
        """Return tasks not currently claimed."""
        pass
```

### InstanceRegistry.py

```python
"""
PRISM Instance Registry v1.0
Tracks active Claude instances for coordination visibility.

Key Methods:
- register(instance_id, metadata) -> RegistrationResult
- heartbeat(instance_id) -> bool
- deregister(instance_id) -> bool
- get_active_instances() -> List[InstanceInfo]
- cleanup_stale(timeout_minutes=15) -> List[str]

File: C:\PRISM\state\instance_registry.json
"""

@dataclass
class InstanceInfo:
    instance_id: str
    registered_at: str
    last_heartbeat: str
    current_task: Optional[str]
    metadata: dict  # e.g., {"type": "web_claude", "focus": "materials"}
```

### MCP Tool Implementations

Add to `C:\PRISM\mcp-server\src\tools\coordinationTools.ts`:

```typescript
/**
 * PRISM MCP Server - Multi-Instance Coordination Tools
 * 
 * Tools:
 * - prism_task_claim: Atomically claim a roadmap task
 * - prism_task_release: Release a claimed task
 * - prism_instance_register: Register this instance
 * - prism_coordination_status: View all instances and claims
 */

import { z } from "zod";
import { execSync } from "child_process";

// prism_task_claim
export const taskClaimSchema = z.object({
  task_id: z.string().describe("Roadmap session ID (e.g., '0.1', '1.1')"),
  instance_id: z.string().describe("Unique identifier for this instance"),
  force: z.boolean().optional().describe("Force claim even if already claimed (use carefully)")
});

export async function taskClaim(params: z.infer<typeof taskClaimSchema>) {
  const result = execSync(
    `python C:\\PRISM\\scripts\\core\\task_coordinator.py claim "${params.task_id}" "${params.instance_id}"`,
    { encoding: 'utf-8' }
  );
  return JSON.parse(result);
}

// prism_task_release
export const taskReleaseSchema = z.object({
  task_id: z.string().describe("Task ID to release"),
  instance_id: z.string().describe("Instance releasing the task")
});

// prism_coordination_status
export async function coordinationStatus() {
  // Returns combined view of:
  // - Active instances
  // - Claimed tasks
  // - Available tasks from roadmap
  // - Stale claims needing cleanup
}
```

---

## INTEGRATION POINTS

### 1. Update ROADMAP_TRACKER.json Schema

Add coordination fields:

```json
{
  "sessions": {
    "0.1": {
      "name": "Compaction Recovery System",
      "status": "IN_PROGRESS",
      "claimed_by": "instance_web_A",      // NEW
      "claimed_at": "2026-02-01T22:00:00Z", // NEW
      "parallelizable": false               // NEW: Can multiple instances work on this?
    }
  }
}
```

### 2. Update GSD Protocol

Modify session start to include:

```
1. prism_instance_register (identify self)
2. prism_coordination_status (see what's taken)
3. prism_task_claim (claim available task)
4. ... do work ...
5. prism_task_release (on completion)
```

### 3. Heartbeat Integration

Every checkpoint should call `prism_instance_heartbeat` to prevent stale detection.

---

## SUCCESS CRITERIA

| Criterion | Test |
|-----------|------|
| Atomic claiming works | Two instances claim same task → one succeeds, one fails |
| No race conditions | 100 concurrent claim attempts → exactly 1 succeeds |
| Stale cleanup works | Instance dies → task auto-releases after timeout |
| Status visibility | Any instance can see all active work |
| Roadmap integration | Claimed tasks shown in tracker |

---

## EXECUTION ORDER

1. Create `C:\PRISM\state\task_claims.json` (initial empty structure)
2. Create `C:\PRISM\state\instance_registry.json` (initial empty structure)
3. Implement `task_coordinator.py` with full locking
4. Implement `instance_registry.py`
5. Implement `conflict_resolver.py`
6. Add MCP tools to server
7. Test with 2 instances claiming same task
8. Update GSD protocol documentation

---

## FILE LOCATIONS

| Type | Path |
|------|------|
| Scripts | C:\PRISM\scripts\core\ |
| State Files | C:\PRISM\state\ |
| MCP Tools | C:\PRISM\mcp-server\src\tools\coordinationTools.ts |
| Tool Index | C:\PRISM\mcp-server\src\tools\index.ts (add export) |

---

## DEPENDENCIES

- Python 3.10+ with `filelock` package (or use `msvcrt` on Windows)
- Existing MCP server infrastructure
- ROADMAP_TRACKER.json exists

---

## ANTI-PATTERNS TO AVOID

1. **Don't use in-memory locks** - File-based required for cross-process
2. **Don't skip heartbeats** - Stale detection depends on them
3. **Don't hardcode instance IDs** - Generate unique per session
4. **Don't ignore lock timeouts** - Could cause deadlocks

---

## ESTIMATED EFFORT

| Component | Lines | Time |
|-----------|-------|------|
| task_coordinator.py | 200 | 20 min |
| instance_registry.py | 150 | 15 min |
| conflict_resolver.py | 180 | 15 min |
| state_lock_manager.py | 120 | 10 min |
| MCP tools (4) | 300 | 25 min |
| Testing | - | 15 min |
| **Total** | **950** | **~100 min** |

---

## START COMMAND

```
Read C:\PRISM\state\ROADMAP_TRACKER.json
Read C:\PRISM\state\CURRENT_STATE.json
Execute this handoff as Session 0.0 (pre-requisite to all parallel work)
Checkpoint every 2 deliverables
```

---

*Generated: 2026-02-01 | Session: Multi-Instance Coordination Handoff*
