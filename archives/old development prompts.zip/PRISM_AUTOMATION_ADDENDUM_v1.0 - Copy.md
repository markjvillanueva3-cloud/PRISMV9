# PRISM AUTOMATION ADDENDUM v1.0
## Full Sync Elimination & Auto-Pipeline Integration
### Addition to Emergency Roadmap v4.0

---

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                         GOAL: ZERO MANUAL SYNCING                            ║
║                                                                              ║
║   Edit Excel → Everything else happens automatically                         ║
║   Edit JSON  → Everything else happens automatically                         ║
║   Edit Code  → Index updates automatically                                   ║
║   Session ends → State preserved automatically                               ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

---

# PHASE 2.5: FULL AUTOMATION SYSTEM (INSERT AFTER PHASE 2)
## Sessions 26.5-26.8 | Time: 8-10 hours | Priority: 🔴 EMERGENCY

## The Current Manual Pain Points

```
TODAY (Manual):
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. You edit materials.xlsx                                                  │
│ 2. You remember to run master_sync.py                     ← MANUAL          │
│ 3. You check if JSON updated correctly                    ← MANUAL          │
│ 4. You verify DuckDB imported                             ← MANUAL          │
│ 5. You upload to Google Drive                             ← MANUAL          │
│ 6. You tell Claude "I updated materials"                  ← MANUAL          │
│                                                                             │
│ FAILURE MODES:                                                              │
│ • Forget to sync → Claude uses stale data                                   │
│ • Sync partially fails → Data inconsistency                                 │
│ • Edit multiple files → Multiple manual syncs                               │
│ • Forget Drive backup → Data loss risk                                      │
└─────────────────────────────────────────────────────────────────────────────┘

AFTER (Automated):
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. You edit materials.xlsx                                                  │
│ 2. File watcher detects change                            ← AUTO            │
│ 3. Validation runs                                        ← AUTO            │
│ 4. JSON generated                                         ← AUTO            │
│ 5. DuckDB updated                                         ← AUTO            │
│ 6. Google Drive synced                                    ← AUTO            │
│ 7. MCP cache invalidated                                  ← AUTO            │
│ 8. Hooks fire for dependent updates                       ← AUTO            │
│ 9. Claude sees new data on next query                     ← AUTO            │
│                                                                             │
│ YOU DO: Edit file. THAT'S IT.                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Session 26.5: File Watcher System

### 26.5.1 Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        FILE WATCHER SYSTEM                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  WATCHER SERVICE (Background Process)                                       │
│  ├── Monitors: C:\PRISM\data\**\*                                          │
│  ├── Monitors: C:\PRISM\src\**\*                                           │
│  ├── Monitors: C:\PRISM\state\**\*                                         │
│  ├── Monitors: C:\PRISM\config\**\*                                        │
│  └── Debounce: 2 seconds (wait for save to complete)                       │
│                                                                             │
│  EVENT TYPES                                                                │
│  ├── FILE_CREATED   → Trigger: index, validate, sync                       │
│  ├── FILE_MODIFIED  → Trigger: validate, sync, cache_invalidate            │
│  ├── FILE_DELETED   → Trigger: cascade_check, index_remove                 │
│  └── FILE_RENAMED   → Trigger: index_update, reference_update              │
│                                                                             │
│  PIPELINE TRIGGERS                                                          │
│  ├── *.xlsx modified  → Excel→JSON→DuckDB→Drive pipeline                   │
│  ├── *.json modified  → Validate→DuckDB→Drive pipeline                     │
│  ├── *.ts modified    → Reindex symbol, update dependencies                │
│  ├── *.py modified    → Validate syntax, update script registry            │
│  └── *.md modified    → Update doc index                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 26.5.2 Watcher Implementation

Create: `C:\PRISM\scripts\services\file_watcher.py`

```python
#!/usr/bin/env python3
"""
PRISM File Watcher Service
Monitors C:\PRISM for changes and triggers appropriate pipelines.
Runs as background service.
"""

import os
import sys
import time
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Callable, Optional
from dataclasses import dataclass
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent
import threading
from queue import Queue

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    handlers=[
        logging.FileHandler('C:\\PRISM\\logs\\file_watcher.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('PRISM.FileWatcher')

@dataclass
class WatchConfig:
    """Configuration for a watched directory"""
    path: str
    patterns: List[str]  # File patterns to watch
    pipeline: str        # Pipeline to trigger
    debounce_ms: int = 2000
    recursive: bool = True
    enabled: bool = True

# Watch configurations
WATCH_CONFIGS: List[WatchConfig] = [
    WatchConfig(
        path="C:\\PRISM\\data\\excel",
        patterns=["*.xlsx", "*.xls"],
        pipeline="excel_to_all",
        debounce_ms=3000  # Excel saves can be slow
    ),
    WatchConfig(
        path="C:\\PRISM\\data\\json",
        patterns=["*.json"],
        pipeline="json_to_db",
        debounce_ms=1000
    ),
    WatchConfig(
        path="C:\\PRISM\\src",
        patterns=["*.ts", "*.tsx"],
        pipeline="code_reindex",
        debounce_ms=2000
    ),
    WatchConfig(
        path="C:\\PRISM\\scripts",
        patterns=["*.py"],
        pipeline="script_validate",
        debounce_ms=1000
    ),
    WatchConfig(
        path="C:\\PRISM\\state",
        patterns=["*.json"],
        pipeline="state_backup",
        debounce_ms=5000  # Don't backup too frequently
    ),
    WatchConfig(
        path="C:\\PRISM\\docs",
        patterns=["*.md"],
        pipeline="doc_reindex",
        debounce_ms=2000
    ),
    WatchConfig(
        path="C:\\PRISM\\config",
        patterns=["*.json", "*.yaml"],
        pipeline="config_validate",
        debounce_ms=1000
    )
]

class DebouncedHandler(FileSystemEventHandler):
    """Handler with debouncing to avoid duplicate triggers"""
    
    def __init__(self, config: WatchConfig, pipeline_executor):
        self.config = config
        self.pipeline_executor = pipeline_executor
        self.pending_events: Dict[str, datetime] = {}
        self.lock = threading.Lock()
        
        # Start debounce processor thread
        self.processor_thread = threading.Thread(target=self._process_pending, daemon=True)
        self.processor_thread.start()
    
    def _matches_pattern(self, path: str) -> bool:
        """Check if path matches any watched pattern"""
        from fnmatch import fnmatch
        filename = os.path.basename(path)
        return any(fnmatch(filename, pattern) for pattern in self.config.patterns)
    
    def _should_ignore(self, path: str) -> bool:
        """Check if path should be ignored"""
        ignore_patterns = [
            '__pycache__', 
            '.git', 
            'node_modules', 
            '.tmp',
            '~$',  # Excel temp files
            '.swp'  # Vim swap files
        ]
        return any(pattern in path for pattern in ignore_patterns)
    
    def on_any_event(self, event: FileSystemEvent):
        """Handle any file system event"""
        if event.is_directory:
            return
        
        path = event.src_path
        
        if self._should_ignore(path):
            return
        
        if not self._matches_pattern(path):
            return
        
        with self.lock:
            self.pending_events[path] = datetime.now()
            logger.debug(f"Event queued: {event.event_type} - {path}")
    
    def _process_pending(self):
        """Process pending events after debounce period"""
        while True:
            time.sleep(0.5)  # Check every 500ms
            
            now = datetime.now()
            to_process = []
            
            with self.lock:
                for path, timestamp in list(self.pending_events.items()):
                    age_ms = (now - timestamp).total_seconds() * 1000
                    if age_ms >= self.config.debounce_ms:
                        to_process.append(path)
                        del self.pending_events[path]
            
            for path in to_process:
                self._trigger_pipeline(path)
    
    def _trigger_pipeline(self, path: str):
        """Trigger the configured pipeline for this path"""
        logger.info(f"Triggering pipeline '{self.config.pipeline}' for: {path}")
        try:
            self.pipeline_executor.execute(
                pipeline=self.config.pipeline,
                trigger_file=path,
                context={
                    "watch_path": self.config.path,
                    "patterns": self.config.patterns,
                    "triggered_at": datetime.now().isoformat()
                }
            )
        except Exception as e:
            logger.error(f"Pipeline '{self.config.pipeline}' failed for {path}: {e}")


class PipelineExecutor:
    """Executes sync pipelines"""
    
    def __init__(self):
        self.pipelines = self._load_pipelines()
        self.execution_log: List[dict] = []
    
    def _load_pipelines(self) -> Dict[str, dict]:
        """Define available pipelines"""
        return {
            "excel_to_all": {
                "description": "Excel → JSON → DuckDB → Drive",
                "steps": [
                    {"action": "excel_to_json", "params": {}},
                    {"action": "validate_json", "params": {"strict": True}},
                    {"action": "json_to_duckdb", "params": {}},
                    {"action": "invalidate_mcp_cache", "params": {}},
                    {"action": "sync_to_drive", "params": {"folder": "PRISM Data"}},
                    {"action": "fire_hooks", "params": {"hooks": ["data.onUpdate"]}}
                ],
                "on_failure": "rollback",
                "notifications": ["log", "state"]
            },
            "json_to_db": {
                "description": "JSON → Validate → DuckDB → Drive",
                "steps": [
                    {"action": "validate_json", "params": {"strict": True}},
                    {"action": "json_to_duckdb", "params": {}},
                    {"action": "invalidate_mcp_cache", "params": {}},
                    {"action": "sync_to_drive", "params": {"folder": "PRISM Data"}},
                    {"action": "fire_hooks", "params": {"hooks": ["data.onUpdate"]}}
                ],
                "on_failure": "alert",
                "notifications": ["log"]
            },
            "code_reindex": {
                "description": "Reindex modified code file",
                "steps": [
                    {"action": "parse_typescript", "params": {}},
                    {"action": "update_symbol_index", "params": {}},
                    {"action": "update_dependencies", "params": {}},
                    {"action": "invalidate_code_cache", "params": {}}
                ],
                "on_failure": "log",
                "notifications": ["log"]
            },
            "script_validate": {
                "description": "Validate Python script syntax",
                "steps": [
                    {"action": "python_syntax_check", "params": {}},
                    {"action": "update_script_registry", "params": {}}
                ],
                "on_failure": "log",
                "notifications": ["log"]
            },
            "state_backup": {
                "description": "Backup state files",
                "steps": [
                    {"action": "copy_to_backup", "params": {"keep_versions": 10}},
                    {"action": "sync_to_drive", "params": {"folder": "PRISM State"}}
                ],
                "on_failure": "alert",
                "notifications": ["log"]
            },
            "doc_reindex": {
                "description": "Reindex documentation",
                "steps": [
                    {"action": "parse_markdown", "params": {}},
                    {"action": "update_doc_index", "params": {}},
                    {"action": "extract_links", "params": {}}
                ],
                "on_failure": "log",
                "notifications": ["log"]
            },
            "config_validate": {
                "description": "Validate configuration files",
                "steps": [
                    {"action": "validate_json_schema", "params": {}},
                    {"action": "reload_config", "params": {}},
                    {"action": "fire_hooks", "params": {"hooks": ["config.onUpdate"]}}
                ],
                "on_failure": "alert",
                "notifications": ["log", "state"]
            }
        }
    
    def execute(self, pipeline: str, trigger_file: str, context: dict) -> dict:
        """Execute a pipeline"""
        if pipeline not in self.pipelines:
            raise ValueError(f"Unknown pipeline: {pipeline}")
        
        config = self.pipelines[pipeline]
        logger.info(f"Executing pipeline: {pipeline} ({config['description']})")
        
        results = {
            "pipeline": pipeline,
            "trigger_file": trigger_file,
            "started_at": datetime.now().isoformat(),
            "steps": [],
            "status": "running"
        }
        
        try:
            for i, step in enumerate(config["steps"]):
                step_result = self._execute_step(step, trigger_file, context)
                results["steps"].append({
                    "action": step["action"],
                    "status": step_result["status"],
                    "duration_ms": step_result.get("duration_ms", 0)
                })
                
                if step_result["status"] == "failed":
                    if config["on_failure"] == "rollback":
                        self._rollback(results["steps"][:i])
                    raise Exception(f"Step {step['action']} failed: {step_result.get('error')}")
            
            results["status"] = "success"
            results["completed_at"] = datetime.now().isoformat()
            
        except Exception as e:
            results["status"] = "failed"
            results["error"] = str(e)
            results["completed_at"] = datetime.now().isoformat()
            logger.error(f"Pipeline {pipeline} failed: {e}")
        
        self.execution_log.append(results)
        self._notify(config["notifications"], results)
        
        return results
    
    def _execute_step(self, step: dict, trigger_file: str, context: dict) -> dict:
        """Execute a single pipeline step"""
        import time
        start = time.time()
        
        action = step["action"]
        params = step.get("params", {})
        
        try:
            # Route to appropriate action handler
            if action == "excel_to_json":
                result = self._action_excel_to_json(trigger_file, params)
            elif action == "validate_json":
                result = self._action_validate_json(trigger_file, params)
            elif action == "json_to_duckdb":
                result = self._action_json_to_duckdb(trigger_file, params)
            elif action == "invalidate_mcp_cache":
                result = self._action_invalidate_cache(trigger_file, params)
            elif action == "sync_to_drive":
                result = self._action_sync_drive(trigger_file, params)
            elif action == "fire_hooks":
                result = self._action_fire_hooks(trigger_file, params)
            elif action == "parse_typescript":
                result = self._action_parse_ts(trigger_file, params)
            elif action == "update_symbol_index":
                result = self._action_update_index(trigger_file, params)
            elif action == "copy_to_backup":
                result = self._action_backup(trigger_file, params)
            else:
                result = {"status": "skipped", "reason": f"Unknown action: {action}"}
            
            result["duration_ms"] = int((time.time() - start) * 1000)
            return result
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e),
                "duration_ms": int((time.time() - start) * 1000)
            }
    
    # Action implementations
    def _action_excel_to_json(self, file: str, params: dict) -> dict:
        """Convert Excel to JSON"""
        import pandas as pd
        
        # Determine output path
        json_path = file.replace('.xlsx', '.json').replace('.xls', '.json')
        json_path = json_path.replace('\\excel\\', '\\json\\')
        
        # Read Excel
        df = pd.read_excel(file)
        
        # Convert to JSON
        data = df.to_dict(orient='records')
        
        # Write JSON
        os.makedirs(os.path.dirname(json_path), exist_ok=True)
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, default=str)
        
        logger.info(f"Converted {file} → {json_path} ({len(data)} records)")
        return {"status": "success", "output": json_path, "records": len(data)}
    
    def _action_validate_json(self, file: str, params: dict) -> dict:
        """Validate JSON file"""
        # If trigger was Excel, find the JSON
        if file.endswith(('.xlsx', '.xls')):
            file = file.replace('.xlsx', '.json').replace('.xls', '.json')
            file = file.replace('\\excel\\', '\\json\\')
        
        with open(file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Basic validation
        if not isinstance(data, (list, dict)):
            return {"status": "failed", "error": "Invalid JSON structure"}
        
        record_count = len(data) if isinstance(data, list) else 1
        return {"status": "success", "records": record_count}
    
    def _action_json_to_duckdb(self, file: str, params: dict) -> dict:
        """Import JSON to DuckDB"""
        import duckdb
        
        # Determine table name from file
        if file.endswith(('.xlsx', '.xls')):
            file = file.replace('.xlsx', '.json').replace('.xls', '.json')
            file = file.replace('\\excel\\', '\\json\\')
        
        table_name = Path(file).stem.lower()
        db_path = "C:\\PRISM\\data\\prism.duckdb"
        
        # Connect and import
        conn = duckdb.connect(db_path)
        
        # Create or replace table
        conn.execute(f"""
            CREATE OR REPLACE TABLE {table_name} AS 
            SELECT * FROM read_json_auto('{file}')
        """)
        
        # Get count
        count = conn.execute(f"SELECT COUNT(*) FROM {table_name}").fetchone()[0]
        conn.close()
        
        logger.info(f"Imported {file} → DuckDB.{table_name} ({count} records)")
        return {"status": "success", "table": table_name, "records": count}
    
    def _action_invalidate_cache(self, file: str, params: dict) -> dict:
        """Invalidate MCP cache for affected data"""
        # Write cache invalidation marker
        cache_file = "C:\\PRISM\\state\\cache_invalidations.json"
        
        invalidations = []
        if os.path.exists(cache_file):
            with open(cache_file, 'r') as f:
                invalidations = json.load(f)
        
        invalidations.append({
            "file": file,
            "timestamp": datetime.now().isoformat(),
            "type": "data_update"
        })
        
        # Keep last 100
        invalidations = invalidations[-100:]
        
        with open(cache_file, 'w') as f:
            json.dump(invalidations, f, indent=2)
        
        return {"status": "success"}
    
    def _action_sync_drive(self, file: str, params: dict) -> dict:
        """Sync to Google Drive (placeholder - needs Drive API)"""
        # This would use Google Drive API
        # For now, just log
        logger.info(f"Would sync {file} to Drive folder: {params.get('folder', 'PRISM')}")
        return {"status": "success", "note": "Drive sync placeholder"}
    
    def _action_fire_hooks(self, file: str, params: dict) -> dict:
        """Fire hooks for data update"""
        hooks = params.get("hooks", [])
        # This would integrate with the hook system
        logger.info(f"Firing hooks: {hooks}")
        return {"status": "success", "hooks_fired": hooks}
    
    def _action_parse_ts(self, file: str, params: dict) -> dict:
        """Parse TypeScript file for indexing"""
        # This would use the monolith indexer
        return {"status": "success"}
    
    def _action_update_index(self, file: str, params: dict) -> dict:
        """Update symbol index"""
        return {"status": "success"}
    
    def _action_backup(self, file: str, params: dict) -> dict:
        """Create backup copy"""
        import shutil
        
        backup_dir = "C:\\PRISM\\backups"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        filename = os.path.basename(file)
        backup_path = os.path.join(backup_dir, f"{timestamp}_{filename}")
        
        os.makedirs(backup_dir, exist_ok=True)
        shutil.copy2(file, backup_path)
        
        # Clean old backups
        keep_versions = params.get("keep_versions", 10)
        self._cleanup_old_backups(backup_dir, filename, keep_versions)
        
        return {"status": "success", "backup": backup_path}
    
    def _cleanup_old_backups(self, backup_dir: str, filename: str, keep: int):
        """Remove old backup versions"""
        pattern = f"*_{filename}"
        backups = sorted(Path(backup_dir).glob(pattern), reverse=True)
        
        for old_backup in backups[keep:]:
            old_backup.unlink()
            logger.debug(f"Removed old backup: {old_backup}")
    
    def _rollback(self, completed_steps: list):
        """Rollback completed steps on failure"""
        logger.warning(f"Rolling back {len(completed_steps)} steps")
        # Implementation depends on specific rollback needs
    
    def _notify(self, channels: list, results: dict):
        """Send notifications"""
        if "log" in channels:
            status = results["status"]
            pipeline = results["pipeline"]
            if status == "success":
                logger.info(f"✅ Pipeline {pipeline} completed successfully")
            else:
                logger.error(f"❌ Pipeline {pipeline} failed: {results.get('error')}")
        
        if "state" in channels:
            # Update state file
            state_file = "C:\\PRISM\\state\\pipeline_status.json"
            with open(state_file, 'w') as f:
                json.dump({
                    "last_pipeline": results["pipeline"],
                    "last_status": results["status"],
                    "last_run": results.get("completed_at"),
                    "last_error": results.get("error")
                }, f, indent=2)


class PRISMFileWatcherService:
    """Main service that manages all file watchers"""
    
    def __init__(self):
        self.observer = Observer()
        self.pipeline_executor = PipelineExecutor()
        self.handlers: List[DebouncedHandler] = []
    
    def start(self):
        """Start watching all configured directories"""
        logger.info("Starting PRISM File Watcher Service...")
        
        for config in WATCH_CONFIGS:
            if not config.enabled:
                logger.info(f"Skipping disabled watch: {config.path}")
                continue
            
            if not os.path.exists(config.path):
                logger.warning(f"Watch path does not exist: {config.path}")
                continue
            
            handler = DebouncedHandler(config, self.pipeline_executor)
            self.handlers.append(handler)
            
            self.observer.schedule(
                handler,
                config.path,
                recursive=config.recursive
            )
            logger.info(f"Watching: {config.path} ({', '.join(config.patterns)})")
        
        self.observer.start()
        logger.info("File Watcher Service started successfully")
    
    def stop(self):
        """Stop all watchers"""
        logger.info("Stopping File Watcher Service...")
        self.observer.stop()
        self.observer.join()
        logger.info("File Watcher Service stopped")
    
    def status(self) -> dict:
        """Get service status"""
        return {
            "running": self.observer.is_alive(),
            "watchers": len(self.handlers),
            "watched_paths": [c.path for c in WATCH_CONFIGS if c.enabled],
            "recent_executions": self.pipeline_executor.execution_log[-10:]
        }


def main():
    """Run the file watcher as a service"""
    service = PRISMFileWatcherService()
    
    try:
        service.start()
        
        # Keep running until interrupted
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        logger.info("Received shutdown signal")
    finally:
        service.stop()


if __name__ == "__main__":
    main()
```

### 26.5.3 New MCP Tools for File Watcher

```python
# File Watcher MCP Tools (8 new tools)

# Service Control
prism_watcher_start()                                 # Start watcher service
prism_watcher_stop()                                  # Stop watcher service
prism_watcher_status()                                # Get service status
prism_watcher_restart()                               # Restart service

# Configuration
prism_watcher_config_get()                            # Get watch configurations
prism_watcher_config_set(path, patterns, pipeline)    # Add/update watch
prism_watcher_config_disable(path)                    # Disable watch

# Manual Triggers
prism_watcher_trigger(file_path, pipeline=None)       # Manually trigger pipeline
```

### 26.5.4 Deliverables for Session 26.5
```
□ Create file_watcher.py service script
□ Implement all pipeline actions
□ Add 8 watcher MCP tools
□ Test with Excel file modification
□ Test with JSON file modification  
□ Test with code file modification
□ Verify debouncing works correctly
□ Document pipeline configurations
□ MCP Server version: v3.4 → v3.5
```

---

## Session 26.6: Google Drive Auto-Sync

### 26.6.1 Drive Sync Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       GOOGLE DRIVE AUTO-SYNC                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  LOCAL CHANGES → DRIVE                                                      │
│  ├── On file change (via watcher)                                          │
│  ├── On manual trigger                                                      │
│  └── On scheduled interval (hourly backup)                                  │
│                                                                             │
│  SYNC MAPPING                                                               │
│  ├── C:\PRISM\data\json\*     → Drive:/PRISM/Data/JSON/                    │
│  ├── C:\PRISM\data\excel\*    → Drive:/PRISM/Data/Excel/                   │
│  ├── C:\PRISM\state\*         → Drive:/PRISM/State/                        │
│  ├── C:\PRISM\outputs\*       → Drive:/PRISM/Outputs/                      │
│  └── C:\PRISM\docs\*          → Drive:/PRISM/Docs/                         │
│                                                                             │
│  CONFLICT RESOLUTION                                                        │
│  ├── Local wins (default)                                                   │
│  ├── Drive wins (on request)                                                │
│  └── Keep both (rename with timestamp)                                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 26.6.2 Drive Sync Implementation

Create: `C:\PRISM\scripts\services\drive_sync.py`

```python
#!/usr/bin/env python3
"""
PRISM Google Drive Sync Service
Automatically syncs local changes to Google Drive.
"""

import os
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

logger = logging.getLogger('PRISM.DriveSync')

SCOPES = ['https://www.googleapis.com/auth/drive.file']

# Sync mappings: local path → Drive folder
SYNC_MAPPINGS = {
    "C:\\PRISM\\data\\json": "PRISM/Data/JSON",
    "C:\\PRISM\\data\\excel": "PRISM/Data/Excel",
    "C:\\PRISM\\state": "PRISM/State",
    "C:\\PRISM\\outputs": "PRISM/Outputs",
    "C:\\PRISM\\docs": "PRISM/Docs",
    "C:\\PRISM\\backups": "PRISM/Backups"
}


class DriveSyncService:
    """Google Drive sync service"""
    
    def __init__(self, credentials_path: str = "C:\\PRISM\\config\\drive_credentials.json"):
        self.credentials_path = credentials_path
        self.token_path = "C:\\PRISM\\config\\drive_token.json"
        self.service = None
        self.folder_cache: Dict[str, str] = {}  # path → folder_id
        self._authenticate()
    
    def _authenticate(self):
        """Authenticate with Google Drive API"""
        creds = None
        
        if os.path.exists(self.token_path):
            creds = Credentials.from_authorized_user_file(self.token_path, SCOPES)
        
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    self.credentials_path, SCOPES
                )
                creds = flow.run_local_server(port=0)
            
            with open(self.token_path, 'w') as token:
                token.write(creds.to_json())
        
        self.service = build('drive', 'v3', credentials=creds)
        logger.info("Google Drive authenticated successfully")
    
    def _get_or_create_folder(self, folder_path: str) -> str:
        """Get or create a folder path in Drive, return folder ID"""
        if folder_path in self.folder_cache:
            return self.folder_cache[folder_path]
        
        parts = folder_path.split('/')
        parent_id = 'root'
        
        for part in parts:
            # Search for existing folder
            query = f"name='{part}' and '{parent_id}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false"
            results = self.service.files().list(q=query, fields="files(id, name)").execute()
            files = results.get('files', [])
            
            if files:
                parent_id = files[0]['id']
            else:
                # Create folder
                folder_metadata = {
                    'name': part,
                    'mimeType': 'application/vnd.google-apps.folder',
                    'parents': [parent_id]
                }
                folder = self.service.files().create(body=folder_metadata, fields='id').execute()
                parent_id = folder.get('id')
                logger.info(f"Created Drive folder: {part}")
        
        self.folder_cache[folder_path] = parent_id
        return parent_id
    
    def sync_file(self, local_path: str, drive_folder: str = None) -> dict:
        """Sync a single file to Drive"""
        if not os.path.exists(local_path):
            return {"status": "failed", "error": f"File not found: {local_path}"}
        
        # Determine Drive folder
        if not drive_folder:
            for local_base, drive_base in SYNC_MAPPINGS.items():
                if local_path.startswith(local_base):
                    # Get relative path and construct Drive path
                    rel_path = os.path.relpath(os.path.dirname(local_path), local_base)
                    if rel_path == '.':
                        drive_folder = drive_base
                    else:
                        drive_folder = f"{drive_base}/{rel_path}".replace('\\', '/')
                    break
        
        if not drive_folder:
            return {"status": "failed", "error": "No sync mapping for path"}
        
        # Get/create folder
        folder_id = self._get_or_create_folder(drive_folder)
        
        # Check if file exists
        filename = os.path.basename(local_path)
        query = f"name='{filename}' and '{folder_id}' in parents and trashed=false"
        results = self.service.files().list(q=query, fields="files(id, name)").execute()
        existing_files = results.get('files', [])
        
        # Prepare upload
        media = MediaFileUpload(local_path, resumable=True)
        
        if existing_files:
            # Update existing file
            file_id = existing_files[0]['id']
            updated = self.service.files().update(
                fileId=file_id,
                media_body=media
            ).execute()
            logger.info(f"Updated Drive file: {filename}")
            return {"status": "success", "action": "updated", "file_id": file_id}
        else:
            # Create new file
            file_metadata = {
                'name': filename,
                'parents': [folder_id]
            }
            created = self.service.files().create(
                body=file_metadata,
                media_body=media,
                fields='id'
            ).execute()
            logger.info(f"Created Drive file: {filename}")
            return {"status": "success", "action": "created", "file_id": created.get('id')}
    
    def sync_directory(self, local_dir: str) -> dict:
        """Sync entire directory to Drive"""
        results = {
            "synced": 0,
            "failed": 0,
            "files": []
        }
        
        for root, dirs, files in os.walk(local_dir):
            for filename in files:
                local_path = os.path.join(root, filename)
                result = self.sync_file(local_path)
                results["files"].append({
                    "path": local_path,
                    "result": result
                })
                if result["status"] == "success":
                    results["synced"] += 1
                else:
                    results["failed"] += 1
        
        return results
    
    def sync_all(self) -> dict:
        """Sync all mapped directories"""
        results = {}
        for local_path, drive_path in SYNC_MAPPINGS.items():
            if os.path.exists(local_path):
                results[local_path] = self.sync_directory(local_path)
        return results


# MCP Integration
class DriveSyncMCP:
    """MCP tools for Drive sync"""
    
    def __init__(self):
        self.service = None
    
    def _ensure_service(self):
        if not self.service:
            self.service = DriveSyncService()
    
    def sync_file(self, local_path: str) -> dict:
        """Sync single file to Drive"""
        self._ensure_service()
        return self.service.sync_file(local_path)
    
    def sync_directory(self, local_dir: str) -> dict:
        """Sync directory to Drive"""
        self._ensure_service()
        return self.service.sync_directory(local_dir)
    
    def sync_all(self) -> dict:
        """Sync all mapped directories"""
        self._ensure_service()
        return self.service.sync_all()
    
    def status(self) -> dict:
        """Get sync status"""
        self._ensure_service()
        return {
            "authenticated": self.service.service is not None,
            "mappings": SYNC_MAPPINGS,
            "folder_cache_size": len(self.service.folder_cache)
        }
```

### 26.6.3 New MCP Tools for Drive Sync

```python
# Drive Sync MCP Tools (6 new tools)

prism_drive_sync_file(local_path)                     # Sync single file
prism_drive_sync_dir(local_dir)                       # Sync directory
prism_drive_sync_all()                                # Sync all mapped dirs
prism_drive_status()                                  # Get sync status
prism_drive_mappings()                                # Get sync mappings
prism_drive_history(last_n=20)                        # Recent sync operations
```

### 26.6.4 Deliverables for Session 26.6
```
□ Create drive_sync.py service
□ Implement Drive API authentication
□ Add folder creation/lookup
□ Implement file sync (create/update)
□ Add 6 Drive sync MCP tools
□ Test with manual file sync
□ Test with watcher-triggered sync
□ Document Drive folder structure
□ MCP Server version: v3.5 → v3.6
```

---

## Session 26.7: DuckDB Live Connection

### 26.7.1 Direct Database Operations

Instead of JSON→DuckDB, enable direct DuckDB operations:

```python
# DuckDB Live MCP Tools (8 new tools)

# Query
prism_db_query(sql, params=None)                      # Execute SQL query
prism_db_table_list()                                 # List all tables
prism_db_table_schema(table_name)                     # Get table schema
prism_db_table_stats(table_name)                      # Get table statistics

# Mutation (with validation)
prism_db_insert(table, records, validate=True)        # Insert records
prism_db_update(table, set_values, where)             # Update records
prism_db_delete(table, where)                         # Delete records
prism_db_upsert(table, records, key_columns)          # Upsert records

# All mutations automatically:
# 1. Validate against schema
# 2. Log to audit trail
# 3. Trigger data.onUpdate hooks
# 4. Invalidate MCP cache
# 5. Queue Drive sync
```

### 26.7.2 Live Query Integration

```python
class DuckDBLive:
    """Live DuckDB connection with auto-sync"""
    
    def __init__(self, db_path: str = "C:\\PRISM\\data\\prism.duckdb"):
        self.db_path = db_path
        self.conn = duckdb.connect(db_path)
        self.audit_log: List[dict] = []
    
    def query(self, sql: str, params: tuple = None) -> dict:
        """Execute read query"""
        try:
            if params:
                result = self.conn.execute(sql, params).fetchall()
            else:
                result = self.conn.execute(sql).fetchall()
            
            columns = [desc[0] for desc in self.conn.description]
            records = [dict(zip(columns, row)) for row in result]
            
            return {
                "status": "success",
                "columns": columns,
                "records": records,
                "count": len(records)
            }
        except Exception as e:
            return {"status": "failed", "error": str(e)}
    
    def insert(self, table: str, records: List[dict], validate: bool = True) -> dict:
        """Insert records with validation and sync"""
        if validate:
            validation = self._validate_records(table, records)
            if not validation["valid"]:
                return {"status": "failed", "errors": validation["errors"]}
        
        try:
            # Build insert SQL
            if not records:
                return {"status": "failed", "error": "No records provided"}
            
            columns = list(records[0].keys())
            placeholders = ', '.join(['?' for _ in columns])
            sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"
            
            # Execute batch insert
            for record in records:
                values = tuple(record[col] for col in columns)
                self.conn.execute(sql, values)
            
            self.conn.commit()
            
            # Log and trigger hooks
            self._audit("insert", table, len(records))
            self._trigger_sync(table)
            
            return {"status": "success", "inserted": len(records)}
            
        except Exception as e:
            self.conn.rollback()
            return {"status": "failed", "error": str(e)}
    
    def _validate_records(self, table: str, records: List[dict]) -> dict:
        """Validate records against table schema"""
        schema = self._get_schema(table)
        errors = []
        
        for i, record in enumerate(records):
            for col_name, col_type in schema.items():
                if col_name not in record:
                    if not schema[col_name].get("nullable", True):
                        errors.append(f"Record {i}: Missing required column '{col_name}'")
                else:
                    # Type validation
                    value = record[col_name]
                    if not self._type_matches(value, col_type):
                        errors.append(f"Record {i}: Invalid type for '{col_name}'")
        
        return {"valid": len(errors) == 0, "errors": errors}
    
    def _audit(self, operation: str, table: str, count: int):
        """Log operation to audit trail"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "operation": operation,
            "table": table,
            "count": count
        }
        self.audit_log.append(entry)
        
        # Write to audit file
        audit_file = "C:\\PRISM\\logs\\db_audit.jsonl"
        with open(audit_file, 'a') as f:
            f.write(json.dumps(entry) + '\n')
    
    def _trigger_sync(self, table: str):
        """Trigger sync pipeline for table"""
        # Export to JSON
        json_path = f"C:\\PRISM\\data\\json\\{table}.json"
        result = self.query(f"SELECT * FROM {table}")
        
        with open(json_path, 'w') as f:
            json.dump(result["records"], f, indent=2, default=str)
        
        # Invalidate cache
        cache_file = "C:\\PRISM\\state\\cache_invalidations.json"
        # ... (trigger cache invalidation)
```

### 26.7.3 Deliverables for Session 26.7
```
□ Implement DuckDBLive class
□ Add 8 database MCP tools
□ Implement validation layer
□ Add audit logging
□ Test insert/update/delete operations
□ Verify auto-sync triggers
□ Document database schema
□ MCP Server version: v3.6 → v3.7
```

---

## Session 26.8: Service Orchestration

### 26.8.1 Service Manager

Create: `C:\PRISM\scripts\services\service_manager.py`

```python
#!/usr/bin/env python3
"""
PRISM Service Manager
Orchestrates all background services.
"""

import os
import sys
import json
import signal
import logging
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional
import psutil

logger = logging.getLogger('PRISM.ServiceManager')

SERVICES = {
    "file_watcher": {
        "script": "C:\\PRISM\\scripts\\services\\file_watcher.py",
        "description": "File change monitoring and auto-sync",
        "auto_start": True,
        "restart_on_failure": True
    },
    "drive_sync": {
        "script": "C:\\PRISM\\scripts\\services\\drive_sync_daemon.py",
        "description": "Google Drive background sync",
        "auto_start": True,
        "restart_on_failure": True
    },
    "mcp_server": {
        "script": "C:\\PRISM\\scripts\\prism_mcp_server.py",
        "description": "MCP tool server",
        "auto_start": True,
        "restart_on_failure": True
    },
    "scheduler": {
        "script": "C:\\PRISM\\scripts\\services\\scheduler.py",
        "description": "Scheduled task execution",
        "auto_start": True,
        "restart_on_failure": True
    }
}


class ServiceManager:
    """Manages PRISM background services"""
    
    def __init__(self):
        self.processes: Dict[str, subprocess.Popen] = {}
        self.status_file = "C:\\PRISM\\state\\service_status.json"
    
    def start_service(self, name: str) -> dict:
        """Start a service"""
        if name not in SERVICES:
            return {"status": "failed", "error": f"Unknown service: {name}"}
        
        if name in self.processes and self.processes[name].poll() is None:
            return {"status": "already_running", "pid": self.processes[name].pid}
        
        config = SERVICES[name]
        script = config["script"]
        
        if not os.path.exists(script):
            return {"status": "failed", "error": f"Script not found: {script}"}
        
        try:
            process = subprocess.Popen(
                [sys.executable, script],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
            )
            self.processes[name] = process
            self._update_status()
            
            logger.info(f"Started service '{name}' (PID: {process.pid})")
            return {"status": "started", "pid": process.pid}
            
        except Exception as e:
            return {"status": "failed", "error": str(e)}
    
    def stop_service(self, name: str) -> dict:
        """Stop a service"""
        if name not in self.processes:
            return {"status": "not_running"}
        
        process = self.processes[name]
        if process.poll() is not None:
            del self.processes[name]
            return {"status": "already_stopped"}
        
        try:
            # Graceful shutdown
            process.terminate()
            process.wait(timeout=10)
            del self.processes[name]
            self._update_status()
            
            logger.info(f"Stopped service '{name}'")
            return {"status": "stopped"}
            
        except subprocess.TimeoutExpired:
            process.kill()
            del self.processes[name]
            return {"status": "killed"}
    
    def restart_service(self, name: str) -> dict:
        """Restart a service"""
        self.stop_service(name)
        return self.start_service(name)
    
    def start_all(self) -> dict:
        """Start all auto-start services"""
        results = {}
        for name, config in SERVICES.items():
            if config.get("auto_start", False):
                results[name] = self.start_service(name)
        return results
    
    def stop_all(self) -> dict:
        """Stop all services"""
        results = {}
        for name in list(self.processes.keys()):
            results[name] = self.stop_service(name)
        return results
    
    def status(self) -> dict:
        """Get status of all services"""
        status = {}
        for name, config in SERVICES.items():
            if name in self.processes:
                process = self.processes[name]
                if process.poll() is None:
                    # Get resource usage
                    try:
                        proc = psutil.Process(process.pid)
                        status[name] = {
                            "status": "running",
                            "pid": process.pid,
                            "cpu_percent": proc.cpu_percent(),
                            "memory_mb": proc.memory_info().rss / 1024 / 1024
                        }
                    except psutil.NoSuchProcess:
                        status[name] = {"status": "stopped"}
                else:
                    status[name] = {"status": "stopped", "exit_code": process.returncode}
            else:
                status[name] = {"status": "stopped"}
        
        return status
    
    def _update_status(self):
        """Write status to file"""
        with open(self.status_file, 'w') as f:
            json.dump({
                "timestamp": datetime.now().isoformat(),
                "services": self.status()
            }, f, indent=2)
    
    def monitor(self):
        """Monitor and restart failed services"""
        while True:
            for name, config in SERVICES.items():
                if not config.get("restart_on_failure", False):
                    continue
                
                if name in self.processes:
                    process = self.processes[name]
                    if process.poll() is not None:
                        logger.warning(f"Service '{name}' died, restarting...")
                        self.start_service(name)
                elif config.get("auto_start", False):
                    self.start_service(name)
            
            self._update_status()
            time.sleep(30)  # Check every 30 seconds


# MCP Integration
class ServiceManagerMCP:
    """MCP tools for service management"""
    
    def __init__(self):
        self.manager = ServiceManager()
    
    def start(self, service: str = None) -> dict:
        if service:
            return self.manager.start_service(service)
        return self.manager.start_all()
    
    def stop(self, service: str = None) -> dict:
        if service:
            return self.manager.stop_service(service)
        return self.manager.stop_all()
    
    def restart(self, service: str) -> dict:
        return self.manager.restart_service(service)
    
    def status(self) -> dict:
        return self.manager.status()
```

### 26.8.2 New MCP Tools for Service Management

```python
# Service Management MCP Tools (6 new tools)

prism_service_start(service=None)                     # Start service(s)
prism_service_stop(service=None)                      # Stop service(s)
prism_service_restart(service)                        # Restart service
prism_service_status()                                # Get all service status
prism_service_logs(service, last_n=100)               # Get service logs
prism_service_config()                                # Get service configurations
```

### 26.8.3 Startup Script

Create: `C:\PRISM\scripts\start_prism.py`

```python
#!/usr/bin/env python3
"""
PRISM Startup Script
Initializes all services for automated operation.
"""

import sys
import logging
from services.service_manager import ServiceManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s',
    handlers=[
        logging.FileHandler('C:\\PRISM\\logs\\startup.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('PRISM.Startup')

def main():
    logger.info("=" * 60)
    logger.info("PRISM Manufacturing Intelligence - Starting Services")
    logger.info("=" * 60)
    
    manager = ServiceManager()
    
    # Start all services
    results = manager.start_all()
    
    for service, result in results.items():
        status = result.get("status", "unknown")
        if status in ["started", "already_running"]:
            logger.info(f"✅ {service}: {status} (PID: {result.get('pid', 'N/A')})")
        else:
            logger.error(f"❌ {service}: {status} - {result.get('error', 'Unknown error')}")
    
    logger.info("=" * 60)
    logger.info("PRISM Services initialized. Monitoring for failures...")
    logger.info("=" * 60)
    
    # Enter monitoring loop
    try:
        manager.monitor()
    except KeyboardInterrupt:
        logger.info("Shutdown requested...")
        manager.stop_all()
        logger.info("All services stopped. Goodbye!")

if __name__ == "__main__":
    main()
```

### 26.8.4 Windows Task Scheduler Integration

Create: `C:\PRISM\scripts\install_service.bat`

```batch
@echo off
REM Install PRISM as Windows startup task

echo Installing PRISM Auto-Start...

REM Create scheduled task to run at login
schtasks /create /tn "PRISM Services" /tr "pythonw C:\PRISM\scripts\start_prism.py" /sc onlogon /rl highest /f

echo.
echo PRISM will now start automatically on login.
echo To start manually: python C:\PRISM\scripts\start_prism.py
echo To stop: python -c "from services.service_manager import ServiceManager; ServiceManager().stop_all()"
echo.

pause
```

### 26.8.5 Deliverables for Session 26.8
```
□ Create service_manager.py
□ Create start_prism.py startup script
□ Create install_service.bat for Windows
□ Add 6 service management MCP tools
□ Test service start/stop/restart
□ Test auto-restart on failure
□ Test Windows startup integration
□ Document service architecture
□ MCP Server version: v3.7 → v3.8 (172 tools)
```

---

# COMPLETE AUTOMATION SUMMARY

## What's Now Automated

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                        AUTOMATION COVERAGE                                    ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  ✅ Excel edits → JSON → DuckDB → Drive (via file watcher)                  ║
║  ✅ JSON edits → DuckDB → Drive (via file watcher)                          ║
║  ✅ Code changes → Index update (via file watcher)                          ║
║  ✅ State changes → Backup (via file watcher)                               ║
║  ✅ Config changes → Validate + reload (via file watcher)                   ║
║  ✅ Service failures → Auto-restart (via service manager)                   ║
║  ✅ System boot → All services start (via Windows scheduler)                ║
║  ✅ MCP cache → Auto-invalidate on data change                              ║
║  ✅ Hooks → Auto-fire on relevant operations                                ║
║                                                                              ║
║  MANUAL TASKS REMAINING:                                                     ║
║  ├── Initial data entry (but sync is automatic)                             ║
║  ├── Major schema changes (need validation)                                  ║
║  └── First-time Google Drive auth (one-time)                                ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

## New MCP Tools Added (This Addendum)

| Category | Tools | Count |
|----------|-------|-------|
| File Watcher | start, stop, status, restart, config_get, config_set, config_disable, trigger | 8 |
| Drive Sync | sync_file, sync_dir, sync_all, status, mappings, history | 6 |
| DuckDB Live | query, table_list, table_schema, table_stats, insert, update, delete, upsert | 8 |
| Service Manager | start, stop, restart, status, logs, config | 6 |
| **TOTAL** | | **28** |

## Updated Timeline

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                    UPDATED ROADMAP WITH AUTOMATION                            ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  PHASE 0: HOOK MAXIMIZATION                     │ 6-9 hrs  │ Sessions 17-19 ║
║  PHASE 1: CODE INTELLIGENCE                     │ 12-16 hrs│ Sessions 20-23 ║
║  PHASE 2: FILE OPERATIONS                       │ 9-12 hrs │ Sessions 24-26 ║
║  PHASE 2.5: FULL AUTOMATION ← NEW               │ 8-10 hrs │ Sessions 26.5-8║
║  PHASE 3: SCRIPT EXECUTION                      │ 9-12 hrs │ Sessions 27-29 ║
║  PHASE 4: FULL INTEGRATION                      │ 9-12 hrs │ Sessions 30-32 ║
║                                                                              ║
║  TOTAL: 53-71 hours │ 20 sessions │ 221 MCP tools │ MCP v4.0+               ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

---

# QUICK START: RUNNING PRISM AUTOMATED

After implementing Sessions 26.5-26.8:

```batch
REM One-time setup
python C:\PRISM\scripts\install_service.bat

REM Or manual start
python C:\PRISM\scripts\start_prism.py
```

Then:
1. **Edit any Excel file** → JSON/DuckDB/Drive update automatically
2. **Edit any JSON file** → DuckDB/Drive update automatically  
3. **Edit any code file** → Index updates automatically
4. **Services crash** → Auto-restart within 30 seconds
5. **Computer restarts** → All services start automatically

**YOU DO**: Edit files. **PRISM DOES**: Everything else.

---

*Addendum Version: 1.0*
*Created: 2026-02-01*
*Extends: PRISM Emergency Roadmap v4.0*
*Goal: Zero Manual Syncing*
