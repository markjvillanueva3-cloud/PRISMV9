# IMPLEMENT MCP-BASED PROTOCOL SYSTEM
## CRITICAL PRIORITY | Full Implementation | Zero Gaps | No Follow-up Required

---

## CONTEXT FOR CLAUDE

I need you to implement an MCP-based protocol system that replaces ~15,700 tokens of per-message protocol overhead with an efficient MCP tool system. This will reduce costs by ~84% while IMPROVING enforcement (executable code vs text-based "please follow these rules").

**YOU MUST:**
1. Complete ALL deliverables in this prompt - no partial implementations
2. Test everything before claiming completion
3. Follow anti-regression protocol (verify nothing is lost)
4. Provide evidence (file listings, content samples, test results)
5. Update all state files when done

**DO NOT:**
- Skip any section saying "I'll do this later"
- Create placeholder files
- Claim completion without testing
- Ask me clarifying questions - all requirements are here

---

## ARCHITECTURE OVERVIEW

```
CURRENT STATE (15,700 tokens per message):
├── PRISM_CONDENSED_PROTOCOL_v15.md (4,500 tok) - always loaded
├── GSD_CORE.md (1,200 tok) - always loaded  
├── MEGA_ROADMAP.md (8,000 tok) - always loaded
└── Project roadmaps (2,000 tok) - always loaded

TARGET STATE (2,500 tokens per message):
├── STABLE_PREFIX.md (1,500 tok) - cached, rarely changes
├── MCP Tool Definitions (500 tok) - cached
├── Dynamic Context (500 tok) - session-specific
└── On-demand retrieval via MCP tools - only when needed
```

---

## PHASE A: CREATE MCP SERVER

### A1. Create Main Server File

**Path:** `C:\PRISM\mcp\prism_protocol_server.py`

```python
#!/usr/bin/env python3
"""
PRISM Protocol MCP Server v1.0
Replaces 15,700 tokens of static protocol with on-demand retrieval + executable enforcement.

Token Savings: ~84% per message
Enforcement: Programmatic (guaranteed) vs text-based (hope-based)

Usage:
    python prism_protocol_server.py
    
MCP Config:
    Add to claude_desktop_config.json or MCP settings
"""

import json
import hashlib
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import sys

# MCP imports - adjust based on your MCP framework
try:
    from mcp.server import Server
    from mcp.types import Tool, TextContent
except ImportError:
    # Fallback for testing without MCP installed
    print("Warning: MCP not installed. Running in standalone mode.", file=sys.stderr)
    Server = None

# =============================================================================
# CONFIGURATION
# =============================================================================

PRISM_ROOT = Path("C:/PRISM")
STATE_DIR = PRISM_ROOT / "state"
PROTOCOL_DIR = PRISM_ROOT / "protocol"
ROADMAP_DIR = PRISM_ROOT / "roadmaps"

# Ensure directories exist
for d in [STATE_DIR, PROTOCOL_DIR, ROADMAP_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# =============================================================================
# DATA CLASSES
# =============================================================================

class Decision(Enum):
    RELEASE = "RELEASE"
    WARN = "WARN"
    BLOCK = "BLOCK"
    HARD_BLOCK = "HARD_BLOCK"

@dataclass
class ValidationResult:
    passed: bool
    score: float
    issues: List[str]
    details: Dict[str, Any]

@dataclass
class OmegaResult:
    omega: float
    omega_lower: float
    components: Dict[str, float]
    decision: Decision
    blocking_reasons: List[str]

@dataclass
class RegressionResult:
    passed: bool
    old_count: int
    new_count: int
    ratio: float
    losses: List[str]
    message: str

@dataclass
class GateResult:
    gate_id: str
    passed: bool
    message: str

@dataclass 
class HookResult:
    hook_id: str
    triggered: bool
    action_taken: str
    data_modified: Dict[str, Any]

# =============================================================================
# PROTOCOL SECTIONS (Extracted from PRISM_CONDENSED_PROTOCOL)
# =============================================================================

PROTOCOL_SECTIONS = {
    "identity": """
## PRISM MANUFACTURING INTELLIGENCE

You are developing PRISM, a safety-critical CNC machine control system where:
- Mathematical errors can result in tool explosions, machine crashes, and operator injury/death
- Wrong speeds/feeds = tool explosion, operator injury
- Incomplete data = machine crash, flying debris
- Every shortcut can kill someone

PRISM encompasses four products:
1. Speed & Feed Calculator
2. Post Processor Generator  
3. Shop Manager/Quoting
4. Auto CNC Programmer

The system manages:
- 1,047+ materials with 127 parameters each
- 824+ machines across 43 manufacturers
- 9,200+ alarm codes across 12 controller families
- 986,621-line monolithic codebase being rebuilt to v9.0+
""",

    "mindsets": """
## 4 MINDSETS (Always Active)

| Mindset | Question | Enforcement |
|---------|----------|-------------|
| **SAFETY** | "Can this hurt someone?" | S(x) ≥ 0.70 HARD BLOCK |
| **COMPLETENESS** | "Is this 100%?" | R(x) completeness metric |
| **ANTI-REGRESSION** | "Am I losing anything?" | New ≥ Old always |
| **PREDICTIVE** | "What goes wrong?" | 3 failure modes required |
""",

    "gates": """
## 9 VALIDATION GATES

| Gate | Check | If Failed |
|------|-------|-----------|
| G1 | C: drive accessible | STOP |
| G2 | State file valid | Create new |
| G3 | Input understood | Clarify |
| G4 | Skills available | Use embedded |
| G5 | Output path on C: | Never /home |
| G6 | Evidence exists | No "done" claim |
| G7 | Replacement ≥ original | Investigate |
| G8 | S(x) ≥ 0.70 | **HARD BLOCK** |
| G9 | D(x) ≥ 0.30 | **HARD BLOCK** |
""",

    "workflow": """
## WORKFLOW

```
BRAINSTORM → PLAN → EXECUTE → REVIEW-SPEC → REVIEW-QUALITY → HANDOFF
    ↓                            ↓
(STOP!)                    SP-DEBUGGING (4-phase)
```

### BRAINSTORM (MANDATORY STOP)
- Explore 3+ approaches before committing
- User must approve before proceeding
- NO execution during brainstorm

### PLAN
- Break into 2-5 minute tasks
- Exact file paths specified
- Dependencies identified

### EXECUTE  
- Checkpoint every 5-8 items
- Track tool calls: 🟢0-8 | 🟡9-14 | 🔴15-18 | ⚫19+ STOP
- Update state files

### REVIEW
- Verify against spec
- Run validation gates
- Check anti-regression

### HANDOFF
- Update CURRENT_STATE.json
- Write quickResume
- Next session starts in 30 seconds
""",

    "commandments": """
## 10 COMMANDMENTS

1. IF IT EXISTS, USE IT EVERYWHERE - No orphaned resources
2. FUSE THE UNFUSABLE - Cross-domain integration
3. TRUST BUT VERIFY - Evidence over claims
4. LEARN FROM EVERYTHING - Extract patterns
5. PREDICT WITH UNCERTAINTY - Bayesian approach
6. EXPLAIN EVERYTHING - No magic values
7. FAIL GRACEFULLY - Recovery paths always
8. PROTECT EVERYTHING - Defense in depth
9. PERFORM ALWAYS - No lazy shortcuts
10. OBSESS OVER USERS - Their success is the goal
""",

    "evidence_levels": """
## EVIDENCE LEVELS

| Level | Type | Use |
|-------|------|-----|
| L1 | Claim only | Insufficient |
| L2 | File listing | Partial |
| L3 | Content sample | **Minimum for "done"** |
| L4 | Reproducible test | Major milestone |
| L5 | User verified | Stage complete |

Never claim completion without L3+ evidence.
""",

    "buffer_zones": """
## BUFFER ZONES (Tool Call Tracking)

| Zone | Calls | Action |
|------|-------|--------|
| 🟢 | 0-8 | Normal operation |
| 🟡 | 9-14 | Plan checkpoint soon |
| 🔴 | 15-18 | IMMEDIATE checkpoint |
| ⚫ | 19+ | **STOP ALL WORK** - checkpoint and handoff |
""",

    "agent_tiers": """
## AGENT TIERS

| Tier | Count | Cost | Use For |
|------|-------|------|---------|
| OPUS | 18 | $75/1M | Architecture, validation, learning extraction |
| SONNET | 37 | $15/1M | Coding, extraction, review |
| HAIKU | 9 | $1.25/1M | Lookup, formatting, counting |

Use the cheapest agent that can do the job correctly.
""",

    "skill_hierarchy": """
## SKILL HIERARCHY

| Level | Count | Purpose | Loading |
|-------|-------|---------|---------|
| L0 | 13 | Always-On Laws | AUTO every session |
| L1 | 7 | Cognitive Coordination | Complex tasks |
| L2 | 15 | Workflow Phases | By phase |
| L3 | 64 | Domain Specialists | By domain |
| L4 | 18 | Reference Libraries | On demand |

Skills location: /mnt/skills/user/[name]/SKILL.md
""",

    "omega_equation": """
## MASTER EQUATION Ω(x) v2.0

```
Ω(x) = 0.18·R + 0.14·C + 0.10·P + 0.22·S + 0.06·L
     + 0.10·D + 0.08·A + 0.07·K + 0.05·M

Components:
  R = Reasoning quality (0-1)
  C = Code quality (0-1)  
  P = Process adherence (0-1)
  S = Safety score (0-1) - HARD CONSTRAINT ≥ 0.70
  L = Learning extraction (0-1)
  D = Anomaly detection (0-1) - HARD CONSTRAINT ≥ 0.30
  A = Attention/focus (0-1)
  K = Causal reasoning (0-1)
  M = Memory/continuity (0-1)
```

**HARD CONSTRAINTS (Both must pass or Ω=0):**
- S(x) ≥ 0.70 (Safety)
- D(x) ≥ 0.30 (Anomaly Detection)

**DECISION THRESHOLDS:**
- Ω ≥ 0.85 + Ω_lower ≥ 0.70 → RELEASE
- Ω ≥ 0.65 → WARN (proceed with caution)
- Ω < 0.65 OR S < 0.70 OR D < 0.30 → BLOCK
""",

    "anti_regression": """
## ANTI-REGRESSION PROTOCOL

**TRIGGERED BY:** update, replace, new version, merge, consolidate, rewrite

**PROCEDURE:**
1. INVENTORY original file:
   - Count sections/items
   - Count lines
   - Note file size in KB
   
2. CREATE new version with inventory visible

3. COMPARE before shipping:
   - new_count >= old_count (REQUIRED)
   - Identify any removed content
   
4. SIZE CHECK:
   - >20% smaller = RED FLAG
   - Must justify any reduction
   
5. NEVER ship if new < old without explicit approval

**COMMON TRAPS:**
- "Consolidating" = often losing
- "Simplifying" = often removing
- "Cleaning up" = often deleting
""",

    "session_protocol": """
## SESSION PROTOCOL

### START
1. Run: `py -3 C:\\PRISM\\scripts\\gsd_startup.py "task description"`
2. Load ONLY recommended skills (view tool)
3. Read state: `C:\\PRISM\\state\\CURRENT_STATE.json`

### DURING
4. Checkpoint every 5-8 items
5. Track tool calls (buffer zones)
6. Update todo.md after checkpoints

### END
7. `py -3 C:\\PRISM\\scripts\\session_memory_manager.py end --status COMPLETE`
8. Update CURRENT_STATE.json with quickResume
9. Preserve errors in context (Law 5)

### POST-COMPACTION RECOVERY
If context compacted:
1. Run gsd_startup.py (auto-detects active session)
2. State restored from events/*.jsonl
3. Continue from checkpoint (don't restart)
""",

    "paths": """
## CRITICAL PATHS

```
State File:     C:\\PRISM\\state\\CURRENT_STATE.json
Session Memory: C:\\PRISM\\state\\SESSION_MEMORY.json
Events Log:     C:\\PRISM\\state\\events\\*.jsonl
Skills (Fast):  /mnt/skills/user/[name]/SKILL.md (43 skills)
Skills (All):   C:\\PRISM\\skills-consolidated\\[name]\\SKILL.md (118 skills)
GSD Startup:    C:\\PRISM\\scripts\\gsd_startup.py
Orchestrator:   C:\\PRISM\\scripts\\prism_unified_system_v6.py
```

**OUTPUT RULES:**
- All outputs to C: drive paths
- NEVER use /home/claude for final outputs
- Users cannot access /home/claude
""",

    "forbidden": """
## FORBIDDEN PATTERNS

**NEVER:**
- Placeholders: "TODO", "...", "etc", "and so on"
- Incomplete: "I'll add more later", "remaining items similar"
- Assumptions: "probably", "should work", "I think"
- Skipping: "for brevity", "omitting", "truncated"
- Wrong paths: /home/claude for user files

**ALWAYS:**
- Complete implementations
- Explicit values (no magic numbers without explanation)
- Evidence before claiming done
- Exact paths
- Error handling
"""
}

# =============================================================================
# QUICK REFERENCE (Compact summary)
# =============================================================================

QUICK_REFERENCE = """
┌─────────────────────────────────────────────────────────────┐
│  PRISM GSD v3.0 | 756 Resources | MCP-Enhanced             │
├─────────────────────────────────────────────────────────────┤
│  Ω(x) = Σ(10 components) | S≥0.70 AND D≥0.30 HARD BLOCKS   │
│  WORKFLOW: BRAINSTORM(STOP!) → PLAN → EXECUTE → REVIEW     │
│  BUFFER: 🟢0-8 | 🟡9-14 | 🔴15-18 | ⚫19+                   │
│  EVIDENCE: L3 minimum for any "done" claim                 │
│  COMMANDMENT #1: IF IT EXISTS, USE IT EVERYWHERE           │
│                                                             │
│  LIVES DEPEND ON COMPLETE DATA. NO SHORTCUTS.              │
└─────────────────────────────────────────────────────────────┘
"""

# =============================================================================
# PHASE-SPECIFIC CHECKLISTS
# =============================================================================

PHASE_CHECKLISTS = {
    "brainstorm": """
## BRAINSTORM CHECKLIST

Before proceeding to PLAN:
□ Explored 3+ alternative approaches
□ Identified pros/cons of each
□ Selected approach with justification
□ Listed 3 potential failure modes
□ User has approved the approach
□ NO implementation code written yet

**MANDATORY STOP** - Do not proceed without user approval.
""",

    "plan": """
## PLAN CHECKLIST

Before proceeding to EXECUTE:
□ Tasks broken into 2-5 minute chunks
□ Each task has exact file path
□ Dependencies between tasks identified
□ Estimated total time calculated
□ Checkpoint locations marked (every 5-8 items)
□ Rollback procedure defined
□ Success criteria for each task specified
""",

    "execute": """
## EXECUTE CHECKLIST

During execution:
□ Working on approved plan only
□ Checkpointing every 5-8 items
□ Tracking tool calls (buffer zone)
□ Updating state files
□ Capturing evidence (L3+) for each completion
□ Not deviating from plan without approval
□ Errors preserved, not hidden
""",

    "review": """
## REVIEW CHECKLIST

Before claiming complete:
□ All planned items implemented
□ No placeholders or TODOs remain
□ Anti-regression check passed (new ≥ old)
□ S(x) ≥ 0.70 verified
□ D(x) ≥ 0.30 verified  
□ Ω(x) computed and meets threshold
□ Evidence provided (L3+ minimum)
□ Tests pass (if applicable)
""",

    "handoff": """
## HANDOFF CHECKLIST

Before ending session:
□ CURRENT_STATE.json updated
□ quickResume section written
□ SESSION_MEMORY.json updated
□ All files saved to C: drive
□ No work in /home/claude
□ Next steps clearly documented
□ Blockers identified (if any)
□ Estimated time for continuation
"""
}

# =============================================================================
# VALIDATION FUNCTIONS (Executable Enforcement)
# =============================================================================

def compute_safety_score(output: Dict[str, Any]) -> ValidationResult:
    """
    Compute S(x) safety score.
    
    Checks for:
    - Machine limits respected
    - Material compatibility verified
    - Speed/feed within safe ranges
    - Collision paths checked
    - Emergency stop conditions defined
    """
    issues = []
    score = 1.0
    details = {}
    
    # Check for safety-critical fields
    if "speeds" in output or "feeds" in output:
        # Manufacturing output - strict checking
        if "material" not in output:
            issues.append("Missing material specification for speed/feed calculation")
            score -= 0.3
        if "machine_limits" not in output:
            issues.append("Machine limits not verified")
            score -= 0.2
        if "tool_specs" not in output:
            issues.append("Tool specifications missing")
            score -= 0.2
    
    # Check for dangerous patterns
    content_str = json.dumps(output).lower()
    dangerous_patterns = [
        ("placeholder", 0.3, "Contains placeholder content"),
        ("todo", 0.2, "Contains TODO markers"),
        ("assumed", 0.1, "Contains assumptions without verification"),
        ("probably", 0.1, "Contains uncertain language in safety context"),
    ]
    
    for pattern, penalty, message in dangerous_patterns:
        if pattern in content_str:
            issues.append(message)
            score -= penalty
    
    # Check for required safety fields in CNC outputs
    if any(k in output for k in ["gcode", "nc_code", "post_processor"]):
        required_safety = ["rapid_height", "clearance_plane", "home_position"]
        for field in required_safety:
            if field not in output:
                issues.append(f"Missing required safety field: {field}")
                score -= 0.15
    
    score = max(0.0, min(1.0, score))
    passed = score >= 0.70
    
    if not passed:
        issues.insert(0, f"SAFETY HARD BLOCK: S(x)={score:.2f} < 0.70")
    
    return ValidationResult(
        passed=passed,
        score=score,
        issues=issues,
        details={"checks_performed": len(dangerous_patterns) + 3}
    )


def compute_anomaly_score(data: Dict[str, Any]) -> ValidationResult:
    """
    Compute D(x) anomaly detection score.
    
    Checks for:
    - Values within expected ranges
    - Data type consistency
    - Required fields present
    - Cross-field consistency
    """
    issues = []
    score = 1.0
    details = {"anomalies": []}
    
    def check_numeric_range(value: Any, field: str, min_val: float, max_val: float):
        nonlocal score
        if isinstance(value, (int, float)):
            if value < min_val or value > max_val:
                issues.append(f"Anomaly: {field}={value} outside range [{min_val}, {max_val}]")
                details["anomalies"].append({"field": field, "value": value, "range": [min_val, max_val]})
                score -= 0.15
    
    # Check common manufacturing ranges
    if "spindle_speed" in data:
        check_numeric_range(data["spindle_speed"], "spindle_speed", 0, 50000)
    if "feed_rate" in data:
        check_numeric_range(data["feed_rate"], "feed_rate", 0, 10000)
    if "depth_of_cut" in data:
        check_numeric_range(data["depth_of_cut"], "depth_of_cut", 0, 50)
    if "tool_diameter" in data:
        check_numeric_range(data["tool_diameter"], "tool_diameter", 0.1, 200)
    
    # Check for null/empty values in required fields
    for key, value in data.items():
        if value is None:
            issues.append(f"Null value in field: {key}")
            score -= 0.1
        elif isinstance(value, str) and value.strip() == "":
            issues.append(f"Empty string in field: {key}")
            score -= 0.1
    
    # Check for consistency
    if "material" in data and "hardness" in data:
        # Could add material-hardness consistency checks
        pass
    
    score = max(0.0, min(1.0, score))
    passed = score >= 0.30
    
    if not passed:
        issues.insert(0, f"ANOMALY HARD BLOCK: D(x)={score:.2f} < 0.30")
    
    return ValidationResult(
        passed=passed,
        score=score,
        issues=issues,
        details=details
    )


def compute_omega(output: Dict[str, Any]) -> OmegaResult:
    """
    Compute full Ω(x) master equation.
    
    Ω(x) = 0.18·R + 0.14·C + 0.10·P + 0.22·S + 0.06·L
         + 0.10·D + 0.08·A + 0.07·K + 0.05·M
    """
    # Compute individual components
    safety_result = compute_safety_score(output)
    anomaly_result = compute_anomaly_score(output)
    
    # Estimate other components (simplified - would be more sophisticated in production)
    components = {
        "R": estimate_reasoning_score(output),
        "C": estimate_code_score(output),
        "P": estimate_process_score(output),
        "S": safety_result.score,
        "L": estimate_learning_score(output),
        "D": anomaly_result.score,
        "A": estimate_attention_score(output),
        "K": estimate_causal_score(output),
        "M": estimate_memory_score(output),
    }
    
    # Weights from master equation
    weights = {
        "R": 0.18, "C": 0.14, "P": 0.10, "S": 0.22, "L": 0.06,
        "D": 0.10, "A": 0.08, "K": 0.07, "M": 0.05
    }
    
    # Compute weighted sum
    omega = sum(components[k] * weights[k] for k in components)
    
    # Compute lower bound (for confidence interval)
    omega_lower = omega * 0.85  # Simplified - would use proper CI in production
    
    # Check hard constraints
    blocking_reasons = []
    if components["S"] < 0.70:
        blocking_reasons.append(f"S(x)={components['S']:.2f} < 0.70 (SAFETY HARD BLOCK)")
    if components["D"] < 0.30:
        blocking_reasons.append(f"D(x)={components['D']:.2f} < 0.30 (ANOMALY HARD BLOCK)")
    
    # Determine decision
    if blocking_reasons:
        decision = Decision.HARD_BLOCK
    elif omega >= 0.85 and omega_lower >= 0.70:
        decision = Decision.RELEASE
    elif omega >= 0.65:
        decision = Decision.WARN
    else:
        decision = Decision.BLOCK
    
    return OmegaResult(
        omega=omega,
        omega_lower=omega_lower,
        components=components,
        decision=decision,
        blocking_reasons=blocking_reasons
    )


def estimate_reasoning_score(output: Dict[str, Any]) -> float:
    """Estimate R(x) reasoning quality."""
    score = 0.7  # Base score
    
    # Check for explanations
    if "explanation" in output or "reasoning" in output:
        score += 0.15
    
    # Check for structured thinking
    if "steps" in output or "approach" in output:
        score += 0.1
    
    # Penalize magic values
    content = json.dumps(output)
    if re.search(r'\b\d{4,}\b', content):  # Large unexplained numbers
        if "// " not in content and "explanation" not in output:
            score -= 0.1
    
    return min(1.0, max(0.0, score))


def estimate_code_score(output: Dict[str, Any]) -> float:
    """Estimate C(x) code quality."""
    score = 0.7
    
    if "code" in output or "script" in output:
        code = output.get("code", output.get("script", ""))
        
        # Check for error handling
        if "try" in code or "except" in code or "catch" in code:
            score += 0.1
        
        # Check for comments
        if "#" in code or "//" in code:
            score += 0.05
        
        # Penalize common issues
        if "pass" in code and code.count("pass") > 2:
            score -= 0.1
        if "TODO" in code or "FIXME" in code:
            score -= 0.2
    
    return min(1.0, max(0.0, score))


def estimate_process_score(output: Dict[str, Any]) -> float:
    """Estimate P(x) process adherence."""
    score = 0.7
    
    # Check for checkpoint markers
    if "checkpoint" in str(output).lower():
        score += 0.1
    
    # Check for state management
    if "state" in output or "status" in output:
        score += 0.1
    
    return min(1.0, max(0.0, score))


def estimate_learning_score(output: Dict[str, Any]) -> float:
    """Estimate L(x) learning extraction."""
    score = 0.5
    
    if "lessons_learned" in output or "patterns" in output:
        score += 0.3
    
    if "improvement" in str(output).lower():
        score += 0.1
    
    return min(1.0, max(0.0, score))


def estimate_attention_score(output: Dict[str, Any]) -> float:
    """Estimate A(x) attention/focus."""
    return 0.75  # Would track goal drift in production


def estimate_causal_score(output: Dict[str, Any]) -> float:
    """Estimate K(x) causal reasoning."""
    score = 0.6
    
    if "because" in str(output).lower() or "therefore" in str(output).lower():
        score += 0.2
    
    if "cause" in output or "effect" in output:
        score += 0.15
    
    return min(1.0, max(0.0, score))


def estimate_memory_score(output: Dict[str, Any]) -> float:
    """Estimate M(x) memory/continuity."""
    score = 0.7
    
    if "previous" in str(output).lower() or "continuation" in str(output).lower():
        score += 0.15
    
    return min(1.0, max(0.0, score))


def check_anti_regression(old_path: str, new_content: str) -> RegressionResult:
    """
    Verify new content doesn't lose information from old.
    
    CRITICAL: This is a core PRISM principle. Never ship if new < old.
    """
    old_path = Path(old_path)
    losses = []
    
    if not old_path.exists():
        return RegressionResult(
            passed=True,
            old_count=0,
            new_count=len(new_content.split('\n')),
            ratio=float('inf'),
            losses=[],
            message="No existing file to compare (new file)"
        )
    
    old_content = old_path.read_text(encoding='utf-8')
    
    # Count by multiple metrics
    old_lines = len(old_content.split('\n'))
    new_lines = len(new_content.split('\n'))
    
    old_sections = len(re.findall(r'^#{1,3}\s+', old_content, re.MULTILINE))
    new_sections = len(re.findall(r'^#{1,3}\s+', new_content, re.MULTILINE))
    
    old_size = len(old_content)
    new_size = len(new_content)
    
    # Check for specific content loss
    old_headers = set(re.findall(r'^#{1,3}\s+(.+)$', old_content, re.MULTILINE))
    new_headers = set(re.findall(r'^#{1,3}\s+(.+)$', new_content, re.MULTILINE))
    missing_headers = old_headers - new_headers
    
    for header in missing_headers:
        losses.append(f"Missing section: {header}")
    
    # Calculate ratio (using most conservative metric)
    ratios = [
        new_lines / max(old_lines, 1),
        new_sections / max(old_sections, 1),
        new_size / max(old_size, 1),
    ]
    min_ratio = min(ratios)
    
    # Determine pass/fail
    passed = min_ratio >= 0.80 and len(losses) == 0
    
    if not passed:
        if min_ratio < 0.80:
            losses.insert(0, f"Size reduction: {min_ratio:.1%} (threshold: 80%)")
    
    return RegressionResult(
        passed=passed,
        old_count=old_lines,
        new_count=new_lines,
        ratio=min_ratio,
        losses=losses,
        message="PASSED" if passed else f"FAILED: {'; '.join(losses[:3])}"
    )


def run_all_gates(context: Dict[str, Any]) -> List[GateResult]:
    """Run all 9 validation gates."""
    results = []
    
    # G1: C: drive accessible
    c_drive = Path("C:/")
    results.append(GateResult(
        gate_id="G1",
        passed=c_drive.exists(),
        message="C: drive accessible" if c_drive.exists() else "C: drive NOT accessible"
    ))
    
    # G2: State file valid
    state_file = STATE_DIR / "CURRENT_STATE.json"
    state_valid = False
    if state_file.exists():
        try:
            json.loads(state_file.read_text())
            state_valid = True
        except:
            pass
    results.append(GateResult(
        gate_id="G2",
        passed=state_valid,
        message="State file valid" if state_valid else "State file invalid or missing"
    ))
    
    # G3: Input understood (would be more sophisticated)
    results.append(GateResult(
        gate_id="G3",
        passed=True,
        message="Input parsed successfully"
    ))
    
    # G4: Skills available
    skills_dir = Path("/mnt/skills/user") if Path("/mnt/skills/user").exists() else PRISM_ROOT / "skills-consolidated"
    results.append(GateResult(
        gate_id="G4",
        passed=skills_dir.exists(),
        message=f"Skills available at {skills_dir}" if skills_dir.exists() else "Skills directory not found"
    ))
    
    # G5: Output path check
    output_path = context.get("output_path", "")
    valid_output = output_path.startswith("C:") or output_path.startswith("/mnt/user-data")
    results.append(GateResult(
        gate_id="G5",
        passed=valid_output or output_path == "",
        message="Output path valid" if valid_output else f"Invalid output path: {output_path}"
    ))
    
    # G6: Evidence exists
    evidence = context.get("evidence", {})
    has_evidence = evidence.get("level", 0) >= 3
    results.append(GateResult(
        gate_id="G6",
        passed=has_evidence,
        message="Evidence L3+ provided" if has_evidence else "Insufficient evidence (need L3+)"
    ))
    
    # G7: Anti-regression
    if "old_path" in context and "new_content" in context:
        regression = check_anti_regression(context["old_path"], context["new_content"])
        results.append(GateResult(
            gate_id="G7",
            passed=regression.passed,
            message=regression.message
        ))
    else:
        results.append(GateResult(
            gate_id="G7",
            passed=True,
            message="No replacement check needed"
        ))
    
    # G8: Safety score
    safety = compute_safety_score(context.get("output", {}))
    results.append(GateResult(
        gate_id="G8",
        passed=safety.passed,
        message=f"S(x)={safety.score:.2f}" + ("" if safety.passed else " HARD BLOCK")
    ))
    
    # G9: Anomaly score
    anomaly = compute_anomaly_score(context.get("output", {}))
    results.append(GateResult(
        gate_id="G9",
        passed=anomaly.passed,
        message=f"D(x)={anomaly.score:.2f}" + ("" if anomaly.passed else " HARD BLOCK")
    ))
    
    return results


def check_completeness(content: str) -> Dict[str, Any]:
    """Check for placeholders, TODOs, and incomplete content."""
    issues = []
    
    # Patterns that indicate incompleteness
    incomplete_patterns = [
        (r'\bTODO\b', "TODO marker found"),
        (r'\bFIXME\b', "FIXME marker found"),
        (r'\bXXX\b', "XXX marker found"),
        (r'\.\.\.(?!\w)', "Ellipsis (incomplete content)"),
        (r'\betc\.?\b', "'etc' - incomplete list"),
        (r'\band so on\b', "'and so on' - incomplete"),
        (r'\bplaceholder\b', "Placeholder content"),
        (r'\bcoming soon\b', "'coming soon' - incomplete"),
        (r'\bto be (added|completed|implemented)\b', "Incomplete marker"),
        (r'#\s*\.\.\.$', "Incomplete section header"),
    ]
    
    locations = []
    for pattern, message in incomplete_patterns:
        matches = list(re.finditer(pattern, content, re.IGNORECASE))
        for match in matches:
            line_num = content[:match.start()].count('\n') + 1
            issues.append(f"Line {line_num}: {message}")
            locations.append({"line": line_num, "pattern": pattern, "text": match.group()})
    
    return {
        "is_complete": len(issues) == 0,
        "issues": issues,
        "locations": locations,
        "issue_count": len(issues)
    }

# =============================================================================
# HOOK SYSTEM
# =============================================================================

HOOKS = {
    # System hooks
    "SYS-LAW1": {"name": "Safety First", "category": "system"},
    "SYS-LAW2": {"name": "Complete Only", "category": "system"},
    "SYS-LAW3": {"name": "Anti-Regression", "category": "system"},
    "SYS-LAW4": {"name": "Predict Failures", "category": "system"},
    "SYS-LAW5": {"name": "Context Engineering", "category": "system"},
    
    # Cognitive hooks
    "BAYES-001": {"name": "Prior Integration", "category": "cognitive"},
    "BAYES-002": {"name": "Change Detection", "category": "cognitive"},
    "BAYES-003": {"name": "Belief Update", "category": "cognitive"},
    
    # Context hooks
    "CTX-CACHE-001": {"name": "Prefix Stability", "category": "context"},
    "CTX-CACHE-002": {"name": "Dynamic Blocking", "category": "context"},
    "CTX-MEM-001": {"name": "File Externalization", "category": "context"},
    "CTX-ERR-001": {"name": "Error Preservation", "category": "context"},
    "CTX-FOCUS-001": {"name": "Goal Recitation", "category": "context"},
    
    # Domain hooks (sample)
    "MAT-VAL-001": {"name": "Material Validation", "category": "domain"},
    "PHYS-KIE-001": {"name": "Kienzle Validation", "category": "domain"},
    "SAFE-LIM-001": {"name": "Limit Checking", "category": "domain"},
}


def trigger_hook(hook_id: str, data: Dict[str, Any]) -> HookResult:
    """Execute a hook by ID."""
    if hook_id not in HOOKS:
        return HookResult(
            hook_id=hook_id,
            triggered=False,
            action_taken="Hook not found",
            data_modified={}
        )
    
    hook = HOOKS[hook_id]
    action_taken = ""
    data_modified = {}
    
    # Execute hook logic based on ID
    if hook_id == "SYS-LAW3":  # Anti-regression
        if "old_path" in data and "new_content" in data:
            result = check_anti_regression(data["old_path"], data["new_content"])
            action_taken = f"Anti-regression check: {result.message}"
            data_modified = asdict(result)
    
    elif hook_id == "BAYES-002":  # Change detection
        action_taken = "Analyzed changes for unexpected patterns"
        # Would implement change detection logic
    
    elif hook_id == "CTX-ERR-001":  # Error preservation
        if "error" in data:
            # Log error to persistent storage
            error_log = STATE_DIR / "errors" / f"{datetime.now().strftime('%Y-%m-%d')}.jsonl"
            error_log.parent.mkdir(exist_ok=True)
            with open(error_log, "a") as f:
                f.write(json.dumps({
                    "timestamp": datetime.now().isoformat(),
                    "error": data["error"],
                    "context": data.get("context", {})
                }) + "\n")
            action_taken = f"Error preserved to {error_log}"
    
    else:
        action_taken = f"Hook {hook_id} ({hook['name']}) triggered"
    
    return HookResult(
        hook_id=hook_id,
        triggered=True,
        action_taken=action_taken,
        data_modified=data_modified
    )

# =============================================================================
# ROADMAP FUNCTIONS
# =============================================================================

def get_roadmap_status(project: str) -> Dict[str, Any]:
    """Get current status of a project roadmap."""
    roadmap_files = {
        "alarm_db": PRISM_ROOT / "EXTRACTED" / "controllers" / "ORCHESTRATION_STATE.json",
        "mega_roadmap": ROADMAP_DIR / "MEGA_ROADMAP_STATE.json",
        "materials": STATE_DIR / "MATERIALS_STATE.json",
        "engines": STATE_DIR / "ENGINES_STATE.json",
    }
    
    if project not in roadmap_files:
        return {
            "error": f"Unknown project: {project}",
            "available": list(roadmap_files.keys())
        }
    
    roadmap_file = roadmap_files[project]
    
    if not roadmap_file.exists():
        # Return default status
        if project == "alarm_db":
            return {
                "project": "alarm_db",
                "current_phase": "Wave 1",
                "progress_pct": 16.1,
                "total": 9200,
                "completed": 1485,
                "next_milestone": "FANUC to 1500",
                "blockers": []
            }
        return {
            "project": project,
            "current_phase": "Not started",
            "progress_pct": 0,
            "next_milestone": "Initialize project",
            "blockers": ["State file not found"]
        }
    
    state = json.loads(roadmap_file.read_text())
    return state


def update_roadmap_status(project: str, update: Dict[str, Any]) -> bool:
    """Update project roadmap status."""
    roadmap_files = {
        "alarm_db": PRISM_ROOT / "EXTRACTED" / "controllers" / "ORCHESTRATION_STATE.json",
        "mega_roadmap": ROADMAP_DIR / "MEGA_ROADMAP_STATE.json",
    }
    
    if project not in roadmap_files:
        return False
    
    roadmap_file = roadmap_files[project]
    
    # Load existing or create new
    if roadmap_file.exists():
        state = json.loads(roadmap_file.read_text())
    else:
        state = {"project": project, "created": datetime.now().isoformat()}
    
    # Apply updates
    state.update(update)
    state["last_updated"] = datetime.now().isoformat()
    
    # Save
    roadmap_file.parent.mkdir(parents=True, exist_ok=True)
    roadmap_file.write_text(json.dumps(state, indent=2))
    
    return True

# =============================================================================
# MCP SERVER DEFINITION
# =============================================================================

def create_mcp_server():
    """Create and configure the MCP server with all tools."""
    
    if Server is None:
        print("MCP not available. Tools defined but server not started.")
        return None
    
    server = Server("prism-protocol")
    
    # =========================================================================
    # PROTOCOL SECTION TOOLS
    # =========================================================================
    
    @server.tool()
    async def prism_protocol_section(section: str) -> str:
        """
        Get a specific section of the PRISM protocol.
        
        Sections: identity, mindsets, gates, workflow, commandments,
                  evidence_levels, buffer_zones, agent_tiers, skill_hierarchy,
                  omega_equation, anti_regression, session_protocol, paths, forbidden
        """
        if section in PROTOCOL_SECTIONS:
            return PROTOCOL_SECTIONS[section]
        return f"Unknown section: {section}. Available: {', '.join(PROTOCOL_SECTIONS.keys())}"
    
    @server.tool()
    async def prism_protocol_quick_ref() -> str:
        """Get the compact quick reference card."""
        return QUICK_REFERENCE
    
    @server.tool()
    async def prism_protocol_checklist(phase: str) -> str:
        """
        Get phase-specific checklist.
        
        Phases: brainstorm, plan, execute, review, handoff
        """
        if phase in PHASE_CHECKLISTS:
            return PHASE_CHECKLISTS[phase]
        return f"Unknown phase: {phase}. Available: {', '.join(PHASE_CHECKLISTS.keys())}"
    
    @server.tool()
    async def prism_protocol_forbidden() -> str:
        """Get the forbidden patterns and required patterns."""
        return PROTOCOL_SECTIONS["forbidden"]
    
    @server.tool()
    async def prism_protocol_full() -> str:
        """Get the complete protocol (all sections). Use sparingly."""
        return "\n\n---\n\n".join(PROTOCOL_SECTIONS.values())
    
    # =========================================================================
    # ROADMAP TOOLS
    # =========================================================================
    
    @server.tool()
    async def prism_roadmap_status(project: str) -> str:
        """
        Get current status of a project.
        
        Projects: alarm_db, mega_roadmap, materials, engines
        """
        status = get_roadmap_status(project)
        return json.dumps(status, indent=2)
    
    @server.tool()
    async def prism_roadmap_update(project: str, completed: int = None, 
                                    phase: str = None, notes: str = None) -> str:
        """Update project roadmap status."""
        update = {}
        if completed is not None:
            update["completed"] = completed
        if phase is not None:
            update["current_phase"] = phase
        if notes is not None:
            update["notes"] = notes
        
        success = update_roadmap_status(project, update)
        return json.dumps({"success": success, "update": update})
    
    @server.tool()
    async def prism_roadmap_next_task(project: str) -> str:
        """Get the highest priority unblocked task for a project."""
        status = get_roadmap_status(project)
        
        # Project-specific logic
        if project == "alarm_db":
            families = [
                ("FANUC", 450, 1500),
                ("SIEMENS", 180, 1200),
                ("HAAS", 250, 1000),
                ("MAZAK", 120, 1000),
            ]
            for family, current, target in families:
                if current < target:
                    return json.dumps({
                        "task": f"Extract {family} alarms",
                        "current": current,
                        "target": target,
                        "gap": target - current,
                        "priority": "P1"
                    })
        
        return json.dumps({"task": "Check roadmap for next task", "status": status})
    
    # =========================================================================
    # VALIDATION TOOLS
    # =========================================================================
    
    @server.tool()
    async def prism_validate_safety(output: str) -> str:
        """
        Compute S(x) safety score.
        
        HARD BLOCKS if S(x) < 0.70
        """
        try:
            data = json.loads(output) if isinstance(output, str) else output
        except:
            data = {"raw": output}
        
        result = compute_safety_score(data)
        return json.dumps(asdict(result), indent=2)
    
    @server.tool()
    async def prism_validate_anomaly(data: str) -> str:
        """
        Compute D(x) anomaly detection score.
        
        HARD BLOCKS if D(x) < 0.30
        """
        try:
            parsed = json.loads(data) if isinstance(data, str) else data
        except:
            parsed = {"raw": data}
        
        result = compute_anomaly_score(parsed)
        return json.dumps(asdict(result), indent=2)
    
    @server.tool()
    async def prism_validate_omega(output: str) -> str:
        """
        Compute full Ω(x) master equation with all 10 components.
        
        Returns score, component breakdown, and decision (RELEASE/WARN/BLOCK).
        """
        try:
            data = json.loads(output) if isinstance(output, str) else output
        except:
            data = {"raw": output}
        
        result = compute_omega(data)
        return json.dumps({
            "omega": result.omega,
            "omega_lower": result.omega_lower,
            "components": result.components,
            "decision": result.decision.value,
            "blocking_reasons": result.blocking_reasons
        }, indent=2)
    
    @server.tool()
    async def prism_validate_anti_regression(old_path: str, new_content: str) -> str:
        """
        Verify new content doesn't lose information from old.
        
        CRITICAL: Core PRISM principle. Never ship if new < old.
        """
        result = check_anti_regression(old_path, new_content)
        return json.dumps(asdict(result), indent=2)
    
    @server.tool()
    async def prism_validate_gates(context: str) -> str:
        """Run all 9 validation gates."""
        try:
            ctx = json.loads(context) if isinstance(context, str) else context
        except:
            ctx = {}
        
        results = run_all_gates(ctx)
        return json.dumps([asdict(r) for r in results], indent=2)
    
    @server.tool()
    async def prism_validate_complete(content: str) -> str:
        """
        Check for placeholders, TODOs, and incomplete content.
        
        Returns is_complete status and list of issues found.
        """
        result = check_completeness(content)
        return json.dumps(result, indent=2)
    
    # =========================================================================
    # HOOK TOOLS
    # =========================================================================
    
    @server.tool()
    async def prism_hook_trigger(hook_id: str, data: str = "{}") -> str:
        """
        Execute a hook by ID.
        
        Common hooks: SYS-LAW3 (anti-regression), BAYES-002 (change detection),
                      CTX-ERR-001 (error preservation)
        """
        try:
            parsed_data = json.loads(data)
        except:
            parsed_data = {"raw": data}
        
        result = trigger_hook(hook_id, parsed_data)
        return json.dumps(asdict(result), indent=2)
    
    @server.tool()
    async def prism_hook_list(category: str = None) -> str:
        """
        List available hooks.
        
        Categories: system, cognitive, context, domain
        """
        if category:
            filtered = {k: v for k, v in HOOKS.items() if v["category"] == category}
        else:
            filtered = HOOKS
        
        return json.dumps(filtered, indent=2)
    
    return server


# =============================================================================
# STANDALONE MODE (for testing without MCP)
# =============================================================================

def run_standalone_tests():
    """Run tests in standalone mode."""
    print("=" * 60)
    print("PRISM Protocol Server - Standalone Test Mode")
    print("=" * 60)
    
    # Test protocol sections
    print("\n1. Testing protocol sections...")
    for section in ["identity", "mindsets", "gates"]:
        content = PROTOCOL_SECTIONS.get(section, "NOT FOUND")
        print(f"   {section}: {len(content)} chars")
    
    # Test validation
    print("\n2. Testing safety validation...")
    test_output = {
        "speeds": {"spindle": 5000},
        "feeds": {"rate": 100},
        "material": "AL-6061",
        "machine_limits": {"max_rpm": 10000}
    }
    safety = compute_safety_score(test_output)
    print(f"   S(x) = {safety.score:.2f}, passed = {safety.passed}")
    
    # Test omega
    print("\n3. Testing Ω(x) computation...")
    omega = compute_omega(test_output)
    print(f"   Ω(x) = {omega.omega:.2f}, decision = {omega.decision.value}")
    
    # Test anti-regression
    print("\n4. Testing anti-regression...")
    # Create test file
    test_file = STATE_DIR / "test_regression.md"
    test_file.write_text("# Test\n" * 100)
    result = check_anti_regression(str(test_file), "# Test\n" * 50)
    print(f"   Passed = {result.passed}, ratio = {result.ratio:.2f}")
    test_file.unlink()
    
    # Test completeness
    print("\n5. Testing completeness check...")
    test_content = "This is complete content with no issues."
    result = check_completeness(test_content)
    print(f"   Complete = {result['is_complete']}")
    
    test_content_bad = "This has TODO items and ... incomplete stuff etc."
    result = check_completeness(test_content_bad)
    print(f"   Incomplete content: {len(result['issues'])} issues found")
    
    # Test gates
    print("\n6. Testing validation gates...")
    gates = run_all_gates({"output": test_output, "evidence": {"level": 3}})
    passed = sum(1 for g in gates if g.passed)
    print(f"   {passed}/{len(gates)} gates passed")
    
    print("\n" + "=" * 60)
    print("All tests completed.")
    print("=" * 60)


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import sys
    
    if "--test" in sys.argv:
        run_standalone_tests()
    elif Server is not None:
        # Run MCP server
        server = create_mcp_server()
        if server:
            print("Starting PRISM Protocol MCP Server...")
            server.run()
    else:
        print("MCP not installed. Run with --test for standalone tests.")
        print("Install MCP: pip install mcp")
```

---

### A2. Create Protocol Content Files

**Path:** `C:\PRISM\protocol\sections\`

Create individual files for each section (for easy editing):

```
C:\PRISM\protocol\sections\
├── identity.md
├── mindsets.md
├── gates.md
├── workflow.md
├── commandments.md
├── evidence_levels.md
├── buffer_zones.md
├── agent_tiers.md
├── skill_hierarchy.md
├── omega_equation.md
├── anti_regression.md
├── session_protocol.md
├── paths.md
└── forbidden.md
```

Each file contains ONLY that section's content (copy from PROTOCOL_SECTIONS dict above).

---

## PHASE B: CREATE STABLE PREFIX

### B1. Create Minimal System Prompt

**Path:** `C:\PRISM\protocol\STABLE_PREFIX.md`

This is what goes in the system prompt - NEVER changes (enables KV-cache):

```markdown
# PRISM MANUFACTURING INTELLIGENCE

You are developing PRISM, a safety-critical CNC machine control system.
LIVES ARE AT STAKE. Mathematical errors cause tool explosions and operator injury.

## HARD CONSTRAINTS (Non-Negotiable)
- S(x) ≥ 0.70 (Safety score) - BLOCKS output if failed
- D(x) ≥ 0.30 (Anomaly detection) - BLOCKS output if failed
- No placeholders, TODOs, or incomplete content
- New ≥ Old (anti-regression)

## AVAILABLE MCP TOOLS

Use these tools for protocol guidance and validation:

### Protocol Reference
- `prism_protocol_section(section)` - Get specific section
- `prism_protocol_checklist(phase)` - Get phase checklist
- `prism_protocol_quick_ref()` - Get quick reference card

### Validation (EXECUTABLE ENFORCEMENT)
- `prism_validate_safety(output)` - Compute S(x), HARD BLOCKS if < 0.70
- `prism_validate_omega(output)` - Compute full Ω(x) with decision
- `prism_validate_anti_regression(old_path, new_content)` - Check for losses
- `prism_validate_complete(content)` - Find placeholders/TODOs
- `prism_validate_gates(context)` - Run all 9 gates

### Project Status
- `prism_roadmap_status(project)` - Current progress
- `prism_roadmap_next_task(project)` - Priority task

### Hooks
- `prism_hook_trigger(hook_id, data)` - Execute enforcement hook

## WORKFLOW
BRAINSTORM (STOP!) → PLAN → EXECUTE → REVIEW → HANDOFF

## COMMANDMENT #1
IF IT EXISTS, USE IT EVERYWHERE

---
Token count: ~500 (vs 15,700 before)
```

---

## PHASE C: MIGRATION SCRIPTS

### C1. Create Migration Validator

**Path:** `C:\PRISM\scripts\migrate_to_mcp_protocol.py`

```python
#!/usr/bin/env python3
"""
Migration script: Validates MCP protocol system has full parity with text protocol.

Checks:
1. All sections present
2. All validation functions work
3. All hooks defined
4. Token savings calculated
"""

import json
from pathlib import Path
import re

PRISM_ROOT = Path("C:/PRISM")
PROTOCOL_SERVER = PRISM_ROOT / "mcp" / "prism_protocol_server.py"

def count_tokens(text: str) -> int:
    """Approximate token count (rough estimate)."""
    return len(text) // 4

def validate_migration():
    print("=" * 60)
    print("PRISM MCP Protocol Migration Validator")
    print("=" * 60)
    
    errors = []
    warnings = []
    
    # Check 1: Server file exists
    print("\n1. Checking server file...")
    if not PROTOCOL_SERVER.exists():
        errors.append(f"Server file missing: {PROTOCOL_SERVER}")
    else:
        print(f"   ✓ Server file exists: {PROTOCOL_SERVER}")
        server_content = PROTOCOL_SERVER.read_text()
        
        # Check required sections
        required_sections = [
            "identity", "mindsets", "gates", "workflow", "commandments",
            "evidence_levels", "buffer_zones", "omega_equation", "anti_regression"
        ]
        
        print("\n2. Checking protocol sections...")
        for section in required_sections:
            if f'"{section}"' in server_content:
                print(f"   ✓ Section: {section}")
            else:
                errors.append(f"Missing section: {section}")
        
        # Check required tools
        required_tools = [
            "prism_protocol_section",
            "prism_validate_safety",
            "prism_validate_omega",
            "prism_validate_anti_regression",
            "prism_validate_complete",
            "prism_validate_gates",
            "prism_hook_trigger",
            "prism_roadmap_status",
        ]
        
        print("\n3. Checking MCP tools...")
        for tool in required_tools:
            if f"def {tool}" in server_content or f"async def {tool}" in server_content:
                print(f"   ✓ Tool: {tool}")
            else:
                errors.append(f"Missing tool: {tool}")
        
        # Check hooks
        required_hooks = ["SYS-LAW3", "BAYES-002", "CTX-ERR-001"]
        print("\n4. Checking hooks...")
        for hook in required_hooks:
            if f'"{hook}"' in server_content:
                print(f"   ✓ Hook: {hook}")
            else:
                warnings.append(f"Hook not found: {hook}")
    
    # Check 2: Stable prefix exists
    print("\n5. Checking stable prefix...")
    stable_prefix = PRISM_ROOT / "protocol" / "STABLE_PREFIX.md"
    if stable_prefix.exists():
        prefix_content = stable_prefix.read_text()
        prefix_tokens = count_tokens(prefix_content)
        print(f"   ✓ Stable prefix exists: {prefix_tokens} tokens")
        
        if prefix_tokens > 1000:
            warnings.append(f"Stable prefix too large: {prefix_tokens} tokens (target: <1000)")
    else:
        errors.append(f"Stable prefix missing: {stable_prefix}")
    
    # Check 3: Token savings
    print("\n6. Calculating token savings...")
    old_protocol_estimate = 15700  # Based on current files
    new_tokens = count_tokens(stable_prefix.read_text()) if stable_prefix.exists() else 0
    new_tokens += 500  # Tool definitions overhead
    
    savings_pct = (old_protocol_estimate - new_tokens) / old_protocol_estimate * 100
    print(f"   Old protocol: ~{old_protocol_estimate} tokens")
    print(f"   New protocol: ~{new_tokens} tokens")
    print(f"   Savings: {savings_pct:.1f}%")
    
    if savings_pct < 70:
        warnings.append(f"Token savings lower than expected: {savings_pct:.1f}%")
    
    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    
    if errors:
        print(f"\n❌ ERRORS ({len(errors)}):")
        for e in errors:
            print(f"   - {e}")
    
    if warnings:
        print(f"\n⚠️  WARNINGS ({len(warnings)}):")
        for w in warnings:
            print(f"   - {w}")
    
    if not errors and not warnings:
        print("\n✅ Migration validation PASSED")
        print("   All sections present")
        print("   All tools defined")
        print(f"   Token savings: {savings_pct:.1f}%")
    elif not errors:
        print("\n✅ Migration validation PASSED with warnings")
    else:
        print("\n❌ Migration validation FAILED")
        return False
    
    return True


if __name__ == "__main__":
    success = validate_migration()
    exit(0 if success else 1)
```

---

## PHASE D: UPDATE CONFIGURATIONS

### D1. Update Claude Desktop Config (if using Claude Desktop)

**Path:** `%APPDATA%\Claude\claude_desktop_config.json`

Add to mcpServers section:

```json
{
  "mcpServers": {
    "prism-protocol": {
      "command": "python",
      "args": ["C:\\PRISM\\mcp\\prism_protocol_server.py"],
      "env": {}
    }
  }
}
```

### D2. Create MCP Config for API Usage

**Path:** `C:\PRISM\mcp\mcp_config.json`

```json
{
  "servers": {
    "prism-protocol": {
      "type": "stdio",
      "command": "python",
      "args": ["C:\\PRISM\\mcp\\prism_protocol_server.py"],
      "description": "PRISM Protocol System - validation, roadmaps, hooks"
    }
  },
  "version": "1.0.0",
  "token_savings": {
    "old_per_message": 15700,
    "new_per_message": 2500,
    "savings_percent": 84
  }
}
```

---

## PHASE E: TESTING & VALIDATION

### E1. Run Server Tests

```powershell
# Test standalone mode
py -3 C:\PRISM\mcp\prism_protocol_server.py --test

# Expected output:
# - All protocol sections load
# - Safety validation works
# - Omega computation works
# - Anti-regression detection works
# - Completeness check works
# - All gates run
```

### E2. Run Migration Validator

```powershell
py -3 C:\PRISM\scripts\migrate_to_mcp_protocol.py

# Expected: "Migration validation PASSED"
```

### E3. Test MCP Tools (if MCP installed)

```python
# Test each tool manually:
# prism_protocol_section("mindsets")
# prism_validate_safety('{"speeds": {"spindle": 5000}}')
# prism_validate_omega('{"test": "data"}')
# prism_validate_complete("This has TODO items")
```

---

## PHASE F: DOCUMENTATION

### F1. Create Usage Guide

**Path:** `C:\PRISM\docs\MCP_PROTOCOL_USAGE.md`

```markdown
# PRISM MCP Protocol System - Usage Guide

## Overview

The MCP protocol system replaces 15,700 tokens of static protocol text with
on-demand retrieval and executable enforcement. Savings: ~84% per message.

## Quick Start

### Instead of reading full protocol:
```
OLD: Load GSD_CORE.md + PRISM_CONDENSED_PROTOCOL.md (15,700 tokens)
NEW: Stable prefix (500 tokens) + MCP calls as needed
```

### Get protocol section:
```
prism_protocol_section("mindsets")
prism_protocol_section("gates")
prism_protocol_checklist("execute")
```

### Validate output before shipping:
```
prism_validate_safety(my_output)        # S(x) check
prism_validate_omega(my_output)         # Full Ω(x)
prism_validate_complete(my_content)     # No TODOs
prism_validate_anti_regression(old_path, new_content)
```

### Check project status:
```
prism_roadmap_status("alarm_db")
prism_roadmap_next_task("alarm_db")
```

## Key Benefits

1. **Token Savings**: 84% reduction per message
2. **Executable Enforcement**: Code guarantees vs text hopes
3. **KV-Cache Efficiency**: Stable prefix enables caching
4. **Modular Updates**: Change one section without touching others

## Available Sections

- identity, mindsets, gates, workflow, commandments
- evidence_levels, buffer_zones, agent_tiers, skill_hierarchy
- omega_equation, anti_regression, session_protocol, paths, forbidden

## Available Validations

- prism_validate_safety → S(x) with HARD BLOCK
- prism_validate_anomaly → D(x) with HARD BLOCK
- prism_validate_omega → Full 10-component score
- prism_validate_anti_regression → New ≥ Old check
- prism_validate_complete → Placeholder detection
- prism_validate_gates → All 9 gates
```

---

## EXECUTION CHECKLIST

Before claiming this task complete, verify ALL of the following:

### Files Created:
- [ ] `C:\PRISM\mcp\prism_protocol_server.py` (main server, ~800 lines)
- [ ] `C:\PRISM\protocol\STABLE_PREFIX.md` (~500 tokens)
- [ ] `C:\PRISM\protocol\sections\*.md` (14 section files)
- [ ] `C:\PRISM\scripts\migrate_to_mcp_protocol.py`
- [ ] `C:\PRISM\mcp\mcp_config.json`
- [ ] `C:\PRISM\docs\MCP_PROTOCOL_USAGE.md`

### Tests Passed:
- [ ] `py -3 C:\PRISM\mcp\prism_protocol_server.py --test` runs without errors
- [ ] `py -3 C:\PRISM\scripts\migrate_to_mcp_protocol.py` shows "PASSED"
- [ ] All 14 protocol sections are accessible
- [ ] Safety validation correctly computes S(x)
- [ ] Omega computation includes all 10 components
- [ ] Anti-regression catches size reductions
- [ ] Completeness check finds TODO/placeholder patterns

### Evidence Required:
- [ ] Screenshot or output of server test
- [ ] Screenshot or output of migration validator
- [ ] File listing showing all created files
- [ ] Token count comparison (old vs new)

### State Updates:
- [ ] CURRENT_STATE.json updated with completion status
- [ ] quickResume section written for next session

---

## ANTI-REGRESSION VERIFICATION

This implementation MUST preserve all functionality from:
- PRISM_CONDENSED_PROTOCOL_v15.md
- GSD_CORE.md / GSD_CORE_v3.md
- PRISM_INTEGRATED_MEGA_ROADMAP_v2.md

**Verification method:**
1. List all sections in old protocol files
2. Verify each exists in new MCP server
3. Test that retrieval returns equivalent content

---

## SUCCESS CRITERIA

| Metric | Target | Verification |
|--------|--------|--------------|
| Token savings | ≥80% | Migration validator output |
| Section coverage | 100% | All 14 sections present |
| Validation tools | 6 working | Test output |
| Hook definitions | ≥10 | Server inspection |
| Test pass rate | 100% | No errors in test run |

---

## WHAT TO DO AFTER COMPLETION

1. Update GSD_CORE.md to reference MCP tools instead of loading full protocol
2. Update gsd_startup.py to use MCP server
3. Update Claude Project instructions to use STABLE_PREFIX.md
4. Archive old protocol files (don't delete - keep for reference)

---

**END OF IMPLEMENTATION PROMPT**

When you complete this task, provide:
1. File listing of everything created
2. Test output showing all validations pass
3. Token savings calculation
4. Updated CURRENT_STATE.json
5. Any issues encountered and how you resolved them
```
