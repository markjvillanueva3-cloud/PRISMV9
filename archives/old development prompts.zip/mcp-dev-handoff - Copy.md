# MCP Server Enhancement - Development Handoff

## Context

I have an existing MCP server setup for PRISM (manufacturing intelligence system). I need to add developer-focused tools that improve Claude's ability to assist with coding tasks. These tools should integrate with my existing workflow which emphasizes: planning → execution → verification → handoff.

## What to Build

Implement these MCP tools in priority order. Use TypeScript with the official MCP SDK. Target streamable HTTP transport for remote use, with stdio fallback for local.

---

## Priority 1: Git Operations MCP

### Tools to implement:

```typescript
git_status
// Returns: { staged: string[], unstaged: string[], untracked: string[], branch: string, ahead: number, behind: number }
// No parameters required

git_diff
// Parameters: { file?: string, staged?: boolean, commit_range?: string }
// Returns: { diff: string, files_changed: number, insertions: number, deletions: number }

git_log
// Parameters: { count?: number, author?: string, since?: string, path?: string, oneline?: boolean }
// Returns: { commits: Array<{ hash: string, author: string, date: string, message: string }> }

git_blame
// Parameters: { file: string, start_line?: number, end_line?: number }
// Returns: { lines: Array<{ line_number: number, commit: string, author: string, date: string, content: string }> }

git_commit
// Parameters: { message: string, files?: string[], all?: boolean }
// Returns: { hash: string, message: string, files_committed: number }
// Annotations: { destructiveHint: true, idempotentHint: false }

git_branch
// Parameters: { action: 'list' | 'create' | 'switch' | 'delete', name?: string }
// Returns: { branches?: string[], current?: string, created?: string, switched?: string, deleted?: string }

git_stash
// Parameters: { action: 'push' | 'pop' | 'list' | 'drop', message?: string, index?: number }
// Returns: { stashes?: Array<{ index: number, message: string }>, applied?: string, dropped?: string }
```

### Implementation notes:
- Use `simple-git` npm package for git operations
- All paths should be relative to working directory passed in server config
- Return structured JSON, not raw git output
- Include proper error messages: "No changes to commit", "Branch already exists", etc.

---

## Priority 2: Test Runner MCP

### Tools to implement:

```typescript
test_run
// Parameters: { pattern?: string, file?: string, watch?: boolean, coverage?: boolean }
// Returns: { passed: number, failed: number, skipped: number, duration_ms: number, failures: Array<{ test: string, error: string, file: string, line: number }> }

test_run_affected
// Parameters: { since?: string } // git ref, defaults to HEAD~1
// Returns: same as test_run, plus { affected_files: string[] }

test_coverage
// Parameters: { file?: string }
// Returns: { total: { lines: number, covered: number, percent: number }, files: Array<{ path: string, lines: number, covered: number, percent: number, uncovered_lines: number[] }> }
```

### Implementation notes:
- Detect test framework from package.json (jest, vitest, mocha, pytest)
- Parse test output into structured results
- For `test_run_affected`, use git diff to find changed files, then find tests that import them

---

## Priority 3: Code Search MCP

### Tools to implement:

```typescript
code_search
// Parameters: { query: string, regex?: boolean, file_pattern?: string, context_lines?: number, max_results?: number }
// Returns: { matches: Array<{ file: string, line: number, content: string, context_before: string[], context_after: string[] }>, total_matches: number, truncated: boolean }

code_search_symbols
// Parameters: { name?: string, type?: 'function' | 'class' | 'variable' | 'import', file_pattern?: string }
// Returns: { symbols: Array<{ name: string, type: string, file: string, line: number, signature?: string }> }

code_references
// Parameters: { symbol: string, file?: string }
// Returns: { definition: { file: string, line: number }, references: Array<{ file: string, line: number, context: string }> }
```

### Implementation notes:
- Use `@ripgrep/ripgrep` or spawn `rg` process for fast search
- For symbol search, use tree-sitter or a lightweight AST parser
- Respect .gitignore by default
- Cap results at 100 by default to avoid context overflow

---

## Priority 4: Lint/Build MCP

### Tools to implement:

```typescript
lint_run
// Parameters: { file?: string, fix?: boolean }
// Returns: { errors: Array<{ file: string, line: number, column: number, rule: string, message: string, severity: 'error' | 'warning', fixable: boolean }>, error_count: number, warning_count: number, fixed_count?: number }

build_check
// Parameters: { } 
// Returns: { success: boolean, errors: Array<{ file: string, line: number, message: string }>, duration_ms: number }
```

### Implementation notes:
- Detect linter from config files (eslint, biome, ruff, pylint)
- Parse linter JSON output into structured format
- For build_check, run `tsc --noEmit` or equivalent without producing output

---

## Priority 5: Diff/Patch MCP

### Tools to implement:

```typescript
diff_generate
// Parameters: { file?: string, staged?: boolean }
// Returns: { patch: string, hunks: Array<{ file: string, start_line: number, end_line: number, content: string }> }

diff_apply
// Parameters: { patch: string, dry_run?: boolean }
// Returns: { applied: boolean, files_modified: string[], errors?: string[] }

diff_preview
// Parameters: { file: string, changes: Array<{ line: number, action: 'insert' | 'delete' | 'replace', content: string }> }
// Returns: { before: string, after: string, diff: string }
```

---

## Server Structure

```
mcp-dev-tools/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts          # Server entry, tool registration
│   ├── config.ts         # Working directory, settings
│   ├── tools/
│   │   ├── git.ts        # Git operations
│   │   ├── test.ts       # Test runner
│   │   ├── search.ts     # Code search
│   │   ├── lint.ts       # Lint/build
│   │   └── diff.ts       # Diff/patch
│   └── utils/
│       ├── exec.ts       # Shell command execution
│       ├── parse.ts      # Output parsing helpers
│       └── errors.ts     # Error formatting
```

## Dependencies

```json
{
  "dependencies": {
    "@modelcontextprotocol/sdk": "latest",
    "simple-git": "^3.x",
    "zod": "^3.x",
    "execa": "^8.x"
  }
}
```

## Key Requirements

1. **Structured output**: Always return parsed JSON, never raw CLI output
2. **Actionable errors**: Include file, line, and suggested fix when possible
3. **Annotations**: Mark destructive tools appropriately (commit, stash drop, etc.)
4. **Working directory**: Accept `workingDirectory` in server config, validate it exists
5. **Timeouts**: 30s default for git/test operations, configurable
6. **Result limits**: Default max results to prevent context overflow

## Testing

After implementation, verify each tool works by:
1. Running `npx @modelcontextprotocol/inspector` 
2. Testing each tool with valid and invalid inputs
3. Confirming error messages are actionable

---

## Start Here

Begin with Priority 1 (Git Operations). Create the project structure, implement `git_status` first as a proof of concept, then add remaining git tools. Once git tools are working, move to Priority 2.

Ask me if you need clarification on any tool's expected behavior or edge cases.
