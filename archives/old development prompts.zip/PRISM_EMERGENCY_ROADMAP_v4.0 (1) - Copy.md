# PRISM EMERGENCY PRIORITY ROADMAP v4.0
## C:\PRISM Full Integration + Hook Maximization
### Created: 2026-02-01 | Priority: 🔴 EMERGENCY | Lives Depend On This

---

```
╔══════════════════════════════════════════════════════════════════════════════════════════╗
║                        ⚠️  SAFETY-CRITICAL MANUFACTURING SOFTWARE  ⚠️                     ║
║                                                                                          ║
║   WRONG CALCULATIONS = TOOL EXPLOSIONS, MACHINE CRASHES, OPERATOR INJURY OR DEATH       ║
║                                                                                          ║
║   MATHEMATICAL CERTAINTY IS NOT OPTIONAL. NO SHORTCUTS. NO PLACEHOLDERS.                ║
╚══════════════════════════════════════════════════════════════════════════════════════════╝
```

---

# EXECUTIVE SUMMARY

## Current State (as of Session 16)
| Component | Count | Status |
|-----------|-------|--------|
| MCP Server Version | v2.5 | ✅ Active |
| MCP Tools | 116 | ✅ Deployed |
| MCP Categories | 22 | ✅ Organized |
| Skills (Real) | 146 | ✅ Indexed |
| Agents | 64 | ✅ Tiered (OPUS/SONNET/HAIKU) |
| Hooks | 6,797 | ⚠️ NEED MAXIMIZATION |
| Hook×Agent Mappings | 6,797×64 | ⚠️ PARTIAL |
| Formulas | 490 | ✅ Indexed |
| Materials Database | 1,047×127 params | ✅ Queryable |
| Machines Database | 824×43 mfrs | ✅ Queryable |
| Alarms Database | 9,200 codes | ✅ Queryable |
| Monolith | 986,621 lines | ❌ NOT INDEXED |
| Python Scripts | 443+ | ❌ NOT EXECUTABLE VIA MCP |
| File Operations | Limited | ❌ NOT INTEGRATED |

## What This Roadmap Achieves

```
BEFORE (Current):
┌─────────────────────────────────────────────────────────────┐
│ Claude Context Window                                       │
│ ├── Must READ files to access (tokens consumed)             │
│ ├── Must LOAD monolith sections (context bloat)             │
│ ├── Cannot EXECUTE scripts (manual only)                    │
│ ├── Hooks exist but NOT wired to all operations             │
│ └── 60-70% context used for data, 30-40% for reasoning      │
└─────────────────────────────────────────────────────────────┘

AFTER (This Roadmap):
┌─────────────────────────────────────────────────────────────┐
│ Claude Context Window                                       │
│ ├── MCP QUERIES return only needed data                     │
│ ├── Monolith INDEXED and searchable (no loading)            │
│ ├── Scripts EXECUTABLE server-side                          │
│ ├── Hooks AUTO-FIRE on every relevant operation             │
│ └── 15-20% context for data, 80-85% for reasoning           │
└─────────────────────────────────────────────────────────────┘
```

---

# PHASE 0: HOOK MAXIMIZATION (CURRENT PRIORITY)
## Continue From Where We Are - Sessions 17-19
### Time: 6-9 hours | Priority: 🔴 EMERGENCY

We were maximizing hooks. This MUST complete before new integration.

## Session 17: Hook Wiring Completion

### 17.1 Hook-to-Operation Mapping Audit
Every operation that CAN trigger a hook MUST trigger a hook.

```
AUDIT CHECKLIST:
┌──────────────────────────────────────────────────────────────────────────────┐
│ OPERATION CATEGORY          │ HOOKS REQUIRED      │ STATUS    │ GAP        │
├──────────────────────────────────────────────────────────────────────────────┤
│ Material Query              │ beforeQuery,        │ ✅ Wired  │ 0          │
│                             │ afterQuery,         │           │            │
│                             │ onValidation        │           │            │
├──────────────────────────────────────────────────────────────────────────────┤
│ Calculation Execution       │ beforeCalc,         │ ⚠️ Partial│ 12 missing │
│                             │ afterCalc,          │           │            │
│                             │ onSafetyViolation,  │           │            │
│                             │ onUncertaintyExceed │           │            │
├──────────────────────────────────────────────────────────────────────────────┤
│ File Creation               │ beforeCreate,       │ ❌ None   │ 8 missing  │
│                             │ afterCreate,        │           │            │
│                             │ onValidationFail    │           │            │
├──────────────────────────────────────────────────────────────────────────────┤
│ State Mutation              │ beforeMutate,       │ ⚠️ Partial│ 6 missing  │
│                             │ afterMutate,        │           │            │
│                             │ onRollback          │           │            │
├──────────────────────────────────────────────────────────────────────────────┤
│ Agent Spawning              │ beforeSpawn,        │ ❌ None   │ 5 missing  │
│                             │ afterSpawn,         │           │            │
│                             │ onAgentError        │           │            │
├──────────────────────────────────────────────────────────────────────────────┤
│ Batch Operations            │ beforeBatch,        │ ❌ None   │ 6 missing  │
│                             │ afterBatch,         │           │            │
│                             │ onPartialFailure    │           │            │
├──────────────────────────────────────────────────────────────────────────────┤
│ Formula Application         │ beforeApply,        │ ⚠️ Partial│ 4 missing  │
│                             │ afterApply,         │           │            │
│                             │ onMAPEExceed        │           │            │
├──────────────────────────────────────────────────────────────────────────────┤
│ TOTAL GAPS                  │                     │           │ 41 hooks   │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 17.2 New MCP Tools for Hook System
```python
# ADD THESE TO prism_mcp_server.py

# Hook Execution Layer (6 new tools)
prism_hook_fire(hook_name, context)      # Manually fire hook
prism_hook_chain(hooks[], context)       # Fire hook sequence
prism_hook_status()                      # All active hooks status
prism_hook_history(last_n=50)            # Recent hook executions
prism_hook_enable(hook_name)             # Enable disabled hook
prism_hook_disable(hook_name, reason)    # Disable with reason (audit trail)

# Hook Analytics (4 new tools)
prism_hook_coverage()                    # % of operations hooked
prism_hook_gaps()                        # Operations without hooks
prism_hook_performance()                 # Hook execution times
prism_hook_failures(last_n=100)          # Recent hook failures
```

### 17.3 Hook Integration Points
Every MCP tool MUST have hook wiring:

```python
# PATTERN: Every tool gets hooks
def prism_material_get(material_id: str) -> dict:
    # BEFORE hook
    context = {"material_id": material_id, "timestamp": now()}
    hook_fire("material.beforeQuery", context)
    
    # ACTUAL OPERATION
    result = _internal_material_lookup(material_id)
    
    # VALIDATION hook
    validation = validate_material_response(result)
    if not validation.valid:
        hook_fire("material.onValidationFail", {**context, "errors": validation.errors})
        raise ValidationError(validation.errors)
    
    # AFTER hook
    hook_fire("material.afterQuery", {**context, "result_size": len(result)})
    
    return result
```

### 17.4 Deliverables for Session 17
```
□ Complete hook gap audit (41 hooks identified)
□ Wire all 41 missing hooks to operations
□ Add 10 new MCP tools for hook management
□ Create hook coverage report (target: 100%)
□ Test all hooks fire correctly
□ Update HOOK_REGISTRY.json with new hooks
□ MCP Server version: v2.5 → v2.6
```

---

## Session 18: Hook-Agent Maximization

### 18.1 Hook×Agent Matrix Completion
Every hook MUST map to appropriate agents:

```
HOOK-AGENT MAPPING PRINCIPLES:
┌─────────────────────────────────────────────────────────────────────────────┐
│ HOOK TYPE              │ AGENT TIER      │ REASON                          │
├─────────────────────────────────────────────────────────────────────────────┤
│ Safety violations      │ OPUS            │ Complex reasoning for override  │
│ Anti-regression        │ OPUS            │ Full context comparison         │
│ Quality scoring (Ω)    │ OPUS            │ Multi-factor evaluation         │
├─────────────────────────────────────────────────────────────────────────────┤
│ Code generation        │ SONNET          │ Balanced speed/quality          │
│ Formula application    │ SONNET          │ Standard calculations           │
│ Batch operations       │ SONNET          │ Parallelizable tasks            │
├─────────────────────────────────────────────────────────────────────────────┤
│ Formatting             │ HAIKU           │ Fast, simple transforms         │
│ Counting/inventory     │ HAIKU           │ No reasoning needed             │
│ Status reporting       │ HAIKU           │ Quick aggregation               │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 18.2 Auto-Escalation Rules
Hooks can escalate to higher tiers:

```python
ESCALATION_RULES = {
    "safety.onViolation": {
        "initial_tier": "SONNET",
        "escalate_to": "OPUS",
        "escalate_when": "severity >= HIGH or S(x) < 0.70"
    },
    "calculation.onUncertaintyExceed": {
        "initial_tier": "SONNET", 
        "escalate_to": "OPUS",
        "escalate_when": "uncertainty > 2σ or safety_critical == True"
    },
    "antiRegression.onFailure": {
        "initial_tier": "SONNET",
        "escalate_to": "OPUS",
        "escalate_when": "data_loss_detected or count_mismatch > 5%"
    }
}
```

### 18.3 New MCP Tools for Agent-Hook Integration
```python
# Agent-Hook Binding (4 new tools)
prism_hook_bind_agent(hook_name, agent_id, tier)   # Bind agent to hook
prism_hook_unbind_agent(hook_name, agent_id)       # Remove binding
prism_hook_agent_map()                              # Full hook→agent mapping
prism_hook_escalation_rules()                       # View escalation config

# Agent Invocation via Hook (3 new tools)
prism_hook_invoke_agent(hook_name, context)         # Fire hook + invoke agent
prism_hook_agent_history(hook_name, last_n=20)      # Agent invocations per hook
prism_hook_agent_performance(hook_name)             # Agent perf per hook
```

### 18.4 Deliverables for Session 18
```
□ Complete hook×agent mapping (6,797 hooks × 64 agents)
□ Implement escalation rules for safety-critical hooks
□ Add 7 new MCP tools for agent-hook integration
□ Test escalation scenarios
□ Document all mappings in HOOK_AGENT_MATRIX.json
□ MCP Server version: v2.6 → v2.7
```

---

## Session 19: Hook Performance & Optimization

### 19.1 Hook Execution Optimization
Hooks must NOT slow down operations:

```
PERFORMANCE TARGETS:
┌──────────────────────────────────────────────────────────────────────────────┐
│ HOOK CATEGORY          │ MAX LATENCY    │ CURRENT    │ OPTIMIZATION         │
├──────────────────────────────────────────────────────────────────────────────┤
│ beforeQuery hooks      │ < 5ms          │ ~3ms       │ ✅ OK                │
│ afterQuery hooks       │ < 10ms         │ ~8ms       │ ✅ OK                │
│ beforeCalc hooks       │ < 2ms          │ ~15ms      │ ❌ OPTIMIZE          │
│ safety hooks           │ < 50ms         │ ~45ms      │ ⚠️ CLOSE             │
│ validation hooks       │ < 20ms         │ ~35ms      │ ❌ OPTIMIZE          │
│ logging hooks          │ < 1ms (async)  │ ~1ms       │ ✅ OK                │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 19.2 Async Hook Pattern
Non-blocking hooks for logging/analytics:

```python
ASYNC_HOOKS = [
    "*.onLog",
    "*.onMetric", 
    "*.onAudit",
    "learning.*",
    "analytics.*"
]

# These fire without blocking main operation
async def hook_fire_async(hook_name, context):
    if hook_name in ASYNC_HOOKS:
        asyncio.create_task(_execute_hook(hook_name, context))
    else:
        await _execute_hook(hook_name, context)
```

### 19.3 Hook Caching Strategy
Frequently-fired hooks cache results:

```python
CACHED_HOOKS = {
    "material.afterQuery": {
        "cache_key": "material_id",
        "ttl_seconds": 300,
        "invalidate_on": ["material.onUpdate", "material.onDelete"]
    },
    "machine.afterQuery": {
        "cache_key": "machine_id", 
        "ttl_seconds": 600,
        "invalidate_on": ["machine.onUpdate"]
    }
}
```

### 19.4 Deliverables for Session 19
```
□ Profile all hook execution times
□ Optimize slow hooks (< target latency)
□ Implement async hooks for non-blocking operations
□ Add hook caching for frequent queries
□ Create HOOK_PERFORMANCE_REPORT.json
□ Verify zero regressions in operation speed
□ MCP Server version: v2.7 → v2.8
```

---

# PHASE 1: CODE INTELLIGENCE INTEGRATION
## Sessions 20-23 | Time: 12-16 hours | Priority: 🔴 HIGH

## Session 20: Monolith AST Indexing

### 20.1 The Problem
The 986,621-line monolith is currently unsearchable without loading chunks into context.

### 20.2 Solution Architecture
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MONOLITH INDEXING SYSTEM                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  C:\PRISM\src\monolith\**\*.ts                                             │
│  └── 986,621 lines │ 831 modules │ ~48MB                                    │
│                    │                                                        │
│                    ▼                                                        │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ AST PARSER (TypeScript Compiler API)                               │    │
│  │ ├── Extract functions (name, params, return, line numbers)         │    │
│  │ ├── Extract classes (name, methods, properties)                    │    │
│  │ ├── Extract interfaces (name, members)                             │    │
│  │ ├── Extract types (name, definition)                               │    │
│  │ ├── Extract imports/exports (dependencies)                         │    │
│  │ └── Extract comments (JSDoc, inline)                               │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                    │                                                        │
│                    ▼                                                        │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ INDEX DATABASE (SQLite or DuckDB)                                  │    │
│  │ ├── symbols table (id, name, type, file, start_line, end_line)     │    │
│  │ ├── dependencies table (symbol_id, depends_on_id)                  │    │
│  │ ├── references table (symbol_id, referenced_by_id, line)           │    │
│  │ ├── fulltext index (symbol_name, file_path, comments)              │    │
│  │ └── call_graph table (caller_id, callee_id)                        │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                    │                                                        │
│                    ▼                                                        │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ MCP QUERY INTERFACE                                                │    │
│  │ ├── prism_code_search(query) → matching symbols                    │    │
│  │ ├── prism_code_extract(symbol) → source code                       │    │
│  │ ├── prism_code_dependencies(symbol) → what it uses                 │    │
│  │ ├── prism_code_dependents(symbol) → what uses it                   │    │
│  │ ├── prism_code_call_graph(symbol) → full call tree                 │    │
│  │ └── prism_code_similar(symbol) → similar code patterns             │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 20.3 Index Schema
```sql
-- PRISM Monolith Index Schema

CREATE TABLE symbols (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    qualified_name TEXT NOT NULL,  -- e.g., "KienzleEngine.calculateForce"
    type TEXT NOT NULL,            -- function, class, interface, type, const
    file_path TEXT NOT NULL,
    start_line INTEGER NOT NULL,
    end_line INTEGER NOT NULL,
    signature TEXT,                -- function/method signature
    jsdoc TEXT,                    -- documentation
    complexity INTEGER,            -- cyclomatic complexity
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dependencies (
    id INTEGER PRIMARY KEY,
    symbol_id INTEGER REFERENCES symbols(id),
    depends_on_id INTEGER REFERENCES symbols(id),
    dependency_type TEXT           -- import, call, extends, implements
);

CREATE TABLE references (
    id INTEGER PRIMARY KEY,
    symbol_id INTEGER REFERENCES symbols(id),
    referenced_in_file TEXT,
    referenced_at_line INTEGER
);

CREATE VIRTUAL TABLE symbol_search USING fts5(
    name, qualified_name, jsdoc, file_path
);

-- Indexes for fast queries
CREATE INDEX idx_symbols_name ON symbols(name);
CREATE INDEX idx_symbols_type ON symbols(type);
CREATE INDEX idx_symbols_file ON symbols(file_path);
CREATE INDEX idx_deps_symbol ON dependencies(symbol_id);
CREATE INDEX idx_deps_depends ON dependencies(depends_on_id);
```

### 20.4 Indexer Script
Create: `C:\PRISM\scripts\monolith_indexer.py`

```python
#!/usr/bin/env python3
"""
PRISM Monolith Indexer
Parses 986,621 lines of TypeScript and builds searchable index.
"""

import os
import re
import json
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass
from concurrent.futures import ProcessPoolExecutor

@dataclass
class Symbol:
    name: str
    qualified_name: str
    type: str  # function, class, interface, type, const
    file_path: str
    start_line: int
    end_line: int
    signature: Optional[str] = None
    jsdoc: Optional[str] = None
    complexity: int = 0

class MonolithIndexer:
    def __init__(self, monolith_root: str, db_path: str):
        self.root = Path(monolith_root)
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self._create_schema()
    
    def _create_schema(self):
        """Create index tables"""
        # ... schema from above
    
    def index_all(self):
        """Index entire monolith with parallel processing"""
        ts_files = list(self.root.rglob("*.ts"))
        print(f"Indexing {len(ts_files)} TypeScript files...")
        
        with ProcessPoolExecutor(max_workers=8) as executor:
            results = executor.map(self._parse_file, ts_files)
        
        for symbols in results:
            self._insert_symbols(symbols)
        
        self._build_dependency_graph()
        self._compute_complexities()
        print(f"Indexing complete. {self._count_symbols()} symbols indexed.")
    
    def _parse_file(self, file_path: Path) -> List[Symbol]:
        """Parse single TypeScript file and extract symbols"""
        # TypeScript AST parsing logic
        pass
    
    def search(self, query: str, limit: int = 20) -> List[Symbol]:
        """Search symbols by name or content"""
        pass
    
    def get_dependencies(self, symbol_id: int) -> List[Symbol]:
        """Get all dependencies of a symbol"""
        pass
    
    def get_dependents(self, symbol_id: int) -> List[Symbol]:
        """Get all symbols that depend on this one"""
        pass

if __name__ == "__main__":
    indexer = MonolithIndexer(
        monolith_root="C:\\PRISM\\src\\monolith",
        db_path="C:\\PRISM\\data\\monolith_index.db"
    )
    indexer.index_all()
```

### 20.5 New MCP Tools for Code Intelligence
```python
# Code Intelligence MCP Tools (12 new tools)

# Search & Discovery
prism_code_search(query, type=None, limit=20)     # Search by name/content
prism_code_grep(pattern, file_pattern=None)        # Regex search in code
prism_code_symbols(file_path)                      # All symbols in file

# Extraction
prism_code_extract(symbol_name)                    # Get source code
prism_code_extract_range(file, start, end)         # Get line range
prism_code_context(symbol_name, lines_before=10)   # Code with context

# Dependencies  
prism_code_dependencies(symbol_name)               # What this uses
prism_code_dependents(symbol_name)                 # What uses this
prism_code_call_graph(symbol_name, depth=3)        # Full call tree
prism_code_import_graph(file_path)                 # File import tree

# Analysis
prism_code_similar(symbol_name, threshold=0.7)     # Similar code patterns
prism_code_complexity(symbol_name)                 # Cyclomatic complexity
```

### 20.6 Deliverables for Session 20
```
□ Create monolith_indexer.py script
□ Build SQLite/DuckDB index schema
□ Index all 986,621 lines (831 modules)
□ Verify index completeness
□ Create monolith_index.db
□ Document index statistics
```

---

## Session 21: Code Query MCP Integration

### 21.1 Add Code Tools to MCP Server
Update: `C:\PRISM\scripts\prism_mcp_server.py`

```python
class CodeIntelligenceMCP:
    """Code intelligence layer for monolith"""
    
    def __init__(self, index_path: str):
        self.conn = sqlite3.connect(index_path)
        self.index_path = index_path
    
    def search(self, query: str, symbol_type: str = None, limit: int = 20) -> dict:
        """Search symbols by name or content"""
        sql = """
            SELECT s.*, GROUP_CONCAT(d.depends_on_id) as deps
            FROM symbols s
            LEFT JOIN dependencies d ON s.id = d.symbol_id
            WHERE s.name LIKE ? OR s.qualified_name LIKE ?
        """
        if symbol_type:
            sql += f" AND s.type = '{symbol_type}'"
        sql += f" GROUP BY s.id LIMIT {limit}"
        
        results = self.conn.execute(sql, (f"%{query}%", f"%{query}%")).fetchall()
        return {"symbols": [self._row_to_dict(r) for r in results]}
    
    def extract(self, symbol_name: str) -> dict:
        """Extract source code for symbol"""
        symbol = self._get_symbol(symbol_name)
        if not symbol:
            return {"error": f"Symbol '{symbol_name}' not found"}
        
        with open(symbol["file_path"]) as f:
            lines = f.readlines()
        
        source = "".join(lines[symbol["start_line"]-1:symbol["end_line"]])
        return {
            "symbol": symbol,
            "source": source,
            "tokens_approx": len(source) // 4  # Rough token estimate
        }
    
    def dependencies(self, symbol_name: str) -> dict:
        """Get all dependencies"""
        symbol = self._get_symbol(symbol_name)
        deps = self.conn.execute("""
            SELECT s2.* FROM dependencies d
            JOIN symbols s2 ON d.depends_on_id = s2.id
            WHERE d.symbol_id = ?
        """, (symbol["id"],)).fetchall()
        return {"dependencies": [self._row_to_dict(d) for d in deps]}
    
    def call_graph(self, symbol_name: str, depth: int = 3) -> dict:
        """Build call graph to specified depth"""
        # Recursive CTE for call graph
        pass
```

### 21.2 Integration Test Suite
```python
# C:\PRISM\tests\test_code_intelligence.py

def test_search_finds_kienzle():
    result = mcp.call("prism_code_search", {"query": "Kienzle"})
    assert len(result["symbols"]) > 0
    assert any("KienzleEngine" in s["name"] for s in result["symbols"])

def test_extract_returns_source():
    result = mcp.call("prism_code_extract", {"symbol_name": "calculateFeedRate"})
    assert "source" in result
    assert "function" in result["source"] or "const" in result["source"]

def test_dependencies_complete():
    result = mcp.call("prism_code_dependencies", {"symbol_name": "KienzleEngine"})
    assert "dependencies" in result
    # KienzleEngine should depend on material types, constants, etc.
    dep_names = [d["name"] for d in result["dependencies"]]
    assert len(dep_names) > 0
```

### 21.3 Deliverables for Session 21
```
□ Add CodeIntelligenceMCP class to MCP server
□ Implement all 12 code intelligence tools
□ Create integration test suite
□ Verify all tests pass
□ Update MCP tool count: v2.8 → v2.9 (+12 tools)
□ Document query examples
```

---

## Session 22: Dependency Graph Visualization

### 22.1 Interactive Call Graph Tool
```python
def prism_code_visualize(symbol_name: str, format: str = "mermaid") -> dict:
    """Generate visual dependency graph"""
    graph = build_call_graph(symbol_name, depth=4)
    
    if format == "mermaid":
        mermaid = "graph TD\n"
        for node in graph["nodes"]:
            mermaid += f"  {node['id']}[{node['name']}]\n"
        for edge in graph["edges"]:
            mermaid += f"  {edge['from']} --> {edge['to']}\n"
        return {"mermaid": mermaid}
    
    elif format == "dot":
        # Graphviz DOT format
        pass
    
    elif format == "json":
        return graph
```

### 22.2 Module Boundary Analysis
```python
def prism_code_modules() -> dict:
    """Analyze module structure and boundaries"""
    modules = analyze_module_structure()
    return {
        "total_modules": len(modules),
        "modules": modules,
        "coupling_matrix": compute_coupling(modules),
        "cohesion_scores": compute_cohesion(modules),
        "suggested_refactors": identify_refactor_opportunities(modules)
    }
```

### 22.3 Deliverables for Session 22
```
□ Implement visualization tools (mermaid, dot, json)
□ Build module boundary analysis
□ Create coupling/cohesion metrics
□ Generate initial architecture report
□ Add 4 new MCP tools for visualization
□ MCP Server version: v2.9 → v3.0
```

---

## Session 23: Code Search Optimization

### 23.1 Full-Text Search Enhancement
```python
# Enable fuzzy search and semantic matching
def prism_code_search_advanced(
    query: str,
    fuzzy: bool = True,
    semantic: bool = False,
    filters: dict = None
) -> dict:
    """Advanced code search with fuzzy and semantic matching"""
    results = []
    
    # Exact match first
    exact = fts_search(query)
    results.extend(exact)
    
    # Fuzzy match
    if fuzzy:
        fuzzy_results = fuzzy_search(query, threshold=0.8)
        results.extend(fuzzy_results)
    
    # Semantic match (if embeddings available)
    if semantic:
        semantic_results = semantic_search(query, top_k=20)
        results.extend(semantic_results)
    
    # Apply filters
    if filters:
        results = apply_filters(results, filters)
    
    return {"results": deduplicate(results)}
```

### 23.2 Deliverables for Session 23
```
□ Implement fuzzy search
□ Add query filters (type, file, date)
□ Build search result ranking
□ Cache frequent queries
□ Benchmark search performance (< 100ms target)
□ MCP Server version: v3.0 → v3.1 (128 tools)
```

---

# PHASE 2: FILE OPERATIONS INTEGRATION
## Sessions 24-26 | Time: 9-12 hours | Priority: 🟠 HIGH

## Session 24: Server-Side File Operations

### 24.1 File Operation Architecture
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       FILE OPERATIONS SYSTEM                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  SAFETY LAYER (All operations pass through)                                 │
│  ├── Path validation (no escapes, allowed directories only)                 │
│  ├── Content validation (no malicious code)                                 │
│  ├── Size limits (prevent memory exhaustion)                                │
│  └── Atomic operations (rollback on failure)                                │
│                                                                             │
│  OPERATION TYPES                                                            │
│  ├── CREATE: New file with validation                                       │
│  ├── READ: Content retrieval with caching                                   │
│  ├── UPDATE: Atomic modification with backup                                │
│  ├── DELETE: Soft delete with recovery option                               │
│  └── BATCH: Multiple operations as transaction                              │
│                                                                             │
│  HOOKS (Auto-fire)                                                          │
│  ├── beforeFileOp: Validate permissions, check conflicts                    │
│  ├── afterFileOp: Log, trigger dependent updates                            │
│  └── onFileOpFail: Rollback, alert, log                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 24.2 New MCP Tools for File Operations
```python
# File Operations (10 new tools)

# Basic CRUD
prism_file_create(path, content, validate=True)      # Create with validation
prism_file_read(path, encoding="utf-8")              # Read with caching
prism_file_update(path, content, backup=True)        # Atomic update
prism_file_delete(path, soft=True)                   # Soft delete
prism_file_exists(path)                              # Check existence

# Batch Operations
prism_file_batch(operations: List[dict])             # Transaction batch
prism_file_copy(src, dst, overwrite=False)           # Copy with safety
prism_file_move(src, dst)                            # Atomic move

# Validation
prism_file_validate(path, schema=None)               # Validate content
prism_file_diff(path1, path2)                        # Compare files
```

### 24.3 Safety Constraints
```python
ALLOWED_DIRECTORIES = [
    "C:\\PRISM\\src",
    "C:\\PRISM\\data",
    "C:\\PRISM\\outputs",
    "C:\\PRISM\\scripts",
    "C:\\PRISM\\state",
    "C:\\PRISM\\docs"
]

BLOCKED_EXTENSIONS = [
    ".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs"
]

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

def validate_file_operation(path: str, operation: str) -> bool:
    """Validate file operation is safe"""
    # Check directory allowed
    if not any(path.startswith(d) for d in ALLOWED_DIRECTORIES):
        raise SecurityError(f"Path {path} not in allowed directories")
    
    # Check extension
    if any(path.endswith(ext) for ext in BLOCKED_EXTENSIONS):
        raise SecurityError(f"Extension blocked for path {path}")
    
    # Check size for writes
    if operation in ["create", "update"]:
        if os.path.getsize(path) > MAX_FILE_SIZE:
            raise SizeError(f"File exceeds {MAX_FILE_SIZE} bytes")
    
    return True
```

### 24.4 Deliverables for Session 24
```
□ Implement file operation safety layer
□ Add 10 file operation MCP tools
□ Create backup/rollback system
□ Test all operations with edge cases
□ Document allowed paths and limits
□ MCP Server version: v3.1 → v3.2 (+10 tools)
```

---

## Session 25: Batch File Generation

### 25.1 Template-Based Generation
For generating multiple files (post processors, configs):

```python
def prism_file_generate_batch(
    template: str,
    configs: List[dict],
    output_dir: str
) -> dict:
    """Generate multiple files from template"""
    results = []
    
    for config in configs:
        # Render template
        content = render_template(template, config)
        
        # Determine output path
        filename = config.get("filename", f"generated_{config['id']}")
        path = os.path.join(output_dir, filename)
        
        # Validate before write
        validation = validate_generated_content(content, config)
        if not validation.valid:
            results.append({
                "path": path,
                "status": "failed",
                "errors": validation.errors
            })
            continue
        
        # Write file
        write_file_atomic(path, content)
        results.append({
            "path": path,
            "status": "success",
            "size": len(content)
        })
    
    return {
        "total": len(configs),
        "success": sum(1 for r in results if r["status"] == "success"),
        "failed": sum(1 for r in results if r["status"] == "failed"),
        "results": results
    }
```

### 25.2 Post Processor Generator
```python
def prism_generate_post_processors(
    controllers: List[str],
    template_id: str = "standard"
) -> dict:
    """Generate post processors for multiple controllers"""
    
    templates = {
        "haas": load_template("haas_post.template"),
        "fanuc": load_template("fanuc_post.template"),
        "siemens": load_template("siemens_post.template"),
        "heidenhain": load_template("heidenhain_post.template"),
        "okuma": load_template("okuma_post.template"),
        "hurco": load_template("hurco_post.template")
    }
    
    results = []
    for controller in controllers:
        template = templates.get(controller.lower())
        if not template:
            results.append({"controller": controller, "error": "No template"})
            continue
        
        # Generate with full validation
        output = generate_post_processor(template, controller)
        results.append(output)
    
    return {"generated": results}
```

### 25.3 Deliverables for Session 25
```
□ Implement template engine
□ Create batch generation MCP tool
□ Build post processor generator
□ Test with all controller families
□ Document template format
□ MCP Server version: v3.2 → v3.3
```

---

## Session 26: Anti-Regression File Validation

### 26.1 File-Level Anti-Regression
```python
def prism_file_validate_replacement(
    old_path: str,
    new_content: str,
    metrics: List[str] = ["lines", "functions", "size"]
) -> dict:
    """Validate new content doesn't regress from old"""
    
    old_content = read_file(old_path)
    
    comparisons = {}
    regressions = []
    
    for metric in metrics:
        old_value = measure(old_content, metric)
        new_value = measure(new_content, metric)
        
        comparisons[metric] = {
            "old": old_value,
            "new": new_value,
            "change": new_value - old_value,
            "change_pct": ((new_value - old_value) / old_value * 100) if old_value else 0
        }
        
        # Flag regressions (significant decrease)
        if new_value < old_value * 0.95:  # 5% tolerance
            regressions.append({
                "metric": metric,
                "severity": "HIGH" if new_value < old_value * 0.80 else "MEDIUM",
                "old": old_value,
                "new": new_value,
                "loss_pct": round((1 - new_value/old_value) * 100, 2)
            })
    
    return {
        "valid": len(regressions) == 0,
        "comparisons": comparisons,
        "regressions": regressions,
        "recommendation": "PROCEED" if not regressions else "BLOCK - Review regressions"
    }
```

### 26.2 Deliverables for Session 26
```
□ Implement file-level anti-regression
□ Add content diff tools
□ Create regression report generator
□ Test with known regression scenarios
□ Document validation rules
□ MCP Server version: v3.3 → v3.4 (140 tools)
```

---

# PHASE 3: SCRIPT EXECUTION INTEGRATION
## Sessions 27-29 | Time: 9-12 hours | Priority: 🟡 MEDIUM

## Session 27: Safe Script Execution

### 27.1 Script Execution Architecture
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       SCRIPT EXECUTION SYSTEM                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  SECURITY LAYER                                                             │
│  ├── Whitelist: Only approved scripts can run                               │
│  ├── Sandbox: Limited file system access                                    │
│  ├── Timeout: Max execution time                                            │
│  └── Resource limits: CPU, memory caps                                      │
│                                                                             │
│  APPROVED SCRIPTS (C:\PRISM\scripts\)                                      │
│  ├── master_sync.py           - Excel→JSON→DuckDB pipeline                 │
│  ├── gsd_startup.py           - Session initialization                      │
│  ├── prism_unified_system.py  - Main orchestrator                          │
│  ├── material_validator.py    - Material data validation                    │
│  ├── monolith_indexer.py      - Code indexing                              │
│  ├── test_runner.py           - Run test suites                            │
│  └── report_generator.py      - Generate reports                           │
│                                                                             │
│  EXECUTION MODES                                                            │
│  ├── SYNC: Wait for completion, return result                               │
│  ├── ASYNC: Start and return immediately, poll for status                   │
│  └── SCHEDULED: Run at specified time/interval                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 27.2 New MCP Tools for Script Execution
```python
# Script Execution (8 new tools)

# Discovery
prism_script_list()                                   # List approved scripts
prism_script_info(script_name)                        # Get script details

# Execution
prism_script_run(script_name, args=None, timeout=300) # Run synchronously
prism_script_start(script_name, args=None)            # Start async
prism_script_status(execution_id)                     # Check async status
prism_script_stop(execution_id)                       # Stop running script

# Output
prism_script_output(execution_id)                     # Get stdout/stderr
prism_script_result(execution_id)                     # Get return value
```

### 27.3 Script Whitelist
```python
APPROVED_SCRIPTS = {
    "master_sync": {
        "path": "C:\\PRISM\\scripts\\master_sync.py",
        "description": "Excel→JSON→DuckDB→Obsidian→Drive pipeline",
        "max_timeout": 600,
        "requires_confirm": False
    },
    "gsd_startup": {
        "path": "C:\\PRISM\\scripts\\gsd_startup.py",
        "description": "Session initialization",
        "max_timeout": 60,
        "requires_confirm": False
    },
    "monolith_indexer": {
        "path": "C:\\PRISM\\scripts\\monolith_indexer.py",
        "description": "Index monolith code",
        "max_timeout": 1800,  # 30 minutes for full index
        "requires_confirm": True  # Confirm before long operation
    },
    "test_runner": {
        "path": "C:\\PRISM\\scripts\\test_runner.py",
        "description": "Run test suites",
        "max_timeout": 300,
        "requires_confirm": False
    }
}
```

### 27.4 Deliverables for Session 27
```
□ Implement script execution security layer
□ Create script whitelist system
□ Add 8 script execution MCP tools
□ Test with all approved scripts
□ Document security constraints
□ MCP Server version: v3.4 → v3.5 (+8 tools)
```

---

## Session 28: Pipeline Execution

### 28.1 Pipeline Definition
```python
PIPELINES = {
    "data_sync": {
        "description": "Full data synchronization pipeline",
        "steps": [
            {"script": "excel_export", "args": ["--source", "materials"]},
            {"script": "json_validate", "args": ["--schema", "material"]},
            {"script": "duckdb_import", "args": ["--table", "materials"]},
            {"script": "obsidian_update", "args": ["--vault", "prism"]},
            {"script": "drive_sync", "args": ["--folder", "PRISM Data"]}
        ],
        "on_failure": "rollback",
        "notifications": ["log", "state"]
    },
    "quality_check": {
        "description": "Full quality validation pipeline",
        "steps": [
            {"script": "material_validator"},
            {"script": "formula_validator"},
            {"script": "hook_coverage_check"},
            {"script": "omega_calculator"}
        ],
        "on_failure": "continue",  # Run all checks even if some fail
        "notifications": ["log", "report"]
    }
}
```

### 28.2 New MCP Tools for Pipelines
```python
# Pipeline Execution (5 new tools)
prism_pipeline_list()                                 # List available pipelines
prism_pipeline_info(pipeline_name)                    # Get pipeline details
prism_pipeline_run(pipeline_name, params=None)        # Run pipeline
prism_pipeline_status(execution_id)                   # Check status
prism_pipeline_history(pipeline_name, last_n=10)      # Recent executions
```

### 28.3 Deliverables for Session 28
```
□ Implement pipeline execution system
□ Define core pipelines
□ Add 5 pipeline MCP tools
□ Test pipeline rollback scenarios
□ Document pipeline definitions
□ MCP Server version: v3.5 → v3.6
```

---

## Session 29: Scheduled Execution

### 29.1 Scheduler System
```python
SCHEDULES = {
    "hourly_state_backup": {
        "script": "state_backup",
        "cron": "0 * * * *",  # Every hour
        "enabled": True
    },
    "daily_quality_check": {
        "pipeline": "quality_check",
        "cron": "0 6 * * *",  # 6 AM daily
        "enabled": True
    },
    "weekly_full_sync": {
        "pipeline": "data_sync",
        "cron": "0 2 * * 0",  # 2 AM Sunday
        "enabled": True
    }
}
```

### 29.2 New MCP Tools for Scheduling
```python
# Scheduling (4 new tools)
prism_schedule_list()                                 # List schedules
prism_schedule_add(name, script_or_pipeline, cron)    # Add schedule
prism_schedule_enable(name)                           # Enable schedule
prism_schedule_disable(name)                          # Disable schedule
```

### 29.3 Deliverables for Session 29
```
□ Implement scheduler system
□ Add 4 scheduling MCP tools
□ Define core schedules
□ Test schedule triggers
□ Document cron patterns
□ MCP Server version: v3.6 → v3.7 (160 tools)
```

---

# PHASE 4: FULL C:\PRISM INTEGRATION
## Sessions 30-32 | Time: 9-12 hours | Priority: 🟡 MEDIUM

## Session 30: Directory Structure Indexing

### 30.1 Full Directory Index
```python
def index_prism_directory():
    """Index entire C:\PRISM directory structure"""
    structure = {
        "root": "C:\\PRISM",
        "directories": {},
        "files": {},
        "statistics": {}
    }
    
    for root, dirs, files in os.walk("C:\\PRISM"):
        rel_path = os.path.relpath(root, "C:\\PRISM")
        
        # Skip ignored directories
        if any(ignored in root for ignored in [
            "node_modules", "__pycache__", ".git", "venv"
        ]):
            continue
        
        structure["directories"][rel_path] = {
            "subdirs": dirs,
            "file_count": len(files),
            "total_size": sum(os.path.getsize(os.path.join(root, f)) for f in files)
        }
        
        for file in files:
            file_path = os.path.join(root, file)
            structure["files"][os.path.relpath(file_path, "C:\\PRISM")] = {
                "size": os.path.getsize(file_path),
                "modified": os.path.getmtime(file_path),
                "extension": os.path.splitext(file)[1]
            }
    
    return structure
```

### 30.2 New MCP Tools for Directory Operations
```python
# Directory Operations (6 new tools)
prism_dir_list(path, recursive=False, pattern=None)   # List directory
prism_dir_tree(path, depth=3)                         # Directory tree
prism_dir_search(pattern, path=None)                  # Search files
prism_dir_stats(path)                                 # Directory statistics
prism_dir_recent(path, days=7)                        # Recently modified
prism_dir_large(path, min_size_mb=10)                 # Large files
```

### 30.3 Deliverables for Session 30
```
□ Build directory indexer
□ Add 6 directory MCP tools
□ Create directory statistics
□ Index full C:\PRISM structure
□ Document directory layout
□ MCP Server version: v3.7 → v3.8
```

---

## Session 31: Configuration Management

### 31.1 Centralized Config System
```python
CONFIG_FILES = {
    "main": "C:\\PRISM\\config\\prism.config.json",
    "mcp": "C:\\PRISM\\config\\mcp.config.json",
    "hooks": "C:\\PRISM\\config\\hooks.config.json",
    "safety": "C:\\PRISM\\config\\safety.config.json",
    "paths": "C:\\PRISM\\config\\paths.config.json"
}
```

### 31.2 New MCP Tools for Configuration
```python
# Configuration (5 new tools)
prism_config_get(config_name, key=None)               # Get config value
prism_config_set(config_name, key, value)             # Set config value
prism_config_list()                                   # List all configs
prism_config_validate(config_name)                    # Validate config
prism_config_export(format="json")                    # Export all configs
```

### 31.3 Deliverables for Session 31
```
□ Create centralized config system
□ Add 5 configuration MCP tools
□ Migrate existing configs
□ Validate all configurations
□ Document config schemas
□ MCP Server version: v3.8 → v3.9
```

---

## Session 32: Documentation Integration

### 32.1 Documentation Index
```python
def index_documentation():
    """Index all documentation files"""
    docs = []
    
    for doc_dir in ["C:\\PRISM\\docs", "C:\\PRISM\\README.md"]:
        for file in glob.glob(f"{doc_dir}/**/*.md", recursive=True):
            content = read_file(file)
            docs.append({
                "path": file,
                "title": extract_title(content),
                "sections": extract_sections(content),
                "links": extract_links(content),
                "updated": os.path.getmtime(file)
            })
    
    return {"documents": docs, "total": len(docs)}
```

### 32.2 New MCP Tools for Documentation
```python
# Documentation (4 new tools)
prism_doc_search(query)                               # Search docs
prism_doc_get(path)                                   # Get doc content
prism_doc_list(category=None)                         # List docs
prism_doc_generate(module, template="api")            # Generate docs
```

### 32.3 Deliverables for Session 32
```
□ Build documentation indexer
□ Add 4 documentation MCP tools
□ Index all docs
□ Create doc search
□ Test doc generation
□ MCP Server version: v3.9 → v4.0 (180 tools)
```

---

# VALIDATION & QUALITY GATES

## Quality Gates (Apply to ALL Phases)

### Gate 1: Context Accessibility
```
REQUIREMENT: All operations work from C: drive context
TEST: Can access C:\PRISM\* paths
ENFORCEMENT: prism_validate_gates includes this check
```

### Gate 5: Output Location
```
REQUIREMENT: All outputs saved to C:\PRISM\*
TEST: No files saved to /home/claude or temp locations
ENFORCEMENT: File operation hooks validate paths
```

### Gate 7: Anti-Regression
```
REQUIREMENT: New version ≥ old version (features, data, coverage)
TEST: prism_validate_anti_regression before ANY replacement
ENFORCEMENT: beforeFileUpdate hook blocks regressions
```

### Gate 8: Safety Score
```
REQUIREMENT: S(x) ≥ 0.70 or output BLOCKED
TEST: prism_quality_safety computes score
ENFORCEMENT: afterCalc hook blocks unsafe outputs
```

### Gate 9: Master Equation
```
REQUIREMENT: Ω(x) ≥ 0.65 or WARN, Ω(x) < 0.65 BLOCK
TEST: prism_quality_omega computes full score
ENFORCEMENT: beforeRelease hook validates
```

---

# TIMELINE SUMMARY

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                           EMERGENCY ROADMAP TIMELINE                          ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  PHASE 0: HOOK MAXIMIZATION (Current Priority)                               ║
║  ├── Session 17: Hook Wiring Completion          │ 2-3 hrs │ MCP v2.6       ║
║  ├── Session 18: Hook-Agent Maximization         │ 2-3 hrs │ MCP v2.7       ║
║  └── Session 19: Hook Performance                │ 2-3 hrs │ MCP v2.8       ║
║      SUBTOTAL: 6-9 hours │ +17 tools │ 133 total                             ║
║                                                                              ║
║  PHASE 1: CODE INTELLIGENCE                                                  ║
║  ├── Session 20: Monolith AST Indexing           │ 3-4 hrs │ Index DB       ║
║  ├── Session 21: Code Query MCP Integration      │ 3-4 hrs │ MCP v2.9       ║
║  ├── Session 22: Dependency Graph Visualization  │ 3-4 hrs │ MCP v3.0       ║
║  └── Session 23: Code Search Optimization        │ 3-4 hrs │ MCP v3.1       ║
║      SUBTOTAL: 12-16 hours │ +16 tools │ 149 total                           ║
║                                                                              ║
║  PHASE 2: FILE OPERATIONS                                                    ║
║  ├── Session 24: Server-Side File Operations     │ 3-4 hrs │ MCP v3.2       ║
║  ├── Session 25: Batch File Generation           │ 3-4 hrs │ MCP v3.3       ║
║  └── Session 26: Anti-Regression File Validation │ 3-4 hrs │ MCP v3.4       ║
║      SUBTOTAL: 9-12 hours │ +12 tools │ 161 total                            ║
║                                                                              ║
║  PHASE 3: SCRIPT EXECUTION                                                   ║
║  ├── Session 27: Safe Script Execution           │ 3-4 hrs │ MCP v3.5       ║
║  ├── Session 28: Pipeline Execution              │ 3-4 hrs │ MCP v3.6       ║
║  └── Session 29: Scheduled Execution             │ 3-4 hrs │ MCP v3.7       ║
║      SUBTOTAL: 9-12 hours │ +17 tools │ 178 total                            ║
║                                                                              ║
║  PHASE 4: FULL INTEGRATION                                                   ║
║  ├── Session 30: Directory Structure Indexing    │ 3-4 hrs │ MCP v3.8       ║
║  ├── Session 31: Configuration Management        │ 3-4 hrs │ MCP v3.9       ║
║  └── Session 32: Documentation Integration       │ 3-4 hrs │ MCP v4.0       ║
║      SUBTOTAL: 9-12 hours │ +15 tools │ 193 total                            ║
║                                                                              ║
║  ══════════════════════════════════════════════════════════════════════════  ║
║  TOTAL: 45-61 hours │ 16 sessions │ 193 MCP tools │ MCP v4.0                 ║
║  ══════════════════════════════════════════════════════════════════════════  ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

---

# EXPECTED OUTCOMES

## After Full Implementation

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| MCP Tools | 116 | 193 | +66% |
| Context for reasoning | 30-40% | 80-85% | +2.5x |
| Monolith searchable | No | Yes | ∞ |
| Scripts executable via MCP | No | Yes | ∞ |
| File ops server-side | No | Yes | ∞ |
| Hook coverage | ~60% | 100% | +67% |
| Anti-regression enforcement | Manual | Automatic | ∞ |
| Data query latency | ~500ms | <50ms | 10x faster |

## The New Development Experience

```
BEFORE:
"Load the KienzleEngine code... that's 500 lines... now find the 
calculateForce function... context at 70%... need to checkpoint..."

AFTER:
mcp.call("prism_code_extract", {"symbol": "KienzleEngine.calculateForce"})
→ Returns just the function, 47 lines, 2% context
```

```
BEFORE:
"Generate 12 post processors... okay doing HAAS first... context full
at processor #4... need new session..."

AFTER:
mcp.call("prism_file_generate_batch", {
    "template": "post_processor",
    "configs": all_12_controllers
})
→ All 12 generated server-side, 0% context cost
```

---

# CRITICAL REMINDERS

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                              ⚠️ NEVER FORGET ⚠️                               ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  1. SAFETY FIRST: S(x) ≥ 0.70 or OUTPUT IS BLOCKED                          ║
║                                                                              ║
║  2. NO PLACEHOLDERS: Every field populated or marked N/A with reason        ║
║                                                                              ║
║  3. ANTI-REGRESSION: New ≥ Old ALWAYS. Count before replacing.              ║
║                                                                              ║
║  4. MCP FIRST: Never read files when MCP tool exists                        ║
║                                                                              ║
║  5. HOOKS EVERYWHERE: Every operation that CAN trigger a hook MUST          ║
║                                                                              ║
║  6. EVIDENCE ≥ L3: No claims without content samples                        ║
║                                                                              ║
║  7. MATHEMATICAL CERTAINTY: Lives depend on correctness                     ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

---

# HOW TO USE THIS ROADMAP

1. **Start with Phase 0** - Complete hook maximization (Sessions 17-19)
2. **Then Phase 1** - Code intelligence gives biggest ROI
3. **Phases 2-4** - Build on foundation in order
4. **Each session**: Read state → Execute tasks → Update state → Checkpoint
5. **Validate constantly**: Run quality gates after every deliverable

**This roadmap transforms PRISM from "load and hope" to "query and know."**

---

*Document Version: 4.0*
*Created: 2026-02-01*
*Author: Claude + Mark*
*Priority: 🔴 EMERGENCY*
*Lives depend on mathematical certainty. No shortcuts. No placeholders.*
