# PRISM GSD Development Prompt v17.0
## Get Shit Done - What ACTUALLY Works
## Updated: 2026-02-03 (Verified)

---

## REALITY CHECK

**277 tools registered, but registries partially loaded.**

### Working Tools (USE THESE)
```
CALCULATIONS (Kienzle/Taylor physics):
- prism:calc_cutting_force ✅
- prism:calc_tool_life ✅
- prism:calc_mrr ✅
- prism:calc_surface_finish ✅
- prism:calc_power ✅
- prism:calc_deflection ✅
- prism:calc_stability ✅
- prism:calc_thermal ✅
- prism:calc_chip_load ✅
- prism:calc_engagement ✅

GSD/SESSION:
- prism:prism_gsd_core ✅
- prism:prism_gsd_quick ✅
- prism:prism_resources_summary ✅
- prism:prism_todo_update ✅
- prism:prism_state_load ✅
- prism:prism_state_save ✅

WORKFLOW:
- prism:prism_sp_brainstorm ✅ (MANDATORY)
- prism:prism_sp_plan ✅
- prism:prism_sp_execute ✅
- prism:prism_sp_review_spec ✅
- prism:prism_sp_review_quality ✅
- prism:prism_cognitive_check ✅

DATA (Partial):
- prism:skill_list ✅ (49 skills)
- prism:agent_list ✅ (9 agents)
- prism:hook_list ✅ (25 hooks)
```

### Broken Tools (DON'T USE)
```
- prism:material_search → Returns empty
- prism:material_get → Returns empty
- prism:alarm_search → f.endsWith error
- prism:alarm_decode → f.endsWith error
```

---

## SESSION START SEQUENCE

```
1. prism:prism_gsd_core
2. Desktop Commander: read C:\PRISM\state\CURRENT_STATE.json
3. prism:prism_todo_update with current_focus
```

---

## 4 LAWS (Simplified)

| # | Law | Check |
|---|-----|-------|
| 1 | S(x) ≥ 0.70 | Safety gate - HARD BLOCK |
| 2 | No placeholders | Complete or don't start |
| 3 | New ≥ Old | Anti-regression |
| 4 | Use working tools | Don't call broken ones |

---

## MASTER EQUATION

```
Ω(x) = 0.25R + 0.20C + 0.15P + 0.30S + 0.10L

R = Reasoning (0-1)
C = Code quality (0-1)
P = Process adherence (0-1)
S = Safety (≥0.70 HARD BLOCK)
L = Learning (0-1)

Ω ≥ 0.70 = Release quality
```

---

## BUFFER MANAGEMENT

| Zone | Calls | Action |
|------|-------|--------|
| 🟢 | 0-8 | Normal |
| 🟡 | 9-14 | Plan checkpoint |
| 🔴 | 15-18 | IMMEDIATE checkpoint |
| ⚫ | 19+ | STOP |

**prism_todo_update every 5-8 calls**

---

## WORKFLOW

```
BRAINSTORM → PLAN → EXECUTE → REVIEW

prism_sp_brainstorm is MANDATORY before implementation
```

---

## KEY FILES

| File | Purpose |
|------|---------|
| C:\PRISM\state\CURRENT_STATE.json | Session state |
| C:\PRISM\PROJECT_INSTRUCTIONS.md | Project setup |
| C:\PRISM\mcp-server\src\index.ts | Tool registration |
| C:\PRISM\mcp-server\src\registries\ | Data registries (BROKEN) |

---

## COMPACTION RECOVERY

```
view /mnt/transcripts/[latest].txt
```

Read incrementally - transcripts can be massive.

---

## FIX PRIORITIES

1. **Registry Loading**: C:\PRISM\mcp-server\src\registries\index.ts
   - Materials not loading (1,047 should load)
   - Alarms have bug (f.endsWith error)
   - Skills partial (49/153)
   - Agents partial (9/69)
   - Hooks partial (25/7114)

2. **Ralph Loop Tools**: Created but not registered in index.ts
   - C:\PRISM\mcp-server\src\tools\ralphLoopTools.ts exists
   - Need to add to tool registration

---

## PHYSICS EQUATIONS (Use These)

**Kienzle Cutting Force:**
```
Fc = kc1.1 × h^(-mc) × b × corrections
```

**Taylor Tool Life:**
```
V × T^n = C
T = (C/V)^(1/n)
```

**Surface Roughness:**
```
Ra = f² / (32 × r)
```

**MRR:**
```
Q = ap × ae × Vf
```

---

## MARK'S SYSTEM

- Python: `py` or full path
- PC: DIGITALSTORM-PC
- State: C:\PRISM\state\

