# PRISM MCP Developer Intelligence Server - Complete Specification v1.0

> **File Location**: `/mnt/skills/user/prism-mcp-intelligence/SKILL.md`
> 
> **Purpose**: Complete specification for building the PRISM MCP Developer Intelligence Server. This document contains all tool definitions, engine specifications, algorithms, formulas, and implementation details. Reference this file instead of regenerating specifications.
>
> **Last Updated**: 2026-02-04

---

# Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Tier 1: Foundation Tools](#tier-1-foundation-tools)
4. [Tier 2: Developer Workflow Tools](#tier-2-developer-workflow-tools)
5. [Tier 3: Advanced Tools](#tier-3-advanced-tools)
6. [Tier 4: Intelligence Engines](#tier-4-intelligence-engines)
7. [Tier 5: Meta-Cognitive Engines](#tier-5-meta-cognitive-engines)
8. [The Omega Equation](#the-omega-equation)
9. [Implementation Roadmap](#implementation-roadmap)
10. [Dependencies](#dependencies)
11. [Server Architecture](#server-architecture)

---

# Overview

The PRISM MCP Developer Intelligence Server transforms Claude from a chatbot into an agentic development partner with capabilities far beyond conventional coding assistants. It combines:

- **Operational Tools**: Background tasks, checkpoints, git, testing, search
- **Intelligence Engines**: Causal inference, entropy analysis, fault localization
- **Meta-Cognitive Systems**: Self-improvement, intention inference, pattern evolution
- **Quality Measurement**: The Omega (Ω) equation for holistic code quality

**Design Principles**:
1. Structured output always (JSON, never raw CLI text)
2. Async-first (long operations run in background)
3. Safe by default (destructive operations require confirmation)
4. Self-improving (learns from outcomes)
5. Causal reasoning (understand WHY, not just WHAT)

---

# Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        PRISM MCP Intelligence Server                         │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 5: META-COGNITIVE                                                     │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐                │
│  │ Self-Improvement│ │Intention Infer  │ │ Pattern Evolve  │                │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘                │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 4: INTELLIGENCE ENGINES                                               │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │ Causal   │ │ Entropy  │ │  Fault   │ │Cognitive │ │Adversarial│          │
│  │ Inference│ │ Thermo   │ │  Local   │ │  Load    │ │ Robustness│          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 3: ADVANCED TOOLS                                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │ Refactor │ │ Sandbox  │ │ Context  │ │   Docs   │ │  Visual  │          │
│  │ Multi-   │ │ Execute  │ │ Compress │ │ Generate │ │  Test    │          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 2: DEVELOPER WORKFLOW                                                 │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │   Git    │ │  Test    │ │  Code    │ │  Lint/   │ │  Diff/   │          │
│  │   Ops    │ │  Runner  │ │  Search  │ │  Build   │ │  Patch   │          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 1: FOUNDATION                                                         │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │Background│ │Checkpoint│ │  Impact  │ │ Semantic │ │ Context  │          │
│  │  Tasks   │ │ Rollback │ │ Analysis │ │  Search  │ │  Sync    │          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────────────────────┤
│  INFRASTRUCTURE                                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │  State   │ │  Cache   │ │ Embeddings│ │   AST    │ │  Metrics │          │
│  │ Manager  │ │  Layer   │ │  Store   │ │  Parser  │ │ Collector│          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# Tier 1: Foundation Tools

These enable everything else. Implement first.

## 1.1 Background Task Orchestrator

Async execution for long-running operations.

```typescript
interface TaskSpawnParams {
  command: string;              // Shell command to execute
  label: string;                // Human-readable identifier
  working_dir?: string;         // Override default working directory
  timeout_minutes?: number;     // Default: 10
  env?: Record<string, string>; // Environment variables
}

interface TaskSpawnResult {
  task_id: string;
  status: "running";
  started_at: string;           // ISO timestamp
  pid: number;
}

interface TaskStatusParams {
  task_id: string;
}

interface TaskStatusResult {
  task_id: string;
  label: string;
  status: "running" | "completed" | "failed" | "timeout" | "killed";
  exit_code?: number;
  output: string;               // stdout + stderr combined
  output_lines: number;
  duration_ms: number;
  started_at: string;
  completed_at?: string;
  memory_peak_mb?: number;
}

interface TaskStreamParams {
  task_id: string;
  since_line?: number;          // Get lines after this
}

interface TaskStreamResult {
  new_lines: string[];
  total_lines: number;
  completed: boolean;
  exit_code?: number;
}

interface TaskKillParams {
  task_id: string;
  signal?: "SIGTERM" | "SIGKILL";  // Default: SIGTERM
}

interface TaskKillResult {
  killed: boolean;
  final_output: string;
  exit_code: number;
}

interface TaskListParams {
  status_filter?: "running" | "completed" | "failed";
  limit?: number;               // Default: 20
}

interface TaskListResult {
  tasks: Array<{
    task_id: string;
    label: string;
    status: string;
    started_at: string;
    duration_ms: number;
  }>;
  running_count: number;
  total_count: number;
}
```

**Implementation Notes**:
- Use `execa` for process spawning
- Store task state in memory (Map<task_id, TaskState>)
- Stream output to temp files, read incrementally
- Use `tree-kill` for killing process trees
- Implement cleanup on server shutdown
- Max concurrent tasks: configurable, default 10

---

## 1.2 Checkpoint & Rollback

Ephemeral save states for fearless experimentation.

```typescript
interface CheckpointCreateParams {
  label: string;
  paths?: string[];             // Specific paths, default: entire workspace
  include_untracked?: boolean;  // Default: true
  include_gitignored?: boolean; // Default: false
}

interface CheckpointCreateResult {
  checkpoint_id: string;        // Format: chk_{timestamp}_{hash}
  label: string;
  created_at: string;
  files_captured: number;
  size_bytes: number;
  git_state: {
    branch: string;
    commit: string;
    dirty: boolean;
    staged_files: string[];
  };
}

interface CheckpointListParams {
  limit?: number;               // Default: 20
}

interface CheckpointListResult {
  checkpoints: Array<{
    checkpoint_id: string;
    label: string;
    created_at: string;
    files_captured: number;
    size_bytes: number;
  }>;
  total_count: number;
  total_size_bytes: number;
}

interface CheckpointDiffParams {
  checkpoint_id: string;
  paths?: string[];             // Filter to specific paths
}

interface CheckpointDiffResult {
  files_added: string[];
  files_modified: string[];
  files_deleted: string[];
  diff_summary: string;         // Unified diff format
  total_changes: number;
  insertions: number;
  deletions: number;
}

interface CheckpointRestoreParams {
  checkpoint_id: string;
  paths?: string[];             // Partial restore if specified
  dry_run?: boolean;            // Default: false
}

interface CheckpointRestoreResult {
  restored_files: string[];
  skipped_files: string[];
  conflicts?: Array<{
    file: string;
    reason: string;
  }>;
  dry_run: boolean;
}

interface CheckpointDeleteParams {
  checkpoint_id: string;
}

interface CheckpointDeleteResult {
  deleted: boolean;
  freed_bytes: number;
}
```

**Implementation Notes**:
- Store in `.mcp-checkpoints/` (gitignored)
- Use tar for efficient compression
- Capture git state as metadata JSON
- Implement max checkpoint limit with LRU cleanup
- Store file hashes for fast diff comparison

---

## 1.3 Impact Analysis

Know what breaks before you change it.

```typescript
interface CodeImpactParams {
  file: string;
  line_range?: [number, number];
  symbol?: string;              // Specific function/class
}

interface CodeImpactResult {
  target: {
    file: string;
    lines?: [number, number];
    symbol?: string;
    type?: "function" | "class" | "variable" | "type";
  };
  direct_importers: Array<{
    file: string;
    import_line: number;
    import_type: "named" | "default" | "namespace" | "side-effect";
  }>;
  transitive_dependents: number;
  dependency_depth: number;     // Max depth in dependency tree
  test_coverage: Array<{
    test_file: string;
    test_names: string[];
    coverage_type: "direct" | "indirect";
    last_run?: string;
    last_result?: "pass" | "fail";
  }>;
  exports_affected: string[];
  breaking_risk: "critical" | "high" | "medium" | "low";
  risk_reasons: string[];
  suggested_actions: string[];
}

interface ImpactTestMapParams {
  file: string;
  function_name?: string;
}

interface ImpactTestMapResult {
  tests: Array<{
    test_file: string;
    test_name: string;
    coverage_lines: number[];
    execution_path: string[];   // Call stack to reach this code
    last_duration_ms?: number;
  }>;
  uncovered_lines: number[];
  coverage_percent: number;
  suggested_tests: Array<{
    description: string;
    test_type: "unit" | "integration" | "e2e";
    priority: "high" | "medium" | "low";
  }>;
}

interface ImpactDependencyGraphParams {
  file: string;
  depth?: number;               // Default: 3
  direction?: "importers" | "imports" | "both";  // Default: both
}

interface ImpactDependencyGraphResult {
  nodes: Array<{
    file: string;
    depth: number;
    type: "source" | "test" | "config" | "asset";
    size_lines: number;
  }>;
  edges: Array<{
    from: string;
    to: string;
    import_type: "static" | "dynamic" | "type-only";
    symbols?: string[];
  }>;
  cycles?: string[][];          // Circular dependency chains
  orphans?: string[];           // Files with no importers
  hubs?: Array<{                // Files with many connections
    file: string;
    connections: number;
  }>;
}
```

**Implementation Notes**:
- Build import graph on first call, cache and update incrementally
- Use tree-sitter for language-aware parsing
- Integrate with test coverage data if available
- Risk scoring formula:
  ```
  risk = (direct_importers * 2 + transitive_dependents * 0.5) * 
         (1 + exports_affected.length * 0.3) *
         (test_coverage.length > 0 ? 0.5 : 1.5)
  ```

---

## 1.4 Semantic Code Search

Find code by meaning, not keywords.

```typescript
interface SemanticIndexBuildParams {
  paths?: string[];             // Default: entire workspace
  force_rebuild?: boolean;      // Ignore existing index
  chunk_strategy?: "function" | "class" | "file" | "smart";  // Default: smart
}

interface SemanticIndexBuildResult {
  files_indexed: number;
  chunks_created: number;
  duration_ms: number;
  index_size_mb: number;
  languages_detected: string[];
}

interface SemanticSearchParams {
  query: string;                // Natural language query
  top_k?: number;               // Default: 10
  file_pattern?: string;        // Filter to specific files
  min_score?: number;           // Similarity threshold 0-1
  include_context?: boolean;    // Include surrounding code
}

interface SemanticSearchResult {
  results: Array<{
    file: string;
    start_line: number;
    end_line: number;
    code: string;
    score: number;              // Similarity score 0-1
    summary: string;            // Auto-generated description
    symbols: string[];          // Functions/classes in this chunk
    context?: {
      before: string;
      after: string;
    };
  }>;
  query_tokens: number;
  search_time_ms: number;
}

interface SemanticSimilarParams {
  file: string;
  start_line: number;
  end_line: number;
  top_k?: number;
}

interface SemanticSimilarResult {
  reference: {
    file: string;
    lines: [number, number];
    code: string;
  };
  similar: Array<{
    file: string;
    start_line: number;
    end_line: number;
    code: string;
    score: number;
    relationship: "duplicate" | "variant" | "related";
  }>;
}
```

**Implementation Notes**:
- Embedding model: `nomic-embed-text` via Ollama or `@xenova/transformers`
- Vector store: LanceDB (embedded, no server) or ChromaDB
- Chunk by AST boundaries (functions, classes), not arbitrary lines
- Store metadata: file, lines, language, symbols, last_modified
- Incremental updates: hash files, re-index only on change
- Embedding dimension: 768 (nomic) or 384 (minilm)

---

## 1.5 Live Context Sync

Stay synchronized with external changes.

```typescript
interface ContextWatchStartParams {
  paths: string[];
  events?: ("modify" | "create" | "delete" | "rename")[];
  ignore_patterns?: string[];   // Default: node_modules, .git, etc.
  debounce_ms?: number;         // Default: 100
}

interface ContextWatchStartResult {
  watcher_id: string;
  watching: string[];
  started_at: string;
  ignore_patterns: string[];
}

interface ContextWatchStopParams {
  watcher_id: string;
}

interface ContextWatchStopResult {
  stopped: boolean;
  events_captured: number;
  duration_ms: number;
}

interface ContextChangesParams {
  watcher_id: string;
  since?: string;               // ISO timestamp
  summarize?: boolean;          // Include AI-generated summaries
  limit?: number;               // Default: 100
}

interface ContextChangesResult {
  events: Array<{
    type: "modify" | "create" | "delete" | "rename";
    path: string;
    timestamp: string;
    size_bytes?: number;
    summary?: string;           // "Added function handleError()"
    diff_snippet?: string;      // For modifications
  }>;
  files_affected: number;
  context_stale: boolean;       // True if significant changes
  oldest_event: string;
  newest_event: string;
}

interface ContextSnapshotParams {
  watcher_id: string;
  include_hashes?: boolean;
}

interface ContextSnapshotResult {
  files: Array<{
    path: string;
    size_bytes: number;
    modified_at: string;
    hash?: string;
  }>;
  total_files: number;
  total_size_bytes: number;
  last_change: string;
}
```

**Implementation Notes**:
- Use `chokidar` for cross-platform file watching
- Ring buffer for events (configurable size, default 1000)
- Auto-cleanup watchers after inactivity (default 30 minutes)
- Debounce rapid changes
- For summaries, diff file and generate brief description

---

# Tier 2: Developer Workflow Tools

Standard development operations with structured output.

## 2.1 Git Operations

```typescript
interface GitStatusResult {
  branch: string;
  upstream?: string;
  staged: Array<{ file: string; status: "added" | "modified" | "deleted" | "renamed" }>;
  unstaged: Array<{ file: string; status: "modified" | "deleted" }>;
  untracked: string[];
  ahead: number;
  behind: number;
  stash_count: number;
  merge_in_progress: boolean;
  rebase_in_progress: boolean;
}

interface GitDiffParams {
  file?: string;
  staged?: boolean;
  commit_range?: string;        // "HEAD~3..HEAD"
  context_lines?: number;       // Default: 3
  stat_only?: boolean;
}

interface GitDiffResult {
  diff: string;
  files: Array<{
    file: string;
    status: "added" | "modified" | "deleted" | "renamed";
    insertions: number;
    deletions: number;
    binary: boolean;
  }>;
  total_insertions: number;
  total_deletions: number;
  total_files: number;
}

interface GitLogParams {
  count?: number;               // Default: 10
  author?: string;
  since?: string;
  until?: string;
  path?: string;
  grep?: string;
  format?: "full" | "oneline";
}

interface GitLogResult {
  commits: Array<{
    hash: string;
    short_hash: string;
    author: string;
    author_email: string;
    date: string;
    message: string;
    body?: string;
    files_changed: number;
    insertions: number;
    deletions: number;
  }>;
  total_commits: number;
}

interface GitBlameParams {
  file: string;
  start_line?: number;
  end_line?: number;
}

interface GitBlameResult {
  lines: Array<{
    line_number: number;
    commit: string;
    author: string;
    date: string;
    content: string;
    age_days: number;
  }>;
  unique_authors: number;
  oldest_line: { line: number; date: string };
  newest_line: { line: number; date: string };
}

interface GitCommitParams {
  message: string;
  files?: string[];             // Specific files, or all if empty
  all?: boolean;                // Stage all modified
  amend?: boolean;
  no_verify?: boolean;          // Skip hooks
}

interface GitCommitResult {
  hash: string;
  short_hash: string;
  message: string;
  files_committed: string[];
  insertions: number;
  deletions: number;
}
// Annotations: { destructiveHint: true, idempotentHint: false }

interface GitBranchParams {
  action: "list" | "create" | "switch" | "delete" | "rename";
  name?: string;
  new_name?: string;            // For rename
  force?: boolean;
  track?: string;               // Remote branch to track
}

interface GitBranchResult {
  action: string;
  branches?: Array<{
    name: string;
    current: boolean;
    tracking?: string;
    ahead?: number;
    behind?: number;
    last_commit: string;
  }>;
  result?: string;
}

interface GitStashParams {
  action: "push" | "pop" | "apply" | "list" | "drop" | "clear" | "show";
  message?: string;
  index?: number;
  include_untracked?: boolean;
}

interface GitStashResult {
  action: string;
  stashes?: Array<{
    index: number;
    message: string;
    date: string;
    files: number;
  }>;
  result?: string;
  files_affected?: string[];
}

interface GitResetParams {
  mode: "soft" | "mixed" | "hard";
  target?: string;              // Commit ref, default: HEAD
  files?: string[];             // For file-level reset
}

interface GitResetResult {
  reset_to: string;
  mode: string;
  files_affected: string[];
  warning?: string;
}
// Annotations: { destructiveHint: true }
```

**Implementation Notes**:
- Use `simple-git` npm package
- Always return structured data
- Include safety warnings for destructive operations

---

## 2.2 Test Runner

```typescript
interface TestRunParams {
  pattern?: string;             // Test name pattern
  file?: string;                // Specific test file
  coverage?: boolean;
  watch?: boolean;              // Returns task_id for background
  update_snapshots?: boolean;
  bail?: boolean;               // Stop on first failure
  timeout_ms?: number;
  grep?: string;                // Filter by test name regex
}

interface TestRunResult {
  passed: number;
  failed: number;
  skipped: number;
  pending: number;
  duration_ms: number;
  suites: number;
  failures: Array<{
    suite: string;
    test: string;
    file: string;
    line: number;
    error: string;
    expected?: string;
    actual?: string;
    diff?: string;
    stack?: string;
  }>;
  coverage_summary?: {
    lines: { total: number; covered: number; percent: number };
    branches: { total: number; covered: number; percent: number };
    functions: { total: number; covered: number; percent: number };
  };
  task_id?: string;             // If watch mode
}

interface TestRunAffectedParams {
  since?: string;               // Git ref, default: HEAD~1
  include_dependents?: boolean; // Test files that import changed files
}

interface TestRunAffectedResult extends TestRunResult {
  affected_files: string[];
  tests_selected: number;
  tests_skipped: number;
  selection_reason: string;
}

interface TestCoverageParams {
  file?: string;
  threshold?: number;           // Fail if below this percent
}

interface TestCoverageResult {
  summary: {
    lines: { total: number; covered: number; percent: number };
    branches: { total: number; covered: number; percent: number };
    functions: { total: number; covered: number; percent: number };
    statements: { total: number; covered: number; percent: number };
  };
  meets_threshold: boolean;
  threshold?: number;
  files: Array<{
    path: string;
    lines: { total: number; covered: number; percent: number };
    uncovered_lines: number[];
    functions_uncovered: string[];
  }>;
}

interface TestDebugParams {
  test_name: string;
  file: string;
}

interface TestDebugResult {
  test_code: string;
  setup_code: string;           // beforeEach, beforeAll, etc.
  teardown_code: string;
  last_run?: {
    passed: boolean;
    error?: string;
    duration_ms: number;
    timestamp: string;
  };
  related_source_files: string[];
  suggested_breakpoints: Array<{
    file: string;
    line: number;
    reason: string;
  }>;
  similar_passing_tests: string[];
}
```

**Implementation Notes**:
- Auto-detect framework: jest, vitest, mocha, pytest, cargo test
- Parse JSON reporter output
- For affected tests, combine git diff with import graph

---

## 2.3 Code Search

```typescript
interface CodeSearchParams {
  query: string;
  regex?: boolean;
  file_pattern?: string;        // "*.ts", "src/**/*.js"
  ignore_case?: boolean;
  whole_word?: boolean;
  context_lines?: number;       // Default: 2
  max_results?: number;         // Default: 100
  include_hidden?: boolean;     // Default: false
}

interface CodeSearchResult {
  matches: Array<{
    file: string;
    line: number;
    column: number;
    content: string;
    context_before: string[];
    context_after: string[];
  }>;
  total_matches: number;
  files_matched: number;
  files_searched: number;
  truncated: boolean;
  search_time_ms: number;
}

interface CodeSearchReplaceParams {
  search: string;
  replace: string;
  regex?: boolean;
  file_pattern?: string;
  dry_run?: boolean;            // Default: true
  confirm_each?: boolean;
}

interface CodeSearchReplaceResult {
  replacements: Array<{
    file: string;
    line: number;
    before: string;
    after: string;
  }>;
  files_affected: number;
  total_replacements: number;
  applied: boolean;
}
// Annotations: { destructiveHint: true } when dry_run=false

interface CodeSymbolsParams {
  name?: string;
  type?: "function" | "class" | "interface" | "variable" | "type" | "enum" | "constant";
  file_pattern?: string;
  exported_only?: boolean;
}

interface CodeSymbolsResult {
  symbols: Array<{
    name: string;
    type: string;
    file: string;
    line: number;
    end_line: number;
    signature?: string;
    exported: boolean;
    async?: boolean;
    jsdoc?: string;
    parameters?: Array<{ name: string; type?: string }>;
    return_type?: string;
  }>;
  total: number;
}

interface CodeReferencesParams {
  symbol: string;
  file?: string;                // Scope to specific file's symbol
  include_definition?: boolean;
}

interface CodeReferencesResult {
  symbol: string;
  definition?: {
    file: string;
    line: number;
    code: string;
  };
  references: Array<{
    file: string;
    line: number;
    column: number;
    context: string;
    type: "read" | "write" | "call" | "import" | "type";
  }>;
  total: number;
}
```

**Implementation Notes**:
- Use ripgrep for text search
- Use tree-sitter for symbol extraction
- Respect .gitignore by default

---

## 2.4 Lint & Build

```typescript
interface LintRunParams {
  files?: string[];
  fix?: boolean;
  rules?: string[];
  max_warnings?: number;
}

interface LintRunResult {
  errors: Array<{
    file: string;
    line: number;
    column: number;
    end_line?: number;
    end_column?: number;
    rule: string;
    message: string;
    severity: "error" | "warning" | "info";
    fixable: boolean;
    suggestion?: string;
    url?: string;               // Rule documentation
  }>;
  error_count: number;
  warning_count: number;
  fixable_count: number;
  fixed_count?: number;
  files_checked: number;
}

interface LintFixParams {
  files?: string[];
  dry_run?: boolean;
}

interface LintFixResult {
  fixed: Array<{
    file: string;
    rule: string;
    line: number;
    description: string;
  }>;
  unfixable: Array<{
    file: string;
    rule: string;
    message: string;
  }>;
  files_modified: string[];
}
// Annotations: { destructiveHint: true }

interface BuildCheckParams {
  incremental?: boolean;
  project?: string;             // tsconfig path
}

interface BuildCheckResult {
  success: boolean;
  errors: Array<{
    file: string;
    line: number;
    column: number;
    code: string;               // TS2322, etc.
    message: string;
    category: "error" | "warning" | "suggestion";
  }>;
  warnings: number;
  duration_ms: number;
}

interface BuildRunParams {
  clean?: boolean;
  production?: boolean;
  watch?: boolean;
}

interface BuildRunResult {
  success: boolean;
  errors: Array<{ file: string; line: number; message: string }>;
  output_dir: string;
  output_files: string[];
  bundle_size_bytes?: number;
  duration_ms: number;
  task_id?: string;             // If watch mode
}
```

---

## 2.5 Diff & Patch

```typescript
interface DiffGenerateParams {
  file?: string;
  staged?: boolean;
  format?: "unified" | "json" | "side-by-side";
}

interface DiffGenerateResult {
  patch: string;
  hunks: Array<{
    file: string;
    old_start: number;
    old_lines: number;
    new_start: number;
    new_lines: number;
    header: string;
    content: string;
    changes: Array<{
      type: "add" | "delete" | "context";
      line_number: number;
      content: string;
    }>;
  }>;
  files_affected: number;
  insertions: number;
  deletions: number;
}

interface DiffApplyParams {
  patch: string;
  reverse?: boolean;
  dry_run?: boolean;
  fuzz?: number;                // Allow fuzzy matching
}

interface DiffApplyResult {
  applied: boolean;
  files_modified: string[];
  hunks_applied: number;
  hunks_failed: number;
  errors?: Array<{
    file: string;
    hunk: number;
    reason: string;
  }>;
}
// Annotations: { destructiveHint: true }

interface DiffPreviewParams {
  file: string;
  changes: Array<{
    line: number;
    action: "insert" | "delete" | "replace";
    content?: string;
  }>;
}

interface DiffPreviewResult {
  before: string;
  after: string;
  diff: string;
  valid: boolean;
  errors?: string[];
  affected_lines: number;
}

interface DiffThreeWayParams {
  base: string;                 // Common ancestor content
  ours: string;                 // Our version
  theirs: string;               // Their version
}

interface DiffThreeWayResult {
  merged: string;
  conflicts: Array<{
    start_line: number;
    end_line: number;
    ours: string;
    theirs: string;
    base: string;
  }>;
  auto_resolved: number;
  manual_required: number;
  clean: boolean;
}
```

---

# Tier 3: Advanced Tools

Specialized capabilities for complex workflows.

## 3.1 Multi-File Refactor

```typescript
interface RefactorRenameParams {
  symbol: string;
  new_name: string;
  file?: string;                // Scope to specific file's symbol
  dry_run?: boolean;
}

interface RefactorRenameResult {
  occurrences: Array<{
    file: string;
    line: number;
    column: number;
    before: string;
    after: string;
    type: "definition" | "reference" | "import" | "export";
  }>;
  files_modified: string[];
  total_replacements: number;
  applied: boolean;
  warnings?: string[];
}
// Annotations: { destructiveHint: true }

interface RefactorExtractFunctionParams {
  file: string;
  start_line: number;
  end_line: number;
  function_name: string;
  parameters?: Array<{ name: string; type?: string }>;
}

interface RefactorExtractFunctionResult {
  extracted_function: string;
  call_site: string;
  file_diff: string;
  inserted_at_line: number;
  parameters_inferred: Array<{ name: string; type: string; reason: string }>;
  return_type_inferred?: string;
  warnings?: string[];          // "Variable 'x' is modified, consider returning it"
}
// Annotations: { destructiveHint: true }

interface RefactorMoveParams {
  symbol: string;
  from_file: string;
  to_file: string;
  update_imports?: boolean;     // Default: true
}

interface RefactorMoveResult {
  moved: boolean;
  symbol_code: string;
  imports_updated: Array<{
    file: string;
    before: string;
    after: string;
  }>;
  exports_updated: Array<{
    file: string;
    change: string;
  }>;
  files_modified: string[];
  warnings?: string[];
}
// Annotations: { destructiveHint: true }

interface RefactorInlineParams {
  symbol: string;
  file: string;
  line: number;
}

interface RefactorInlineResult {
  inlined_at: Array<{
    file: string;
    line: number;
    before: string;
    after: string;
  }>;
  definition_removed: boolean;
  files_modified: string[];
  warnings?: string[];
}
// Annotations: { destructiveHint: true }
```

---

## 3.2 Execution Sandbox

```typescript
interface SandboxRunParams {
  code: string;
  language?: "javascript" | "typescript" | "python";
  timeout_ms?: number;          // Default: 5000
  memory_limit_mb?: number;     // Default: 128
  imports?: string[];           // Modules to make available
  env?: Record<string, string>;
}

interface SandboxRunResult {
  stdout: string;
  stderr: string;
  return_value?: any;
  return_type?: string;
  exit_code: number;
  runtime_ms: number;
  memory_used_mb: number;
  timed_out: boolean;
}

interface SandboxEvalParams {
  expression: string;
  file_context?: string;        // File to import before eval
  variables?: Record<string, any>;
  timeout_ms?: number;
}

interface SandboxEvalResult {
  result: any;
  type: string;
  stringified: string;
  runtime_ms: number;
  error?: string;
}

interface SandboxReplParams {
  language: "javascript" | "typescript" | "python";
  preload_files?: string[];
}

interface SandboxReplResult {
  session_id: string;
  ready: boolean;
  preloaded: string[];
}

interface SandboxReplExecParams {
  session_id: string;
  code: string;
}

interface SandboxReplExecResult {
  result: any;
  stdout: string;
  stderr: string;
  variables_changed: string[];
}

interface SandboxReplEndParams {
  session_id: string;
}
```

**Implementation Notes**:
- Use vm2 or isolated-vm for JavaScript
- Use subprocess with resource limits for Python
- Timeout and memory limits are critical

---

## 3.3 Context Compression

```typescript
interface ContextSummarizeParams {
  focus?: "decisions" | "code_changes" | "todos" | "all";
  since?: string;               // Timestamp or "session_start"
  format?: "markdown" | "json" | "handoff";
}

interface ContextSummarizeResult {
  summary: string;
  key_decisions: Array<{
    decision: string;
    reasoning: string;
    timestamp: string;
    confidence: "high" | "medium" | "low";
  }>;
  files_modified: Array<{
    file: string;
    change_type: "created" | "modified" | "deleted";
    summary: string;
    lines_changed: number;
  }>;
  open_questions: string[];
  blockers: string[];
  next_actions: Array<{
    action: string;
    priority: "high" | "medium" | "low";
    estimated_effort?: string;
  }>;
  metadata: {
    turns: number;
    time_span_minutes: number;
    tools_used: Array<{ tool: string; count: number }>;
    tokens_used?: number;
  };
}

interface ContextExportParams {
  include_file_contents?: boolean;
  include_checkpoints?: boolean;
  compress?: boolean;
}

interface ContextExportResult {
  export_data: string;          // JSON blob (optionally gzipped + base64)
  format_version: string;
  size_bytes: number;
  files_included: number;
  checkpoints_included: number;
  checksum: string;
  created_at: string;
}

interface ContextImportParams {
  export_data: string;
  verify_checksum?: boolean;
  merge_strategy?: "replace" | "merge" | "skip_existing";
}

interface ContextImportResult {
  imported: boolean;
  files_restored: number;
  checkpoints_restored: number;
  state_restored: boolean;
  conflicts?: Array<{
    type: string;
    description: string;
    resolution: string;
  }>;
  warnings?: string[];
}
```

---

## 3.4 Documentation Generator

```typescript
interface DocsGenerateParams {
  file: string;
  format?: "markdown" | "jsdoc" | "docstring" | "tsdoc";
  include_examples?: boolean;
  include_types?: boolean;
  overwrite?: boolean;
}

interface DocsGenerateResult {
  documentation: string;
  symbols_documented: number;
  coverage: {
    documented: number;
    total: number;
    percent: number;
  };
  inserted_at?: Array<{
    line: number;
    symbol: string;
  }>;
  warnings?: string[];
}

interface DocsReadmeParams {
  sections?: ("overview" | "installation" | "usage" | "api" | "contributing" | "license")[];
  update_existing?: boolean;
  analyze_codebase?: boolean;
}

interface DocsReadmeResult {
  readme: string;
  sections_generated: string[];
  merged_with_existing: boolean;
  detected_info: {
    package_name?: string;
    description?: string;
    main_language?: string;
    frameworks?: string[];
    license?: string;
  };
}

interface DocsApiParams {
  entry_points: string[];
  format?: "markdown" | "openapi" | "html" | "typedoc";
  include_private?: boolean;
  group_by?: "file" | "category" | "tag";
}

interface DocsApiResult {
  documentation: string;
  endpoints?: number;
  symbols?: number;
  categories?: string[];
  output_file?: string;
}
```

---

## 3.5 Visual Testing

```typescript
interface ScreenshotCaptureParams {
  url: string;
  selector?: string;
  viewport?: { width: number; height: number };
  full_page?: boolean;
  delay_ms?: number;
  device?: string;              // "iPhone 12", "iPad", etc.
}

interface ScreenshotCaptureResult {
  image_base64: string;
  dimensions: { width: number; height: number };
  file_path?: string;
  capture_time_ms: number;
}

interface ScreenshotDiffParams {
  baseline: string;             // Path or base64
  current: string;
  threshold?: number;           // 0-1, default 0.1
  ignore_regions?: Array<{ x: number; y: number; width: number; height: number }>;
}

interface ScreenshotDiffResult {
  match: boolean;
  diff_percent: number;
  diff_pixels: number;
  total_pixels: number;
  diff_regions: Array<{
    x: number;
    y: number;
    width: number;
    height: number;
    diff_percent: number;
  }>;
  diff_image_base64?: string;
}

interface VisualRegressionRunParams {
  config_file?: string;
  update_baselines?: boolean;
  filter?: string;
}

interface VisualRegressionRunResult {
  passed: number;
  failed: number;
  new_screenshots: number;
  updated: number;
  failures: Array<{
    name: string;
    diff_percent: number;
    baseline_path: string;
    current_path: string;
    diff_path?: string;
  }>;
}
```

---

## 3.6 External Knowledge

```typescript
interface DocsFetchParams {
  package: string;
  version?: string;
  section?: string;
  language?: string;
}

interface DocsFetchResult {
  documentation: string;
  package: string;
  version: string;
  sections_available: string[];
  source_url: string;
  last_updated?: string;
  cached: boolean;
}

interface NpmInfoParams {
  package: string;
}

interface NpmInfoResult {
  name: string;
  version: string;
  description: string;
  repository?: string;
  homepage?: string;
  license?: string;
  weekly_downloads: number;
  dependencies: number;
  dev_dependencies: number;
  last_publish: string;
  typescript: boolean;
  types_package?: string;
  maintainers: number;
  alternatives?: string[];
  security_advisories?: Array<{
    severity: string;
    title: string;
    url: string;
  }>;
}

interface StackOverflowSearchParams {
  query: string;
  tags?: string[];
  top_k?: number;
  sort?: "relevance" | "votes" | "newest";
}

interface StackOverflowSearchResult {
  results: Array<{
    question: string;
    question_url: string;
    score: number;
    answer_count: number;
    accepted_answer?: {
      text: string;
      score: number;
      code_blocks: string[];
    };
    tags: string[];
    asked_date: string;
  }>;
}
```

---

# Tier 4: Intelligence Engines

These provide reasoning capabilities beyond conventional tools.

## 4.1 Causal Inference Engine

Understand WHY things break, not just WHAT changed.

```typescript
interface CausalAnalyzeParams {
  change: {
    file: string;
    lines?: [number, number];
    diff?: string;
  };
  depth?: number;               // Causal chain depth, default: 3
}

interface CausalAnalyzeResult {
  change_summary: string;
  direct_effects: Array<{
    component: string;
    effect: string;
    mechanism: string;          // HOW the change affects this
    confidence: number;
  }>;
  cascade_chain: Array<{
    level: number;
    component: string;
    effect: string;
    path: string[];             // Causal path from change to this effect
  }>;
  probability_of_failure: Array<{
    component: string;
    p_fail: number;
    mechanism: string;
    contributing_factors: string[];
  }>;
  counterfactual: string;       // "If you DON'T make this change..."
  recommended_mitigations: string[];
}

interface CausalWhyParams {
  symptom: string;              // "tests failing in module X"
  context?: {
    recent_changes?: string[];
    error_messages?: string[];
  };
}

interface CausalWhyResult {
  symptom_analysis: string;
  root_causes: Array<{
    cause: string;
    confidence: number;
    evidence_for: string[];
    evidence_against: string[];
    intervention: string;       // What to do about it
    intervention_confidence: number;
  }>;
  causal_graph: {
    nodes: Array<{ id: string; label: string; type: "root" | "intermediate" | "symptom" }>;
    edges: Array<{ from: string; to: string; strength: number; mechanism: string }>;
  };
  diagnostic_actions: Array<{
    action: string;
    information_gain: number;   // Bits of information this would provide
    cost: "low" | "medium" | "high";
  }>;
}

interface CausalInterventionParams {
  target: string;               // Component to intervene on
  intervention: string;         // Proposed change
}

interface CausalInterventionResult {
  predicted_effects: Array<{
    component: string;
    effect: string;
    probability: number;
    time_to_manifest: string;
  }>;
  side_effects: Array<{
    component: string;
    effect: string;
    severity: "critical" | "major" | "minor";
  }>;
  success_probability: number;
  confidence_interval: [number, number];
  recommended: boolean;
  reasoning: string;
}
```

**Mathematical Foundation**:

Pearl's do-calculus for causal inference:
```
P(Y | do(X)) ≠ P(Y | X)

Where:
- P(Y | X) = observational probability (correlation)
- P(Y | do(X)) = interventional probability (causation)

Computed using:
- Backdoor adjustment: P(Y | do(X)) = Σ_z P(Y | X, Z) * P(Z)
- Front-door adjustment when backdoor is blocked
- Structural Causal Models (SCMs) for the codebase
```

**Building the Causal Graph**:
1. Parse imports/exports for dependency structure
2. Analyze function calls for data flow
3. Track state mutations for side effects
4. Use test coverage for behavioral connections
5. Incorporate historical bug data for learned causal links

---

## 4.2 Code Thermodynamics Engine

Treat the codebase as a thermodynamic system.

```typescript
interface EntropyMeasureParams {
  scope?: "file" | "module" | "workspace";
  path?: string;
}

interface EntropyMeasureResult {
  total_entropy: number;        // Bits, higher = more disorder
  normalized_entropy: number;   // 0-1 scale
  max_sustainable_entropy: number;
  entropy_by_component: Array<{
    path: string;
    entropy: number;
    normalized: number;
    trend: "increasing" | "stable" | "decreasing";
  }>;
  entropy_sources: Array<{
    location: string;
    type: "coupling" | "complexity" | "duplication" | "inconsistency" | "dead_code";
    contribution: number;
    description: string;
  }>;
  entropy_trend: number[];      // Over last N commits
  predicted_entropy: number;    // If current trajectory continues
  time_to_critical: string;     // When entropy exceeds maintainability threshold
  health_grade: "A" | "B" | "C" | "D" | "F";
}

interface EntropyMinimizeParams {
  budget_hours: number;
  target_reduction?: number;    // Absolute entropy reduction goal
  focus_areas?: string[];
}

interface EntropyMinimizeResult {
  current_entropy: number;
  target_entropy: number;
  recommended_refactors: Array<{
    action: string;
    location: string;
    entropy_reduction: number;
    effort_hours: number;
    roi: number;                // Entropy reduced per hour
    risk: "low" | "medium" | "high";
    dependencies: string[];     // Other refactors this depends on
  }>;
  optimal_sequence: string[];
  achievable_reduction: number;
  new_projected_entropy: number;
}

interface PhaseTransitionDetectResult {
  current_phase: "stable" | "metastable" | "critical" | "chaotic";
  phase_indicators: Array<{
    indicator: string;
    value: number;
    threshold: number;
    status: "normal" | "warning" | "critical";
  }>;
  transition_probability: number;
  time_to_transition?: string;
  recommended_architecture?: string;
  transition_cost: {
    effort_hours: number;
    risk_level: string;
    timeline: string;
  };
  historical_transitions: Array<{
    date: string;
    from_phase: string;
    to_phase: string;
    trigger: string;
  }>;
}
```

**Entropy Formula**:

```
H(codebase) = H_pattern + H_coupling + H_complexity + H_inconsistency

Where:

H_pattern = -Σ p(pattern_i) * log₂(p(pattern_i))
  - p(pattern_i) = frequency of code pattern i / total patterns
  - Higher uniformity → lower entropy → more maintainable

H_coupling = λ * Σ (coupling(m_i, m_j) * distance(m_i, m_j))
  - coupling = number of shared dependencies / total dependencies
  - distance = shortest path in module graph
  - λ = coupling weight factor

H_complexity = μ * Σ (cyclomatic(f_i) * nesting(f_i) * size(f_i))
  - Normalized by codebase average
  - μ = complexity weight factor

H_inconsistency = ν * Σ deviation(style_i, dominant_style)
  - Measures naming conventions, formatting, patterns
  - ν = inconsistency weight factor

Phase transition indicators:
- Coupling ratio > 0.7 → metastable
- Entropy growth rate > 0.1/month → approaching critical
- Circular dependencies > 5% of modules → chaotic
```

---

## 4.3 Probabilistic Fault Localization

Bayesian inference for bug hunting.

```typescript
interface FaultLocalizeParams {
  failing_tests: string[];
  passing_tests?: string[];
  recent_changes?: string[];
  error_messages?: string[];
}

interface FaultLocalizeResult {
  suspects: Array<{
    location: {
      file: string;
      start_line: number;
      end_line: number;
      function?: string;
    };
    posterior_probability: number;
    prior_probability: number;
    likelihood_ratio: number;
    suspiciousness_score: number;  // SBFL score
    evidence_for: string[];
    evidence_against: string[];
    suggested_fix?: string;
  }>;
  diagnostic_tests: Array<{
    test: string;
    information_gain: number;
    disambiguates: string[];    // Which suspects this would help distinguish
  }>;
  confidence: number;           // Overall confidence in localization
  methodology: string;          // Which SBFL formula was used
}

interface FaultDiagnoseParams {
  suspect: {
    file: string;
    line: number;
  };
  symptom: string;
}

interface FaultDiagnoseResult {
  diagnosis: string;
  fault_type: "logic" | "state" | "timing" | "resource" | "interface" | "data";
  root_cause: string;
  fix_suggestions: Array<{
    fix: string;
    confidence: number;
    side_effects: string[];
    test_to_verify: string;
  }>;
  similar_past_bugs: Array<{
    description: string;
    fix_applied: string;
    commit: string;
  }>;
}
```

**Fault Localization Formula**:

```
P(fault at L | evidence) ∝ P(evidence | fault at L) * P(fault at L)

Prior P(fault at L) incorporates:
1. Change recency: e^(-λt) where t = days since last change
2. Historical bugs: bugs_at_L / total_bugs
3. Complexity: cyclomatic(L) / max_cyclomatic
4. Churn: changes_to_L / total_changes

Likelihood P(evidence | fault at L) uses SBFL:
- Tarantula: (failed_covering/total_failed) / ((failed_covering/total_failed) + (passed_covering/total_passed))
- Ochiai: failed_covering / √(total_failed * (failed_covering + passed_covering))
- DStar: failed_covering² / (passed_covering + (total_failed - failed_covering))

Information gain for diagnostic test T:
IG(T) = H(suspects) - H(suspects | T)
     = -Σ P(s) log P(s) + Σ P(outcome) * Σ P(s|outcome) log P(s|outcome)
```

---

## 4.4 Cognitive Load Optimizer

Minimize mental effort to understand code.

```typescript
interface CognitiveLoadAnalyzeParams {
  file: string;
  include_suggestions?: boolean;
}

interface CognitiveLoadAnalyzeResult {
  total_cognitive_load: number;
  working_memory_chunks: number;  // Should be ≤ 7±2
  load_by_function: Array<{
    function: string;
    line: number;
    intrinsic_load: number;     // Essential complexity
    extraneous_load: number;    // Unnecessary complexity (fixable)
    germane_load: number;       // Useful complexity
    total_load: number;
    grade: "A" | "B" | "C" | "D" | "F";
  }>;
  overload_points: Array<{
    location: string;
    load: number;
    threshold: number;
    cause: string;
    simplification: string;
  }>;
  reading_order: string[];      // Optimal order to understand this code
  comprehension_time_estimate: string;
}

interface CognitiveSimplifyParams {
  file: string;
  target_load?: number;
  preserve_behavior?: boolean;
}

interface CognitiveSimplifyResult {
  original_load: number;
  new_load: number;
  reduction_percent: number;
  refactored_code: string;
  changes: Array<{
    type: "extract_function" | "rename" | "reorder" | "add_comment" | "simplify_condition" | "reduce_nesting";
    location: string;
    before: string;
    after: string;
    cognitive_benefit: number;
    reasoning: string;
  }>;
  warnings?: string[];
}
```

**Cognitive Load Formula**:

Based on Cognitive Load Theory (Sweller) and empirical software engineering research:

```
CL(code) = Σ(element_complexity * interaction_factor) + chunk_penalty

element_complexity(e) = 
  cyclomatic_complexity(e) * 0.3 +
  nesting_depth(e) * 0.2 +
  identifier_complexity(e) * 0.15 +
  line_length(e) * 0.1 +
  parameter_count(e) * 0.15 +
  state_mutations(e) * 0.1

interaction_factor(e1, e2) = 
  coupling_strength(e1, e2) * 
  conceptual_distance(e1, e2) *
  temporal_distance(e1, e2)

chunk_penalty = max(0, unique_concepts - 7) * 2
  - unique_concepts = distinct variables + distinct functions called + distinct types used
  - Penalize exceeding working memory capacity (7±2)

Intrinsic load: Minimum CL required by problem domain
Extraneous load: CL from poor code organization (reducible)
Germane load: CL that aids schema formation (beneficial)

Total CL = Intrinsic + Extraneous + Germane
Goal: Minimize Extraneous while preserving Germane
```

---

## 4.5 Adversarial Robustness Engine

Attack your own code to find weaknesses.

```typescript
interface AdversarialProbeParams {
  target: string;               // Function, module, or endpoint
  attack_vectors?: ("input" | "timing" | "resource" | "concurrency" | "type")[];
  intensity?: "light" | "medium" | "heavy";
}

interface AdversarialProbeResult {
  target: string;
  vulnerabilities: Array<{
    type: string;
    severity: "critical" | "high" | "medium" | "low";
    description: string;
    exploit: {
      input: any;
      steps: string[];
      outcome: string;
    };
    cwe_id?: string;            // Common Weakness Enumeration
    fix_suggestion: string;
    fix_effort: "trivial" | "moderate" | "significant";
  }>;
  attack_surface_score: number;
  hardening_recommendations: Array<{
    recommendation: string;
    priority: "high" | "medium" | "low";
    vulnerabilities_addressed: string[];
  }>;
  resilience_score: number;     // 0-100
}

interface FuzzIntelligentParams {
  target: string;
  iterations?: number;
  strategy?: "coverage" | "mutation" | "grammar" | "hybrid";
  seed_inputs?: any[];
}

interface FuzzIntelligentResult {
  iterations_run: number;
  coverage_achieved: number;
  crashes: Array<{
    input: any;
    stack_trace: string;
    root_cause: string;
    reproducible: boolean;
  }>;
  hangs: Array<{
    input: any;
    location: string;
    likely_cause: string;
    duration_ms: number;
  }>;
  unexpected_behaviors: Array<{
    input: any;
    expected: string;
    actual: string;
    category: string;
  }>;
  interesting_inputs: Array<{
    input: any;
    reason: string;             // "Reached new branch", "Triggered edge case"
    coverage_contribution: number;
  }>;
  suggested_test_cases: Array<{
    input: any;
    expected_behavior: string;
    importance: "high" | "medium" | "low";
  }>;
}
```

---

## 4.6 Semantic Diff Engine

Understand behavioral changes, not just textual changes.

```typescript
interface SemanticDiffParams {
  base: string;                 // Commit, branch, or file path
  head: string;
  focus?: "behavior" | "interface" | "performance" | "all";
}

interface SemanticDiffResult {
  behavioral_changes: Array<{
    description: string;
    type: "feature" | "fix" | "breaking" | "optimization" | "refactor" | "deprecation";
    confidence: number;
    affected_users: string[];
    affected_flows: string[];
    locations: Array<{ file: string; lines: [number, number] }>;
  }>;
  interface_changes: Array<{
    type: "added" | "removed" | "modified";
    symbol: string;
    before?: string;
    after?: string;
    breaking: boolean;
    migration_guide?: string;
  }>;
  invariants_broken: Array<{
    invariant: string;
    description: string;
    violation_location: string;
    severity: "critical" | "warning";
  }>;
  semantic_conflicts: Array<{
    change_a: { description: string; location: string };
    change_b: { description: string; location: string };
    conflict: string;
    resolution_suggestion: string;
  }>;
  performance_implications: Array<{
    change: string;
    implication: "improvement" | "regression" | "neutral" | "unknown";
    affected_paths: string[];
    estimated_impact?: string;
  }>;
  changelog_entry: string;      // Auto-generated changelog
}
```

---

## 4.7 Counterfactual Simulation Engine

Explore alternate futures before committing to changes.

```typescript
interface CounterfactualSimulateParams {
  proposed_change: {
    file: string;
    diff: string;
  };
  scenarios?: number;           // How many timelines to explore
  time_horizon?: "immediate" | "sprint" | "quarter" | "year";
  focus?: ("bugs" | "performance" | "maintainability" | "security")[];
}

interface CounterfactualSimulateResult {
  timelines: Array<{
    scenario_id: number;
    narrative: string;          // Story of what happens
    probability: number;
    outcome: "success" | "degradation" | "failure";
    key_events: Array<{
      time_offset: string;
      event: string;
      impact: number;
      trigger: string;
    }>;
    final_state: {
      performance: number;
      stability: number;
      maintainability: number;
      security: number;
      technical_debt: number;
    };
    branching_points: Array<{
      event: string;
      alternatives: string[];
    }>;
  }>;
  dominant_timeline: number;
  risk_timeline: number;
  best_case_timeline: number;
  expected_value: number;
  variance: number;
  decision_recommendation: string;
  key_uncertainties: string[];
  information_to_gather: string[];
}
```

---

# Tier 5: Meta-Cognitive Engines

Self-awareness and continuous improvement.

## 5.1 Self-Improvement Engine

Learn from outcomes and get better over time.

```typescript
interface SelfReflectParams {
  task_id?: string;             // Specific task to reflect on
  time_range?: { start: string; end: string };
}

interface SelfReflectResult {
  task_outcome: "success" | "partial" | "failure";
  what_worked: Array<{
    action: string;
    why_effective: string;
    generalizability: "high" | "medium" | "low";
  }>;
  what_failed: Array<{
    action: string;
    why_failed: string;
    alternative: string;
  }>;
  root_cause_of_failure?: string;
  learned_heuristics: Array<{
    condition: string;          // "When encountering X"
    action: string;             // "Do Y instead of Z"
    confidence: number;
    evidence: string[];
  }>;
  updated_beliefs: Array<{
    belief: string;
    old_probability: number;
    new_probability: number;
    evidence: string;
  }>;
  capability_gaps: string[];
  improvement_suggestions: string[];
}

interface SelfImproveParams {
  apply_heuristics?: boolean;
  prune_ineffective?: boolean;
}

interface SelfImproveResult {
  active_heuristics: Array<{
    heuristic: string;
    times_applied: number;
    success_rate: number;
    avg_improvement: number;
  }>;
  deprecated_heuristics: Array<{
    heuristic: string;
    reason: string;
    deprecated_at: string;
  }>;
  capability_growth: {
    tasks_completed: number;
    success_rate_trend: number[];
    new_capabilities: string[];
    improved_capabilities: string[];
  };
  belief_state: Array<{
    domain: string;
    confidence: number;
    last_updated: string;
  }>;
}

interface SelfDiagnoseResult {
  current_performance: {
    success_rate: number;
    avg_task_time_ms: number;
    error_rate: number;
  };
  bottlenecks: Array<{
    area: string;
    impact: number;
    improvement_potential: number;
    suggested_intervention: string;
  }>;
  blind_spots: string[];
  overconfidence_areas: string[];
  underconfidence_areas: string[];
}
```

---

## 5.2 Intention Inference Engine

Understand what the user is trying to accomplish.

```typescript
interface IntentionInferParams {
  request: string;
  context?: {
    recent_files: string[];
    recent_searches: string[];
    recent_errors: string[];
    time_of_day: string;
    session_duration_minutes: number;
  };
}

interface IntentionInferResult {
  stated_intention: string;
  likely_true_intention: string;
  confidence: number;
  intention_type: "explore" | "fix" | "build" | "understand" | "optimize" | "refactor";
  urgency: "immediate" | "soon" | "eventually";
  clarifying_questions: Array<{
    question: string;
    information_gain: number;
    priority: "critical" | "helpful" | "optional";
  }>;
  alternative_interpretations: Array<{
    interpretation: string;
    probability: number;
    if_true_then: string;
  }>;
  inferred_constraints: string[];
  inferred_preferences: string[];
}

interface IntentionTrackParams {
  conversation_id?: string;
}

interface IntentionTrackResult {
  original_goal: string;
  current_goal: string;
  goal_evolution: Array<{
    turn: number;
    goal: string;
    trigger: string;
  }>;
  drift_events: Array<{
    turn: number;
    from_goal: string;
    to_goal: string;
    reason: string;
    intentional: boolean;
  }>;
  are_we_on_track: boolean;
  completion_estimate: number;  // 0-1
  blockers: string[];
  recommendation: string;
}
```

---

## 5.3 Pattern Evolution Engine

Learn and evolve patterns from your specific codebase.

```typescript
interface PatternExtractParams {
  scope?: "file" | "module" | "workspace";
  min_occurrences?: number;
}

interface PatternExtractResult {
  patterns: Array<{
    id: string;
    name: string;               // Auto-generated descriptive name
    structure: string;          // AST pattern representation
    occurrences: number;
    locations: Array<{ file: string; line: number }>;
    contexts: string[];
    success_rate: number;       // How often code using this pattern succeeds
    bug_correlation: number;    // Correlation with bug reports
    evolution_history: Array<{
      date: string;
      change: string;
    }>;
  }>;
  anti_patterns: Array<{
    pattern: string;
    occurrences: number;
    bug_correlation: number;
    recommended_alternative: string;
    refactoring_effort: "low" | "medium" | "high";
  }>;
  pattern_clusters: Array<{
    theme: string;
    patterns: string[];
  }>;
}

interface PatternSuggestParams {
  context: {
    file: string;
    cursor_position: number;
    surrounding_code: string;
  };
}

interface PatternSuggestResult {
  suggestions: Array<{
    pattern_id: string;
    pattern_name: string;
    code_template: string;
    relevance_score: number;
    similar_usages: Array<{ file: string; line: number }>;
    success_probability: number;
    reasoning: string;
  }>;
}

interface PatternEvolveParams {
  pattern_id: string;
  feedback?: "positive" | "negative";
}

interface PatternEvolveResult {
  original_pattern: string;
  evolved_variants: Array<{
    variant: string;
    improvement_reason: string;
    projected_success_rate: number;
    projected_bug_reduction: number;
    adoption_cost: "trivial" | "low" | "medium" | "high";
  }>;
  recommended_variant: number;
  migration_guide: string;
}
```

---

## 5.4 Swarm Intelligence Search

Multiple agents exploring the codebase in parallel.

```typescript
interface SwarmSearchParams {
  goal: string;                 // Natural language goal
  agent_count?: number;         // Default: 5
  strategy?: "exploration" | "exploitation" | "balanced";
  time_limit_ms?: number;
}

interface SwarmSearchResult {
  goal: string;
  agents_deployed: number;
  search_time_ms: number;
  findings: Array<{
    agent_id: number;
    path_taken: string[];
    discoveries: Array<{
      location: string;
      relevance: number;
      insight: string;
      confidence: number;
    }>;
    dead_ends: string[];
    distance_traveled: number;
  }>;
  pheromone_map: {
    hot_spots: Array<{ path: string; strength: number }>;
    cold_spots: string[];
    unexplored: string[];
    recommended_next: string[];
  };
  consensus_findings: Array<{
    finding: string;
    agreed_by: number[];
    confidence: number;
  }>;
  synthesis: string;
  coverage_percent: number;
}
```

---

## 5.5 Code DNA Sequencer

Treat code as genetic material.

```typescript
interface DnaSequenceParams {
  file: string;
}

interface DnaSequenceResult {
  genome: string;               // Abstract representation
  genome_length: number;
  genes: Array<{
    id: string;
    name: string;
    sequence: string;
    function: string;
    start_line: number;
    end_line: number;
    conservation_score: number;
    essential: boolean;
  }>;
  ancestry: {
    likely_ancestors: Array<{
      file: string;
      similarity: number;
      divergence_date?: string;
    }>;
    descendants: Array<{
      file: string;
      similarity: number;
    }>;
    siblings: Array<{
      file: string;
      common_ancestor?: string;
    }>;
  };
  mutations: Array<{
    type: "beneficial" | "neutral" | "harmful";
    location: string;
    description: string;
    introduced: string;         // Commit
    phenotype_effect: string;
  }>;
  genetic_health: number;       // 0-100
  inbreeding_coefficient: number;  // Code reuse/copy-paste metric
}

interface DnaCrisprParams {
  target_gene: string;
  edit: {
    type: "insert" | "delete" | "replace" | "silence";
    content?: string;
  };
  dry_run?: boolean;
}

interface DnaCrisprResult {
  target: string;
  affected_locations: string[];
  edit_preview: Array<{
    file: string;
    before: string;
    after: string;
  }>;
  off_target_risk: number;
  off_target_sites: string[];
  phenotype_change: string;
  fitness_impact: number;       // Predicted change in code quality
  recommended: boolean;
  warnings: string[];
}
```

---

# The Omega Equation

The master quality equation that integrates all metrics.

## Definition

```
Ω(codebase) = Σ[w_i * f_i(codebase)] * S(x) * R(x)

Subject to hard constraints:
- S(x) = Safety score (must be ≥ 0.9)
- R(x) = Reasoning validity (must be ≥ 0.8)

If constraints violated, Ω = 0 regardless of other scores.
```

## Component Functions

### f₁: Correctness
```
f₁ = 1 - P(bug | code)
   = test_pass_rate * (1 - historical_bug_density) * mutation_score

Where:
- test_pass_rate = passing_tests / total_tests
- historical_bug_density = bugs_in_last_year / lines_of_code
- mutation_score = killed_mutants / total_mutants
```

### f₂: Robustness
```
f₂ = 1 - P(failure | adversarial_input)
   = (1 - vulnerability_score) * (1 - crash_rate) * recovery_rate

Where:
- vulnerability_score = from adversarial_probe results
- crash_rate = crashes_in_fuzzing / total_fuzz_runs
- recovery_rate = successful_recoveries / total_failures
```

### f₃: Maintainability
```
f₃ = e^(-entropy / k)
   = e^(-(H_pattern + H_coupling + H_complexity + H_inconsistency) / k)

Where k is a normalization constant based on codebase size
```

### f₄: Performance
```
f₄ = 1 / (1 + α*latency + β*memory + γ*cpu)

Where:
- latency = avg response time / target response time
- memory = peak memory / available memory
- cpu = avg cpu utilization
- α, β, γ are weights based on application type
```

### f₅: Security
```
f₅ = 1 - attack_surface_score
   = 1 - (Σ vulnerability_severity_i * exposure_i) / max_possible_score

Where exposure considers:
- Public API surface
- Authentication requirements
- Data sensitivity
```

### f₆: Cognitive Load
```
f₆ = 1 / (1 + CL(code) / threshold)

Where CL is computed per the cognitive load formula above
```

### f₇: Evolvability
```
f₇ = ΔΩ / Δchange
   = (avg improvement in Ω per commit) / (avg effort per commit)

Measures how easily the codebase improves with changes
```

### f₈: Testability
```
f₈ = coverage * mutation_score * test_stability

Where:
- coverage = lines_covered / total_lines
- mutation_score = mutants_killed / total_mutants
- test_stability = 1 - flaky_test_rate
```

### f₉: Causality (Transparency)
```
f₉ = 1 / (1 + Σ hidden_dependencies)

Where hidden dependencies include:
- Global state mutations
- Implicit ordering requirements
- Undocumented side effects
- Magic values
```

### f₁₀: Predictability
```
f₁₀ = 1 - variance(behavior | inputs)

Measures how deterministic the code is:
- Pure functions score high
- Heavy state mutation scores low
- Random/time-dependent code scores low
```

## Weight Learning

Weights w_i are learned from user feedback and outcomes:

```
w_i(t+1) = w_i(t) + η * (outcome - predicted) * ∂Ω/∂w_i

Where:
- η = learning rate
- outcome = actual success/failure of changes
- predicted = predicted outcome based on Ω
```

## Implementation

```typescript
interface OmegaComputeParams {
  scope?: "file" | "module" | "workspace";
  path?: string;
}

interface OmegaComputeResult {
  omega: number;                // 0-1 overall score
  grade: "A+" | "A" | "B" | "C" | "D" | "F";
  components: {
    correctness: { score: number; weight: number; details: string };
    robustness: { score: number; weight: number; details: string };
    maintainability: { score: number; weight: number; details: string };
    performance: { score: number; weight: number; details: string };
    security: { score: number; weight: number; details: string };
    cognitive_load: { score: number; weight: number; details: string };
    evolvability: { score: number; weight: number; details: string };
    testability: { score: number; weight: number; details: string };
    causality: { score: number; weight: number; details: string };
    predictability: { score: number; weight: number; details: string };
  };
  hard_constraints: {
    safety: { score: number; passed: boolean };
    reasoning: { score: number; passed: boolean };
  };
  trend: number[];              // Historical Ω values
  improvement_potential: number;
  top_improvements: Array<{
    action: string;
    omega_increase: number;
    effort: string;
    roi: number;
  }>;
}

interface OmegaOptimizeParams {
  target_omega: number;
  constraints?: {
    max_effort_hours?: number;
    preserve_components?: string[];
    focus_components?: string[];
  };
}

interface OmegaOptimizeResult {
  current_omega: number;
  target_omega: number;
  achievable_omega: number;
  optimization_plan: Array<{
    phase: number;
    actions: string[];
    expected_omega_after: number;
    effort_hours: number;
    risk: "low" | "medium" | "high";
  }>;
  timeline: string;
  bottlenecks: string[];
}
```

---

# Implementation Roadmap

## Phase 1: Foundation (Weeks 1-3)
- [ ] Project setup (TypeScript, MCP SDK, dependencies)
- [ ] Infrastructure (state manager, cache, metrics)
- [ ] Background Task Orchestrator
- [ ] Checkpoint & Rollback
- [ ] Basic testing framework

## Phase 2: Developer Tools (Weeks 4-6)
- [ ] Git Operations
- [ ] Test Runner
- [ ] Code Search (text-based)
- [ ] Lint & Build
- [ ] Diff & Patch

## Phase 3: Advanced Foundation (Weeks 7-9)
- [ ] Impact Analysis
- [ ] Semantic Search (embeddings)
- [ ] Live Context Sync
- [ ] Multi-File Refactor

## Phase 4: Intelligence Engines (Weeks 10-14)
- [ ] Cognitive Load Optimizer
- [ ] Entropy Measurement
- [ ] Fault Localization
- [ ] Semantic Diff

## Phase 5: Causal & Predictive (Weeks 15-18)
- [ ] Causal Inference Engine
- [ ] Counterfactual Simulation
- [ ] Adversarial Robustness

## Phase 6: Meta-Cognitive (Weeks 19-22)
- [ ] Self-Improvement Engine
- [ ] Intention Inference
- [ ] Pattern Evolution

## Phase 7: Integration (Weeks 23-25)
- [ ] Omega Equation implementation
- [ ] Swarm Intelligence
- [ ] Code DNA
- [ ] Full system integration testing

## Phase 8: Optimization (Weeks 26+)
- [ ] Performance tuning
- [ ] Weight learning for Omega
- [ ] Documentation
- [ ] User feedback integration

---

# Dependencies

```json
{
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.0",
    "zod": "^3.23.0",
    "execa": "^8.0.0",
    "simple-git": "^3.24.0",
    "chokidar": "^3.6.0",
    "tree-sitter": "^0.21.0",
    "tree-sitter-typescript": "^0.21.0",
    "tree-sitter-javascript": "^0.21.0",
    "tree-sitter-python": "^0.21.0",
    "@vscode/ripgrep": "^1.15.0",
    "lancedb": "^0.5.0",
    "@xenova/transformers": "^2.17.0",
    "tar": "^6.2.0",
    "pixelmatch": "^5.3.0",
    "playwright": "^1.42.0",
    "isolated-vm": "^4.7.0",
    "mathjs": "^12.4.0",
    "ml-matrix": "^6.11.0"
  },
  "devDependencies": {
    "typescript": "^5.4.0",
    "@types/node": "^20.11.0",
    "vitest": "^1.3.0",
    "eslint": "^8.57.0",
    "@typescript-eslint/eslint-plugin": "^7.1.0",
    "@typescript-eslint/parser": "^7.1.0"
  }
}
```

---

# Server Architecture

```
prism-mcp-intelligence/
├── package.json
├── tsconfig.json
├── SKILL.md                    # This file
├── src/
│   ├── index.ts                # Server entry point
│   ├── config.ts               # Configuration
│   ├── types/                  # TypeScript interfaces
│   │   ├── tools.ts
│   │   ├── engines.ts
│   │   └── omega.ts
│   │
│   ├── infrastructure/
│   │   ├── state.ts            # State management
│   │   ├── cache.ts            # Caching layer
│   │   ├── embeddings.ts       # Vector store
│   │   ├── ast.ts              # AST parsing
│   │   ├── metrics.ts          # Metrics collection
│   │   └── exec.ts             # Shell execution
│   │
│   ├── tools/
│   │   ├── tier1/              # Foundation
│   │   │   ├── tasks.ts
│   │   │   ├── checkpoints.ts
│   │   │   ├── impact.ts
│   │   │   ├── semantic.ts
│   │   │   └── context.ts
│   │   ├── tier2/              # Developer workflow
│   │   │   ├── git.ts
│   │   │   ├── test.ts
│   │   │   ├── search.ts
│   │   │   ├── lint.ts
│   │   │   └── diff.ts
│   │   └── tier3/              # Advanced
│   │       ├── refactor.ts
│   │       ├── sandbox.ts
│   │       ├── compress.ts
│   │       ├── docs.ts
│   │       └── visual.ts
│   │
│   ├── engines/
│   │   ├── causal.ts           # Causal inference
│   │   ├── entropy.ts          # Thermodynamics
│   │   ├── fault.ts            # Fault localization
│   │   ├── cognitive.ts        # Cognitive load
│   │   ├── adversarial.ts      # Robustness
│   │   ├── semantic-diff.ts    # Semantic diff
│   │   └── counterfactual.ts   # Simulation
│   │
│   ├── meta/
│   │   ├── self-improve.ts     # Self-improvement
│   │   ├── intention.ts        # Intention inference
│   │   ├── pattern.ts          # Pattern evolution
│   │   ├── swarm.ts            # Swarm intelligence
│   │   └── dna.ts              # Code DNA
│   │
│   ├── omega/
│   │   ├── compute.ts          # Omega calculation
│   │   ├── components.ts       # Individual metrics
│   │   ├── optimize.ts         # Optimization
│   │   └── learn.ts            # Weight learning
│   │
│   └── utils/
│       ├── errors.ts
│       ├── parse.ts
│       ├── format.ts
│       └── math.ts
│
├── data/
│   ├── .mcp-checkpoints/       # Checkpoint storage
│   ├── .mcp-index/             # Semantic search index
│   ├── .mcp-cache/             # General cache
│   ├── .mcp-state/             # Persistent state
│   └── .mcp-learning/          # Learned heuristics
│
└── tests/
    ├── tools/
    ├── engines/
    ├── meta/
    └── integration/
```

---

# Usage Notes

## Quick Reference

**To compute code quality:**
```
omega_compute({ scope: "workspace" })
```

**To understand why something broke:**
```
causal_why({ symptom: "API returns 500 on /users endpoint" })
```

**To safely try a risky refactor:**
```
checkpoint_create({ label: "before-refactor" })
// make changes
checkpoint_diff({ checkpoint_id: "..." })
// if bad:
checkpoint_restore({ checkpoint_id: "..." })
```

**To find code by meaning:**
```
semantic_search({ query: "function that validates user permissions" })
```

**To run tests in background:**
```
task_spawn({ command: "npm test", label: "test-suite" })
// continue working
task_status({ task_id: "..." })
```

## Best Practices

1. **Always checkpoint before risky operations**
2. **Use impact_analyze before modifying shared code**
3. **Run omega_compute periodically to track code health**
4. **Use causal_why instead of guessing at bug causes**
5. **Let self_reflect run after major tasks**
6. **Use semantic_search for unfamiliar codebases**
7. **Check entropy_measure monthly**

---

# Version History

- **v1.0.0** (2026-02-04): Initial specification
  - Complete tool definitions for Tiers 1-3
  - Intelligence engine specifications for Tier 4
  - Meta-cognitive engine specifications for Tier 5
  - Omega equation with all component formulas
  - Implementation roadmap and architecture

---

# References

1. Pearl, J. (2009). Causality: Models, Reasoning, and Inference
2. Sweller, J. (1988). Cognitive Load Theory
3. Shannon, C. (1948). A Mathematical Theory of Communication
4. Wong, W.E. et al. (2016). A Survey on Software Fault Localization
5. Dorigo, M. (1992). Ant Colony Optimization
6. Holland, J. (1975). Adaptation in Natural and Artificial Systems

---

**END OF SPECIFICATION**
