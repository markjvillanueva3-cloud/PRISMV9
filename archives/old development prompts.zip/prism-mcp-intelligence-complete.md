# PRISM MCP Developer Intelligence Server - Complete Specification v2.0

> **Purpose**: Transform Claude from a chatbot into an agentic development partner with genuine cognitive enhancement. This document contains everything needed to build the server: prioritized tools, hook-based intelligence, token-efficient patterns, and implementation details.
>
> **Target**: 986K line PRISM Manufacturing Intelligence monolith
>
> **Philosophy**: Spend tokens wisely. The MCP server saves ~50K tokens/session through context compression. Reinvest ~5-10K on intelligence features for 10x ROI.

---

# Table of Contents

1. [Quick Start](#quick-start)
2. [Architecture](#architecture)
3. [Token Budget System](#token-budget-system)
4. [Hook-Based Intelligence](#hook-based-intelligence)
5. [Priority 1: Foundation Tools](#priority-1-foundation-tools)
6. [Priority 2: Workflow Tools](#priority-2-workflow-tools)
7. [Priority 3: Intelligence Engines](#priority-3-intelligence-engines)
8. [Priority 4: Meta-Cognitive Systems](#priority-4-meta-cognitive-systems)
9. [The Omega Equation](#the-omega-equation)
10. [Implementation Roadmap](#implementation-roadmap)
11. [Dependencies & Structure](#dependencies--structure)

---

# Quick Start

## Build Order (80/20 Rule - These give 80% of value)

### Week 1-2: Foundation (Must Have)
```
1. Checkpoint & Rollback     - Fearless experimentation
2. Background Tasks          - Async tests/builds while working  
3. Subagent Spawner          - Delegate research to isolated contexts
```

### Week 3-4: Core Intelligence (High Value)
```
4. Impact Analysis           - Know what breaks before editing
5. Semantic Search           - Find code by meaning
6. Hook System               - Conditional token spending
```

### Week 5-6: Workflow (Productivity)
```
7. Git Operations            - Structured git output
8. Test Runner               - JSON test results
9. Cascading Review          - Smart code review
```

## Immediate Setup
```bash
mkdir prism-mcp-intelligence && cd prism-mcp-intelligence
npm init -y
npm install @modelcontextprotocol/sdk zod execa simple-git tar \
            tree-sitter lancedb @xenova/transformers chokidar tree-kill
npm install -D typescript @types/node vitest
```

## What NOT to Build (Use Existing)
| Don't Build | Use Instead | Reason |
|------------|-------------|--------|
| Git wrapper | `simple-git` | Already perfect |
| Test runner | Direct Jest/Vitest | JSON output built-in |
| Lint runner | ESLint/Biome direct | Structured output exists |
| Code search | ripgrep + tree-sitter | Faster than custom |
| Browser automation | Playwright MCP | Already exists |

---

# Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        PRISM MCP Intelligence Server                         │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 6: HOOK-BASED INTELLIGENCE (NEW)                                      │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐                │
│  │  Token Budget   │ │ Event Triggers  │ │Cascading Review │                │
│  │    Tracker      │ │   & Hooks       │ │    System       │                │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘                │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 5: META-COGNITIVE                                                     │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐                │
│  │ Self-Improvement│ │Intention Infer  │ │ Pattern Evolve  │                │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘                │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 4: INTELLIGENCE ENGINES                                               │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │ Causal   │ │ Entropy  │ │  Fault   │ │Cognitive │ │  Smart   │          │
│  │ Inference│ │ Thermo   │ │  Local   │ │  Load    │ │Reflection│          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 3: AGENTIC PATTERNS                                                   │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐                        │
│  │ Subagent │ │  Master  │ │   TDD    │ │ Context  │                        │
│  │  Spawn   │ │  Clone   │ │   Loop   │ │ Hygiene  │                        │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘                        │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 2: DEVELOPER WORKFLOW                                                 │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │   Git    │ │  Test    │ │  Code    │ │  Lint/   │ │  Diff/   │          │
│  │   Ops    │ │  Runner  │ │  Search  │ │  Build   │ │  Patch   │          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 1: FOUNDATION (Build First)                                           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │Checkpoint│ │Background│ │ Subagent │ │  Impact  │ │ Semantic │          │
│  │ Rollback │ │  Tasks   │ │ Spawner  │ │ Analysis │ │  Search  │          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────────────────────┤
│  INFRASTRUCTURE                                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │  State   │ │  Cache   │ │ Embeddings│ │   AST    │ │  Metrics │          │
│  │ Manager  │ │  Layer   │ │  (Local) │ │  Parser  │ │ Collector│          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# Token Budget System

The MCP server saves massive tokens through context compression. We reinvest a portion on intelligence.

```typescript
// src/utils/token-budget.ts

interface TokenBudgetConfig {
  session_budget: number;        // Default: 10000
  categories: {
    reflection: number;          // Max per reflection: 300
    review: number;              // Max per review: 800
    deep_analysis: number;       // Max per deep analysis: 1500
    background: number;          // Max for background tasks: 500
  };
}

class TokenBudget {
  private spent: number = 0;
  private breakdown: Map<string, number> = new Map();
  
  constructor(private config: TokenBudgetConfig = {
    session_budget: 10000,
    categories: {
      reflection: 300,
      review: 800,
      deep_analysis: 1500,
      background: 500
    }
  }) {}
  
  canSpend(category: string, tokens: number): boolean {
    const categoryLimit = this.config.categories[category];
    if (categoryLimit && tokens > categoryLimit) return false;
    return this.spent + tokens <= this.config.session_budget;
  }
  
  spend(category: string, tokens: number): boolean {
    if (!this.canSpend(category, tokens)) return false;
    this.spent += tokens;
    this.breakdown.set(category, (this.breakdown.get(category) || 0) + tokens);
    return true;
  }
  
  get remaining(): number {
    return this.config.session_budget - this.spent;
  }
  
  getReport(): BudgetReport {
    return {
      total_budget: this.config.session_budget,
      spent: this.spent,
      remaining: this.remaining,
      breakdown: Object.fromEntries(this.breakdown),
      efficiency_score: this.calculateEfficiency()
    };
  }
}
```

## Token Cost Reference

| Operation | Token Cost | When to Use |
|-----------|-----------|-------------|
| Confidence in prompt | 10-20 | Always |
| Quick reflection | 200-300 | On test failure |
| Focused review | 300-500 | Risk score > 0.5 |
| Deep review | 800-1500 | Risk score > 0.8 |
| Multi-perspective | 1500-2500 | Critical changes only |
| Background health | 300-500 | Once per session |
| Function summary | 50 | On new/changed functions |

## Zero-Token Intelligence (Programmatic)

These provide intelligence without any LLM calls:

```typescript
// All of these cost ZERO tokens

// 1. Execution feedback
const testResults = await jest.run();  // Pass/fail is ground truth

// 2. Static analysis  
const complexity = cyclomaticComplexity(code);  // AST-based
const imports = extractImports(ast);  // tree-sitter
const callGraph = buildCallGraph(files);  // Graph traversal

// 3. Local embeddings
import { pipeline } from '@xenova/transformers';
const embedder = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
const embedding = await embedder(code);  // ~30ms local

// 4. Entropy calculation
const health = shannonEntropy(patternFrequencies);  // Pure math

// 5. Impact from graph
const affected = graph.downstream(file, symbol);  // Graph traversal

// 6. Logprob confidence (if API returns it)
const confidence = Math.exp(avgLogprob);  // Free from API response
```

---

# Hook-Based Intelligence

Spend tokens conditionally based on triggers. This is the key innovation.

## Hook Configuration

```typescript
// src/hooks/intelligence-config.ts

interface HookConfig {
  trigger: 'always' | 'on_failure' | 'on_threshold' | 'periodic' | 'on_pattern';
  threshold?: number;
  pattern?: RegExp;
  max_tokens: number;
  cache_ttl?: number;  // Seconds, don't re-run if cached
  fallback?: 'programmatic' | 'skip' | 'warn';
}

const INTELLIGENCE_HOOKS: Record<string, HookConfig> = {
  // Always run (cheap)
  confidence_check: {
    trigger: 'always',
    max_tokens: 50,
  },
  
  // Only on test failure
  smart_reflection: {
    trigger: 'on_failure',
    max_tokens: 300,
    cache_ttl: 3600,  // Don't re-analyze same error for 1 hour
  },
  
  // Only when risk exceeds threshold
  focused_review: {
    trigger: 'on_threshold',
    threshold: 0.5,
    max_tokens: 500,
  },
  
  deep_review: {
    trigger: 'on_threshold',
    threshold: 0.8,
    max_tokens: 1500,
    fallback: 'programmatic',
  },
  
  // Security patterns always trigger
  security_review: {
    trigger: 'on_pattern',
    pattern: /eval\(|innerHTML|dangerouslySetInnerHTML|exec\(|spawn\(/,
    max_tokens: 600,
  },
  
  // Once per session
  codebase_health: {
    trigger: 'periodic',
    max_tokens: 500,
    cache_ttl: 86400,  // 24 hours
  },
  
  // Background indexing (amortized)
  semantic_summary: {
    trigger: 'on_threshold',
    threshold: 0,  // New/changed functions only
    max_tokens: 60,
    cache_ttl: 604800,  // 1 week
  }
};
```

## Smart Reflection (On Failure)

```typescript
// src/hooks/smart-reflection.ts

interface ReflectionResult {
  diagnosis: string;
  fix_suggestion: string;
  confidence: number;
  is_root_cause: boolean;
  cached: boolean;
}

async function smartReflection(
  code: string,
  error: ExecutionError,
  budget: TokenBudget
): Promise<ReflectionResult> {
  
  // STAGE 1: Programmatic diagnosis (0 tokens)
  const staticAnalysis = {
    error_location: parseErrorLocation(error),
    related_symbols: findRelatedSymbols(code, error.location),
    recent_changes: await git.diff('HEAD~1', error.file),
    similar_fixes: await vectorSearch(error.message),  // Local embeddings
  };
  
  // STAGE 2: Check cache (0 tokens if hit)
  const cacheKey = hash(error.message + error.file + error.line);
  const cached = await cache.get<ReflectionResult>(cacheKey);
  if (cached && cached.success_rate > 0.7) {
    return { ...cached.data, cached: true };
  }
  
  // STAGE 3: Check budget
  if (!budget.canSpend('reflection', 250)) {
    // Fallback to programmatic only
    return {
      diagnosis: staticAnalysis.error_location.message,
      fix_suggestion: staticAnalysis.similar_fixes[0]?.fix || 'Review error manually',
      confidence: 2,
      is_root_cause: false,
      cached: false
    };
  }
  
  // STAGE 4: Single focused LLM call (~200-250 tokens)
  budget.spend('reflection', 250);
  
  const response = await llm.complete({
    model: 'claude-sonnet-4-20250514',  // Fast model for reflection
    max_tokens: 300,
    messages: [{
      role: 'user',
      content: `Debug this error. Be concise.

ERROR: ${error.message}
LOCATION: ${error.file}:${error.line}

RELEVANT CODE:
\`\`\`
${staticAnalysis.related_symbols.slice(0, 500)}
\`\`\`

RECENT CHANGES:
${staticAnalysis.recent_changes.slice(0, 300)}

SIMILAR PAST FIXES:
${staticAnalysis.similar_fixes.slice(0, 3).map(f => `- ${f.summary}`).join('\n')}

Respond in JSON:
{"diagnosis": "<1-2 sentences>", "fix": "<specific fix>", "confidence": <1-5>, "is_root_cause": <boolean>}`
    }]
  });
  
  const result = JSON.parse(response.content);
  
  // Cache successful reflections
  await cache.set(cacheKey, { data: result, timestamp: Date.now() });
  
  return { ...result, cached: false };
}
```

## Cascading Code Review (Threshold-Based)

```typescript
// src/hooks/cascading-review.ts

interface ReviewResult {
  level: 0 | 1 | 2 | 3;
  risk_score: number;
  issues: Issue[];
  tokens_used: number;
  stopped_early: boolean;
}

async function cascadingReview(
  change: Change,
  budget: TokenBudget
): Promise<ReviewResult> {
  
  // ═══════════════════════════════════════════════════════════════════
  // LEVEL 0: Programmatic checks (0 tokens) - ALWAYS RUN
  // ═══════════════════════════════════════════════════════════════════
  const programmatic = {
    lint: await eslint.lint(change.files),
    types: await tsc.check(change.files),
    complexity: await measureComplexity(change.files),
    test_coverage: await coverage.check(change.files),
    security_patterns: detectSecurityPatterns(change.diff),
  };
  
  // If programmatic finds errors, stop here
  if (programmatic.lint.errors.length > 0 || programmatic.types.errors.length > 0) {
    return {
      level: 0,
      risk_score: 0.3,
      issues: [...programmatic.lint.errors, ...programmatic.types.errors],
      tokens_used: 0,
      stopped_early: true
    };
  }
  
  // Security patterns always escalate to Level 2+
  if (programmatic.security_patterns.length > 0) {
    return await securityReview(change, programmatic.security_patterns, budget);
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // LEVEL 1: Quick risk assessment (~50 tokens)
  // ═══════════════════════════════════════════════════════════════════
  if (!budget.canSpend('review', 50)) {
    return { level: 0, risk_score: 0.5, issues: [], tokens_used: 0, stopped_early: true };
  }
  
  budget.spend('review', 50);
  
  const quickAssessment = await llm.complete({
    max_tokens: 80,
    messages: [{
      role: 'user',
      content: `Rate this change 1-5 for bug risk. Just number + one sentence.
      
Files: ${change.files.join(', ')}
Stats: +${change.insertions}/-${change.deletions} lines

Diff preview:
${change.diff.slice(0, 400)}`
    }]
  });
  
  const riskScore = parseInt(quickAssessment.content) / 5;
  
  // Low risk: stop here
  if (riskScore <= 0.4) {
    return {
      level: 1,
      risk_score: riskScore,
      issues: [],
      tokens_used: 50,
      stopped_early: false
    };
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // LEVEL 2: Focused review (~300 tokens) - risk > 0.4
  // ═══════════════════════════════════════════════════════════════════
  if (!budget.canSpend('review', 300)) {
    return { level: 1, risk_score: riskScore, issues: [], tokens_used: 50, stopped_early: true };
  }
  
  const impactAnalysis = await computeImpact(change);  // Programmatic
  
  budget.spend('review', 300);
  
  const focusedReview = await llm.complete({
    max_tokens: 400,
    messages: [{
      role: 'user',
      content: `Review for bugs and breaking changes only. Skip style issues.

CHANGE:
${change.diff.slice(0, 1500)}

IMPACT:
- ${impactAnalysis.affected_modules.length} modules affected
- ${impactAnalysis.breaking_exports.length} potentially breaking
- Test coverage: ${impactAnalysis.test_coverage}%

Return JSON array: [{"issue": "...", "severity": "high|medium|low", "line": N}]
Empty array [] if no real issues.`
    }]
  });
  
  const issues = JSON.parse(focusedReview.content);
  
  // No serious issues: stop here
  if (issues.length === 0 || !issues.some(i => i.severity === 'high')) {
    return {
      level: 2,
      risk_score: riskScore,
      issues,
      tokens_used: 350,
      stopped_early: false
    };
  }
  
  // ═══════════════════════════════════════════════════════════════════
  // LEVEL 3: Deep review (~1000 tokens) - high severity issues found
  // ═══════════════════════════════════════════════════════════════════
  if (!budget.canSpend('deep_analysis', 1000)) {
    return { level: 2, risk_score: riskScore, issues, tokens_used: 350, stopped_early: true };
  }
  
  budget.spend('deep_analysis', 1000);
  
  const deepReview = await llm.complete({
    max_tokens: 1200,
    messages: [{
      role: 'user',
      content: `Deep review needed. High-severity issues flagged.

FULL CHANGE:
${change.diff}

FLAGGED ISSUES:
${JSON.stringify(issues, null, 2)}

FULL IMPACT:
${JSON.stringify(impactAnalysis, null, 2)}

For each issue:
1. Confirm or dismiss with reasoning
2. If confirmed, provide specific fix
3. Identify any missed issues

Return JSON: {"confirmed": [...], "dismissed": [...], "additional": [...], "fixes": {...}}`
    }]
  });
  
  return {
    level: 3,
    risk_score: riskScore,
    issues: JSON.parse(deepReview.content),
    tokens_used: 1350,
    stopped_early: false
  };
}
```

## Event-Triggered Hooks

```typescript
// src/hooks/event-triggers.ts

const eventHandlers: Record<string, EventHandler> = {
  
  // ═══════════════════════════════════════════════════════════════════
  // Git Events
  // ═══════════════════════════════════════════════════════════════════
  
  'git:pre-commit': async (files: string[], budget: TokenBudget) => {
    const change = await git.diff('--staged');
    return await cascadingReview(change, budget);
  },
  
  'git:post-commit': async (commit: Commit, budget: TokenBudget) => {
    // Update semantic index for changed files (amortized cost)
    const changed = await git.diff(`${commit.sha}~1`, commit.sha);
    if (changed.files.length > 0) {
      await backgroundIntelligence.updateSemanticIndex(changed.files, budget);
    }
  },
  
  // ═══════════════════════════════════════════════════════════════════
  // Test Events
  // ═══════════════════════════════════════════════════════════════════
  
  'test:fail': async (failure: TestFailure, budget: TokenBudget) => {
    return await smartReflection(failure.code, failure.error, budget);
  },
  
  'test:pass': async (results: TestResults) => {
    // Update success patterns in cache (0 tokens)
    await cache.recordSuccess(results.file, results.testName);
  },
  
  // ═══════════════════════════════════════════════════════════════════
  // File Events
  // ═══════════════════════════════════════════════════════════════════
  
  'file:save': async (file: string, budget: TokenBudget) => {
    const content = await fs.readFile(file, 'utf-8');
    
    // Check complexity (0 tokens)
    const complexity = cyclomaticComplexity(content);
    if (complexity > 15 && budget.canSpend('review', 150)) {
      budget.spend('review', 150);
      return await suggestSimplification(content, complexity);
    }
    
    // Check for security patterns (0 tokens to detect)
    const securityIssues = detectSecurityPatterns(content);
    if (securityIssues.length > 0) {
      return await securityReview({ files: [file], diff: content }, securityIssues, budget);
    }
  },
  
  // ═══════════════════════════════════════════════════════════════════
  // Session Events
  // ═══════════════════════════════════════════════════════════════════
  
  'session:start': async (budget: TokenBudget) => {
    // Load cached health report or generate new one
    const cached = await cache.get('codebase_health');
    if (cached && Date.now() - cached.timestamp < 86400000) {
      return cached.data;
    }
    
    if (budget.canSpend('background', 400)) {
      budget.spend('background', 400);
      const health = await analyzeCodebaseHealth();
      await cache.set('codebase_health', { data: health, timestamp: Date.now() });
      return health;
    }
  },
  
  'session:end': async (budget: TokenBudget) => {
    // Generate session summary
    return budget.getReport();
  }
};
```

## Background Intelligence (Amortized)

```typescript
// src/hooks/background-intelligence.ts

class BackgroundIntelligence {
  
  /**
   * Update semantic index for changed files.
   * Cost is amortized: ~50 tokens per NEW function, 0 for unchanged.
   */
  async updateSemanticIndex(
    changedFiles: string[],
    budget: TokenBudget
  ): Promise<IndexUpdateResult> {
    const results = { indexed: 0, skipped: 0, tokens_used: 0 };
    
    for (const file of changedFiles) {
      const content = await fs.readFile(file, 'utf-8');
      const functions = extractFunctions(content);  // AST, 0 tokens
      
      for (const fn of functions) {
        const hash = computeHash(fn.code);
        const existing = await cache.get(`fn:${file}:${fn.name}`);
        
        // Skip unchanged functions
        if (existing?.hash === hash) {
          results.skipped++;
          continue;
        }
        
        // Generate summary for new/changed functions
        if (budget.canSpend('background', 50)) {
          budget.spend('background', 50);
          results.tokens_used += 50;
          
          const summary = await llm.complete({
            max_tokens: 60,
            messages: [{
              role: 'user',
              content: `Summarize in 10 words: \`\`\`${fn.code.slice(0, 400)}\`\`\``
            }]
          });
          
          // Store embedding + summary
          const embedding = await localEmbed(fn.code + ' ' + summary.content);
          await vectorDb.upsert({
            id: `${file}:${fn.name}`,
            embedding,
            metadata: { file, name: fn.name, summary: summary.content, hash }
          });
          
          results.indexed++;
        }
      }
    }
    
    return results;
  }
  
  /**
   * Analyze overall codebase health.
   * Run once per session, cache for 24 hours.
   */
  async analyzeCodebaseHealth(budget: TokenBudget): Promise<HealthReport> {
    // Gather programmatic metrics (0 tokens)
    const metrics = {
      total_files: await countFiles('src/**/*.ts'),
      total_lines: await countLines('src/**/*.ts'),
      avg_complexity: await avgComplexity('src/**/*.ts'),
      max_complexity: await maxComplexity('src/**/*.ts'),
      test_coverage: await getCoverage(),
      dependency_depth: maxDepth(await buildDependencyGraph()),
      hotspots: await findHotspots(30),  // Most changed files in 30 days
      entropy: await computeCodebaseEntropy(),
      circular_deps: await findCircularDependencies(),
    };
    
    // Single LLM call for interpretation
    if (!budget.canSpend('background', 400)) {
      return { metrics, interpretation: null, generated_at: new Date().toISOString() };
    }
    
    budget.spend('background', 400);
    
    const interpretation = await llm.complete({
      max_tokens: 500,
      messages: [{
        role: 'user',
        content: `Interpret these codebase health metrics. Be actionable.

${JSON.stringify(metrics, null, 2)}

Return JSON:
{
  "health_score": <0-100>,
  "top_concerns": ["...", "...", "..."],
  "quick_wins": ["...", "...", "..."],
  "files_need_attention": ["...", "...", "..."],
  "trend": "improving|stable|declining"
}`
      }]
    });
    
    return {
      metrics,
      interpretation: JSON.parse(interpretation.content),
      generated_at: new Date().toISOString()
    };
  }
}
```

---

# Priority 1: Foundation Tools

Build these first. Everything else depends on them.

## 1.1 Checkpoint & Rollback

Ephemeral save states for fearless experimentation.

```typescript
// src/tools/foundation/checkpoints.ts

interface CheckpointCreateParams {
  label: string;
  paths?: string[];              // Specific paths, default: entire workspace
  include_untracked?: boolean;   // Default: true
  include_gitignored?: boolean;  // Default: false
}

interface CheckpointCreateResult {
  checkpoint_id: string;         // Format: chk_{timestamp}_{hash}
  label: string;
  created_at: string;
  files_captured: number;
  size_bytes: number;
  git_state: {
    branch: string;
    commit: string;
    dirty: boolean;
    staged_files: string[];
  };
}

interface CheckpointRestoreParams {
  checkpoint_id: string;
  paths?: string[];              // Partial restore if specified
  dry_run?: boolean;             // Default: false
}

interface CheckpointRestoreResult {
  restored_files: string[];
  skipped_files: string[];
  conflicts?: Array<{ file: string; reason: string }>;
  dry_run: boolean;
}

interface CheckpointDiffParams {
  checkpoint_id: string;
  paths?: string[];
}

interface CheckpointDiffResult {
  files_added: string[];
  files_modified: string[];
  files_deleted: string[];
  diff_summary: string;
  insertions: number;
  deletions: number;
}

interface CheckpointListResult {
  checkpoints: Array<{
    checkpoint_id: string;
    label: string;
    created_at: string;
    files_captured: number;
    size_bytes: number;
  }>;
  total_count: number;
  total_size_bytes: number;
}
```

**Implementation Notes**:
- Store in `.mcp-checkpoints/` (add to .gitignore)
- Use `tar` for compression
- Store file hashes for fast diff
- Max 20 checkpoints with LRU cleanup
- Capture git state (branch, commit, dirty) as metadata
- ~2-3 days to implement

---

## 1.2 Background Task Orchestrator

Async execution for tests/builds while you keep working.

```typescript
// src/tools/foundation/tasks.ts

interface TaskSpawnParams {
  command: string;
  label: string;
  working_dir?: string;
  timeout_minutes?: number;      // Default: 10
  env?: Record<string, string>;
}

interface TaskSpawnResult {
  task_id: string;
  status: "running";
  started_at: string;
  pid: number;
}

interface TaskStatusParams {
  task_id: string;
}

interface TaskStatusResult {
  task_id: string;
  label: string;
  status: "running" | "completed" | "failed" | "timeout" | "killed";
  exit_code?: number;
  output: string;
  output_lines: number;
  duration_ms: number;
  started_at: string;
  completed_at?: string;
}

interface TaskStreamParams {
  task_id: string;
  since_line?: number;
}

interface TaskStreamResult {
  new_lines: string[];
  total_lines: number;
  completed: boolean;
}

interface TaskKillParams {
  task_id: string;
  signal?: "SIGTERM" | "SIGKILL";
}

interface TaskKillResult {
  killed: boolean;
  final_output: string;
  exit_code: number;
}

interface TaskListResult {
  tasks: Array<{
    task_id: string;
    label: string;
    status: string;
    started_at: string;
    duration_ms: number;
  }>;
  running_count: number;
}
```

**Implementation Notes**:
- Use `execa` for process spawning
- Stream output to temp files, read incrementally
- Use `tree-kill` for killing process trees
- Max 10 concurrent tasks
- Clean up on server shutdown
- ~2-3 days to implement

---

## 1.3 Subagent Spawner

Delegate research to isolated contexts. Proven pattern from Claude Code.

```typescript
// src/tools/foundation/subagents.ts

interface SubagentSpawnParams {
  name: string;                  // Identifier for this agent
  task: string;                  // What to accomplish
  tools?: string[];              // Which tools agent can use
  context_files?: string[];      // Files to include in context
  max_tokens?: number;           // Limit output length
  timeout_minutes?: number;      // Default: 5
}

interface SubagentSpawnResult {
  agent_id: string;
  status: "running" | "completed" | "failed" | "timeout";
  result?: string;               // Agent's findings/output
  tokens_used: number;
  duration_ms: number;
  files_read: string[];
  tools_used: string[];
}

interface SubagentTemplateParams {
  template: "security-reviewer" | "test-writer" | "bug-hunter" | 
            "refactor-advisor" | "performance-analyzer" | "doc-writer";
  target: string;                // File or directory to analyze
  focus?: string;                // Specific aspect to focus on
}

// Pre-defined templates
const SUBAGENT_TEMPLATES = {
  'security-reviewer': {
    task: 'Review for security vulnerabilities: injection, auth flaws, secrets exposure, insecure data handling',
    tools: ['read_file', 'search_code', 'semantic_search'],
    max_tokens: 1000
  },
  'test-writer': {
    task: 'Write comprehensive tests: unit tests, edge cases, error paths, integration points',
    tools: ['read_file', 'search_code', 'run_tests'],
    max_tokens: 2000
  },
  'bug-hunter': {
    task: 'Hunt for bugs: logic errors, off-by-one, null handling, race conditions, resource leaks',
    tools: ['read_file', 'search_code', 'semantic_search'],
    max_tokens: 1000
  },
  'refactor-advisor': {
    task: 'Analyze for refactoring: code smells, extraction opportunities, pattern improvements',
    tools: ['read_file', 'search_code', 'complexity_check'],
    max_tokens: 1500
  },
  'performance-analyzer': {
    task: 'Analyze performance: algorithmic complexity, memory usage, I/O bottlenecks, caching opportunities',
    tools: ['read_file', 'search_code', 'profile'],
    max_tokens: 1000
  },
  'doc-writer': {
    task: 'Generate documentation: function docs, README sections, API documentation, usage examples',
    tools: ['read_file', 'search_code'],
    max_tokens: 2000
  }
};
```

**Implementation Notes**:
- Each subagent runs in isolated context (separate conversation)
- Main agent receives only summary, keeping context clean
- Can run multiple in parallel
- Great for research that reads many files
- ~2-3 days to implement

---

## 1.4 Impact Analysis

Know what breaks before you edit.

```typescript
// src/tools/foundation/impact.ts

interface CodeImpactParams {
  file: string;
  line_range?: [number, number];
  symbol?: string;
}

interface CodeImpactResult {
  target: {
    file: string;
    lines?: [number, number];
    symbol?: string;
    type?: "function" | "class" | "variable" | "type";
  };
  direct_importers: Array<{
    file: string;
    import_line: number;
    import_type: "named" | "default" | "namespace" | "side-effect";
  }>;
  transitive_dependents: number;
  dependency_depth: number;
  test_coverage: Array<{
    test_file: string;
    test_names: string[];
    coverage_type: "direct" | "indirect";
  }>;
  exports_affected: string[];
  breaking_risk: "critical" | "high" | "medium" | "low";
  risk_reasons: string[];
  suggested_actions: string[];
}

interface ImpactDependencyGraphParams {
  file: string;
  depth?: number;                // Default: 3
  direction?: "importers" | "imports" | "both";
}

interface ImpactDependencyGraphResult {
  nodes: Array<{
    file: string;
    depth: number;
    type: "source" | "test" | "config";
    size_lines: number;
  }>;
  edges: Array<{
    from: string;
    to: string;
    import_type: "static" | "dynamic" | "type-only";
    symbols?: string[];
  }>;
  cycles?: string[][];
  hubs?: Array<{ file: string; connections: number }>;
}
```

**Risk Scoring Formula** (0 tokens, pure computation):
```typescript
function calculateRisk(analysis: CodeImpactResult): number {
  const base = (
    analysis.direct_importers.length * 2 + 
    analysis.transitive_dependents * 0.5
  );
  const exportMultiplier = 1 + analysis.exports_affected.length * 0.3;
  const testMultiplier = analysis.test_coverage.length > 0 ? 0.5 : 1.5;
  
  const score = base * exportMultiplier * testMultiplier;
  
  if (score > 50) return "critical";
  if (score > 20) return "high";
  if (score > 5) return "medium";
  return "low";
}
```

**Implementation Notes**:
- Build import graph on first call, cache and update incrementally
- Use tree-sitter for language-aware parsing
- Integrate with test coverage data if available
- All computation is programmatic (0 tokens)
- ~1-2 weeks to implement properly

---

## 1.5 Semantic Code Search

Find code by meaning, not keywords.

```typescript
// src/tools/foundation/semantic.ts

interface SemanticIndexBuildParams {
  paths?: string[];
  force_rebuild?: boolean;
  chunk_strategy?: "function" | "class" | "file" | "smart";
}

interface SemanticIndexBuildResult {
  files_indexed: number;
  chunks_created: number;
  duration_ms: number;
  index_size_mb: number;
}

interface SemanticSearchParams {
  query: string;
  top_k?: number;                // Default: 10
  file_pattern?: string;
  min_score?: number;            // 0-1, default: 0.5
  include_context?: boolean;
}

interface SemanticSearchResult {
  results: Array<{
    file: string;
    start_line: number;
    end_line: number;
    code: string;
    score: number;
    summary: string;
    symbols: string[];
  }>;
  query_embedding_ms: number;
  search_ms: number;
}

interface SemanticSimilarParams {
  file: string;
  start_line: number;
  end_line: number;
  top_k?: number;
}

interface SemanticSimilarResult {
  similar: Array<{
    file: string;
    lines: [number, number];
    code: string;
    score: number;
    relationship: "duplicate" | "variant" | "related";
  }>;
}
```

**Implementation Notes**:
- Embedding: `@xenova/transformers` with `Xenova/all-MiniLM-L6-v2` (runs locally, 0 API cost)
- Vector store: LanceDB (embedded, no server needed)
- Chunk by AST boundaries (functions, classes), not arbitrary lines
- Store metadata: file, lines, language, symbols, last_modified
- Incremental updates: hash files, re-index only on change
- Background task generates summaries (~50 tokens per function, amortized)
- ~1 week to implement

---

# Priority 2: Workflow Tools

Standard development operations with structured output.

## 2.1 Git Operations

```typescript
// src/tools/workflow/git.ts

interface GitStatusResult {
  branch: string;
  upstream?: string;
  staged: Array<{ file: string; status: string }>;
  unstaged: Array<{ file: string; status: string }>;
  untracked: string[];
  ahead: number;
  behind: number;
  stash_count: number;
  merge_in_progress: boolean;
}

interface GitDiffParams {
  file?: string;
  staged?: boolean;
  commit_range?: string;
  stat_only?: boolean;
}

interface GitDiffResult {
  diff: string;
  files: Array<{
    file: string;
    status: string;
    insertions: number;
    deletions: number;
  }>;
  total_insertions: number;
  total_deletions: number;
}

interface GitLogParams {
  count?: number;
  author?: string;
  since?: string;
  path?: string;
}

interface GitLogResult {
  commits: Array<{
    hash: string;
    short_hash: string;
    author: string;
    date: string;
    message: string;
    files_changed: number;
  }>;
}

interface GitBlameParams {
  file: string;
  line_range?: [number, number];
}

interface GitBlameResult {
  lines: Array<{
    line_number: number;
    commit: string;
    author: string;
    date: string;
    content: string;
  }>;
  contributors: Array<{ author: string; lines: number }>;
}
```

**Implementation**: Use `simple-git` library. ~2-3 days.

---

## 2.2 Test Runner

```typescript
// src/tools/workflow/test.ts

interface TestRunParams {
  pattern?: string;
  file?: string;
  test_name?: string;
  watch?: boolean;
  coverage?: boolean;
  update_snapshots?: boolean;
  bail?: boolean;
  timeout_ms?: number;
}

interface TestRunResult {
  status: "passed" | "failed" | "error";
  total: number;
  passed: number;
  failed: number;
  skipped: number;
  duration_ms: number;
  suites: Array<{
    name: string;
    file: string;
    tests: Array<{
      name: string;
      status: "passed" | "failed" | "skipped";
      duration_ms: number;
      error?: {
        message: string;
        stack: string;
        diff?: string;
      };
    }>;
  }>;
  coverage?: {
    lines: number;
    branches: number;
    functions: number;
    statements: number;
  };
}
```

**Implementation**: Direct Jest/Vitest calls with `--json` flag. ~1-2 days.

---

## 2.3 Code Search

```typescript
// src/tools/workflow/search.ts

interface CodeSearchParams {
  query: string;
  paths?: string[];
  file_pattern?: string;
  case_sensitive?: boolean;
  whole_word?: boolean;
  regex?: boolean;
  context_lines?: number;
  max_results?: number;
}

interface CodeSearchResult {
  matches: Array<{
    file: string;
    line: number;
    column: number;
    content: string;
    context?: {
      before: string[];
      after: string[];
    };
  }>;
  total_matches: number;
  files_searched: number;
  duration_ms: number;
}

interface SymbolSearchParams {
  name: string;
  type?: "function" | "class" | "variable" | "type" | "interface";
  scope?: "workspace" | "file";
  file?: string;
}

interface SymbolSearchResult {
  symbols: Array<{
    name: string;
    type: string;
    file: string;
    line: number;
    signature?: string;
    exported: boolean;
  }>;
}
```

**Implementation**: Use ripgrep + tree-sitter. ~2-3 days.

---

## 2.4 Lint & Type Check

```typescript
// src/tools/workflow/lint.ts

interface LintRunParams {
  files?: string[];
  fix?: boolean;
  rules?: string[];
}

interface LintRunResult {
  files_checked: number;
  error_count: number;
  warning_count: number;
  fixable_count: number;
  issues: Array<{
    file: string;
    line: number;
    column: number;
    severity: "error" | "warning";
    rule: string;
    message: string;
    fix?: { range: [number, number]; text: string };
  }>;
}

interface TypeCheckResult {
  success: boolean;
  errors: Array<{
    file: string;
    line: number;
    column: number;
    message: string;
    code: number;
    suggestion?: string;
  }>;
  error_count: number;
}
```

**Implementation**: Direct ESLint/tsc calls. ~1-2 days.

---

# Priority 3: Intelligence Engines

These provide genuine cognitive enhancement. Build after foundation is solid.

## 3.1 Causal Inference Engine

Pearl's do-calculus applied to code. Answer "what if?" questions.

```typescript
// src/engines/causal.ts

interface CausalWhyParams {
  symptom: string;               // "API returns 500 on /users"
  context?: {
    recent_changes?: boolean;
    error_logs?: string;
    time_range?: string;
  };
}

interface CausalWhyResult {
  symptom: string;
  root_causes: Array<{
    cause: string;
    probability: number;         // 0-1 confidence
    evidence: string[];
    causal_chain: string[];      // A → B → C → symptom
    fix_suggestion: string;
  }>;
  causal_graph: {
    nodes: string[];
    edges: Array<{ from: string; to: string; strength: number }>;
  };
  confounders: string[];         // Variables that might mislead
  recommended_experiments: string[];  // How to verify
}

interface CausalWhatIfParams {
  intervention: string;          // "Change timeout from 30s to 60s"
  target: string;                // What outcome to predict
  context?: string[];
}

interface CausalWhatIfResult {
  intervention: string;
  predicted_effects: Array<{
    outcome: string;
    direction: "increase" | "decrease" | "unchanged";
    magnitude: "high" | "medium" | "low";
    confidence: number;
    reasoning: string;
  }>;
  side_effects: Array<{
    outcome: string;
    effect: string;
    likelihood: number;
  }>;
  assumptions: string[];
  alternative_interventions: string[];
}
```

**Mathematical Foundation**:
```
P(Y|do(X)) ≠ P(Y|X)

Intervention (do) differs from observation:
- Observation: P(symptom | error_log) - correlation
- Intervention: P(symptom | do(fix_code)) - causation

Causal chain validation:
1. Build dependency graph from AST (programmatic)
2. Identify potential causes from graph paths (programmatic)
3. Use LLM to evaluate probability of each path (~200-400 tokens)
4. Rank by evidence strength
```

---

## 3.2 Code Thermodynamics (Entropy)

Measure codebase health through information theory.

```typescript
// src/engines/entropy.ts

interface EntropyMeasureParams {
  scope: "file" | "directory" | "workspace";
  path?: string;
  compare_to?: string;           // Compare to previous state
}

interface EntropyMeasureResult {
  scope: string;
  entropy: {
    structural: number;          // AST pattern diversity
    naming: number;              // Identifier consistency
    coupling: number;            // Dependency randomness
    churn: number;               // Change pattern disorder
    overall: number;             // Weighted combination
  };
  interpretation: "healthy" | "concerning" | "critical";
  hotspots: Array<{
    path: string;
    entropy: number;
    reason: string;
  }>;
  trend?: {
    direction: "increasing" | "decreasing" | "stable";
    rate: number;
  };
  recommendations: string[];
}
```

**Entropy Calculation** (0 tokens, pure math):
```typescript
function shannonEntropy(frequencies: number[]): number {
  const total = frequencies.reduce((a, b) => a + b, 0);
  return -frequencies
    .filter(f => f > 0)
    .map(f => f / total)
    .reduce((sum, p) => sum + p * Math.log2(p), 0);
}

function structuralEntropy(ast: AST): number {
  const patterns = extractPatterns(ast);  // e.g., if-else, loops, try-catch
  const frequencies = countFrequencies(patterns);
  return shannonEntropy(Object.values(frequencies));
}

function namingEntropy(identifiers: string[]): number {
  const conventions = classifyNamingConventions(identifiers);
  return shannonEntropy(Object.values(conventions));
}
```

---

## 3.3 Cognitive Load Optimizer

Sweller's Cognitive Load Theory applied to code.

```typescript
// src/engines/cognitive.ts

interface CognitiveLoadParams {
  file: string;
  function_name?: string;
}

interface CognitiveLoadResult {
  target: string;
  load: {
    intrinsic: number;           // Inherent complexity (0-10)
    extraneous: number;          // Unnecessary complexity (0-10)
    germane: number;             // Learning-relevant complexity (0-10)
    total: number;               // Weighted sum
  };
  factors: Array<{
    factor: string;
    contribution: number;
    location?: { line: number; column: number };
    suggestion: string;
  }>;
  working_memory_chunks: number; // Miller's 7±2
  exceeds_threshold: boolean;
  simplification_suggestions: Array<{
    description: string;
    expected_reduction: number;
    effort: "low" | "medium" | "high";
    code_example?: string;
  }>;
}
```

**Cognitive Load Factors** (programmatic calculation):
```typescript
function calculateCognitiveLoad(code: string): CognitiveFactors {
  const ast = parse(code);
  
  return {
    // Intrinsic load (can't reduce without changing requirements)
    intrinsic: {
      algorithm_complexity: cyclomaticComplexity(ast),
      domain_concepts: countDomainConcepts(ast),
      async_operations: countAsyncOperations(ast),
    },
    
    // Extraneous load (CAN reduce - this is where we help)
    extraneous: {
      nesting_depth: maxNestingDepth(ast),
      variable_scope_distance: avgScopeDistance(ast),
      implicit_state: countImplicitState(ast),
      naming_inconsistency: namingInconsistencyScore(ast),
      long_functions: countLongFunctions(ast, threshold=50),
      parameter_count: maxParameterCount(ast),
    },
    
    // Working memory estimation (Miller's 7±2)
    working_memory_chunks: estimateChunks(ast),
  };
}
```

---

## 3.4 Fault Localization

Statistical debugging to find likely bug locations.

```typescript
// src/engines/fault.ts

interface FaultLocalizeParams {
  failing_tests: string[];
  passing_tests?: string[];
  error_message?: string;
}

interface FaultLocalizeResult {
  suspects: Array<{
    file: string;
    line_range: [number, number];
    function_name?: string;
    suspiciousness: number;      // 0-1, higher = more likely
    technique: "spectrum" | "mutation" | "delta" | "statistical";
    evidence: string[];
  }>;
  execution_data: {
    failing_coverage: string[];
    passing_coverage: string[];
    unique_to_failing: string[];
  };
  recommended_inspection_order: string[];
  confidence: number;
}
```

**Suspiciousness Formulas** (0 tokens):
```typescript
// Tarantula formula
function tarantula(ef: number, ep: number, nf: number, np: number): number {
  const failed_ratio = ef / nf;
  const passed_ratio = ep / np;
  return failed_ratio / (failed_ratio + passed_ratio);
}

// Ochiai formula (often performs better)
function ochiai(ef: number, ep: number, nf: number): number {
  return ef / Math.sqrt(nf * (ef + ep));
}

// DStar formula
function dstar(ef: number, ep: number, star: number = 2): number {
  return Math.pow(ef, star) / (ep + (nf - ef));
}
```

---

# Priority 4: Meta-Cognitive Systems

Self-improvement, pattern learning, intention inference.

## 4.1 Self-Improvement Engine

Learn from outcomes to improve future performance.

```typescript
// src/meta/self-improve.ts

interface SelfReflectParams {
  task_completed: string;
  outcome: "success" | "failure" | "partial";
  context?: {
    time_taken_ms?: number;
    iterations?: number;
    errors_encountered?: string[];
    user_feedback?: string;
  };
}

interface SelfReflectResult {
  task: string;
  outcome: string;
  analysis: {
    what_worked: string[];
    what_failed: string[];
    root_causes: string[];
    surprises: string[];
  };
  learnings: Array<{
    insight: string;
    confidence: number;
    applicable_to: string[];     // Future task types
  }>;
  heuristic_updates: Array<{
    heuristic: string;
    old_value?: any;
    new_value: any;
    reason: string;
  }>;
  improvement_suggestions: string[];
}

interface SelfHeuristicsResult {
  heuristics: Array<{
    name: string;
    description: string;
    value: any;
    learned_from: number;        // Number of experiences
    success_rate: number;
    last_updated: string;
  }>;
  total_experiences: number;
  improvement_trend: number;
}
```

**Learning Storage**:
```typescript
// Store in .mcp-learning/heuristics.json
interface LearnedHeuristics {
  patterns: {
    // Pattern → successful approach
    [pattern: string]: {
      approach: string;
      success_count: number;
      failure_count: number;
      last_used: string;
    };
  };
  
  // Error → likely fix
  error_fixes: {
    [error_signature: string]: {
      fix: string;
      success_rate: number;
      times_applied: number;
    };
  };
  
  // User preferences learned
  preferences: {
    code_style: Record<string, any>;
    communication_style: Record<string, any>;
    risk_tolerance: number;
  };
}
```

---

## 4.2 Intention Inference

Predict what the user is trying to accomplish.

```typescript
// src/meta/intention.ts

interface IntentionInferParams {
  recent_actions: string[];
  current_context: {
    open_files?: string[];
    recent_searches?: string[];
    recent_errors?: string[];
    current_branch?: string;
  };
}

interface IntentionInferResult {
  primary_intention: {
    goal: string;
    confidence: number;
    evidence: string[];
  };
  secondary_intentions: Array<{
    goal: string;
    confidence: number;
  }>;
  predicted_next_actions: Array<{
    action: string;
    probability: number;
    helpful_if_automated: boolean;
  }>;
  proactive_suggestions: Array<{
    suggestion: string;
    relevance: number;
    effort_saved: "high" | "medium" | "low";
  }>;
  context_understood: {
    task_type: "feature" | "bugfix" | "refactor" | "exploration" | "review";
    scope: "local" | "module" | "cross-cutting";
    phase: "planning" | "implementing" | "testing" | "debugging";
  };
}
```

---

# The Omega Equation

Unified quality measurement combining all metrics.

```
Ω(x) = Σᵢ wᵢ · fᵢ(x) · H(Sᵢ) · H(Rᵢ)

Where:
- Ω(x) = Overall quality score for code x
- wᵢ = Learned weight for component i
- fᵢ(x) = Component function value
- H(Sᵢ) = Safety hard constraint (0 or 1)
- H(Rᵢ) = Reasoning constraint (0 or 1)
```

## Component Functions

```typescript
// src/omega/components.ts

const OMEGA_COMPONENTS = {
  // Code Quality (40% weight default)
  correctness: (x) => testPassRate(x) * 0.6 + typeCheckScore(x) * 0.4,
  maintainability: (x) => 1 - (cognitiveLoad(x) / 10),
  security: (x) => 1 - (vulnerabilityScore(x)),
  performance: (x) => performanceScore(x),
  
  // Process Quality (30% weight default)
  test_coverage: (x) => coveragePercent(x) / 100,
  documentation: (x) => docCoverage(x),
  code_review: (x) => reviewCompleteness(x),
  
  // Health Metrics (30% weight default)
  entropy: (x) => 1 - normalizedEntropy(x),
  coupling: (x) => 1 - couplingScore(x),
  churn_stability: (x) => 1 - churnVolatility(x),
};

// Hard constraints (if violated, Ω = 0)
const HARD_CONSTRAINTS = {
  no_critical_vulnerabilities: (x) => criticalVulnCount(x) === 0,
  builds_successfully: (x) => buildStatus(x) === 'success',
  no_type_errors: (x) => typeErrorCount(x) === 0,
};
```

## Omega Tool Interface

```typescript
interface OmegaComputeParams {
  scope: "file" | "directory" | "workspace";
  path?: string;
  include_breakdown?: boolean;
}

interface OmegaComputeResult {
  omega: number;                 // 0-1, the unified score
  grade: "A" | "B" | "C" | "D" | "F";
  breakdown?: {
    component: string;
    raw_value: number;
    weight: number;
    weighted_value: number;
  }[];
  hard_constraints: {
    constraint: string;
    satisfied: boolean;
    details?: string;
  }[];
  bottlenecks: string[];         // What's dragging score down
  quick_wins: string[];          // Easy improvements
  trend?: {
    direction: "improving" | "declining" | "stable";
    change_30d: number;
  };
}
```

---

# Implementation Roadmap

## Phase 1: Foundation (Weeks 1-2) ⭐ CRITICAL
```
[x] Project setup (TypeScript, MCP SDK)
[ ] Infrastructure (state, cache, AST parser)
[ ] Checkpoint & Rollback
[ ] Background Task Orchestrator
[ ] Subagent Spawner
[ ] Token Budget System
```

## Phase 2: Core Intelligence (Weeks 3-4) ⭐ HIGH VALUE
```
[ ] Impact Analysis
[ ] Semantic Search (local embeddings)
[ ] Hook System (event triggers)
[ ] Cascading Review
[ ] Smart Reflection
```

## Phase 3: Workflow Tools (Weeks 5-6)
```
[ ] Git Operations
[ ] Test Runner
[ ] Code Search
[ ] Lint & Type Check
[ ] Diff & Patch
```

## Phase 4: Intelligence Engines (Weeks 7-10)
```
[ ] Cognitive Load Optimizer
[ ] Entropy Measurement
[ ] Fault Localization
[ ] Causal Inference (basic)
```

## Phase 5: Meta-Cognitive (Weeks 11-14)
```
[ ] Self-Improvement Engine
[ ] Intention Inference
[ ] Pattern Evolution
[ ] Heuristic Learning
```

## Phase 6: Integration (Weeks 15-18)
```
[ ] Omega Equation
[ ] Weight Learning
[ ] Full System Testing
[ ] Performance Optimization
```

---

# Dependencies & Structure

## Package.json
```json
{
  "name": "prism-mcp-intelligence",
  "version": "1.0.0",
  "type": "module",
  "main": "dist/index.js",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch",
    "start": "node dist/index.js",
    "test": "vitest"
  },
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.0",
    "zod": "^3.23.0",
    "execa": "^8.0.0",
    "simple-git": "^3.24.0",
    "chokidar": "^3.6.0",
    "tree-sitter": "^0.21.0",
    "tree-sitter-typescript": "^0.21.0",
    "tree-sitter-javascript": "^0.21.0",
    "lancedb": "^0.5.0",
    "@xenova/transformers": "^2.17.0",
    "tar": "^6.2.0",
    "tree-kill": "^1.2.2",
    "mathjs": "^12.4.0"
  },
  "devDependencies": {
    "typescript": "^5.4.0",
    "@types/node": "^20.11.0",
    "vitest": "^1.3.0"
  }
}
```

## Directory Structure
```
prism-mcp-intelligence/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts                # Server entry point
│   ├── config.ts
│   │
│   ├── infrastructure/
│   │   ├── state.ts            # State management
│   │   ├── cache.ts            # Caching layer
│   │   ├── embeddings.ts       # Local vector store
│   │   ├── ast.ts              # AST parsing
│   │   └── metrics.ts          # Metrics collection
│   │
│   ├── hooks/                  # ⭐ NEW: Hook-based intelligence
│   │   ├── intelligence-config.ts
│   │   ├── smart-reflection.ts
│   │   ├── cascading-review.ts
│   │   ├── event-triggers.ts
│   │   └── background-intelligence.ts
│   │
│   ├── tools/
│   │   ├── foundation/         # Priority 1
│   │   │   ├── checkpoints.ts
│   │   │   ├── tasks.ts
│   │   │   ├── subagents.ts
│   │   │   ├── impact.ts
│   │   │   └── semantic.ts
│   │   │
│   │   └── workflow/           # Priority 2
│   │       ├── git.ts
│   │       ├── test.ts
│   │       ├── search.ts
│   │       └── lint.ts
│   │
│   ├── engines/                # Priority 3
│   │   ├── causal.ts
│   │   ├── entropy.ts
│   │   ├── cognitive.ts
│   │   └── fault.ts
│   │
│   ├── meta/                   # Priority 4
│   │   ├── self-improve.ts
│   │   ├── intention.ts
│   │   └── pattern.ts
│   │
│   ├── omega/
│   │   ├── compute.ts
│   │   ├── components.ts
│   │   └── learn.ts
│   │
│   └── utils/
│       ├── token-budget.ts     # ⭐ NEW
│       ├── errors.ts
│       └── math.ts
│
├── data/
│   ├── .mcp-checkpoints/
│   ├── .mcp-index/
│   ├── .mcp-cache/
│   └── .mcp-learning/
│
└── tests/
```

---

# Quick Reference

## Start a Session
```
1. checkpoint_create({ label: "session-start" })
2. Session health check (if budget allows)
```

## Before Risky Changes
```
1. checkpoint_create({ label: "before-{change}" })
2. code_impact({ file, symbol })
3. If risk > 0.5: cascading_review()
```

## On Test Failure
```
1. smart_reflection() triggered automatically
2. If root cause found: apply fix
3. If not: fault_localize()
```

## Find Code
```
semantic_search({ query: "function that validates user permissions" })
```

## Understand Health
```
omega_compute({ scope: "workspace" })
entropy_measure({ scope: "workspace" })
```

## Debug "Why"
```
causal_why({ symptom: "API returns 500 on /users" })
```

---

# Key Principles

1. **Token Efficiency**: Spend tokens wisely. Programmatic first, LLM when valuable.
2. **Hook Everything**: Conditional spending based on triggers, not always-on.
3. **Cascade Up**: Start with cheap checks, escalate only when needed.
4. **Cache Aggressively**: Same error → same diagnosis (for a while).
5. **Learn Continuously**: Every outcome improves future performance.
6. **Structured Output**: JSON always, never raw text.
7. **Safe by Default**: Checkpoints before changes, confirmations for destructive ops.

---

**END OF SPECIFICATION v2.0**
