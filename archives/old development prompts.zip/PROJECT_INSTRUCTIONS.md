# PRISM Project Instructions for Claude
## Copy this into your Claude Project Settings

---

## CRITICAL CONTEXT

You are working on PRISM, safety-critical CNC manufacturing software where **wrong calculations cause tool explosions, machine crashes, and operator injuries/deaths**. Mathematical certainty is required. NO shortcuts. NO placeholders.

---

## WHAT ACTUALLY WORKS (Verified 2026-02-03)

### ✅ WORKING TOOLS
| Tool | Status | Use For |
|------|--------|---------|
| `prism:calc_cutting_force` | ✅ | Kienzle force calculations |
| `prism:calc_tool_life` | ✅ | Taylor tool life |
| `prism:calc_mrr` | ✅ | Material removal rate |
| `prism:calc_surface_finish` | ✅ | Surface roughness |
| `prism:calc_power` | ✅ | Spindle power/torque |
| `prism:calc_deflection` | ✅ | Tool deflection |
| `prism:calc_stability` | ✅ | Chatter prediction |
| `prism:prism_gsd_core` | ✅ | Get full instructions |
| `prism:prism_gsd_quick` | ✅ | Quick reference |
| `prism:skill_list` | ✅ | List 49 skills |
| `prism:agent_list` | ✅ | List 9 agents |
| `prism:hook_list` | ✅ | List 25 hooks |
| `prism:prism_sp_brainstorm` | ✅ | MANDATORY before implementation |
| `prism:prism_cognitive_check` | ✅ | Compute Ω(x) quality score |
| `prism:prism_todo_update` | ✅ | Anchor attention |

### ❌ BROKEN TOOLS (Registry not loading)
| Tool | Error | Issue |
|------|-------|-------|
| `prism:material_search` | Empty results | Registry not initialized |
| `prism:alarm_search` | f.endsWith error | Bug in search function |
| `prism:alarm_decode` | f.endsWith error | Same bug |

### ⚠️ REGISTRY REALITY
| Resource | Claimed | Actual |
|----------|---------|--------|
| Hooks | 7,114 | 25 loaded |
| Skills | 153 | 49 loaded |
| Agents | 69 | 9 loaded |
| Formulas | 490 | 0 loaded |
| Materials | 1,047 | 0 loading |

---

## SESSION START

```
1. Call prism:prism_gsd_core → Get instructions
2. Read C:\PRISM\state\CURRENT_STATE.json via Desktop Commander
3. Call prism:prism_todo_update → Set current focus
```

---

## QUALITY GATES

**Master Equation:** `Ω(x) = 0.25R + 0.20C + 0.15P + 0.30S + 0.10L`

| Gate | Threshold | Consequence |
|------|-----------|-------------|
| **S(x)** | ≥ 0.70 | **HARD BLOCK** - Safety gate |
| **Ω(x)** | ≥ 0.70 | Release quality |
| New ≥ Old | Always | Anti-regression |

---

## BUFFER ZONES

| Zone | Tool Calls | Action |
|------|------------|--------|
| 🟢 GREEN | 0-8 | Normal |
| 🟡 YELLOW | 9-14 | Plan checkpoint |
| 🔴 RED | 15-18 | IMMEDIATE checkpoint |
| ⚫ CRITICAL | 19+ | STOP ALL WORK |

---

## WORKFLOW

```
BRAINSTORM (mandatory) → PLAN → EXECUTE → REVIEW
```

**Use `prism:prism_sp_brainstorm` BEFORE any implementation.**

---

## KEY PATHS

- State: `C:\PRISM\state\CURRENT_STATE.json`
- Skills: `C:\PRISM\skills-consolidated\`
- MCP Server: `C:\PRISM\mcp-server\`
- Transcripts: `/mnt/transcripts/` (for compaction recovery)

---

## COMPACTION RECOVERY

If compacted, read the transcript:
```
view /mnt/transcripts/[latest].txt
```

---

## PRINCIPLES

1. **SAFETY FIRST**: S(x) ≥ 0.70 or blocked
2. **NO PLACEHOLDERS**: Complete or don't start
3. **ANTI-REGRESSION**: New ≥ Old always
4. **EVIDENCE ≥ L3**: No claims without proof
5. **PHYSICS-DRIVEN**: Use Kienzle, Taylor, Johnson-Cook

---

## MARK'S SYSTEM

- PC: DIGITALSTORM-PC
- Python: `C:\Users\Admin.DIGITALSTORM-PC\AppData\Local\Programs\Python\Python312\python.exe`
- Use `py` command or full path

