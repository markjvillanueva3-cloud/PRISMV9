# PRISM CODING PRACTICES SKILL PACKAGE
## Approved Roadmap for Execution
## v1.0 | 2026-01-29 | 6 Skills | ~3,850 Lines

---

# EXECUTIVE SUMMARY

```
╔═══════════════════════════════════════════════════════════════════════════════════════════╗
║                    CODING PRACTICES SKILL PACKAGE - APPROVED PLAN                          ║
╠═══════════════════════════════════════════════════════════════════════════════════════════╣
║                                                                                           ║
║  NEW SKILLS: 6                                                                            ║
║  TOTAL LINES: ~3,850                                                                      ║
║  TOTAL SIZE: ~150KB                                                                       ║
║  MICROSESSIONS: 4                                                                         ║
║  ESTIMATED TIME: 52 ± 17 minutes (95% CI)                                                 ║
║  TOOL CALLS: 52 ± 13 (95% CI)                                                             ║
║                                                                                           ║
║  SKILLS TO CREATE:                                                                        ║
║  1. prism-solid-principles      (~650 lines)                                              ║
║  2. prism-design-patterns       (~850 lines)                                              ║
║  3. prism-typescript-safety     (~700 lines)                                              ║
║  4. prism-error-handling-patterns (~600 lines)                                            ║
║  5. prism-security-coding       (~550 lines)                                              ║
║  6. prism-performance-patterns  (~500 lines)                                              ║
║                                                                                           ║
║  OUTPUT PATH: C:\PRISM\skills-consolidated\prism-[skill-name]\SKILL.md                    ║
║                                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════════════════════╝
```

---

# MATHPLAN GATE (PRE-APPROVED)

```
╔═══════════════════════════════════════════════════════════════════════════════════════════╗
║                              MATHPLAN GATE v1.0 - PASSED                                   ║
╠═══════════════════════════════════════════════════════════════════════════════════════════╣
║                                                                                           ║
║  ☑ SCOPE: S = 6 skills × 650 avg = 3,850 lines                                            ║
║  ☑ COMPLETENESS: C(T) = Σ Done(i) / 6 = 1.0 required                                      ║
║  ☑ DECOMPOSITION: d₁+d₂+d₃+d₄+d₅+d₆ = 3,850 ✓                                             ║
║  ☑ EFFORT: 52 ± 13 calls (95% CI)                                                         ║
║  ☑ MS_COUNT: ⌈52/15⌉ = 4 microsessions                                                    ║
║  ☑ TIME: 52 ± 17 minutes                                                                  ║
║  ☑ ORDER: SOLID → Patterns → TypeScript → Errors → Security → Performance                 ║
║  ☑ CONSTRAINTS: Lines ≥ 400, Examples ≥ 10, Integrations ≥ 2, S(x) ≥ 0.70                 ║
║                                                                                           ║
║  STATUS: ALL GATES PASSED ✓ → EXECUTE                                                     ║
╚═══════════════════════════════════════════════════════════════════════════════════════════╝
```

---

# EXECUTION ROADMAP

## MICROSESSION 1: Foundation Patterns (SOLID + Design Patterns)

```
□ 1.1 Create C:\PRISM\skills-consolidated\prism-solid-principles\SKILL.md
□ 1.2 Verify SOLID skill (format, content, examples)
□ 1.3 Create C:\PRISM\skills-consolidated\prism-design-patterns\SKILL.md
□ 1.4 Verify Patterns skill (format, content, examples)
□ 1.5 CHECKPOINT: 2/6 skills complete (33%)

Est: 16 ± 4 calls | Time: 15 ± 5 min
```

## MICROSESSION 2: Type Safety & Errors

```
□ 2.1 Create C:\PRISM\skills-consolidated\prism-typescript-safety\SKILL.md
□ 2.2 Verify TypeScript skill (format, content, examples)
□ 2.3 Create C:\PRISM\skills-consolidated\prism-error-handling-patterns\SKILL.md
□ 2.4 Verify Error skill (format, content, examples)
□ 2.5 CHECKPOINT: 4/6 skills complete (67%)

Est: 16 ± 4 calls | Time: 15 ± 5 min
```

## MICROSESSION 3: Security & Performance

```
□ 3.1 Create C:\PRISM\skills-consolidated\prism-security-coding\SKILL.md
□ 3.2 Verify Security skill (format, content, examples)
□ 3.3 Create C:\PRISM\skills-consolidated\prism-performance-patterns\SKILL.md
□ 3.4 Verify Performance skill (format, content, examples)
□ 3.5 CHECKPOINT: 6/6 skills complete (100%)

Est: 12 ± 3 calls | Time: 12 ± 4 min
```

## MICROSESSION 4: Integration & Finalization

```
□ 4.1 Update C:\PRISM\skills-consolidated\prism-all-skills\SKILL.md to v6.0
□ 4.2 Add 6 new skills to Level 3 Domain section
□ 4.3 Update counts: 100 → 106 skills
□ 4.4 Verify all 6 skills load correctly
□ 4.5 FINAL CHECKPOINT: Package complete

Est: 8 ± 2 calls | Time: 10 ± 3 min
```

---

# SKILL 1: prism-solid-principles

## Specification

```yaml
name: prism-solid-principles
level: 3 (Domain)
lines: ~650
purpose: SOLID principles applied to manufacturing software
integrates_with:
  - prism-code-master
  - prism-life-safety-mindset
  - prism-design-patterns
```

## Required Sections

```
---
name: prism-solid-principles
description: |
  SOLID object-oriented design principles applied to PRISM Manufacturing Intelligence.
  5 principles: Single Responsibility, Open/Closed, Liskov Substitution, Interface
  Segregation, Dependency Inversion. All with manufacturing-specific examples.
  Use when designing modules, refactoring code, or reviewing architecture.
---

# PRISM SOLID PRINCIPLES
## Object-Oriented Design for Manufacturing Intelligence

## QUICK REFERENCE (cheat sheet table)

## SECTION 1: SINGLE RESPONSIBILITY PRINCIPLE (SRP)
- Definition: One class = one reason to change
- PRISM Example: MaterialValidator vs MaterialEnhancer (separate concerns)
- Anti-pattern: God modules that validate, enhance, calculate, and persist
- Checklist: 5 items

## SECTION 2: OPEN/CLOSED PRINCIPLE (OCP)
- Definition: Open for extension, closed for modification
- PRISM Example: Adding new cutting force model without changing base engine
- Pattern: Strategy injection, plugin architecture
- Checklist: 5 items

## SECTION 3: LISKOV SUBSTITUTION PRINCIPLE (LSP)
- Definition: Subtypes must be substitutable for base types
- PRISM Example: All materials implement IMaterial consistently
- Anti-pattern: Titanium implementation breaking steel assumptions
- Checklist: 5 items

## SECTION 4: INTERFACE SEGREGATION PRINCIPLE (ISP)
- Definition: Many specific interfaces > one general interface
- PRISM Example: IMillingMaterial vs ITurningMaterial vs IDrillingMaterial
- Benefit: Consumers only depend on what they need
- Checklist: 5 items

## SECTION 5: DEPENDENCY INVERSION PRINCIPLE (DIP)
- Definition: Depend on abstractions, not concretions
- PRISM Example: PhysicsEngine depends on IMaterialDatabase, not JSONMaterialDatabase
- Pattern: Dependency injection container
- Checklist: 5 items

## SECTION 6: MANUFACTURING APPLICATIONS
- 15+ concrete PRISM examples
- Material system architecture
- Engine isolation patterns
- Database abstraction

## SECTION 7: ANTI-PATTERNS
- 10 common SOLID violations in manufacturing software
- Detection and remediation

## SECTION 8: INTEGRATION WITH PRISM
- Links to prism-code-master
- Links to prism-design-patterns
- Links to prism-life-safety-mindset

## SECTION 9: MASTER CHECKLIST
- 25 items covering all 5 principles
```

---

# SKILL 2: prism-design-patterns

## Specification

```yaml
name: prism-design-patterns
level: 3 (Domain)
lines: ~850
purpose: Gang of Four + domain patterns for PRISM architecture
integrates_with:
  - prism-solid-principles
  - prism-code-master
  - prism-api-contracts
```

## Required Sections

```
---
name: prism-design-patterns
description: |
  Gang of Four design patterns applied to PRISM Manufacturing Intelligence.
  Creational: Factory, Abstract Factory, Builder, Singleton.
  Structural: Adapter, Decorator, Facade.
  Behavioral: Strategy, Observer, Command, State, Chain of Responsibility.
  All with manufacturing-specific implementations and UML diagrams.
---

# PRISM DESIGN PATTERNS
## GoF Patterns for Manufacturing Intelligence

## QUICK REFERENCE (pattern selection decision tree)

## SECTION 1: CREATIONAL PATTERNS

### 1.1 Factory Method
- Purpose: Create objects without specifying exact class
- PRISM: MaterialFactory.create('4140-annealed')
- PRISM: MachineFactory.create('DMG-DMU-50')
- Code example (TypeScript)
- UML diagram (ASCII)

### 1.2 Abstract Factory
- Purpose: Create families of related objects
- PRISM: ControllerFactory creates Fanuc family OR Siemens family
- Code example
- UML diagram

### 1.3 Builder
- Purpose: Construct complex objects step by step
- PRISM: ToolpathBuilder.start().approach().cut().retract().build()
- PRISM: GCodeProgramBuilder
- Code example
- UML diagram

### 1.4 Singleton
- Purpose: Single instance with global access
- PRISM: ConfigurationManager, DatabaseConnectionPool
- Warning: Use sparingly, prefer DI
- Code example

## SECTION 2: STRUCTURAL PATTERNS

### 2.1 Adapter
- Purpose: Convert interface to expected interface
- PRISM: FanucAdapter implements IController
- PRISM: SiemensAdapter implements IController
- Code example
- UML diagram

### 2.2 Decorator
- Purpose: Add behavior without changing class
- PRISM: LoggingMaterialDatabase wraps MaterialDatabase
- PRISM: CachingCalculator wraps Calculator
- Code example
- UML diagram

### 2.3 Facade
- Purpose: Simple interface to complex subsystem
- PRISM: SpeedFeedFacade hides 15 underlying engines
- PRISM: ToolpathFacade
- Code example
- UML diagram

## SECTION 3: BEHAVIORAL PATTERNS

### 3.1 Strategy
- Purpose: Interchangeable algorithms
- PRISM: ICuttingForceStrategy → Kienzle, Merchant, Oxley
- PRISM: IOptimizationStrategy → PSO, GA, SimulatedAnnealing
- Code example
- UML diagram

### 3.2 Observer
- Purpose: Notify dependents of state changes
- PRISM: EventBus for MaterialUpdated → recalculate consumers
- PRISM: MachineStateChanged notifications
- Code example
- UML diagram

### 3.3 Command
- Purpose: Encapsulate request as object
- PRISM: GCodeCommand with execute/undo
- PRISM: ToolChangeCommand, SpindleStartCommand
- Code example
- UML diagram

### 3.4 State
- Purpose: Alter behavior when state changes
- PRISM: MachineState: IDLE → RUNNING → PAUSED → ERROR
- PRISM: CalculationState: PENDING → COMPUTING → COMPLETE
- Code example
- UML diagram

### 3.5 Chain of Responsibility
- Purpose: Pass request along chain of handlers
- PRISM: ValidationChain: Type → Range → Physics → Safety
- PRISM: ErrorRecoveryChain
- Code example
- UML diagram

## SECTION 4: PATTERN SELECTION GUIDE
- Decision tree: When to use which pattern
- Manufacturing context considerations
- Performance implications

## SECTION 5: ANTI-PATTERNS
- Pattern misuse examples
- Over-engineering warnings

## SECTION 6: INTEGRATION WITH PRISM
- How patterns map to v9.0 architecture
- Module boundaries
- Cross-cutting concerns
```

---

# SKILL 3: prism-typescript-safety

## Specification

```yaml
name: prism-typescript-safety
level: 3 (Domain)
lines: ~700
purpose: Type safety for 127-parameter schemas and unit safety
integrates_with:
  - prism-material-schema
  - prism-code-master
  - prism-api-contracts
```

## Required Sections

```
---
name: prism-typescript-safety
description: |
  TypeScript best practices for PRISM Manufacturing Intelligence.
  Branded types for unit safety (mm vs inches, N vs lbf).
  Discriminated unions for machine types. Strict mode enforcement.
  Template literal types for IDs. Type guards for runtime safety.
  Essential for 127-parameter material schemas.
---

# PRISM TYPESCRIPT SAFETY
## Type-Safe Manufacturing Intelligence

## QUICK REFERENCE (type patterns cheat sheet)

## SECTION 1: STRICT MODE ENFORCEMENT
- tsconfig.json requirements
- strict: true mandatory
- noImplicitAny, strictNullChecks, strictFunctionTypes
- PRISM requirement: 100% type coverage

## SECTION 2: BRANDED TYPES FOR UNITS
- Problem: addForce(lengthInMM, forceInN) type-checks but is wrong
- Solution: Branded/nominal types

```typescript
type Millimeters = number & { readonly __brand: 'mm' };
type Inches = number & { readonly __brand: 'in' };
type Newtons = number & { readonly __brand: 'N' };
type RPM = number & { readonly __brand: 'rpm' };
type MetersPerMinute = number & { readonly __brand: 'm/min' };

// Now this is a compile error:
function calculateForce(depth: Millimeters, width: Millimeters): Newtons;
calculateForce(depthInInches, widthInMM); // ERROR!

// Helper functions
function mm(value: number): Millimeters { return value as Millimeters; }
function inches(value: number): Inches { return value as Inches; }
```

- Complete unit type library for PRISM
- Conversion functions with type safety

## SECTION 3: DISCRIMINATED UNIONS FOR MACHINES
```typescript
type Machine = 
  | { type: 'mill'; axes: 3 | 4 | 5; spindle: SpindleSpec; table: TableSpec }
  | { type: 'lathe'; turret: TurretSpec; tailstock: boolean; barFeeder?: BarFeederSpec }
  | { type: 'swiss'; guideWidth: Millimeters; slidingHeadstock: boolean }
  | { type: 'grinder'; wheelSpec: WheelSpec; dressing: DressingSpec };

// Exhaustive switch
function getMaxRPM(machine: Machine): RPM {
  switch (machine.type) {
    case 'mill': return machine.spindle.maxRPM;
    case 'lathe': return machine.turret.maxRPM;
    case 'swiss': return machine.slidingHeadstock ? rpm(12000) : rpm(8000);
    case 'grinder': return machine.wheelSpec.maxRPM;
    // TypeScript error if case missing!
  }
}
```

## SECTION 4: CONST ASSERTIONS
```typescript
const SEVERITY_LEVELS = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'] as const;
type Severity = typeof SEVERITY_LEVELS[number]; // 'CRITICAL' | 'HIGH' | ...

const MATERIAL_CATEGORIES = ['P', 'M', 'K', 'N', 'S', 'H'] as const;
type MaterialCategory = typeof MATERIAL_CATEGORIES[number];
```

## SECTION 5: TEMPLATE LITERAL TYPES
```typescript
type MaterialID = `MAT-${string}-${number}`;
type MachineID = `MCH-${string}-${number}`;
type AlarmCode = `ALM-${ControllerFamily}-${string}`;
type ToolID = `TOOL-${ToolType}-${number}`;

// Valid: 'MAT-4140-001'
// Invalid: '4140' (compile error)
```

## SECTION 6: MAPPED TYPES FOR SCHEMAS
```typescript
// Make all 127 material params validated
type ValidatedMaterial = {
  [K in keyof RawMaterial]: ValidatedParam<RawMaterial[K]>;
};

// Require specific subset
type KienzleMaterial = Required<Pick<Material, 
  'kienzleK11' | 'kienzleMc' | 'chipBreakingIndex'
>>;

// Partial for updates
type MaterialUpdate = Partial<Material> & { id: MaterialID };
```

## SECTION 7: TYPE GUARDS
```typescript
function isMill(machine: Machine): machine is MillMachine {
  return machine.type === 'mill';
}

function hasKienzleData(mat: Material): mat is KienzleMaterial {
  return mat.kienzleK11 !== undefined && mat.kienzleMc !== undefined;
}

function isValidMaterialID(id: string): id is MaterialID {
  return /^MAT-[A-Z0-9]+-\d+$/.test(id);
}
```

## SECTION 8: GENERIC CONSTRAINTS
```typescript
interface IDatabase<T extends { id: string }> {
  get(id: T['id']): Promise<T | null>;
  set(item: T): Promise<void>;
  query(predicate: (item: T) => boolean): Promise<T[]>;
}

// Now MaterialDatabase must have items with 'id' property
class MaterialDatabase implements IDatabase<Material> { ... }
```

## SECTION 9: PRISM 127-PARAMETER SCHEMA TYPING
- Complete type definitions for Material interface
- Nested types for Kienzle, Taylor, Johnson-Cook
- Optional vs required parameter handling
- Validation type predicates

## SECTION 10: ANTI-PATTERNS
- `any` usage (forbidden)
- Type assertions without guards
- Implicit any in callbacks
- Non-null assertions without checks
- 15 common mistakes

## SECTION 11: INTEGRATION
- How to type prism-material-schema
- API contract typing
- Event payload typing
```

---

# SKILL 4: prism-error-handling-patterns

## Specification

```yaml
name: prism-error-handling-patterns
level: 3 (Domain)
lines: ~600
purpose: Result types, recovery chains, graceful degradation
integrates_with:
  - prism-error-catalog
  - prism-sp-debugging
  - prism-life-safety-mindset
```

## Required Sections

```
---
name: prism-error-handling-patterns
description: |
  Error handling patterns for safety-critical manufacturing software.
  Result<T,E> types for explicit error handling. Recovery chains for
  graceful degradation. Error boundaries. Structured logging.
  Never crash - always return safe values for CNC operations.
---

# PRISM ERROR HANDLING PATTERNS
## Safety-Critical Error Management

## QUICK REFERENCE (error handling decision tree)

## SECTION 1: THE RESULT TYPE PATTERN
```typescript
type Result<T, E = PRISMError> = 
  | { success: true; value: T }
  | { success: false; error: E };

// Usage
function calculateKienzleForce(params: ForceParams): Result<ForceResult, PhysicsError> {
  if (!params.material.kienzleK11) {
    return { success: false, error: new PhysicsError('Missing Kienzle K1.1', 3001) };
  }
  
  const force = params.material.kienzleK11 * Math.pow(params.chipThickness, 1 - params.material.kienzleMc);
  return { success: true, value: { force, unit: 'N', confidence: 0.95 } };
}

// Consuming
const result = calculateKienzleForce(params);
if (result.success) {
  console.log(`Force: ${result.value.force} ${result.value.unit}`);
} else {
  console.error(`Error ${result.error.code}: ${result.error.message}`);
}
```

## SECTION 2: ERROR CLASS HIERARCHY
```typescript
class PRISMError extends Error {
  constructor(
    message: string,
    public code: number,
    public severity: Severity,
    public recoverable: boolean = true
  ) {
    super(message);
    this.name = 'PRISMError';
  }
}

class PhysicsError extends PRISMError {
  constructor(
    message: string,
    code: number,
    public formula: string,
    public inputs: Record<string, unknown>
  ) {
    super(message, code, 'HIGH', true);
    this.name = 'PhysicsError';
  }
}

class SafetyError extends PRISMError {
  constructor(message: string, code: number) {
    super(message, code, 'CRITICAL', false); // Never recoverable
    this.name = 'SafetyError';
  }
}

class ValidationError extends PRISMError { ... }
class DatabaseError extends PRISMError { ... }
class ConfigurationError extends PRISMError { ... }
```

## SECTION 3: RECOVERY CHAINS
```typescript
class ResultChain<T, E extends PRISMError> {
  constructor(private result: Result<T, E>) {}
  
  recover(handler: (error: E) => Result<T, E>): ResultChain<T, E> {
    if (this.result.success) return this;
    return new ResultChain(handler(this.result.error));
  }
  
  map<U>(fn: (value: T) => U): ResultChain<U, E> {
    if (!this.result.success) return new ResultChain(this.result as Result<U, E>);
    return new ResultChain({ success: true, value: fn(this.result.value) });
  }
  
  orDefault(defaultValue: T): T {
    return this.result.success ? this.result.value : defaultValue;
  }
  
  orThrow(): T {
    if (!this.result.success) throw this.result.error;
    return this.result.value;
  }
}

// Usage: Graceful degradation
const force = new ResultChain(calculateKienzleForce(params))
  .recover(() => calculateMerchantForce(params))      // Fallback 1
  .recover(() => useEmpirical(params.material))        // Fallback 2
  .recover(() => ({ success: true, value: SAFE_MINIMUM_FORCE })) // Safe default
  .orThrow();
```

## SECTION 4: ERROR BOUNDARIES
```typescript
// Component-level boundary
function withErrorBoundary<T>(
  operation: () => T,
  fallback: T,
  onError?: (error: Error) => void
): T {
  try {
    return operation();
  } catch (error) {
    onError?.(error as Error);
    return fallback;
  }
}

// Calculation boundary
class CalculationBoundary {
  private errors: PRISMError[] = [];
  
  execute<T>(calc: () => Result<T, PRISMError>, fallback: T): T {
    const result = calc();
    if (result.success) return result.value;
    this.errors.push(result.error);
    return fallback;
  }
  
  getErrors(): PRISMError[] { return [...this.errors]; }
  hasErrors(): boolean { return this.errors.length > 0; }
}
```

## SECTION 5: GRACEFUL DEGRADATION PATTERNS
- Full calculation → Simplified → Conservative default
- Never return undefined/null for safety values
- Always have a SAFE fallback
- Log degradation for analysis

```typescript
const DEGRADATION_LEVELS = {
  FULL: { confidence: 0.95, method: 'full_physics' },
  SIMPLIFIED: { confidence: 0.80, method: 'simplified' },
  EMPIRICAL: { confidence: 0.60, method: 'empirical' },
  CONSERVATIVE: { confidence: 0.40, method: 'conservative_default' }
} as const;
```

## SECTION 6: STRUCTURED LOGGING
```typescript
interface ErrorLog {
  timestamp: string;
  code: number;
  severity: Severity;
  message: string;
  context: {
    operation: string;
    inputs: Record<string, unknown>;
    user?: string;
    session?: string;
  };
  stack?: string;
}

function logError(error: PRISMError, context: ErrorContext): void {
  const log: ErrorLog = {
    timestamp: new Date().toISOString(),
    code: error.code,
    severity: error.severity,
    message: error.message,
    context,
    stack: error.stack
  };
  
  // Structured JSON logging
  console.error(JSON.stringify(log));
  
  // Alert if critical
  if (error.severity === 'CRITICAL') {
    alertOperations(log);
  }
}
```

## SECTION 7: USER-FACING ERROR MESSAGES
- Technical → Human readable mapping
- Actionable suggestions
- Never expose stack traces to users
- Severity indicators in UI

## SECTION 8: INTEGRATION WITH PRISM
- Links to prism-error-catalog (error codes)
- Links to prism-sp-debugging (resolution)
- Links to prism-life-safety-mindset (safety context)

## SECTION 9: ANTI-PATTERNS
- Swallowing errors silently
- Generic catch blocks
- Throwing strings
- Missing error codes
- No recovery strategy
```

---

# SKILL 5: prism-security-coding

## Specification

```yaml
name: prism-security-coding
level: 3 (Domain)
lines: ~550
purpose: OWASP principles, input validation, injection prevention
integrates_with:
  - prism-validator
  - prism-api-contracts
  - prism-gcode-reference
```

## Required Sections

```
---
name: prism-security-coding
description: |
  Security coding practices for PRISM Manufacturing Intelligence.
  Input validation, G-code injection prevention, path traversal protection,
  authentication patterns, data protection. Based on OWASP Top 10.
  Critical for CNC systems that control physical machines.
---

# PRISM SECURITY CODING
## Secure Manufacturing Intelligence

## QUICK REFERENCE (security checklist)

## SECTION 1: INPUT VALIDATION
```typescript
// Whitelist validation for material parameters
function validateMaterialParam(name: string, value: unknown): Result<number, ValidationError> {
  const schema = MATERIAL_PARAM_SCHEMA[name];
  if (!schema) {
    return { success: false, error: new ValidationError(`Unknown parameter: ${name}`, 5001) };
  }
  
  if (typeof value !== 'number') {
    return { success: false, error: new ValidationError(`${name} must be number`, 5002) };
  }
  
  if (value < schema.min || value > schema.max) {
    return { success: false, error: new ValidationError(
      `${name} must be ${schema.min}-${schema.max}, got ${value}`, 5003
    )};
  }
  
  return { success: true, value };
}

// Physics-based bounds checking
const MATERIAL_PARAM_SCHEMA = {
  hardness: { min: 10, max: 70, unit: 'HRC' },
  tensileStrength: { min: 100, max: 3000, unit: 'MPa' },
  thermalConductivity: { min: 5, max: 500, unit: 'W/mK' },
  // ... all 127 parameters with physics bounds
};
```

## SECTION 2: G-CODE INJECTION PREVENTION
```typescript
// NEVER do this:
const gcode = `G1 X${userInput} F${feedRate}`; // DANGEROUS!

// ALWAYS do this:
function generateMove(x: Millimeters, f: MetersPerMinute): string {
  // Validate inputs are numbers within bounds
  if (!isValidCoordinate(x)) throw new SecurityError('Invalid X coordinate', 8001);
  if (!isValidFeedrate(f)) throw new SecurityError('Invalid feedrate', 8002);
  
  // Use parameterized template
  return GCODE_TEMPLATES.LINEAR_MOVE
    .replace('{X}', formatCoordinate(x))
    .replace('{F}', formatFeedrate(f));
}

const GCODE_TEMPLATES = {
  LINEAR_MOVE: 'G1 X{X} F{F}',
  RAPID_MOVE: 'G0 X{X} Y{Y} Z{Z}',
  // Pre-validated templates
};

// Output encoding
function formatCoordinate(value: Millimeters): string {
  // Ensure only digits, decimal point, minus sign
  const formatted = value.toFixed(4);
  if (!/^-?\d+\.\d{4}$/.test(formatted)) {
    throw new SecurityError('Coordinate format violation', 8003);
  }
  return formatted;
}
```

## SECTION 3: PATH TRAVERSAL PREVENTION
```typescript
// NEVER do this:
const filePath = `${baseDir}/${userInput}`; // DANGEROUS!

// ALWAYS do this:
function resolveFilePath(baseDir: string, userPath: string): Result<string, SecurityError> {
  // Normalize and resolve
  const resolved = path.resolve(baseDir, userPath);
  
  // Verify still within allowed directory
  if (!resolved.startsWith(path.resolve(baseDir))) {
    return { 
      success: false, 
      error: new SecurityError('Path traversal attempt detected', 8010) 
    };
  }
  
  // Verify no dangerous patterns
  if (/\.\.|%2e%2e/i.test(userPath)) {
    return { 
      success: false, 
      error: new SecurityError('Suspicious path pattern', 8011) 
    };
  }
  
  return { success: true, value: resolved };
}
```

## SECTION 4: AUTHENTICATION PATTERNS
- Token-based authentication
- Session management best practices
- Secure token storage
- Logout and token revocation

## SECTION 5: AUTHORIZATION
```typescript
// Permission checking
interface Permission {
  resource: string;
  action: 'read' | 'write' | 'execute' | 'admin';
}

function checkPermission(user: User, required: Permission): boolean {
  return user.permissions.some(p => 
    p.resource === required.resource && 
    permissionLevel(p.action) >= permissionLevel(required.action)
  );
}

// Machine control requires elevated permissions
const DANGEROUS_OPERATIONS: Permission[] = [
  { resource: 'machine', action: 'execute' },
  { resource: 'gcode', action: 'write' },
  { resource: 'postprocessor', action: 'execute' },
];
```

## SECTION 6: DATA PROTECTION
- Encryption at rest for sensitive data
- Secure key management
- PII handling (if any)
- Audit trails

## SECTION 7: LOGGING SECURITY
```typescript
// Never log secrets
function sanitizeForLogging(obj: unknown): unknown {
  if (typeof obj !== 'object' || obj === null) return obj;
  
  const SENSITIVE_KEYS = ['password', 'token', 'apiKey', 'secret', 'credential'];
  const sanitized = { ...obj };
  
  for (const key of Object.keys(sanitized)) {
    if (SENSITIVE_KEYS.some(s => key.toLowerCase().includes(s))) {
      sanitized[key] = '[REDACTED]';
    }
  }
  
  return sanitized;
}
```

## SECTION 8: DEPENDENCY SECURITY
- npm audit / yarn audit usage
- Pinned versions for reproducibility
- Supply chain verification

## SECTION 9: OWASP TOP 10 MAPPING
| OWASP | PRISM Risk | Mitigation |
|-------|------------|------------|
| Injection | G-code injection | Parameterized templates |
| Broken Auth | Unauthorized machine control | Token + permission checks |
| Sensitive Data | Material formulas | Encryption at rest |
| ... | ... | ... |

## SECTION 10: SECURITY CHECKLIST
- 30 items for code review
```

---

# SKILL 6: prism-performance-patterns

## Specification

```yaml
name: prism-performance-patterns
level: 3 (Domain)
lines: ~500
purpose: Memoization, caching, lazy loading for calculations
integrates_with:
  - prism-code-master
  - prism-material-lookup
  - prism-speed-feed-engine
```

## Required Sections

```
---
name: prism-performance-patterns
description: |
  Performance optimization patterns for PRISM Manufacturing Intelligence.
  Memoization for expensive calculations. Multi-level caching. Lazy loading.
  Web Workers for physics engines. Targets: <2s load, <500ms calculation.
  Measure first, optimize second.
---

# PRISM PERFORMANCE PATTERNS
## Efficient Manufacturing Intelligence

## QUICK REFERENCE (performance targets)

```
PRISM PERFORMANCE TARGETS:
- Initial load: < 2 seconds
- Material lookup: < 50ms
- Speed/feed calculation: < 500ms
- Toolpath preview: < 1 second
- Full simulation: < 5 seconds
```

## SECTION 1: MEMOIZATION
```typescript
// Generic memoization with TTL and max size
function memoize<Args extends unknown[], R>(
  fn: (...args: Args) => R,
  options: {
    maxSize?: number;
    ttl?: number; // milliseconds
    keyFn?: (...args: Args) => string;
  } = {}
): (...args: Args) => R {
  const { maxSize = 1000, ttl = 60000, keyFn = JSON.stringify } = options;
  const cache = new Map<string, { value: R; timestamp: number }>();
  
  return (...args: Args): R => {
    const key = keyFn(...args);
    const cached = cache.get(key);
    
    if (cached && Date.now() - cached.timestamp < ttl) {
      return cached.value;
    }
    
    const value = fn(...args);
    
    // LRU eviction if at capacity
    if (cache.size >= maxSize) {
      const oldestKey = cache.keys().next().value;
      cache.delete(oldestKey);
    }
    
    cache.set(key, { value, timestamp: Date.now() });
    return value;
  };
}

// PRISM usage: Memoize Kienzle calculation
const memoizedKienzle = memoize(calculateKienzleForce, {
  maxSize: 1000,
  ttl: 300000, // 5 minutes
  keyFn: (mat, params) => `${mat.id}:${params.depth}:${params.width}:${params.speed}`
});
```

## SECTION 2: MULTI-LEVEL CACHING
```typescript
// L1: In-memory (fastest, smallest)
// L2: IndexedDB (persistent, larger)
// L3: Server cache (shared, largest)

class MultiLevelCache<T> {
  constructor(
    private l1: MemoryCache<T>,
    private l2: IndexedDBCache<T>,
    private l3?: ServerCache<T>
  ) {}
  
  async get(key: string): Promise<T | null> {
    // Check L1
    const l1Result = this.l1.get(key);
    if (l1Result) return l1Result;
    
    // Check L2
    const l2Result = await this.l2.get(key);
    if (l2Result) {
      this.l1.set(key, l2Result); // Promote to L1
      return l2Result;
    }
    
    // Check L3
    if (this.l3) {
      const l3Result = await this.l3.get(key);
      if (l3Result) {
        this.l1.set(key, l3Result);
        await this.l2.set(key, l3Result);
        return l3Result;
      }
    }
    
    return null;
  }
  
  async set(key: string, value: T): Promise<void> {
    this.l1.set(key, value);
    await this.l2.set(key, value);
    if (this.l3) await this.l3.set(key, value);
  }
}
```

## SECTION 3: LAZY LOADING
```typescript
// Lazy-loaded material database
class LazyMaterialDatabase {
  private materials: Map<string, Material> = new Map();
  private loadedCategories: Set<string> = new Set();
  
  async getMaterial(id: MaterialID): Promise<Material | null> {
    // Check if already loaded
    if (this.materials.has(id)) {
      return this.materials.get(id)!;
    }
    
    // Load category on demand
    const category = this.extractCategory(id); // e.g., 'P' for steels
    if (!this.loadedCategories.has(category)) {
      await this.loadCategory(category);
    }
    
    return this.materials.get(id) ?? null;
  }
  
  private async loadCategory(category: string): Promise<void> {
    const materials = await fetch(`/api/materials?category=${category}`);
    for (const mat of materials) {
      this.materials.set(mat.id, mat);
    }
    this.loadedCategories.add(category);
  }
}
```

## SECTION 4: WEB WORKERS FOR HEAVY CALCULATIONS
```typescript
// physics-worker.ts
self.onmessage = (e: MessageEvent<PhysicsRequest>) => {
  const { type, params } = e.data;
  
  switch (type) {
    case 'kienzle':
      postMessage({ type: 'result', value: calculateKienzle(params) });
      break;
    case 'stability':
      postMessage({ type: 'result', value: calculateStabilityLobes(params) });
      break;
  }
};

// main thread
class PhysicsWorkerPool {
  private workers: Worker[] = [];
  private queue: Array<{ resolve: Function; reject: Function; task: PhysicsRequest }> = [];
  
  constructor(poolSize: number = navigator.hardwareConcurrency || 4) {
    for (let i = 0; i < poolSize; i++) {
      const worker = new Worker('/workers/physics-worker.js');
      worker.onmessage = (e) => this.handleResult(worker, e.data);
      this.workers.push(worker);
    }
  }
  
  async calculate(task: PhysicsRequest): Promise<PhysicsResult> {
    return new Promise((resolve, reject) => {
      const availableWorker = this.getAvailableWorker();
      if (availableWorker) {
        availableWorker.postMessage(task);
      } else {
        this.queue.push({ resolve, reject, task });
      }
    });
  }
}
```

## SECTION 5: BATCH PROCESSING
```typescript
// Batch material lookups
class BatchedMaterialLookup {
  private pending: Map<string, Array<(mat: Material | null) => void>> = new Map();
  private batchTimeout: ReturnType<typeof setTimeout> | null = null;
  
  get(id: MaterialID): Promise<Material | null> {
    return new Promise((resolve) => {
      if (!this.pending.has(id)) {
        this.pending.set(id, []);
      }
      this.pending.get(id)!.push(resolve);
      
      if (!this.batchTimeout) {
        this.batchTimeout = setTimeout(() => this.flush(), 10); // 10ms batch window
      }
    });
  }
  
  private async flush(): Promise<void> {
    const ids = Array.from(this.pending.keys());
    const materials = await this.batchFetch(ids);
    
    for (const [id, resolvers] of this.pending) {
      const material = materials.find(m => m.id === id) ?? null;
      resolvers.forEach(resolve => resolve(material));
    }
    
    this.pending.clear();
    this.batchTimeout = null;
  }
}
```

## SECTION 6: PROFILING & MEASUREMENT
```typescript
// Performance measurement decorator
function measure(target: any, key: string, descriptor: PropertyDescriptor) {
  const original = descriptor.value;
  
  descriptor.value = function(...args: any[]) {
    const start = performance.now();
    const result = original.apply(this, args);
    
    if (result instanceof Promise) {
      return result.finally(() => {
        const duration = performance.now() - start;
        console.log(`${key}: ${duration.toFixed(2)}ms`);
        if (duration > 500) {
          console.warn(`${key} exceeded 500ms threshold`);
        }
      });
    }
    
    const duration = performance.now() - start;
    console.log(`${key}: ${duration.toFixed(2)}ms`);
    return result;
  };
}

// Usage
class SpeedFeedCalculator {
  @measure
  calculateOptimalParams(material: Material, tool: Tool): SpeedFeedResult {
    // ...
  }
}
```

## SECTION 7: OPTIMIZATION GATES
- ALWAYS measure before optimizing
- Profile in production-like environment
- Regression testing for performance
- Budget allocation per component

## SECTION 8: ANTI-PATTERNS
- Premature optimization
- Optimizing without measuring
- Micro-optimizations over architecture
- Caching without invalidation strategy
- Blocking main thread with calculations

## SECTION 9: PERFORMANCE CHECKLIST
- 20 items for performance review
```

---

# INTEGRATION UPDATES

## prism-all-skills v6.0 Updates

Add to LEVEL 3: DOMAIN section:

```markdown
**Code Practices (6 NEW):**
- prism-solid-principles - SOLID for manufacturing
- prism-design-patterns - GoF patterns
- prism-typescript-safety - Type safety
- prism-error-handling-patterns - Result types, recovery
- prism-security-coding - OWASP, validation
- prism-performance-patterns - Caching, workers
```

Update counts:
- Skills: 100 → 106
- Hooks: 152 (unchanged)
- Formulas: 25 (unchanged)

---

# VERIFICATION CHECKLIST

After each skill creation, verify:

```
□ File exists at C:\PRISM\skills-consolidated\prism-[name]\SKILL.md
□ YAML frontmatter is valid (name, description)
□ All required sections present
□ Manufacturing examples ≥ 10
□ Code examples compile (TypeScript)
□ Integration links to other skills
□ Anti-patterns section included
□ Checklist section included
□ Line count ≥ 400
```

---

# QUICK START COMMAND

For the main chat, start with:

```
Execute PRISM_CODING_PRACTICES_ROADMAP.md starting at MS1.
Create prism-solid-principles first, then prism-design-patterns.
Use chunked file creation for files > 25KB.
Checkpoint after each skill.
```

---

**APPROVED FOR EXECUTION**
**Version 1.0 | 2026-01-29 | 6 Skills | ~3,850 Lines**
