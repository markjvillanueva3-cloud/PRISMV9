# PRISM MCP Developer Intelligence Server - Development Handoff

## What We're Building
An MCP server that transforms Claude from a chatbot into an agentic development partner. Target codebase: 986K line monolith (PRISM Manufacturing Intelligence).

## Your Full Specification
The complete spec is at: `/mnt/skills/user/prism-mcp-intelligence/SKILL.md` (or will be uploaded with this prompt)
- 3,000+ lines with all tool interfaces, formulas, and implementation details
- TypeScript interfaces for every tool
- Mathematical foundations for all engines

## Build Order (80/20 - These 5 give you 80% of the value)

### Week 1-2: Foundation
1. **Checkpoint & Rollback** - Ephemeral save states for fearless experimentation. Uses tar compression, stores in `.mcp-checkpoints/`. Every agentic workflow needs undo.

2. **Background Task Orchestrator** - Async execution for tests/builds. Use `execa` for spawning, stream output to temp files. Returns task_id for polling.

3. **Subagent Spawner** - Delegate research to separate context windows. Pre-defined templates: security-reviewer, test-writer, bug-hunter, refactor-advisor.

### Week 3-4: Core
4. **Impact Analysis** - Know what breaks before editing. Build import graph with tree-sitter, cache incrementally. Risk scoring formula included in spec.

5. **Semantic Search** - Find code by meaning. Use LanceDB + nomic-embed-text. Chunk by AST boundaries, not arbitrary lines.

## Key Design Principles
- Structured output always (JSON, never raw CLI text)
- Async-first (long ops run in background)
- Safe by default (destructive ops require confirmation)
- Don't reinvent: use simple-git, ripgrep, ESLint directly

## Don't Build (Use Existing)
- Git operations → `simple-git` library
- Code search → ripgrep + tree-sitter
- Test runner → Direct Jest/Vitest calls (already JSON)
- Browser automation → Playwright MCP exists

## Novel Value (Build These - No One Has Them)
- **Causal Inference Engine** - Pearl's do-calculus for code
- **Code Thermodynamics** - Entropy measurement for codebase health
- **Cognitive Load Optimizer** - Sweller's CLT applied to code
- **Omega Equation** - Unified quality score with learnable weights

## Tech Stack
```json
{
  "@modelcontextprotocol/sdk": "^1.0.0",
  "execa": "^8.0.0", 
  "simple-git": "^3.24.0",
  "tree-sitter": "^0.21.0",
  "lancedb": "^0.5.0",
  "@xenova/transformers": "^2.17.0",
  "tar": "^6.2.0"
}
```

## Directory Structure
```
prism-mcp-intelligence/
├── src/
│   ├── tools/foundation/   # checkpoints, tasks, subagents, impact, semantic
│   ├── tools/workflow/     # git, test, search, lint, diff
│   ├── engines/            # causal, entropy, fault, cognitive
│   ├── meta/               # self-improve, intention, pattern
│   └── omega/              # compute, optimize, learn
├── data/
│   ├── .mcp-checkpoints/
│   ├── .mcp-index/
│   └── .mcp-learning/
```

## Start Here
```bash
mkdir prism-mcp-intelligence && cd prism-mcp-intelligence
npm init -y
npm install @modelcontextprotocol/sdk zod execa simple-git tar
```

Then implement `checkpoint_create`, `checkpoint_restore`, `checkpoint_diff` first. Test manually. Then `task_spawn`, `task_status`, `task_kill`.

---

## Quick Reference: Priority 1 Tool Interfaces

### Checkpoint Tools
```typescript
// checkpoint_create
{ label: string, paths?: string[], include_untracked?: boolean }
→ { checkpoint_id, files_captured, size_bytes, git_state }

// checkpoint_restore  
{ checkpoint_id: string, paths?: string[], dry_run?: boolean }
→ { restored_files, skipped_files, conflicts? }

// checkpoint_diff
{ checkpoint_id: string, paths?: string[] }
→ { files_added, files_modified, files_deleted, diff_summary }
```

### Background Task Tools
```typescript
// task_spawn
{ command: string, label: string, timeout_minutes?: number }
→ { task_id, status: "running", pid }

// task_status
{ task_id: string }
→ { status, exit_code?, output, duration_ms }

// task_kill
{ task_id: string, signal?: "SIGTERM" | "SIGKILL" }
→ { killed, final_output, exit_code }
```

### Subagent Tools
```typescript
// subagent_spawn
{ name: string, task: string, tools?: string[], context_files?: string[] }
→ { agent_id, status, result?, tokens_used, duration_ms }

// subagent_template
{ template: "security-reviewer" | "test-writer" | "bug-hunter", target: string }
→ { agent_id, status, result? }
```

### Impact Analysis Tools
```typescript
// code_impact
{ file: string, line_range?: [number, number], symbol?: string }
→ { direct_importers, transitive_dependents, test_coverage, breaking_risk }

// impact_test_map
{ file: string, function_name?: string }
→ { tests, uncovered_lines, coverage_percent, suggested_tests }
```

### Semantic Search Tools
```typescript
// semantic_index_build
{ paths?: string[], force_rebuild?: boolean }
→ { files_indexed, chunks_created, duration_ms }

// semantic_search
{ query: string, top_k?: number, min_score?: number }
→ { results: [{ file, start_line, end_line, code, score, summary }] }
```

---

## Implementation Notes

### Checkpoints
- Store in `.mcp-checkpoints/` (add to .gitignore)
- Use `tar` for compression
- Store file hashes for fast diff
- Max 20 checkpoints with LRU cleanup
- Capture git state (branch, commit, dirty) as metadata

### Background Tasks
- Use `execa` for process spawning
- Stream output to temp files
- Use `tree-kill` for killing process trees
- Max 10 concurrent tasks
- Clean up on server shutdown

### Subagents
- Each runs in isolated context
- Main agent receives only summary
- Can run multiple in parallel
- Great for research that reads many files

### Impact Analysis
- Build import graph on first call
- Cache and update incrementally
- Use tree-sitter for language-aware parsing
- Risk formula: `(direct_importers * 2 + transitive * 0.5) * (1 + exports * 0.3) * (has_tests ? 0.5 : 1.5)`

### Semantic Search
- Embedding: nomic-embed-text or minilm
- Vector store: LanceDB (embedded, no server)
- Chunk by AST boundaries (functions, classes)
- Incremental: hash files, re-index on change

---

**Reference the full SKILL.md for complete TypeScript interfaces, mathematical formulas, and all 50+ tools across 5 tiers.**
