# MCP Developer Tools Server - Complete Implementation Handoff

## Context

Build a comprehensive MCP server that transforms Claude from a chatbot into an agentic development partner. This server provides tools for async task execution, safe code modification, intelligent search, and workflow automation.

Target stack: TypeScript + official MCP SDK, streamable HTTP transport (stdio fallback for local).

The tools are ordered by impact—implement in sequence, each tier builds on the previous.

---

# TIER 1: GAME CHANGERS (Implement First)

These fundamentally change what's possible.

---

## 1. Background Task Orchestrator

**Why first**: Everything else benefits from async execution. Tests, builds, lints can run in background while conversation continues.

```typescript
task_spawn
// Starts a long-running process in background
// Parameters: { 
//   command: string,           // "npm test", "cargo build", etc.
//   label: string,             // Human-readable identifier
//   working_dir?: string,      // Override default working directory
//   timeout_minutes?: number,  // Default 10
//   env?: Record<string, string>
// }
// Returns: { task_id: string, status: "running", started_at: string }
// Annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: true }

task_status
// Check on a running/completed task
// Parameters: { task_id: string }
// Returns: { 
//   task_id: string,
//   label: string,
//   status: "running" | "completed" | "failed" | "timeout",
//   exit_code?: number,
//   output: string,            // stdout + stderr combined
//   duration_ms: number,
//   started_at: string,
//   completed_at?: string
// }

task_stream
// Get incremental output from running task
// Parameters: { task_id: string, since_line?: number }
// Returns: { 
//   new_lines: string[],
//   total_lines: number,
//   completed: boolean,
//   exit_code?: number
// }

task_kill
// Terminate a running task
// Parameters: { task_id: string }
// Returns: { killed: boolean, final_output: string }
// Annotations: { destructiveHint: true }

task_list
// List all tasks (active and recent)
// Parameters: { status_filter?: "running" | "completed" | "failed", limit?: number }
// Returns: { tasks: Array<{ task_id, label, status, started_at, duration_ms }> }
```

### Implementation Notes:
- Use `execa` with `subprocess.pid` tracking
- Store task state in memory (Map) with configurable history limit
- Stream output to temp files, read incrementally for `task_stream`
- Implement proper cleanup on server shutdown
- Consider using `tree-kill` for killing process trees

---

## 2. Checkpoint & Rollback

**Why second**: Enables fearless experimentation. Make risky changes knowing you can instantly revert.

```typescript
checkpoint_create
// Snapshot current state (including uncommitted changes)
// Parameters: { 
//   label: string,                    // "before-refactor", "pre-migration"
//   paths?: string[],                 // Specific paths, default entire working dir
//   include_untracked?: boolean,      // Default true
//   include_gitignored?: boolean      // Default false
// }
// Returns: { 
//   checkpoint_id: string,
//   label: string,
//   created_at: string,
//   files_captured: number,
//   size_bytes: number,
//   git_state: { branch: string, commit: string, dirty: boolean }
// }

checkpoint_list
// List available checkpoints
// Parameters: { limit?: number }
// Returns: { checkpoints: Array<{ checkpoint_id, label, created_at, files_captured, size_bytes }> }

checkpoint_diff
// Compare current state to checkpoint
// Parameters: { checkpoint_id: string, paths?: string[] }
// Returns: { 
//   files_added: string[],
//   files_modified: string[],
//   files_deleted: string[],
//   diff_summary: string,      // Unified diff format
//   total_changes: number
// }

checkpoint_restore
// Revert to checkpoint state
// Parameters: { 
//   checkpoint_id: string,
//   paths?: string[],          // Partial restore if specified
//   dry_run?: boolean          // Preview what would be restored
// }
// Returns: { 
//   restored_files: string[],
//   conflicts?: Array<{ file: string, reason: string }>,
//   dry_run: boolean
// }
// Annotations: { destructiveHint: true, idempotentHint: false }

checkpoint_delete
// Remove a checkpoint
// Parameters: { checkpoint_id: string }
// Returns: { deleted: boolean, freed_bytes: number }
// Annotations: { destructiveHint: true }
```

### Implementation Notes:
- Store checkpoints in `.mcp-checkpoints/` directory (gitignored)
- Use tar/zip for efficient storage
- Capture git state (branch, HEAD, staged changes) as metadata
- For partial restore, apply only specified paths
- Implement max checkpoint limit with auto-cleanup of oldest

---

## 3. Impact Analysis

**Why third**: Before any edit, know exactly what could break. Essential for large codebases.

```typescript
code_impact
// Analyze impact of changing a file or symbol
// Parameters: { 
//   file: string,
//   line_range?: [number, number],    // Specific lines, or entire file
//   symbol?: string                   // Specific function/class name
// }
// Returns: { 
//   target: { file: string, lines?: [number, number], symbol?: string },
//   direct_importers: Array<{ file: string, import_line: number }>,
//   transitive_dependents: number,    // Files that indirectly depend
//   test_coverage: Array<{ 
//     test_file: string, 
//     test_names: string[],
//     coverage_type: "direct" | "indirect" 
//   }>,
//   exports_affected: string[],       // Exported symbols that could break
//   breaking_risk: "critical" | "high" | "medium" | "low",
//   risk_reasons: string[],
//   suggested_actions: string[]       // "Run tests in src/__tests__/foo.test.ts"
// }

impact_test_map
// Find all tests that exercise given code
// Parameters: { file: string, function_name?: string }
// Returns: { 
//   tests: Array<{ 
//     test_file: string, 
//     test_name: string, 
//     coverage_lines: number[],
//     execution_path: string[]        // Call stack to reach this code
//   }>,
//   uncovered_lines: number[],
//   coverage_percent: number
// }

impact_dependency_graph
// Get full dependency graph for a file
// Parameters: { file: string, depth?: number, direction?: "importers" | "imports" | "both" }
// Returns: { 
//   nodes: Array<{ file: string, depth: number }>,
//   edges: Array<{ from: string, to: string, import_type: "static" | "dynamic" }>,
//   cycles?: Array<string[]>          // Circular dependency chains
// }
```

### Implementation Notes:
- Build import graph on first call, cache and update incrementally
- Use AST parsing (tree-sitter or ts-morph for TS) to extract imports/exports
- For test mapping, analyze test files for imports, or integrate with coverage tools
- Risk assessment heuristics: more importers = higher risk, exported symbols = higher risk

---

## 4. Semantic Code Search

**Why fourth**: Find code by meaning, not just keywords. Critical for inconsistently-named large codebases.

```typescript
semantic_index_build
// Build/rebuild the semantic search index
// Parameters: { 
//   paths?: string[],          // Default: entire workspace
//   force_rebuild?: boolean    // Ignore existing index
// }
// Returns: { 
//   files_indexed: number,
//   chunks_created: number,
//   duration_ms: number,
//   index_size_mb: number
// }

semantic_search
// Search code by natural language description
// Parameters: { 
//   query: string,             // "function that calculates tool wear"
//   top_k?: number,            // Default 10
//   file_pattern?: string,     // Filter to specific files
//   min_score?: number         // Similarity threshold 0-1
// }
// Returns: { 
//   results: Array<{
//     file: string,
//     start_line: number,
//     end_line: number,
//     code: string,
//     score: number,            // Similarity score 0-1
//     summary: string           // Auto-generated description
//   }>,
//   query_embedding_cached: boolean
// }

semantic_similar
// Find code similar to a given snippet
// Parameters: { 
//   file: string,
//   start_line: number,
//   end_line: number,
//   top_k?: number
// }
// Returns: { 
//   similar: Array<{ file: string, start_line: number, end_line: number, code: string, score: number }>
// }
```

### Implementation Notes:
- Use local embedding model: `nomic-embed-text` via Ollama, or `@xenova/transformers`
- Vector store: LanceDB (embedded, no server) or ChromaDB
- Chunk code by function/class boundaries, not arbitrary line counts
- Store metadata: file path, line range, language, symbols defined
- Incremental updates: re-index only changed files (watch for file changes)

---

## 5. Live Context Sync

**Why fifth**: Know when files change outside the conversation. Stay synchronized with reality.

```typescript
context_watch_start
// Start watching for file changes
// Parameters: { 
//   paths: string[],           // Directories or files to watch
//   events?: ("modify" | "create" | "delete" | "rename")[],
//   ignore_patterns?: string[] // Default: node_modules, .git, etc.
// }
// Returns: { watcher_id: string, watching: string[], started_at: string }

context_watch_stop
// Stop a watcher
// Parameters: { watcher_id: string }
// Returns: { stopped: boolean }

context_changes
// Get changes since last check
// Parameters: { 
//   watcher_id: string,
//   since?: string,            // ISO timestamp
//   summarize?: boolean        // Include AI-generated summaries
// }
// Returns: { 
//   events: Array<{
//     type: "modify" | "create" | "delete" | "rename",
//     path: string,
//     timestamp: string,
//     summary?: string,         // "Added function handleError()"
//     diff_snippet?: string     // For modifications
//   }>,
//   files_affected: number,
//   context_stale: boolean      // True if significant changes occurred
// }

context_snapshot
// Get current state summary of watched paths
// Parameters: { watcher_id: string }
// Returns: { 
//   files: Array<{ path: string, size_bytes: number, modified_at: string }>,
//   total_files: number,
//   last_change: string
// }
```

### Implementation Notes:
- Use `chokidar` for cross-platform file watching
- Debounce rapid changes (100ms)
- For summaries, diff the file and generate brief description
- Store events in ring buffer (last N events per watcher)
- Auto-cleanup watchers after inactivity timeout

---

# TIER 2: FORCE MULTIPLIERS

Build on Tier 1 capabilities.

---

## 6. Git Operations

```typescript
git_status
// Returns: { 
//   branch: string,
//   staged: Array<{ file: string, status: "added" | "modified" | "deleted" }>,
//   unstaged: Array<{ file: string, status: "modified" | "deleted" }>,
//   untracked: string[],
//   ahead: number,
//   behind: number,
//   stash_count: number
// }

git_diff
// Parameters: { file?: string, staged?: boolean, commit_range?: string, context_lines?: number }
// Returns: { 
//   diff: string,
//   files: Array<{ file: string, insertions: number, deletions: number }>,
//   total_insertions: number,
//   total_deletions: number
// }

git_log
// Parameters: { count?: number, author?: string, since?: string, until?: string, path?: string, grep?: string }
// Returns: { 
//   commits: Array<{ 
//     hash: string, 
//     short_hash: string,
//     author: string, 
//     date: string, 
//     message: string,
//     files_changed: number
//   }> 
// }

git_blame
// Parameters: { file: string, start_line?: number, end_line?: number }
// Returns: { 
//   lines: Array<{ 
//     line_number: number, 
//     commit: string, 
//     author: string, 
//     date: string, 
//     content: string 
//   }> 
// }

git_commit
// Parameters: { message: string, files?: string[], all?: boolean, amend?: boolean }
// Returns: { hash: string, message: string, files_committed: string[] }
// Annotations: { destructiveHint: true, idempotentHint: false }

git_branch
// Parameters: { action: "list" | "create" | "switch" | "delete" | "rename", name?: string, new_name?: string, force?: boolean }
// Returns: { branches?: Array<{ name: string, current: boolean, tracking?: string }>, result?: string }
// Annotations: { destructiveHint: true } // for delete

git_stash
// Parameters: { action: "push" | "pop" | "apply" | "list" | "drop" | "clear", message?: string, index?: number }
// Returns: { stashes?: Array<{ index: number, message: string, date: string }>, result?: string }
// Annotations: { destructiveHint: true } // for drop, clear

git_reset
// Parameters: { mode: "soft" | "mixed" | "hard", target?: string, files?: string[] }
// Returns: { reset_to: string, files_affected: string[] }
// Annotations: { destructiveHint: true }
```

### Implementation Notes:
- Use `simple-git` npm package
- Always return structured data, parse git output
- Include safety checks for destructive operations

---

## 7. Test Runner

```typescript
test_run
// Parameters: { 
//   pattern?: string,          // Test name pattern
//   file?: string,             // Specific test file
//   coverage?: boolean,
//   watch?: boolean,           // Returns task_id for background watch
//   update_snapshots?: boolean,
//   bail?: boolean             // Stop on first failure
// }
// Returns: { 
//   passed: number,
//   failed: number,
//   skipped: number,
//   duration_ms: number,
//   failures: Array<{ 
//     test: string, 
//     file: string, 
//     line: number,
//     error: string,
//     expected?: string,
//     actual?: string,
//     stack?: string
//   }>,
//   task_id?: string           // If watch mode
// }

test_run_affected
// Run only tests affected by recent changes
// Parameters: { since?: string, include_dependents?: boolean }
// Returns: { 
//   ...test_run returns,
//   affected_files: string[],
//   tests_selected: number,
//   tests_skipped_reason: string  // "No changes affect tests"
// }

test_coverage
// Parameters: { file?: string, threshold?: number }
// Returns: { 
//   summary: { lines: number, covered: number, percent: number, meets_threshold: boolean },
//   files: Array<{ 
//     path: string, 
//     lines: number, 
//     covered: number, 
//     percent: number,
//     uncovered_lines: number[]
//   }>,
//   branches?: { total: number, covered: number, percent: number }
// }

test_debug
// Get detailed info for debugging a failing test
// Parameters: { test_name: string, file: string }
// Returns: { 
//   test_code: string,
//   setup_code: string,         // beforeEach, etc.
//   last_run: { passed: boolean, error?: string, duration_ms: number },
//   related_source_files: string[],
//   suggested_breakpoints: Array<{ file: string, line: number, reason: string }>
// }
```

### Implementation Notes:
- Auto-detect framework from package.json (jest, vitest, mocha, pytest, cargo test)
- Parse JSON reporter output for structured results
- For affected tests, use git diff + import graph from impact analysis

---

## 8. Code Search (Text-Based)

```typescript
code_search
// Fast text/regex search
// Parameters: { 
//   query: string,
//   regex?: boolean,
//   file_pattern?: string,     // "*.ts", "src/**/*.js"
//   ignore_case?: boolean,
//   whole_word?: boolean,
//   context_lines?: number,    // Default 2
//   max_results?: number       // Default 100
// }
// Returns: { 
//   matches: Array<{
//     file: string,
//     line: number,
//     column: number,
//     content: string,
//     context_before: string[],
//     context_after: string[]
//   }>,
//   total_matches: number,
//   files_searched: number,
//   truncated: boolean
// }

code_search_replace
// Search and replace with preview
// Parameters: { 
//   search: string,
//   replace: string,
//   regex?: boolean,
//   file_pattern?: string,
//   dry_run?: boolean          // Default true
// }
// Returns: { 
//   replacements: Array<{ file: string, line: number, before: string, after: string }>,
//   files_affected: number,
//   total_replacements: number,
//   applied: boolean
// }
// Annotations: { destructiveHint: true } // when dry_run=false

code_symbols
// Find symbols (functions, classes, etc.)
// Parameters: { 
//   name?: string,             // Symbol name pattern
//   type?: "function" | "class" | "interface" | "variable" | "type" | "enum",
//   file_pattern?: string,
//   exported_only?: boolean
// }
// Returns: { 
//   symbols: Array<{
//     name: string,
//     type: string,
//     file: string,
//     line: number,
//     signature?: string,
//     exported: boolean,
//     jsdoc?: string
//   }>
// }

code_references
// Find all references to a symbol
// Parameters: { symbol: string, file?: string, include_definition?: boolean }
// Returns: { 
//   definition?: { file: string, line: number, code: string },
//   references: Array<{ 
//     file: string, 
//     line: number, 
//     context: string,
//     type: "read" | "write" | "call" | "import"
//   }>,
//   total: number
// }
```

### Implementation Notes:
- Use ripgrep (`@vscode/ripgrep` or spawn `rg`) for fast text search
- Use tree-sitter for symbol extraction (language-aware)
- Respect .gitignore by default
- Cap results to prevent context overflow

---

## 9. Lint & Build

```typescript
lint_run
// Parameters: { 
//   files?: string[],          // Specific files, or entire workspace
//   fix?: boolean,
//   rules?: string[],          // Specific rules to check
//   format?: "stylish" | "json"
// }
// Returns: { 
//   errors: Array<{ 
//     file: string, 
//     line: number, 
//     column: number, 
//     rule: string, 
//     message: string, 
//     severity: "error" | "warning" | "info",
//     fixable: boolean,
//     suggestion?: string
//   }>,
//   error_count: number,
//   warning_count: number,
//   fixable_count: number,
//   fixed_count?: number       // If fix=true
// }

lint_fix
// Auto-fix all fixable issues
// Parameters: { files?: string[], dry_run?: boolean }
// Returns: { 
//   fixed: Array<{ file: string, rule: string, line: number }>,
//   unfixable: Array<{ file: string, rule: string, message: string }>,
//   files_modified: string[]
// }
// Annotations: { destructiveHint: true }

build_check
// Type-check without emitting
// Parameters: { incremental?: boolean }
// Returns: { 
//   success: boolean,
//   errors: Array<{ 
//     file: string, 
//     line: number, 
//     column: number, 
//     code: string,           // TS2322, etc.
//     message: string 
//   }>,
//   duration_ms: number
// }

build_run
// Full build
// Parameters: { clean?: boolean, production?: boolean }
// Returns: { 
//   success: boolean,
//   errors: Array<{ file: string, line: number, message: string }>,
//   output_dir: string,
//   duration_ms: number,
//   task_id?: string          // If spawned as background task
// }
```

### Implementation Notes:
- Auto-detect linter (eslint, biome, ruff) from config files
- Parse JSON output for structured errors
- For build, detect from package.json scripts or tsconfig.json

---

## 10. Diff & Patch

```typescript
diff_generate
// Create patch from current changes
// Parameters: { file?: string, staged?: boolean, format?: "unified" | "json" }
// Returns: { 
//   patch: string,
//   hunks: Array<{
//     file: string,
//     old_start: number,
//     old_lines: number,
//     new_start: number,
//     new_lines: number,
//     content: string
//   }>,
//   files_affected: number
// }

diff_apply
// Apply a patch
// Parameters: { 
//   patch: string,
//   reverse?: boolean,
//   dry_run?: boolean,
//   fuzz?: number              // Allow fuzzy matching
// }
// Returns: { 
//   applied: boolean,
//   files_modified: string[],
//   hunks_applied: number,
//   hunks_failed: number,
//   errors?: Array<{ file: string, reason: string }>
// }
// Annotations: { destructiveHint: true }

diff_preview
// Preview changes before applying
// Parameters: { 
//   file: string,
//   changes: Array<{ 
//     line: number, 
//     action: "insert" | "delete" | "replace",
//     content?: string
//   }>
// }
// Returns: { 
//   before: string,
//   after: string,
//   diff: string,
//   valid: boolean,
//   errors?: string[]
// }

diff_three_way
// Merge changes from two sources
// Parameters: { base: string, ours: string, theirs: string }
// Returns: { 
//   merged: string,
//   conflicts: Array<{ 
//     start_line: number, 
//     end_line: number,
//     ours: string,
//     theirs: string
//   }>,
//   auto_resolved: number,
//   manual_required: number
// }
```

---

# TIER 3: ADVANCED CAPABILITIES

---

## 11. Multi-File Refactor

```typescript
refactor_rename
// Rename symbol across entire codebase
// Parameters: { 
//   symbol: string,
//   new_name: string,
//   file?: string,             // Scope to specific file's symbol
//   dry_run?: boolean
// }
// Returns: { 
//   occurrences: Array<{ file: string, line: number, before: string, after: string }>,
//   files_modified: string[],
//   total_replacements: number,
//   applied: boolean
// }
// Annotations: { destructiveHint: true }

refactor_extract_function
// Extract code into new function
// Parameters: { 
//   file: string,
//   start_line: number,
//   end_line: number,
//   function_name: string,
//   parameters?: Array<{ name: string, type?: string }>
// }
// Returns: { 
//   extracted_function: string,
//   call_site: string,
//   file_diff: string,
//   warnings?: string[]        // "Variable 'x' is modified, consider passing by reference"
// }
// Annotations: { destructiveHint: true }

refactor_move
// Move symbol to different file
// Parameters: { 
//   symbol: string,
//   from_file: string,
//   to_file: string,
//   update_imports?: boolean
// }
// Returns: { 
//   moved: boolean,
//   imports_updated: Array<{ file: string, changes: string }>,
//   files_modified: string[],
//   warnings?: string[]
// }
// Annotations: { destructiveHint: true }

refactor_inline
// Inline a function/variable
// Parameters: { symbol: string, file: string, line: number }
// Returns: { 
//   inlined_at: Array<{ file: string, line: number }>,
//   definition_removed: boolean,
//   files_modified: string[]
// }
// Annotations: { destructiveHint: true }
```

---

## 12. Execution Sandbox

```typescript
sandbox_run
// Execute code in isolated environment
// Parameters: { 
//   code: string,
//   language?: "javascript" | "typescript" | "python",
//   timeout_ms?: number,       // Default 5000
//   memory_limit_mb?: number,  // Default 128
//   imports?: string[]         // Modules to make available
// }
// Returns: { 
//   stdout: string,
//   stderr: string,
//   return_value?: any,        // If expression returns value
//   exit_code: number,
//   runtime_ms: number,
//   memory_used_mb: number
// }

sandbox_eval
// Evaluate expression in project context
// Parameters: { 
//   expression: string,
//   file_context?: string,     // File to import before eval
//   timeout_ms?: number
// }
// Returns: { 
//   result: any,
//   type: string,
//   stringified: string,
//   runtime_ms: number
// }

sandbox_repl
// Start interactive REPL session
// Parameters: { language: string, preload_files?: string[] }
// Returns: { session_id: string, ready: boolean }

sandbox_repl_exec
// Execute in REPL session (maintains state)
// Parameters: { session_id: string, code: string }
// Returns: { result: any, stdout: string, stderr: string }
```

### Implementation Notes:
- Use VM2 or isolated-vm for JavaScript sandboxing
- For Python, use subprocess with resource limits
- Timeout and memory limits are critical for safety

---

## 13. Context Compression

```typescript
context_summarize
// Summarize conversation/changes for handoff
// Parameters: { 
//   focus?: "decisions" | "code_changes" | "todos" | "all",
//   since?: string,            // Timestamp or "session_start"
//   format?: "markdown" | "json"
// }
// Returns: { 
//   summary: string,
//   key_decisions: Array<{ decision: string, reasoning: string, timestamp: string }>,
//   files_modified: Array<{ file: string, change_type: string, summary: string }>,
//   open_questions: string[],
//   blockers: string[],
//   next_actions: Array<{ action: string, priority: "high" | "medium" | "low" }>,
//   metadata: { 
//     conversation_length: number,
//     time_span_minutes: number,
//     tools_used: string[]
//   }
// }

context_export
// Export full context for session transfer
// Parameters: { include_file_contents?: boolean, compress?: boolean }
// Returns: { 
//   export_data: string,       // JSON blob
//   size_bytes: number,
//   files_included: number,
//   checksum: string
// }

context_import
// Import context from previous session
// Parameters: { export_data: string, verify_checksum?: boolean }
// Returns: { 
//   imported: boolean,
//   files_restored: number,
//   state_restored: boolean,
//   warnings?: string[]
// }
```

---

## 14. Documentation Generator

```typescript
docs_generate
// Generate documentation for code
// Parameters: { 
//   file: string,
//   format?: "markdown" | "jsdoc" | "docstring",
//   include_examples?: boolean,
//   include_types?: boolean
// }
// Returns: { 
//   documentation: string,
//   symbols_documented: number,
//   coverage: { documented: number, total: number, percent: number },
//   warnings?: string[]
// }

docs_readme
// Generate/update README
// Parameters: { 
//   sections?: ("overview" | "installation" | "usage" | "api" | "contributing")[],
//   update_existing?: boolean
// }
// Returns: { 
//   readme: string,
//   sections_generated: string[],
//   merged_with_existing: boolean
// }

docs_api
// Generate API documentation
// Parameters: { 
//   entry_points: string[],
//   format?: "markdown" | "openapi" | "html",
//   include_private?: boolean
// }
// Returns: { 
//   documentation: string,
//   endpoints?: number,        // For OpenAPI
//   symbols?: number,          // For code docs
//   output_file?: string       // If written to file
// }
```

---

## 15. External Knowledge

```typescript
docs_fetch
// Fetch documentation for a package
// Parameters: { 
//   package: string,
//   version?: string,
//   section?: string           // "api", "getting-started", etc.
// }
// Returns: { 
//   documentation: string,
//   version: string,
//   source_url: string,
//   last_updated: string
// }

npm_info
// Get package info and recommendations
// Parameters: { package: string }
// Returns: { 
//   name: string,
//   version: string,
//   description: string,
//   repository: string,
//   weekly_downloads: number,
//   dependencies: number,
//   last_publish: string,
//   typescript: boolean,
//   alternatives?: string[]
// }

stackoverflow_search
// Search StackOverflow for solutions
// Parameters: { query: string, tags?: string[], top_k?: number }
// Returns: { 
//   results: Array<{
//     question: string,
//     question_url: string,
//     score: number,
//     accepted_answer?: string,
//     answer_score?: number,
//     tags: string[]
//   }>
// }
```

---

## 16. Visual Testing

```typescript
screenshot_capture
// Capture screenshot of web page
// Parameters: { 
//   url: string,
//   selector?: string,         // Specific element
//   viewport?: { width: number, height: number },
//   full_page?: boolean,
//   delay_ms?: number          // Wait before capture
// }
// Returns: { 
//   image_base64: string,
//   dimensions: { width: number, height: number },
//   file_path?: string
// }

screenshot_diff
// Compare two screenshots
// Parameters: { 
//   baseline: string,          // Path or base64
//   current: string,           // Path or base64
//   threshold?: number         // 0-1, default 0.1
// }
// Returns: { 
//   match: boolean,
//   diff_percent: number,
//   diff_regions: Array<{ x: number, y: number, width: number, height: number }>,
//   diff_image_base64?: string
// }

visual_regression_run
// Run visual regression test suite
// Parameters: { config_file?: string, update_baselines?: boolean }
// Returns: { 
//   passed: number,
//   failed: number,
//   new_screenshots: number,
//   failures: Array<{ name: string, diff_percent: number, diff_image: string }>
// }
```

### Implementation Notes:
- Use Playwright for screenshot capture
- Use pixelmatch or similar for image diffing
- Store baselines in `.visual-baselines/` directory

---

# Server Architecture

```
mcp-dev-tools/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts                 # Server entry, tool registration
│   ├── config.ts                # Working directory, settings
│   ├── state.ts                 # In-memory state (tasks, watchers, checkpoints)
│   │
│   ├── tools/
│   │   ├── tasks.ts             # Background task orchestrator
│   │   ├── checkpoints.ts       # Checkpoint & rollback
│   │   ├── impact.ts            # Impact analysis
│   │   ├── semantic.ts          # Semantic search
│   │   ├── context.ts           # Live context sync
│   │   ├── git.ts               # Git operations
│   │   ├── test.ts              # Test runner
│   │   ├── search.ts            # Code search
│   │   ├── lint.ts              # Lint & build
│   │   ├── diff.ts              # Diff & patch
│   │   ├── refactor.ts          # Multi-file refactor
│   │   ├── sandbox.ts           # Execution sandbox
│   │   ├── compress.ts          # Context compression
│   │   ├── docs.ts              # Documentation
│   │   ├── external.ts          # External knowledge
│   │   └── visual.ts            # Visual testing
│   │
│   └── utils/
│       ├── exec.ts              # Shell execution helpers
│       ├── parse.ts             # Output parsing
│       ├── errors.ts            # Error formatting
│       ├── cache.ts             # Caching layer
│       ├── embeddings.ts        # Vector embedding helpers
│       └── ast.ts               # AST parsing helpers
│
├── .mcp-checkpoints/            # Checkpoint storage (gitignored)
├── .mcp-index/                  # Semantic search index (gitignored)
└── .mcp-cache/                  # General cache (gitignored)
```

---

# Dependencies

```json
{
  "dependencies": {
    "@modelcontextprotocol/sdk": "latest",
    "zod": "^3.x",
    "execa": "^8.x",
    "simple-git": "^3.x",
    "chokidar": "^3.x",
    "tree-sitter": "^0.20.x",
    "tree-sitter-typescript": "^0.20.x",
    "@vscode/ripgrep": "^1.x",
    "lancedb": "^0.x",
    "@xenova/transformers": "^2.x",
    "tar": "^6.x",
    "pixelmatch": "^5.x",
    "playwright": "^1.x"
  },
  "devDependencies": {
    "typescript": "^5.x",
    "@types/node": "^20.x"
  }
}
```

---

# Implementation Order

Start with Tier 1 in order—each builds on the previous:

1. **Background Tasks** → Enables async everything
2. **Checkpoints** → Safe experimentation
3. **Impact Analysis** → Know what breaks
4. **Semantic Search** → Find code by meaning
5. **Context Sync** → Stay synchronized

Then Tier 2 for standard dev workflow:

6. **Git** → Version control
7. **Tests** → TDD loops
8. **Search** → Fast text search
9. **Lint/Build** → Quality gates
10. **Diff/Patch** → Surgical edits

Tier 3 as needed for advanced workflows.

---

# Testing

After each tool:
1. `npx @modelcontextprotocol/inspector` for interactive testing
2. Test happy path + error cases
3. Verify structured output matches schema
4. Check destructive operations have proper annotations

---

# Start Here

Begin with `task_spawn` and `task_status`. Create the project structure, implement background task execution, verify it works with a simple `echo "hello"` command. Then add `task_stream` and `task_kill`. Once background tasks work, move to checkpoints.

Ask me for clarification on any tool behavior, edge cases, or implementation details.
