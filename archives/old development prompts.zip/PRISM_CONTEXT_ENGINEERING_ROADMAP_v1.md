# PRISM CONTEXT ENGINEERING & MULTI-AGENT ROADMAP v1.0
## Integrating Manus AI + Claude Code TeammateTool Patterns
## For Claude.ai Main Chat Implementation
### 2026-02-01

---

# EXECUTIVE SUMMARY

This roadmap transforms PRISM Manufacturing Intelligence into a production-grade autonomous system by integrating proven patterns from:

| Source | Key Discovery | Application to PRISM |
|--------|---------------|---------------------|
| **Manus AI** | 6 Laws of Context Engineering | Prompt architecture, memory, caching |
| **Claude Code** | TeammateTool multi-agent system | Task coordination, heartbeat, messaging |
| **PRISM Current** | 706 resources, generator-first | Foundation to build upon |

**Meta acquired Manus in 2026** - validating this architecture as industry-leading.

---

# PART 1: THE 6 LAWS OF CONTEXT ENGINEERING

## From Manus AI (Meta) - Direct from their engineering blog

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    THE 6 LAWS (Manus AI, July 2025)                           ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  LAW 1: KV-CACHE STABILITY                                                    ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  "KV-cache hit rate is THE single most important metric for production AI"    ║
║                                                                               ║
║  • Keep prompt prefix STABLE (identical every session)                        ║
║  • Put timestamps at END, never at start (kills cache)                        ║
║  • Make context APPEND-ONLY (never modify previous content)                   ║
║  • Ensure DETERMINISTIC serialization (sorted JSON keys)                      ║
║                                                                               ║
║  IMPACT: Cached tokens $0.30/MTok vs Uncached $3.00/MTok = 10x savings        ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  LAW 2: MASK DON'T REMOVE                                                     ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  "Avoid dynamically adding or removing tools mid-iteration"                   ║
║                                                                               ║
║  • Keep ALL tools in context ALWAYS                                           ║
║  • Use token logits masking to constrain selection                            ║
║  • Tools prefixed consistently (browser_*, shell_*, prism_*)                  ║
║  • State machine controls AVAILABILITY, not PRESENCE                          ║
║                                                                               ║
║  WHY: Tool changes invalidate KV-cache + confuse the model                    ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  LAW 3: FILE SYSTEM AS CONTEXT                                                ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  "128K tokens isn't enough for real agentic work"                             ║
║                                                                               ║
║  • Files = unlimited externalized memory                                      ║
║  • Agent writes/reads files on demand                                         ║
║  • Compression is RESTORABLE (keep URLs, paths, references)                   ║
║  • "Agentic SSMs could be successors to Neural Turing Machines"               ║
║                                                                               ║
║  KEY: Never permanently lose information - always keep restoration path       ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  LAW 4: ATTENTION MANIPULATION VIA RECITATION                                 ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  "50+ tool calls = model drifts, forgets goals"                               ║
║                                                                               ║
║  • Constantly rewrite todo.md with current goals                              ║
║  • Pushes plan into RECENT attention span                                     ║
║  • Avoids "lost-in-the-middle" effect                                         ║
║  • Natural language biases own focus toward objectives                        ║
║                                                                               ║
║  MECHANISM: Goals at END of context = highest attention weight                ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  LAW 5: KEEP WRONG STUFF IN CONTEXT                                           ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  "Error recovery is clearest indicator of true agentic behavior"              ║
║                                                                               ║
║  • Leave failed actions IN context (never clean)                              ║
║  • Model sees error → updates beliefs → avoids repeat                         ║
║  • Erasing failure removes evidence                                           ║
║  • "Without evidence, the model can't adapt"                                  ║
║                                                                               ║
║  PRINCIPLE: Errors are learning signals, not things to hide                   ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  LAW 6: DON'T GET FEW-SHOTTED                                                 ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  "The more uniform your context, the more brittle your agent"                 ║
║                                                                               ║
║  • Repetitive actions → model mimics patterns → drift/hallucination           ║
║  • Introduce STRUCTURED VARIATION in serialization                            ║
║  • Alternate phrasing, minor noise in order/formatting                        ║
║  • "Controlled randomness helps break the pattern"                            ║
║                                                                               ║
║  SOLUTION: Vary templates, phrasing, formatting to prevent mimicry            ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# PART 2: CLAUDE CODE TEAMMATETOOL ARCHITECTURE

## Reverse-Engineered from Claude Code v2.1.19

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    CLAUDE CODE MULTI-AGENT SYSTEM                             ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  STATUS: Fully implemented but feature-flagged (I9() && qFB())                ║
║  DISCOVERY: Binary strings analysis revealed hidden operations                ║
║                                                                               ║
║  OPERATIONS FOUND:                                                            ║
║  ├── spawnTeam         Create a new team                                      ║
║  ├── spawn             Add agent to team                                      ║
║  ├── broadcast         Send message to all team members                       ║
║  ├── requestShutdown   Initiate graceful shutdown                             ║
║  └── cleanup           Remove team and task directories                       ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  FILE STRUCTURE (Proposed in GitHub Gist):                                    ║
║                                                                               ║
║  ~/.claude/                                                                   ║
║  ├── teams/                                                                   ║
║  │   └── {team-id}/                                                           ║
║  │       ├── config.json       # Team metadata, leader, members               ║
║  │       └── messages/         # Inter-agent mailbox                          ║
║  │           └── {agent-id}/   # Inbox per agent                              ║
║  └── tasks/                                                                   ║
║      └── {team-id}/                                                           ║
║          ├── 1.json            # Task with dependencies                       ║
║          └── ...                                                              ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  TASK SCHEMA (Enhanced):                                                      ║
║                                                                               ║
║  {                                                                            ║
║    "id": "1",                                                                 ║
║    "subject": "Review the landing page",                                      ║
║    "status": "pending|in_progress|completed|blocked",                         ║
║    "owner": "agent-abc123",        // Assigned agent                          ║
║    "priority": "p1|p2|p3",         // Priority level                          ║
║    "blocks": ["2", "3"],           // Task IDs this blocks                    ║
║    "blockedBy": [],                // Task IDs blocking this                  ║
║    "heartbeat": "ISO-timestamp",   // Last activity (crash detection)         ║
║    "metadata": {}                  // Arbitrary data                          ║
║  }                                                                            ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  KEY MECHANISMS:                                                              ║
║                                                                               ║
║  1. HEARTBEAT: 30s interval, 5min abandonment timeout                         ║
║     - Detects crashed/stuck agents                                            ║
║     - Auto-releases abandoned tasks                                           ║
║                                                                               ║
║  2. ATOMIC CLAIMING: .lock files prevent race conditions                      ║
║     - Only one agent can claim a task                                         ║
║     - Lock acquired before status change                                      ║
║                                                                               ║
║  3. DEPENDENCY GRAPH: blocks/blockedBy arrays                                 ║
║     - Task cannot start if blockedBy incomplete                               ║
║     - Cycle detection prevents deadlock                                       ║
║                                                                               ║
║  4. MESSAGE INBOX: Per-agent directories                                      ║
║     - Write to specific agent or broadcast                                    ║
║     - Agents poll their inbox for instructions                                ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# PART 3: PRISM GAP ANALYSIS

## Current State vs Industry Best Practices

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    PRISM GAP ANALYSIS                                         ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  COMPONENT              PRISM NOW           MANUS/CC PATTERN    GAP LEVEL     ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  Prompt Stability       Timestamps in prefix Move to END         🔴 CRITICAL  ║
║  Serialization          Not deterministic    Sorted JSON keys    🔴 CRITICAL  ║
║  Tool Loading           Dynamic              Static + masking    🔴 CRITICAL  ║
║  State Management       CURRENT_STATE.json   Append-only events  🟡 PARTIAL   ║
║  Error Handling         Sometimes cleaned    Always preserved    🟡 PARTIAL   ║
║  Goal Tracking          quickResume field    todo.md recitation  🟡 PARTIAL   ║
║  Pattern Variation      Very consistent      Structured variation 🔴 MISSING  ║
║  Team Coordination      None                 TeammateTool        🔴 MISSING   ║
║  Task Dependencies      None                 blocks/blockedBy    🔴 MISSING   ║
║  Heartbeat/Recovery     None                 30s/5min timeouts   🔴 MISSING   ║
║  Inter-Agent Comms      None                 Inbox/broadcast     🔴 MISSING   ║
║  Memory Tiers           Partial              Full externalization 🟡 PARTIAL  ║
║                                                                               ║
║  ALIGNMENT SCORE: 3/12 (25%) with industry best practices                     ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# PART 4: UNIFIED IMPLEMENTATION ROADMAP

## Phase Overview

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    PRISM CONTEXT ENGINEERING ROADMAP                          ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  PHASE 0: CONTEXT OPTIMIZATION (Foundation)         4 sessions | 12 hours    ║
║  ├── 0.1: KV-Cache Stable Prefix Protocol           3 hrs                     ║
║  ├── 0.2: Append-Only State Architecture            3 hrs                     ║
║  ├── 0.3: Tool Masking State Machine                3 hrs                     ║
║  └── 0.4: Error Preservation System                 3 hrs                     ║
║                                                                               ║
║  PHASE 1: FILE-BASED MEMORY SYSTEM                  3 sessions | 9 hours     ║
║  ├── 1.1: todo.md Recitation Protocol               3 hrs                     ║
║  ├── 1.2: Externalized Memory Architecture          3 hrs                     ║
║  └── 1.3: Restorable Compression Engine             3 hrs                     ║
║                                                                               ║
║  PHASE 2: TEAM COORDINATION SYSTEM                  4 sessions | 12 hours    ║
║  ├── 2.1: Team/Task File Structure                  3 hrs                     ║
║  ├── 2.2: Task Dependency Graph                     3 hrs                     ║
║  ├── 2.3: Heartbeat & Abandonment Detection         3 hrs                     ║
║  └── 2.4: Inter-Agent Communication                 3 hrs                     ║
║                                                                               ║
║  PHASE 3: PATTERN VARIATION ENGINE                  2 sessions | 6 hours     ║
║  ├── 3.1: Serialization Templates                   3 hrs                     ║
║  └── 3.2: Structured Randomness                     3 hrs                     ║
║                                                                               ║
║  PHASE 4: INTEGRATION & VALIDATION                  3 sessions | 9 hours     ║
║  ├── 4.1: MCP Server Integration                    3 hrs                     ║
║  ├── 4.2: Generator Alignment                       3 hrs                     ║
║  └── 4.3: Full System Validation                    3 hrs                     ║
║                                                                               ║
║  ═══════════════════════════════════════════════════════════════════════════  ║
║  TOTAL: 16 sessions | 48 hours | ~16 days @ 3 hrs/day                        ║
║  ═══════════════════════════════════════════════════════════════════════════  ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# PHASE 0: CONTEXT OPTIMIZATION

## Session 0.1: KV-Cache Stable Prefix Protocol (3 hours)

### Problem
```python
# CURRENT (WRONG) - Kills cache every time
system_prompt = f"""
Current time: {datetime.now()}  # ← Cache invalidated here!
Session: {session_id}           # ← And here!
You are PRISM Manufacturing Intelligence...
"""

# CORRECT - Cache stable prefix
system_prompt = """
You are PRISM Manufacturing Intelligence...
[... ALL stable content first ...]

<dynamic_context>
<!-- Dynamic content goes at END only -->
</dynamic_context>
"""
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Audit GSD_CORE for dynamic content in prefix | 15m | Issue list |
| 2 | Audit PRISM_CONDENSED_PROTOCOL | 15m | Issue list |
| 3 | Create STABLE_PREFIX_TEMPLATE.md | 30m | Template file |
| 4 | Restructure GSD_CORE (timestamps → END) | 30m | Updated file |
| 5 | Create JSON key sorting utility | 20m | Python script |
| 6 | Update CURRENT_STATE.json schema | 20m | Schema doc |
| 7 | Create cache stability checker script | 30m | Validator tool |
| 8 | Test prefix stability across 5 sessions | 20m | Test report |
| 9 | Document KV-cache optimization rules | 20m | Protocol addition |

### New Protocol Section
```markdown
## KV-CACHE OPTIMIZATION RULES (Manus Law 1)

### Prompt Structure (MANDATORY ORDER)
┌─────────────────────────────────────────────────────────────┐
│ [STABLE PREFIX - Never changes, cached]                     │
│ ├── Role definition                                         │
│ ├── Core capabilities                                       │
│ ├── Tool definitions (ALL tools, always present)            │
│ ├── Validation gates                                        │
│ └── Quality equations                                       │
├─────────────────────────────────────────────────────────────┤
│ [APPEND-ONLY MIDDLE - Actions/observations, never modified] │
│ ├── Previous actions (immutable once recorded)              │
│ ├── Previous observations (immutable once recorded)         │
│ └── Error traces (always preserved, never cleaned)          │
├─────────────────────────────────────────────────────────────┤
│ [DYNAMIC SUFFIX - Changes each turn, not cached]            │
│ ├── Current timestamp                                       │
│ ├── Session state summary                                   │
│ └── Current task focus (recitation)                         │
└─────────────────────────────────────────────────────────────┘

### Serialization Rules
- JSON keys MUST be sorted alphabetically: json.dumps(obj, sort_keys=True)
- Never include random IDs in prompt prefix
- Hash-based IDs only in dynamic suffix
- Timestamp format: ISO 8601 at END of context only
```

---

## Session 0.2: Append-Only State Architecture (3 hours)

### New Directory Structure
```
C:\PRISM\state\
├── CURRENT_STATE.json          # Current snapshot (read-heavy)
├── events/                     # Append-only event log
│   ├── 2026-02-01_001.jsonl   # Session 1 events
│   ├── 2026-02-01_002.jsonl   # Session 2 events
│   └── ...
├── decisions/                  # Decision log (never modified)
│   └── 2026-02-01.jsonl
├── errors/                     # Error traces (preserved forever)
│   └── 2026-02-01.jsonl
└── snapshots/                  # Periodic full snapshots
    └── 2026-02-01T06-30-00.json
```

### Event Schema
```json
{
  "event_id": "EVT-20260201-001-042",
  "timestamp": "2026-02-01T06:30:00Z",
  "event_type": "ACTION|OBSERVATION|ERROR|DECISION|CHECKPOINT",
  "session_id": "SESSION-20260201-001",
  "sequence": 42,
  "content": {
    "action": "prism_material_query",
    "parameters": {"material_id": "AL-6061-T6"},
    "result": "...",
    "duration_ms": 150
  },
  "checksum": "sha256:abc123..."
}
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design append-only state schema | 30m | Schema document |
| 2 | Create state versioning system | 30m | Python module |
| 3 | Implement event logger (JSONL append) | 25m | Logger script |
| 4 | Implement error trace preserver | 25m | Error handler |
| 5 | Create state rollback utility | 20m | Rollback tool |
| 6 | Migrate current state to new format | 20m | Migration script |
| 7 | Test append-only guarantees | 20m | Test suite |
| 8 | Update gsd_startup.py for new structure | 20m | Updated script |
| 9 | Document state management protocol | 10m | Protocol doc |

---

## Session 0.3: Tool Masking State Machine (3 hours)

### Current vs New Approach
```
CURRENT (WRONG - breaks cache):
├── Session starts
├── Detect task type
├── Load relevant tools (cache invalidated!)
└── Execute

NEW (Manus Law 2 - cache stable):
├── Session starts
├── ALL tools always in context (never changes)
├── State machine determines AVAILABLE tools
├── Mask unavailable tools via constraints
└── Execute with masked selection
```

### Tool Prefix Convention (prism_* namespace)
```python
TOOL_PREFIXES = {
    "prism_material_":  "Material database operations",
    "prism_machine_":   "Machine database operations",
    "prism_physics_":   "Physics calculations",
    "prism_safety_":    "Safety validation",
    "prism_code_":      "Code generation",
    "prism_file_":      "File operations",
    "prism_state_":     "State management",
    "prism_team_":      "Team coordination",
    "prism_memory_":    "Memory management",
    "prism_cache_":     "Cache management"
}
```

### State Machine Definition
```python
TOOL_STATES = {
    "INITIALIZATION": {
        "available": ["prism_state_*", "prism_file_read", "prism_memory_retrieve"],
        "masked": ["prism_material_write", "prism_machine_write", "prism_code_*"]
    },
    "PLANNING": {
        "available": ["prism_state_*", "prism_file_*", "prism_memory_*"],
        "masked": ["prism_code_execute", "prism_material_write"]
    },
    "EXECUTION": {
        "available": ["*"],  # All tools available
        "masked": []
    },
    "VALIDATION": {
        "available": ["prism_safety_*", "prism_state_*", "prism_file_read"],
        "masked": ["prism_code_execute", "prism_material_write"]
    },
    "ERROR_RECOVERY": {
        "available": ["prism_state_*", "prism_file_*", "prism_safety_*", "prism_memory_*"],
        "masked": ["prism_material_write", "prism_machine_write", "prism_code_execute"]
    }
}

def get_available_tools(state: str, all_tools: List[str]) -> List[str]:
    """Return tools available in current state (for response prefill)"""
    config = TOOL_STATES[state]
    available = set()
    for pattern in config["available"]:
        if pattern == "*":
            available = set(all_tools)
            break
        available.update(t for t in all_tools if fnmatch(t, pattern))
    
    for pattern in config["masked"]:
        available -= set(t for t in available if fnmatch(t, pattern))
    
    return sorted(available)
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Inventory all current tools with usage | 20m | Tool catalog |
| 2 | Assign prism_* prefixes to all tools | 30m | Renamed tools |
| 3 | Design state machine states/transitions | 30m | State diagram |
| 4 | Implement tool availability matrix | 30m | Matrix module |
| 5 | Create masking constraint generator | 30m | Constraint engine |
| 6 | Update skill loader to include ALL tools | 20m | Updated loader |
| 7 | Test tool masking with 5 scenarios | 20m | Test results |
| 8 | Document tool masking protocol | 10m | Protocol doc |

---

## Session 0.4: Error Preservation System (3 hours)

### Philosophy (Manus Law 5)
```
OLD: Error → Retry silently → Hope it works → Model doesn't learn
NEW: Error → Preserve in context → Model sees it → Avoids repeat

"Erasing failure removes evidence. Without evidence, the model can't adapt."
```

### Error Event Schema
```json
{
  "error_id": "ERR-20260201-001-007",
  "timestamp": "2026-02-01T06:45:00Z",
  "tool": "prism_physics_kienzle",
  "action_attempted": "compute_cutting_force",
  "parameters": {
    "material": "AL-6061",
    "depth_of_cut": 5.0,
    "feed_rate": 0.2
  },
  "error_type": "VALIDATION_FAILURE",
  "error_message": "Depth of cut (5.0mm) exceeds safe limit for AL-6061 (max 3.0mm)",
  "stack_trace": "...",
  "context_at_failure": {
    "recent_actions": ["...", "..."],
    "state_summary": "..."
  },
  "recovery_attempted": false,
  "resolution": null,
  "prevention_rule": "Check material depth limits before physics calculations"
}
```

### Error Handling Protocol
```python
async def handle_tool_error(tool: str, params: dict, error: Exception) -> ErrorEvent:
    """
    NEVER clean errors - preserve them for learning
    """
    event = ErrorEvent(
        error_id=generate_error_id(),
        timestamp=datetime.now().isoformat(),
        tool=tool,
        action_attempted=f"{tool}({params})",
        parameters=params,
        error_type=classify_error(error),
        error_message=str(error),
        stack_trace=traceback.format_exc(),
        context_at_failure=get_recent_context(5),
        recovery_attempted=False,
        resolution=None
    )
    
    # APPEND to error log (never modify existing)
    append_to_error_log(event)
    
    # KEEP in context for model learning
    inject_error_into_context(event)
    
    # Suggest recovery (don't auto-execute)
    event.recovery_suggestion = suggest_recovery(event)
    
    return event
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design error event schema | 20m | Schema doc |
| 2 | Create error preservation handler | 30m | Handler module |
| 3 | Implement error context injector | 25m | Injector script |
| 4 | Create error pattern detector | 30m | Pattern detector |
| 5 | Build error recovery suggester | 25m | Suggester module |
| 6 | Update all tool wrappers for error capture | 20m | Updated wrappers |
| 7 | Test error preservation (10 scenarios) | 15m | Test results |
| 8 | Document error handling protocol | 15m | Protocol doc |

---

# PHASE 1: FILE-BASED MEMORY SYSTEM

## Session 1.1: todo.md Recitation Protocol (3 hours)

### Purpose (Manus Law 4)
```
"By constantly rewriting the todo list, Manus is reciting its objectives 
into the end of the context. This pushes the global plan into the model's 
recent attention span, avoiding 'lost-in-the-middle' issues."
```

### PRISM todo.md Template
```markdown
# PRISM Active Task: [TASK_NAME]
## Session: [SESSION_ID] | Updated: [TIMESTAMP]

## 🎯 CURRENT FOCUS (ATTENTION ANCHOR)
> [One sentence: What I'm doing RIGHT NOW]

## Plan Status
- [x] Step 1: [Description] ✓ COMPLETE
- [x] Step 2: [Description] ✓ COMPLETE
- [ ] Step 3: [Description] ← CURRENT
- [ ] Step 4: [Description]
- [ ] Step 5: [Description]

## Progress: 2/5 (40%) ████░░░░░░

## Blocking Issues
- None currently

## Quality Gates
- S(x): Pending validation
- Ω(x): Not yet computed

## Recent Decisions
1. [Decision made and why]

## Next Action
> [Specific next step to take]
```

### Update Protocol
```python
async def update_todo_on_checkpoint(completed: int, next_item: str):
    """
    Called after EVERY significant action to maintain attention focus
    """
    todo = load_todo()
    
    # Update progress
    todo.completed = completed
    todo.progress_pct = (completed / todo.total) * 100
    
    # Update current focus (ATTENTION ANCHOR)
    todo.current_focus = next_item
    
    # Update timestamp (goes at END of file)
    todo.updated = datetime.now().isoformat()
    
    # Rewrite entire file (recitation mechanism)
    save_todo(todo)
    
    # Inject into context end (high attention weight)
    inject_todo_summary_to_context_end(todo)
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design todo.md template | 20m | Template file |
| 2 | Create todo manager module | 30m | Python module |
| 3 | Implement auto-update on checkpoint | 25m | Update hook |
| 4 | Create attention anchor extractor | 20m | Extractor |
| 5 | Integrate with session_memory_manager | 25m | Integration |
| 6 | Test recitation effect (20 actions) | 20m | Test report |
| 7 | Measure goal drift with/without | 20m | Comparison |
| 8 | Document recitation protocol | 10m | Protocol doc |

---

## Session 1.2: Externalized Memory Architecture (3 hours)

### Memory Hierarchy (Manus Law 3)
```
C:\PRISM\memory\
├── short_term/              # Current session (< 1 hour old)
│   ├── observations/        # Tool outputs (raw)
│   ├── decisions/           # Reasoning traces
│   └── artifacts/           # Generated files
│
├── working/                 # Current task (< 1 day old)
│   ├── research/            # Gathered information
│   ├── drafts/              # Work in progress
│   └── references/          # External sources (with restoration paths)
│
├── long_term/               # Persistent knowledge
│   ├── lessons_learned/     # What worked/didn't
│   ├── patterns/            # Recognized patterns
│   └── preferences/         # User/system preferences
│
└── archive/                 # Historical (compressed with restoration metadata)
    └── YYYY-MM/
        └── compressed_*.gz  # Contains restoration paths
```

### Memory Operations
```python
class MemoryManager:
    async def store(self, content: str, tier: str, metadata: dict) -> str:
        """Store content in appropriate tier with restoration path"""
        entry = MemoryEntry(
            id=generate_memory_id(),
            content=content,
            tier=tier,
            metadata=metadata,
            created=datetime.now(),
            restoration_path=self.compute_restoration_path(content, metadata)
        )
        return await self.save_to_tier(entry)
    
    async def retrieve(self, query: str, tier: str = None) -> List[MemoryEntry]:
        """Retrieve from memory, restoring compressed content as needed"""
        results = await self.search(query, tier)
        for r in results:
            if r.compressed:
                r.content = await self.restore(r.restoration_path)
        return results
    
    async def compress(self, entry: MemoryEntry) -> CompressedEntry:
        """Compress but ALWAYS preserve restoration path"""
        return CompressedEntry(
            id=entry.id,
            summary=self.summarize(entry.content),
            restoration_path=entry.restoration_path,  # NEVER lose this
            original_size=len(entry.content),
            compressed_at=datetime.now()
        )
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design memory hierarchy | 20m | Directory structure |
| 2 | Create memory manager module | 35m | Manager module |
| 3 | Implement tier promotion/demotion | 30m | Tier logic |
| 4 | Create memory retrieval system | 30m | Retrieval module |
| 5 | Implement memory reference injection | 25m | Injector |
| 6 | Test persistence across sessions | 15m | Test report |
| 7 | Document memory protocol | 15m | Protocol doc |

---

## Session 1.3: Restorable Compression Engine (3 hours)

### Philosophy
```
WRONG: Summarize content → Lose original forever
RIGHT: Keep restoration path → Restore on demand

"Our compression strategies are always designed to be restorable."
- Manus Engineering Blog
```

### Compression Strategies
```python
COMPRESSION_STRATEGIES = {
    "web_content": {
        "preserve": ["url", "title", "fetch_timestamp"],
        "compress": ["body_text"],
        "restore_method": "web_fetch(url)",
        "example_compressed": {
            "type": "web_content",
            "url": "https://example.com/article",
            "title": "Article Title",
            "fetch_timestamp": "2026-02-01T06:30:00Z",
            "summary": "Brief summary...",
            "_restore": "web_fetch('https://example.com/article')"
        }
    },
    "file_content": {
        "preserve": ["path", "checksum", "size", "modified"],
        "compress": ["content"],
        "restore_method": "file_read(path)",
        "example_compressed": {
            "type": "file_content",
            "path": "C:\\PRISM\\research\\paper.pdf",
            "checksum": "sha256:abc123",
            "size": 1048576,
            "summary": "Research paper about...",
            "_restore": "file_read('C:\\PRISM\\research\\paper.pdf')"
        }
    },
    "tool_output": {
        "preserve": ["tool_name", "parameters", "timestamp", "duration"],
        "compress": ["full_output"],
        "restore_method": "re-execute tool with same parameters",
        "example_compressed": {
            "type": "tool_output",
            "tool_name": "prism_material_query",
            "parameters": {"material_id": "AL-6061-T6"},
            "timestamp": "2026-02-01T06:35:00Z",
            "summary": "Aluminum alloy properties...",
            "_restore": "prism_material_query(material_id='AL-6061-T6')"
        }
    },
    "conversation": {
        "preserve": ["message_id", "speaker", "timestamp"],
        "compress": ["full_text"],
        "restore_method": "conversation_search(message_id)",
        "example_compressed": {
            "type": "conversation",
            "message_id": "MSG-20260201-001-015",
            "speaker": "user",
            "timestamp": "2026-02-01T06:20:00Z",
            "summary": "User asked about...",
            "_restore": "conversation_search('MSG-20260201-001-015')"
        }
    }
}
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design compression schema | 25m | Schema doc |
| 2 | Implement web content compressor | 25m | Compressor |
| 3 | Implement file content compressor | 20m | Compressor |
| 4 | Implement tool output compressor | 20m | Compressor |
| 5 | Create restoration engine | 30m | Restore engine |
| 6 | Test compression/restoration cycle | 20m | Test results |
| 7 | Measure context savings | 10m | Metrics report |
| 8 | Document compression protocol | 10m | Protocol doc |

---

# PHASE 2: TEAM COORDINATION SYSTEM

## Session 2.1: Team/Task File Structure (3 hours)

### Directory Structure (Claude Code compatible)
```
C:\PRISM\teams\
├── {team-id}/
│   ├── config.json           # Team metadata
│   └── messages/
│       ├── leader/           # Leader inbox
│       ├── worker-001/       # Worker 1 inbox
│       └── worker-002/       # Worker 2 inbox
│
└── tasks/
    └── {team-id}/
        ├── 001.json          # Task 1
        ├── 001.lock          # Lock file (atomic claiming)
        ├── 002.json          # Task 2
        └── todo.md           # Team-level progress (recitation)
```

### Team Config Schema
```json
{
  "id": "TEAM-20260201-001",
  "name": "materials-extraction",
  "created": "2026-02-01T06:00:00Z",
  "leader": {
    "id": "opus-main",
    "model": "claude-opus-4-5-20251101",
    "role": "coordinator"
  },
  "members": [
    {
      "id": "sonnet-001",
      "model": "claude-sonnet-4-5-20250929",
      "role": "extractor",
      "specialization": "carbon_steels"
    },
    {
      "id": "sonnet-002",
      "model": "claude-sonnet-4-5-20250929",
      "role": "extractor",
      "specialization": "alloy_steels"
    }
  ],
  "status": "active",
  "task_count": 10,
  "completed_count": 3
}
```

### Task Schema (Enhanced)
```json
{
  "id": "001",
  "subject": "Extract Carbon Steel CS-001 through CS-050",
  "description": "Extract material properties for low carbon steels",
  "status": "in_progress",
  "owner": "sonnet-001",
  "priority": "p1",
  "blocks": ["003", "004"],
  "blockedBy": [],
  "heartbeat": "2026-02-01T06:45:00Z",
  "created": "2026-02-01T06:00:00Z",
  "started": "2026-02-01T06:30:00Z",
  "completed": null,
  "metadata": {
    "registry": "MaterialRegistry",
    "category": "CARBON_STEEL",
    "target_count": 50,
    "completed_count": 25
  }
}
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Create team directory structure | 15m | Directories |
| 2 | Design team config schema | 20m | Schema doc |
| 3 | Design task schema with dependencies | 25m | Schema doc |
| 4 | Implement team manager module | 35m | Manager module |
| 5 | Implement task manager module | 35m | Manager module |
| 6 | Create CLI for team operations | 20m | CLI tool |
| 7 | Test team creation/discovery | 15m | Test results |
| 8 | Document team structure | 15m | Documentation |

---

## Session 2.2: Task Dependency Graph (3 hours)

### Dependency Rules
```python
class TaskDependencyManager:
    """
    Implements blocks/blockedBy dependency system from Claude Code
    """
    
    def can_start(self, task: Task) -> Tuple[bool, List[str]]:
        """Check if task can start based on dependencies"""
        if not task.blockedBy:
            return True, []
        
        blocking_tasks = []
        for blocker_id in task.blockedBy:
            blocker = self.get_task(blocker_id)
            if blocker.status != "completed":
                blocking_tasks.append(blocker_id)
        
        return len(blocking_tasks) == 0, blocking_tasks
    
    def on_task_complete(self, task: Task):
        """Update all tasks that this task was blocking"""
        for blocked_id in task.blocks:
            blocked_task = self.get_task(blocked_id)
            blocked_task.blockedBy.remove(task.id)
            
            # Check if now unblocked
            can_start, _ = self.can_start(blocked_task)
            if can_start and blocked_task.status == "blocked":
                blocked_task.status = "pending"
                self.notify_available(blocked_task)
    
    def detect_cycles(self, tasks: List[Task]) -> List[List[str]]:
        """Detect circular dependencies (prevents deadlock)"""
        # Build adjacency list
        graph = {t.id: t.blocks for t in tasks}
        
        # Tarjan's algorithm for cycle detection
        cycles = []
        visited = set()
        rec_stack = set()
        
        def dfs(node, path):
            visited.add(node)
            rec_stack.add(node)
            path.append(node)
            
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    dfs(neighbor, path)
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:])
            
            path.pop()
            rec_stack.remove(node)
        
        for task_id in graph:
            if task_id not in visited:
                dfs(task_id, [])
        
        return cycles
```

### Priority Inheritance
```python
def compute_effective_priority(task: Task, all_tasks: Dict[str, Task]) -> str:
    """
    Task inherits maximum priority of tasks it blocks
    (If I'm blocking a P1 task, I become P1)
    """
    priorities = {"p1": 1, "p2": 2, "p3": 3}
    
    min_priority_value = priorities[task.priority]
    
    for blocked_id in task.blocks:
        blocked = all_tasks.get(blocked_id)
        if blocked:
            blocked_priority = priorities[blocked.priority]
            min_priority_value = min(min_priority_value, blocked_priority)
    
    # Convert back to string
    for p, v in priorities.items():
        if v == min_priority_value:
            return p
    
    return task.priority
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Implement dependency graph structure | 30m | Graph module |
| 2 | Create cycle detection algorithm | 25m | Detector |
| 3 | Implement blocking status checker | 20m | Checker |
| 4 | Create dependency resolution engine | 30m | Resolver |
| 5 | Implement priority inheritance | 20m | Priority logic |
| 6 | Build dependency visualization | 20m | Visualizer |
| 7 | Test with complex dependency chains | 15m | Test results |
| 8 | Document dependency protocol | 10m | Protocol doc |

---

## Session 2.3: Heartbeat & Abandonment Detection (3 hours)

### Heartbeat System
```python
HEARTBEAT_INTERVAL_MS = 30_000      # 30 seconds
ABANDONMENT_TIMEOUT_MS = 300_000    # 5 minutes

class HeartbeatManager:
    async def start_heartbeat(self, agent_id: str, task_id: str):
        """Start heartbeat loop for active task"""
        while self.is_task_active(task_id):
            await self.update_heartbeat(task_id, datetime.now())
            await asyncio.sleep(HEARTBEAT_INTERVAL_MS / 1000)
    
    async def update_heartbeat(self, task_id: str, timestamp: datetime):
        """Update task heartbeat timestamp"""
        task = await self.load_task(task_id)
        task.heartbeat = timestamp.isoformat()
        await self.save_task(task)
    
    async def check_abandoned_tasks(self, team_id: str) -> List[Task]:
        """Find and release abandoned tasks"""
        tasks = await self.list_tasks(team_id)
        now = datetime.now()
        abandoned = []
        
        for task in tasks:
            if task.status != "in_progress":
                continue
                
            if not task.heartbeat:
                continue
            
            last_beat = datetime.fromisoformat(task.heartbeat)
            elapsed_ms = (now - last_beat).total_seconds() * 1000
            
            if elapsed_ms > ABANDONMENT_TIMEOUT_MS:
                # Task abandoned - release it
                task.status = "pending"
                task.owner = None
                task.heartbeat = None
                await self.save_task(task)
                await self.notify_team(
                    team_id, 
                    f"Task {task.id} released - agent timeout after {elapsed_ms/1000:.0f}s"
                )
                abandoned.append(task)
        
        return abandoned
```

### Atomic Task Claiming
```python
class TaskClaimer:
    async def claim_task(self, task_id: str, agent_id: str) -> bool:
        """
        Atomically claim a task using lock file
        Prevents race conditions between agents
        """
        lock_path = f"C:\\PRISM\\teams\\tasks\\{task_id}.lock"
        
        try:
            # Try to create lock file (atomic operation)
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, agent_id.encode())
            os.close(fd)
            
            # Lock acquired - update task
            task = await self.load_task(task_id)
            task.status = "in_progress"
            task.owner = agent_id
            task.heartbeat = datetime.now().isoformat()
            task.started = datetime.now().isoformat()
            await self.save_task(task)
            
            return True
            
        except FileExistsError:
            # Another agent already claimed it
            return False
    
    async def release_task(self, task_id: str, agent_id: str, completed: bool = False):
        """Release task and remove lock"""
        lock_path = f"C:\\PRISM\\teams\\tasks\\{task_id}.lock"
        
        # Verify we own the lock
        if os.path.exists(lock_path):
            with open(lock_path, 'r') as f:
                owner = f.read().strip()
            
            if owner == agent_id:
                os.remove(lock_path)
                
                task = await self.load_task(task_id)
                task.owner = None
                task.heartbeat = None
                
                if completed:
                    task.status = "completed"
                    task.completed = datetime.now().isoformat()
                else:
                    task.status = "pending"
                
                await self.save_task(task)
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design heartbeat schema | 15m | Schema |
| 2 | Implement heartbeat updater | 25m | Updater |
| 3 | Create abandonment detector | 25m | Detector |
| 4 | Implement atomic task claiming | 30m | Claimer |
| 5 | Create agent health monitor | 25m | Monitor |
| 6 | Build recovery notification system | 20m | Notifier |
| 7 | Test crash recovery scenarios | 15m | Test results |
| 8 | Document heartbeat protocol | 10m | Protocol doc |

---

## Session 2.4: Inter-Agent Communication (3 hours)

### Message Types
```python
MESSAGE_TYPES = {
    "instruction": {
        "description": "Leader → Worker: Task assignment or guidance",
        "requires_ack": True
    },
    "status": {
        "description": "Worker → Leader: Progress update",
        "requires_ack": False
    },
    "query": {
        "description": "Agent → Agent: Information request",
        "requires_ack": True
    },
    "response": {
        "description": "Agent → Agent: Answer to query",
        "requires_ack": False
    },
    "broadcast": {
        "description": "Leader → All: Team-wide announcement",
        "requires_ack": False
    },
    "shutdown": {
        "description": "Leader → All: Prepare to shutdown",
        "requires_ack": True
    },
    "ack": {
        "description": "Agent → Sender: Acknowledged",
        "requires_ack": False
    }
}
```

### Message Schema
```json
{
  "id": "MSG-20260201-001-042",
  "team_id": "TEAM-20260201-001",
  "from_agent": "opus-main",
  "to_agent": "sonnet-001",
  "type": "instruction",
  "priority": "normal",
  "content": {
    "action": "proceed_with_extraction",
    "details": "Continue with carbon steels CS-026 through CS-050"
  },
  "timestamp": "2026-02-01T07:00:00Z",
  "read": false,
  "ack_required": true,
  "ack_received": null
}
```

### Communication Protocol
```python
class AgentMessenger:
    async def send(self, from_agent: str, to_agent: str, msg_type: str, content: dict):
        """Send message to specific agent's inbox"""
        message = Message(
            id=generate_message_id(),
            team_id=self.team_id,
            from_agent=from_agent,
            to_agent=to_agent,
            type=msg_type,
            content=content,
            timestamp=datetime.now().isoformat(),
            ack_required=MESSAGE_TYPES[msg_type]["requires_ack"]
        )
        
        # Write to recipient's inbox
        inbox_path = f"C:\\PRISM\\teams\\{self.team_id}\\messages\\{to_agent}\\"
        await self.write_message(inbox_path, message)
        
        return message.id
    
    async def broadcast(self, from_agent: str, msg_type: str, content: dict):
        """Send message to ALL team members"""
        team = await self.load_team_config()
        message_ids = []
        
        for member in team.members:
            if member.id != from_agent:
                msg_id = await self.send(from_agent, member.id, msg_type, content)
                message_ids.append(msg_id)
        
        return message_ids
    
    async def poll_inbox(self, agent_id: str, unread_only: bool = True) -> List[Message]:
        """Check agent's inbox for messages"""
        inbox_path = f"C:\\PRISM\\teams\\{self.team_id}\\messages\\{agent_id}\\"
        messages = await self.read_all_messages(inbox_path)
        
        if unread_only:
            messages = [m for m in messages if not m.read]
        
        return sorted(messages, key=lambda m: m.timestamp)
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design message schema | 15m | Schema |
| 2 | Implement inbox manager | 30m | Inbox module |
| 3 | Create send (targeted) function | 20m | Send function |
| 4 | Create broadcast function | 20m | Broadcast |
| 5 | Implement message polling | 25m | Poller |
| 6 | Create message aggregator | 20m | Aggregator |
| 7 | Test multi-agent communication | 15m | Test results |
| 8 | Document messaging protocol | 15m | Protocol doc |

---

# PHASE 3: PATTERN VARIATION ENGINE

## Session 3.1: Serialization Templates (3 hours)

### Purpose (Manus Law 6)
```
"Language models are excellent mimics; they imitate the pattern of behavior 
in the context. If your context is full of similar past action-observation 
pairs, the model will tend to follow that pattern, even when it's no longer 
optimal."
```

### Template Bank
```python
SERIALIZATION_TEMPLATES = {
    "action_format": [
        "Executing {tool} with params: {params}",
        "Tool call: {tool}({params})",
        "Action: {tool} | Input: {params}",
        "Running {tool}...\nParameters: {params}",
        "→ {tool}\n  Args: {params}"
    ],
    
    "observation_format": [
        "Result: {result}",
        "Output:\n{result}",
        "← Observation: {result}",
        "{tool} returned: {result}",
        "Response:\n```\n{result}\n```"
    ],
    
    "error_format": [
        "Error: {error}",
        "Failed: {error}",
        "⚠️ Exception: {error}",
        "Tool {tool} raised: {error}",
        "ERROR in {tool}:\n{error}"
    ],
    
    "checkpoint_format": [
        "Progress: {completed}/{total} items complete",
        "Checkpoint: {completed} done, {remaining} remaining",
        "Status: {percentage}% complete",
        "Milestone: {completed} of {total} ✓",
        "📊 {completed}/{total} ({percentage}%)"
    ],
    
    "decision_format": [
        "Decision: {decision}\nRationale: {rationale}",
        "Chose to {decision} because {rationale}",
        "→ {decision}\n  Why: {rationale}",
        "DECISION: {decision}\nREASON: {rationale}"
    ]
}

class TemplateRotator:
    def __init__(self):
        self.usage_history = defaultdict(list)
        self.session_seed = int(time.time())
    
    def get_template(self, category: str) -> str:
        """Get varied template, avoiding recent repetition"""
        templates = SERIALIZATION_TEMPLATES[category]
        
        # Calculate recency weights (penalize recently used)
        weights = []
        recent = self.usage_history[category][-5:]  # Last 5 uses
        
        for i, t in enumerate(templates):
            if t in recent:
                # Penalize by how recently used (most recent = heaviest penalty)
                recency = recent[::-1].index(t) + 1
                weights.append(1.0 / (recency + 1))
            else:
                weights.append(1.0)
        
        # Normalize weights
        total = sum(weights)
        weights = [w / total for w in weights]
        
        # Select with weighted randomness (seeded for reproducibility)
        random.seed(self.session_seed + len(self.usage_history[category]))
        selected = random.choices(templates, weights=weights)[0]
        
        self.usage_history[category].append(selected)
        return selected
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design template categories | 20m | Category list |
| 2 | Create 5+ templates per category | 40m | Template bank |
| 3 | Implement weighted rotation | 25m | Rotator |
| 4 | Create template usage tracker | 20m | Tracker |
| 5 | Implement recency-based weighting | 20m | Weight calculator |
| 6 | Test variation effectiveness | 20m | Test results |
| 7 | Measure pattern drift reduction | 10m | Metrics |
| 8 | Document variation protocol | 15m | Protocol doc |

---

## Session 3.2: Structured Randomness (3 hours)

### Variation Configuration
```python
VARIATION_CONFIG = {
    "json_formatting": {
        "indent_options": [2, 4, None],  # None = compact
        "key_style": ["unchanged", "camelCase", "snake_case"],
        "variation_rate": 0.2  # 20% of the time, vary
    },
    
    "timestamp_format": {
        "formats": [
            "%Y-%m-%dT%H:%M:%SZ",      # ISO 8601
            "%Y-%m-%d %H:%M:%S",        # Human readable
            "%d %b %Y %H:%M",           # Short human
        ],
        "variation_rate": 0.15
    },
    
    "list_presentation": {
        "styles": ["bullet", "numbered", "comma_separated", "inline"],
        "shuffle_rate": 0.1  # 10% chance to shuffle non-critical lists
    },
    
    "whitespace": {
        "section_gaps": [1, 2],         # Newlines between sections
        "indent_spaces": [2, 4],
        "variation_rate": 0.25
    },
    
    "punctuation": {
        "sentence_endings": [".", ".", ".", "..."],  # Weighted toward period
        "list_separators": [", ", "; ", " | ", " / "],
        "variation_rate": 0.1
    }
}

class StructuredRandomizer:
    def __init__(self, seed: int = None):
        self.seed = seed or int(time.time())
        self.variation_count = 0
    
    def maybe_vary(self, category: str, value: Any) -> Any:
        """Apply variation with configured probability"""
        config = VARIATION_CONFIG[category]
        
        random.seed(self.seed + self.variation_count)
        self.variation_count += 1
        
        if random.random() > config.get("variation_rate", 0.2):
            return value  # No variation
        
        # Apply category-specific variation
        if category == "json_formatting":
            return self._vary_json(value, config)
        elif category == "timestamp_format":
            return self._vary_timestamp(value, config)
        elif category == "list_presentation":
            return self._vary_list(value, config)
        # ... etc
        
        return value
    
    def _vary_json(self, obj: dict, config: dict) -> str:
        indent = random.choice(config["indent_options"])
        return json.dumps(obj, indent=indent, sort_keys=True)
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Design variation configuration | 20m | Config schema |
| 2 | Implement JSON formatting variator | 20m | JSON module |
| 3 | Implement timestamp variator | 15m | Timestamp module |
| 4 | Implement list presentation variator | 20m | List module |
| 5 | Create variation controller | 25m | Controller |
| 6 | Implement seeded randomness (reproducible) | 20m | Seeder |
| 7 | Test pattern-breaking effectiveness | 20m | Test results |
| 8 | Document randomness protocol | 10m | Protocol doc |

---

# PHASE 4: INTEGRATION & VALIDATION

## Session 4.1: MCP Server Integration (3 hours)

### New MCP Tools
```typescript
// Context Engineering Tools
interface ContextEngineeringTools {
  // Cache Management
  prism_cache_check(): CacheStats;
  prism_cache_optimize(context: string): OptimizationSuggestions;
  
  // State Management (Append-Only)
  prism_state_append(event: StateEvent): EventId;
  prism_state_snapshot(): Snapshot;
  prism_state_rollback(to_event: EventId): void;
  
  // Memory Management
  prism_memory_store(content: string, tier: string, meta: object): MemoryId;
  prism_memory_retrieve(query: string, tier?: string): MemoryEntry[];
  prism_memory_compress(entry_id: MemoryId): CompressedEntry;
  prism_memory_restore(entry_id: MemoryId): string;
  
  // Team Management
  prism_team_create(name: string, config: TeamConfig): TeamId;
  prism_team_join(team_id: TeamId, agent_config: AgentConfig): void;
  prism_team_status(team_id: TeamId): TeamStatus;
  
  // Task Management
  prism_task_create(team_id: TeamId, task: TaskConfig): TaskId;
  prism_task_claim(task_id: TaskId, agent_id: AgentId): boolean;
  prism_task_complete(task_id: TaskId, result: object): void;
  prism_task_heartbeat(task_id: TaskId): void;
  
  // Messaging
  prism_message_send(to: AgentId, type: string, content: object): MessageId;
  prism_message_broadcast(type: string, content: object): MessageId[];
  prism_message_poll(unread_only?: boolean): Message[];
  
  // Variation
  prism_vary_template(category: string): string;
  prism_vary_format(content: object, category: string): string;
  
  // Todo/Recitation
  prism_todo_update(completed: number, next: string): void;
  prism_todo_get(): TodoState;
}
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Define new MCP tool schemas | 30m | Tool definitions |
| 2 | Implement cache management tools | 25m | Cache tools |
| 3 | Implement state management tools | 25m | State tools |
| 4 | Implement memory management tools | 25m | Memory tools |
| 5 | Implement team/task tools | 25m | Team tools |
| 6 | Update MCP server registration | 15m | Registration |
| 7 | Test all new tools | 15m | Test results |
| 8 | Document MCP additions | 10m | Documentation |

---

## Session 4.2: Generator Alignment (3 hours)

### Generator Updates Required
```
HookGenerator
├── Add CONTEXT_CACHE hook (validates cache stability)
├── Add APPEND_ONLY hook (enforces state immutability)  
├── Add ERROR_PRESERVE hook (prevents error cleanup)
└── Add VARIATION hook (tracks pattern diversity)

SkillGenerator
├── Output skills use prism_* tool prefixes
├── Skills include variation templates
└── Skills respect append-only state

ScriptGenerator
├── Scripts use append-only state operations
├── Scripts include heartbeat updates
└── Scripts use restorable compression

EngineGenerator
├── Engines maintain cache-stable prompts
├── Engines implement task dependencies
└── Engines support team coordination

SwarmOrchestrator
├── Uses team file structure
├── Implements heartbeat monitoring
├── Handles abandoned task recovery
└── Manages inter-agent messaging
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Update HookGenerator for context hooks | 25m | Updated generator |
| 2 | Add variation to SkillGenerator output | 25m | Updated generator |
| 3 | Ensure ScriptGenerator uses append-only | 20m | Updated generator |
| 4 | Add cache stability to EngineGenerator | 20m | Updated generator |
| 5 | Integrate SwarmOrchestrator with teams | 25m | Integration |
| 6 | Test generator outputs for compliance | 15m | Test results |
| 7 | Update generator documentation | 10m | Documentation |

---

## Session 4.3: Full System Validation (3 hours)

### Validation Checklist
```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    CONTEXT ENGINEERING VALIDATION                             ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  KV-CACHE STABILITY (Law 1)                                                   ║
║  [ ] Prompt prefix identical across 10 sessions                               ║
║  [ ] No timestamps in prefix                                                  ║
║  [ ] JSON serialization deterministic (sorted keys)                           ║
║  [ ] Cache hit rate > 80%                                                     ║
║                                                                               ║
║  TOOL MASKING (Law 2)                                                         ║
║  [ ] All tools have prism_* prefix                                            ║
║  [ ] State machine transitions correctly                                      ║
║  [ ] Masked tools not selectable                                              ║
║  [ ] Tool definitions never change mid-session                                ║
║                                                                               ║
║  FILE-BASED MEMORY (Law 3)                                                    ║
║  [ ] Memory tiers functioning (short/working/long)                            ║
║  [ ] Compression preserves restoration paths                                  ║
║  [ ] Restoration works for all content types                                  ║
║  [ ] Context savings > 50% on long tasks                                      ║
║                                                                               ║
║  ATTENTION RECITATION (Law 4)                                                 ║
║  [ ] todo.md updated every checkpoint                                         ║
║  [ ] Current focus always at context END                                      ║
║  [ ] Goal drift reduced over 50+ actions                                      ║
║  [ ] Task completion rate improved                                            ║
║                                                                               ║
║  ERROR PRESERVATION (Law 5)                                                   ║
║  [ ] Errors never cleaned from context                                        ║
║  [ ] Error patterns detected                                                  ║
║  [ ] Recovery suggestions generated                                           ║
║  [ ] Error repeat rate < 10%                                                  ║
║                                                                               ║
║  PATTERN VARIATION (Law 6)                                                    ║
║  [ ] Templates rotate correctly                                               ║
║  [ ] Variation is seeded (reproducible)                                       ║
║  [ ] Pattern drift reduced                                                    ║
║  [ ] No few-shot mimicry observed                                             ║
║                                                                               ║
║  TEAM COORDINATION                                                            ║
║  [ ] Teams can be created/discovered                                          ║
║  [ ] Tasks support dependencies (blocks/blockedBy)                            ║
║  [ ] Heartbeat detects abandoned tasks (5min timeout)                         ║
║  [ ] Inter-agent messaging works                                              ║
║  [ ] Atomic task claiming prevents races                                      ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

### Deliverables

| # | Task | Est | Output |
|---|------|-----|--------|
| 1 | Run cache stability tests | 20m | Test report |
| 2 | Run tool masking tests | 15m | Test report |
| 3 | Run memory system tests | 20m | Test report |
| 4 | Run recitation tests | 15m | Test report |
| 5 | Run error preservation tests | 15m | Test report |
| 6 | Run variation tests | 15m | Test report |
| 7 | Run team coordination tests | 20m | Test report |
| 8 | Generate final validation report | 15m | Final report |
| 9 | Update all documentation | 15m | Documentation |

---

# IMPLEMENTATION TIMELINE

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    WEEK-BY-WEEK TIMELINE                                      ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  WEEK 1 (Days 1-4): PHASE 0 - Context Optimization                            ║
║  ├── Day 1: Session 0.1 - KV-Cache Stable Prefix                              ║
║  ├── Day 2: Session 0.2 - Append-Only State                                   ║
║  ├── Day 3: Session 0.3 - Tool Masking State Machine                          ║
║  └── Day 4: Session 0.4 - Error Preservation                                  ║
║                                                                               ║
║  WEEK 2 (Days 5-7): PHASE 1 - File-Based Memory                               ║
║  ├── Day 5: Session 1.1 - todo.md Recitation                                  ║
║  ├── Day 6: Session 1.2 - Externalized Memory                                 ║
║  └── Day 7: Session 1.3 - Restorable Compression                              ║
║                                                                               ║
║  WEEK 3 (Days 8-11): PHASE 2 - Team Coordination                              ║
║  ├── Day 8:  Session 2.1 - Team/Task Structure                                ║
║  ├── Day 9:  Session 2.2 - Task Dependencies                                  ║
║  ├── Day 10: Session 2.3 - Heartbeat & Abandonment                            ║
║  └── Day 11: Session 2.4 - Inter-Agent Communication                          ║
║                                                                               ║
║  WEEK 4 (Days 12-13): PHASE 3 - Pattern Variation                             ║
║  ├── Day 12: Session 3.1 - Serialization Templates                            ║
║  └── Day 13: Session 3.2 - Structured Randomness                              ║
║                                                                               ║
║  WEEK 5 (Days 14-16): PHASE 4 - Integration                                   ║
║  ├── Day 14: Session 4.1 - MCP Server Integration                             ║
║  ├── Day 15: Session 4.2 - Generator Alignment                                ║
║  └── Day 16: Session 4.3 - Full Validation                                    ║
║                                                                               ║
║  ═══════════════════════════════════════════════════════════════════════════  ║
║  TOTAL: 16 sessions | 48 hours | 16 days @ 3 hrs/day                         ║
║  ═══════════════════════════════════════════════════════════════════════════  ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# SUCCESS METRICS

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    TARGET METRICS                                             ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  METRIC                          CURRENT    TARGET    MEASUREMENT             ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  KV-Cache Hit Rate               Unknown    > 80%     API cache analytics     ║
║  Context Token Efficiency        ~50%       > 85%     Useful tokens / total   ║
║  Error Repeat Rate               ~30%       < 10%     Same error twice        ║
║  Goal Drift (50+ actions)        High       Low       Plan adherence score    ║
║  Pattern Mimicry                 High       Low       Action diversity index  ║
║  Task Completion (complex)       ~60%       > 90%     End-to-end success      ║
║  Recovery from Failure           ~40%       > 80%     Error → Success rate    ║
║  Multi-Agent Coordination        N/A        Working   Team task completion    ║
║  Cost per Session                Baseline   -50%      API costs               ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# QUICK START: BEGIN WITH SESSION 0.1

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║  SESSION 0.1: KV-CACHE STABLE PREFIX PROTOCOL                                 ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  OBJECTIVE: Restructure all PRISM prompts to maximize KV-cache hit rate       ║
║                                                                               ║
║  TASKS (9 items, 3 hours):                                                    ║
║  1. [ ] Audit GSD_CORE for dynamic content in prefix                          ║
║  2. [ ] Audit PRISM_CONDENSED_PROTOCOL                                        ║
║  3. [ ] Create STABLE_PREFIX_TEMPLATE.md                                      ║
║  4. [ ] Restructure GSD_CORE (timestamps → END)                               ║
║  5. [ ] Create JSON key sorting utility                                       ║
║  6. [ ] Update CURRENT_STATE.json schema                                      ║
║  7. [ ] Create cache stability checker script                                 ║
║  8. [ ] Test prefix stability across 5 sessions                               ║
║  9. [ ] Document KV-cache optimization rules                                  ║
║                                                                               ║
║  CHECKPOINT: Prompt prefix 100% stable across sessions                        ║
║  IMPACT: Up to 10x cost reduction on cached tokens                            ║
║                                                                               ║
║  SAY: "Start Session 0.1" to begin                                            ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# APPENDIX A: REFERENCE SOURCES

| Source | Description | URL |
|--------|-------------|-----|
| Manus Context Engineering | Official engineering blog | https://manus.im/blog/Context-Engineering-for-AI-Agents-Lessons-from-Building-Manus |
| Manus Technical Report | Reverse-engineered architecture | https://gist.github.com/renschni/4fbc70b31bad8dd57f3370239dccd58f |
| Claude Code TeammateTool | Feature proposal with ERD | https://gist.github.com/kieranklaassen/d2b35569be2c7f1412c64861a219d51f |
| Claude Code Reverse | Prompt/tool analysis | https://github.com/Yuyz0112/claude-code-reverse |

---

# APPENDIX B: PRISM INTEGRATION POINTS

| PRISM Component | Context Engineering Integration |
|-----------------|--------------------------------|
| CURRENT_STATE.json | → Append-only events + snapshots |
| gsd_startup.py | → Cache-stable prefix + todo.md |
| session_memory_manager.py | → Externalized memory tiers |
| prism_unified_system_v6.py | → Team coordination + heartbeat |
| skill_selector.py | → Tool masking state machine |
| All generators | → Variation templates |

---

**PRISM CONTEXT ENGINEERING ROADMAP v1.0**
*Integrating Manus AI + Claude Code TeammateTool Patterns*
*16 sessions | 48 hours | 16 days*
*Created: 2026-02-01*
