# PHASE DA: DEVELOPMENT ACCELERATION — v14.4
# Status: not-started | Sessions: 8-12 | MS: 9 (MS0-MS8) | Role: Multi (see per-MS)
# Environment: Claude Code 100% (fallback: MCP + DC)
# Model: Varies per MS — Haiku (bulk ops), Sonnet (implementation), Opus (architecture)
# v14.4: Expanded from 6→9 milestones. Integrates: 15 operational improvements,
#         4-branch hierarchical index, session knowledge system.
#         See MASTER_ACTION_PLAN_v2.md for full rationale and dependency map.
# FALLBACK: If Claude Code is not available (not installed, not GA, licensing issue):
#   Execute DA in Claude.ai MCP + Desktop Commander instead. Adjustments:
#   - MS0 step 1 (CLAUDE.md): Create files via prism_dev action=file_write instead of CC
#   - MS1 steps 3-5 (subagents): Document specs in SUBAGENT_SPECS.md for future CC setup
#   - MS2 step 2 (skill conversion): Write .claude/skills/ files to disk, test when CC available
#   - MS2 step 3 (slash commands): Write .claude/commands/ files to disk, test when CC available
#   - MS4 (hooks): Write .claude/settings.json to disk, test when CC available
#   - MS5 gate: Skip CC-specific tests (subagent memory persistence, slash command execution)
#     Add: "CC_DEFERRED" items to ACTION_TRACKER for future validation
#   All file creation and skill conversion still happens — just tested later when CC is ready.
# Pattern: Every MS follows AUDIT → OPTIMIZE → TEST → DOCUMENT
#
# WHY THIS PHASE EXISTS AND WHY IT GOES FIRST:
#   Every session we lose context to compaction. Every session we under-utilize
#   skills, scripts, hooks, and agents. Every session we re-discover what was
#   already known. Every session we could be 2-3x faster if the development
#   infrastructure was optimized. This phase fixes that BEFORE R1 continues,
#   because the ROI compounds across every subsequent session.
#
#   Estimated time saved: 15-30 minutes per session × 50+ remaining sessions
#   = 12-25 hours of recovered development time.
#
# DEPENDS ON: P0 complete (dispatchers wired, Opus 4.6 configured)
# LEVERAGES: F2 (Memory Graph), F3 (Telemetry), F6 (NL Hooks), W2.5 (HSS)
# Gate: Ω ≥ 0.70 | All 5 subagents respond, 5 commands execute, 15 skills auto-load,
#       hooks fire on edit/bash, E2E test passes, Claude Code operational

---

## QUICK REFERENCE (standalone after compaction — no other doc needed)
```
BUILD:      npm run build (NEVER standalone tsc — OOM at current scale)
SAFETY:     S(x) >= 0.70 is HARD BLOCK
POSITION:   Update CURRENT_POSITION.md every 3 calls
FLUSH:      Write results to disk after each logical unit of work
ERROR:      Fix ONE build error, rebuild, repeat. >5 from one edit → git revert
IDEMPOTENT: Read-only = safe to re-run. Write = check if already done first.
STUCK:      3 same-approach fails → try different approach. 6 total → skip if non-blocking.
TRANSITION: Update CURRENT_POSITION first, ROADMAP_TRACKER second.
RECOVERY:   Read PRISM_RECOVERY_CARD.md for full recovery steps.
ENV:        DA = Claude Code 100% (fallback: MCP + DC). Model: Sonnet.
```

---

## CONTEXT BRIDGE

WHAT CAME BEFORE: P0 wired 31 dispatchers. F1-F8 features all complete. W2.5 HSS
optimization delivered 53 hooks, 6 skill chains, 6 response templates, pressure-adaptive
auto-injection. R1-MS0 through MS4 loaded registries to >95%.

WHAT THIS PHASE DOES: Optimizes the DEVELOPMENT PROCESS itself — context management,
session continuity, compaction recovery, tool utilization, AND configures Claude Code
as the primary development environment with persistent-memory subagents, deterministic
hooks, slash commands, and on-demand skill loading.

WHAT COMES AFTER: R1-MS4.5 through MS9 (data foundation completion), then R2 safety.

---

## DA-MS0: CONTEXT ENGINEERING AUDIT + OPTIMIZATION + CLAUDE.md HIERARCHY
### Goal: Minimize context loss, maximize useful context per token, establish Claude Code foundation
### Source: Manus AI 6 Laws, HSS W2.5, Compaction API behavior, Claude Code Briefing

```
0. SPLIT PROTOCOLS_CORE IMMEDIATELY (do this before anything else):
   Current: ~111KB (huge). Most sessions use <30% of content.
   Action: Split into tiered loading:
     PRISM_PROTOCOLS_BOOT.md      — Boot sequence + laws + effort config (~2K tokens)
     PRISM_PROTOCOLS_SAFETY.md    — Structured outputs + physics validation (~2K tokens)
     PRISM_PROTOCOLS_CODING.md    — Code standards + build process (~1.5K tokens)
   Load BOOT every session. Load SAFETY only during R2+ calc phases.
   Load CODING only during implementation sessions.
   Verify: load BOOT only → run health check → confirm system operational.
   SAVINGS: Immediate ~3-5K tokens per session from this point forward.
   This is a prerequisite, not a milestone — do it in the first 10 minutes of DA.
   ⚡ CLAUDE CODE: Can execute the split + verification in terminal while Desktop plans.

1. CREATE CLAUDE.md HIERARCHY (Claude Code foundation):
   Root CLAUDE.md at C:\PRISM\mcp-server\CLAUDE.md containing:
   - Core laws: S(x)≥0.70 hard block, Ω≥0.70 release ready
   - Current position: phase, milestone, active subtask
   - Build commands: npm run build (NEVER standalone tsc — OOM at current scale)
   - Registry counts: materials 3518, machines 824, tools (pending), alarms 9200+
   - Safety rules: no bare numbers, uncertainty bounds required on all values
   - Key file locations: MASTER_INDEX.md, wiring registries (D2F, F2E, E2S), state files
   - Code conventions: TypeScript patterns, import style, test structure

   Create nested CLAUDE.md files:
   - src/engines/CLAUDE.md — Engine conventions, AtomicValue schema requirement,
     force/power calculation patterns, uncertainty propagation rules
   - src/dispatchers/CLAUDE.md — Dispatcher patterns, parameter normalization,
     action routing, effort tier mapping

   WHY: Replaces ~80% of manual session boot protocol. Claude Code auto-loads
   these every session — no manual context injection needed.
   VERIFY: Start new Claude Code session, confirm it knows S(x) threshold,
   build command, and current phase without being told.

2. AUDIT CURRENT CONTEXT COSTS:
   Measure actual token cost of every framework file:
     - This master index: ___K tokens
     - PRISM_PROTOCOLS_BOOT.md (after split): ___K tokens
     - Each phase doc: ___K tokens
     - Boot overhead: ___K tokens
     - Skill auto-injection: ___K tokens (pressure-adaptive from W2.5)
   Record in CONTEXT_AUDIT.md

3. OPTIMIZE PHASE DOC LOADING:
   Large phase docs (R1=62K, R3=36K, R7=37K) contain completed MS content.
   Action: Add "SKIP TO CURRENT" markers in each phase doc.
   Format: <!-- CURRENT_MS: R1-MS5 --> at the active milestone.
   Loader reads from marker forward, skipping completed MS detail.
   SAVINGS: ~30-50% of phase doc tokens for phases with many completed MS.

4. IMPLEMENT CONTEXT BUDGET TRACKING:
   Add to boot protocol: measure framework load + log to CONTEXT_BUDGET_LOG.md
   Track: session_date, framework_tokens, work_tokens, compaction_count, ms_completed
   Enables: trend analysis showing if framework is growing unsustainably.

5. OPTIMIZE SKILL AUTO-INJECTION:
   W2.5 built pressure-adaptive sizing for 117 enriched skill descriptions.
   Audit: Which skills actually get injected? Which are useful vs noise?
   Action: Create SKILL_RELEVANCE_MAP.json mapping phase→relevant_skills.
   During R1: inject only data/registry skills. During R2: only calc/safety skills.
   SAVINGS: Inject 5-8 relevant skills instead of broad auto-injection.

6. CLAUDE CODE READINESS:
   a. Verify Claude Code runs simultaneously with Desktop (already confirmed v2.1.42)
   b. Verify CLAUDE.md at project root is read correctly (already confirmed)
   c. Create initial .claude/skills/ directory (full conversion in DA-MS3)
   d. Run parallel session test (Desktop + CLI simultaneously)
   e. Test agent teams if experimental flag available
   f. Document results in CLAUDE_CODE_READINESS.md
   g. Update PARALLEL_TASK_MAP.md with Claude Code capabilities
   h. Identify first 3 tasks to delegate to Claude Code in R1
```

### v14.4 ADDITIONS TO MS0 (Wave 0 + Wave 1):

```
W0-PROTOCOL FIXES (do FIRST, ~15 min, any model):
  W0-1: Add PowerShell DC protocol to PROTOCOLS_CORE §code_standards:
        "Never inline $ vars in DC start_process. Write .ps1 file first."
        Also add 1-liner to RECOVERY_CARD §ESSENTIAL RULES.
  W0-2: Add companion asset tracking format to PROTOCOLS_CORE:
        "COMPANION: [action] — SKILL: pending | HOOK: pending | SCRIPT: pending"
        Add gate check to PHASE_TEMPLATE.md.
  W0-3: Ensure position auto-save says "every 3 calls" (not 5). Add emphasis
        that this is the ONLY reliable cross-session state.
  VERIFY: Read back all 3 edits. Confirm text appears where expected.

W1-SECTION ANCHORS + INDEX (~1 session, Haiku+Sonnet):
  W1-1: Place ~220 section anchors across all 20+ roadmap .md files.
        Model: Haiku (mechanical bulk work, parallel 3 subagents).
        Format: <!-- ANCHOR: [prefix]_[section_name] --> before each ## and ### header.
        Prefixes: pc_ (PROTOCOLS_CORE), r1_ (R1), da_ (DA), mi_ (MASTER_INDEX), etc.
        Process: Read file → find headers → insert anchors → write back → verify count.
        TOTAL: 220-250 anchors. Verify: grep -r "ANCHOR:" roadmap/ | wc -l >= 220.
  W1-2: Build ROADMAP_SECTION_INDEX.md from placed anchors.
        Model: Sonnet (needs judgment for descriptions).
        Format: table per file with anchor|line|section|description columns.
        ~200 lines, ~1.5K tokens. This becomes the new "load first" navigation file.
  W1-3: Build scripts/roadmap/rebuild-section-index.ps1.
        Model: Sonnet. Scans all .md files, finds anchors, regenerates index.
        Also writes .roadmap-index-baseline.json for drift detection (>10 line shift = WARNING).
  W1-4: Update RECOVERY_CARD: Add STEP 1.5 "Load Section Index (optional, saves tokens)"
        between STEP 1 (position) and STEP 2 (phase doc).
  VERIFY: Anchor count >=220, index has all entries, script regenerates identically,
          Recovery Card has STEP 1.5, no files lost content.
```

---

## DA-MS1: SESSION CONTINUITY + SUBAGENTS WITH PERSISTENT MEMORY
### Goal: Zero re-discovery between sessions. Resume in <60 seconds. Persistent memory via subagents.
### Source: W2.5 checkpoint system, F2 Memory Graph, compaction behavior, Claude Code subagents

```
1. HARDEN CURRENT_POSITION.md:
   Current format: single line "CURRENT: R1-MS5 | LAST_COMPLETE: R1-MS4 2026-02-15"
   Expand to structured state:
     CURRENT_MS: DA-MS1
     LAST_COMPLETE: DA-MS0 2026-02-XX
     ACTIVE_SUBTASK: "Implementing session state persistence"
     BLOCKED_BY: (none)
     NEXT_3_STEPS: ["Finish subtask X", "Test Y", "Gate check Z"]
     CONTEXT_NOTES: "Key decision: split PROTOCOLS_CORE into 3 files. File X was modified."
     FILES_MODIFIED_THIS_SESSION: ["file1.ts", "file2.md"]
     UNCOMMITTED_WORK: "ToolIndex.ts has 200 lines written, needs testing"
   This survives compaction because it's on disk, not in context.

2. IMPLEMENT SESSION HANDOFF PROTOCOL:
   At session end (STEP 9 in workflow), write HANDOFF.md:
     - What was accomplished (bullet list)
     - What's in progress (with file locations)
     - What's next (ordered)
     - Key decisions made (with rationale)
     - Any gotchas or blockers discovered
   At session start, read HANDOFF.md FIRST — before loading phase doc.
   Delete after reading (single-use, prevents stale handoffs).

3. FLUSH-TO-DISK PROTOCOL OPTIMIZATION:
   Current: "Flush non-regenerable results every 5 tool calls"
   Problem: 5 calls is too infrequent. Compaction at call 4 loses work.
   New rule: Flush after EVERY significant result:
     - Calc result → write to CALC_RESULTS_STAGING.json
     - Code written → save file immediately (already done)
     - Decision made → append to DECISIONS_LOG.md
     - Error found → append to TODO via prism_context→todo_update
   Cost: ~2 extra seconds per flush. Benefit: zero work lost to compaction.

4. MEMORY GRAPH INTEGRATION (F2):
   F2 Memory Graph stores cross-session knowledge.
   Audit: What's in the graph? Is it being read at boot?
   Action: Ensure boot protocol reads key_memories from Memory Graph.
   Key memories to persist: active phase, recent decisions, known blockers,
   registry counts, last build status, current role.
   This provides continuity even if HANDOFF.md is missing.

5. CREATE 5 SUBAGENTS WITH PERSISTENT MEMORY:
   Create at ~/.claude/agents/:

   a. prism-safety-reviewer.md
      - Model: Opus | Memory: project | Tools: Read, Grep, Glob, Bash
      - Context: S(x)≥0.70 hard block. Check all calcs against CALC_BENCHMARKS.json.
        Update memory with calculation failure patterns across sessions.

   b. prism-registry-expert.md
      - Model: Sonnet | Memory: project | Tools: Read, Grep, Glob, Bash
      - Context: Manages 3518 materials, 824 machines, tools, 9200+ alarms,
        500 formulas, 697 strategies. Knows schemas. Updates memory with
        data quality patterns discovered during loading.

   c. prism-architect.md
      - Model: Opus | Memory: project | Tools: Read, Write, Grep, Glob, Bash
      - Context: Principal Systems Architect. Tracks design decisions with rationale.
        Consults wiring registries (D2F, F2E, E2S) before new implementations.
        Updates memory with architectural decisions across sessions.

   d. prism-test-runner.md
      - Model: Sonnet | Memory: project | Tools: Read, Bash, Glob
      - Context: Runs test suites, regression checks, benchmark validation.
        Tracks test coverage and failure history in memory.

   e. prism-data-validator.md
      - Model: Sonnet | Memory: project | Tools: Read, Grep, Glob, Bash
      - Context: Validates registry data quality — schema compliance, completeness,
        cross-reference integrity. Quarantines bad records with reason codes.

   WHY: Persistent memory replaces HANDOFF.md for cross-session knowledge.
   The safety reviewer accumulates knowledge about which calculations fail
   and why. The architect remembers design decisions without handoff files.
   VERIFY: Invoke each subagent with a test query. End session. Start new session.
   Ask subagent to recall the test query result. If it remembers → PASS.

6. COMPACTION RECOVERY ENHANCEMENT:
   Current: API handles compaction automatically. Recovery reads position files.
   Problem: After compaction, Claude loses in-progress reasoning and partial results.
   New protocol:
     a. Pre-compaction: Write COMPACTION_SNAPSHOT.md with current reasoning state
     b. Post-compaction: Boot reads COMPACTION_SNAPSHOT.md + HANDOFF.md + CURRENT_POSITION.md
     c. Three-source recovery: position (where), handoff (what), snapshot (why)
   COMPACTION_SNAPSHOT.md format:
     REASONING_STATE: "Evaluating whether to use TypeScript enum or const for tool categories"
     PARTIAL_RESULTS: "Tested 3 of 5 approaches, results in STAGING.json"
     DECISION_PENDING: "Need to decide enum vs const before proceeding"
```

### v14.4 ADDITIONS TO MS1 (Wave 4 — Session Intelligence):

```
W4-SESSION HEALTH + PRE-COMPACTION AUTO-DUMP (~1 session, Sonnet+Opus):

  W4-1: SESSION HEALTH SIGNAL (Sonnet implements, Opus designs thresholds):
    Add to PRISM state tracking:
      SessionHealth { call_count, estimated_tokens, elapsed_turns,
                      last_position_save, compaction_count, health_status }
    Thresholds (Opus decides exact values):
      GREEN:  calls < 20, tokens < 50K, compactions = 0
      YELLOW: calls 20-35 OR tokens 50-80K OR compactions = 1
      RED:    calls > 35 OR tokens > 80K OR compactions >= 2
    YELLOW → advisory "Session aging, save state, consider wrapping up"
    RED → directive "Complete current step, write handoff, stop"
    Expose: prism_session action=health_check → returns SessionHealth
    Wire into cadence: piggyback on existing todo@5 cadence check.

  W4-2: PRE-COMPACTION AUTO-DUMP HOOK (Sonnet):
    New hook in hookRegistration.ts:
      Name: pre_compaction_dump
      Trigger: cadence (fires on pressure check)
      Condition: contextPressure() > 0.55
      Action: writeCurrentPosition() + appendActionTracker() + writeCompactionSnapshot()
      Blocking: false (advisory, doesn't interrupt work)
    This REPLACES reactive "detect after compaction" with proactive "save before it hits."

  W4-3: WIRE INTO RECOVERY CARD (Sonnet):
    Update RECOVERY_CARD §COMPACTION ADAPTATION:
      After recovery → prism_session action=health_check
      RED → ultra-minimal mode (already defined)
      YELLOW → reduced mode (skip non-essential skill loading)
      GREEN → normal mode

  VERIFY: health_check returns correct status. Auto-dump fires at >55% pressure.
    npm run build succeeds. prism_dev action=health shows new action available.
```

---

## DA-MS2: SKILL / SCRIPT / HOOK UTILIZATION + SLASH COMMANDS + SKILL CONVERSION
### Goal: Use existing 126 skills, 161 scripts, 75 agents, 53 hooks at >50% utilization.
###       Convert top skills to Claude Code format. Create slash commands for workflow automation.
### Source: W2.5 HSS, ASSET_INVENTORY.md, TOOL_UTILIZATION_AUDIT, Claude Code Briefing

```
1. SKILL UTILIZATION AUDIT:
   126 skills exist. How many are actively used per session? Estimate: <10%.
   Action: Classify all 126 skills into tiers:
     TIER A (always relevant): core manufacturing, safety, data, session mgmt
     TIER B (phase-relevant): inject only during matching phase
     TIER C (rarely needed): specialized, load on demand only
     TIER D (dead/redundant): archive or merge
   Create SKILL_TIER_MAP.json. Wire into auto-injection so Tier A always loads,
   Tier B loads per-phase, Tier C/D never auto-inject.

1b. SCRIPT STUB AUDIT (v14.3 — audit finding GAP 4.4):
   1,320 scripts registered in SCRIPT_REGISTRY.json but only ~161 have implementations (12.3%).
   The 1,159 stubs are either future work or dead weight — unknown without classification.
   Action: Read SCRIPT_REGISTRY.json. For each registered script:
     - If implementation exists in ScriptExecutor → mark ACTIVE
     - If planned for a specific phase → mark DEFERRED with target phase
     - If no plan and no implementation → mark DEAD
   Create SCRIPT_CLASSIFICATION.json with { name, status: ACTIVE|DEFERRED|DEAD, target_phase? }
   Remove DEAD entries from SCRIPT_REGISTRY.json (Law 6: if it exists, it must work).
   Update MASTER_INDEX.md script counts to reflect reality.
   VERIFY: Script count in MASTER_INDEX matches ACTIVE + DEFERRED in classification.

2. CONVERT TOP 15 SKILLS TO CLAUDE CODE FORMAT:
   Convert from skills-consolidated/ to .claude/skills/ SKILL.md format with
   YAML frontmatter (name, description fields). Priority order:
     1. cutting-parameters (Kienzle, chip thinning, speed/feed)
     2. material-selection (ISO groups, machinability, substitution)
     3. safety-validation (S(x) computation, force limits, breakage risk)
     4. toolpath-strategy (697 strategies, feature matching)
     5. threading (tap drill, thread milling, engagement calc)
     6. surface-finish (Ra/Rz prediction, parameter influence)
     7. chip-control (chip breaking, evacuation, morphology)
     8. workholding (clamping force, fixture validation)
     9. coolant (flood/MQL/high-pressure selection, concentration)
     10. tool-life (Taylor equation, wear prediction, cost optimization)
     11. wear-analysis (flank/crater/notch patterns, countermeasures)
     12. alarm-diagnosis (9200+ codes, root cause, resolution)
     13. machine-capability (envelope, spindle, axis limits)
     14. controller-programming (Fanuc/Haiku/Siemens/Okuma G-code patterns)
     15. tolerance-analysis (IT grades, process capability, stack-up)
   WHY: Claude Code auto-loads skills when it detects relevance. Replaces W2.5
   pressure-adaptive injection system. Hot-reloading: save skill → instant update.
   VERIFY: Start a conversation about cutting parameters without mentioning the skill.
   Claude Code should auto-load cutting-parameters.md. If not → improve description.

3. CREATE 5 SLASH COMMANDS:
   Create at ~/.claude/commands/:
   a. /boot (boot.md) — Load CURRENT_POSITION.md, identify active phase, load phase doc,
      check for HANDOFF.md, plan session. Report: current MS, next 3 steps, blockers, scope.
   b. /gate (gate.md) — Run phase gate check: verify criteria, npm run build, test suite,
      Omega estimate, list unresolved findings.
   c. /checkpoint (checkpoint.md) — Save state: update CURRENT_POSITION.md, append
      ROADMAP_TRACKER.md, write HANDOFF.md, run npm run build for clean state.
   d. /plan (plan.md) — Read phase doc, identify next MS, break into steps, estimate effort,
      identify parallel work, propose session plan with model tier recommendations.
   e. /build (build.md) — Run npm run build, parse output, report errors with file:line,
      suggest fixes. NEVER run standalone tsc.
   WHY: Replaces manual multi-step session protocols. One keystroke instead of 9 steps.

4. SCRIPT UTILIZATION AUDIT:
   161 scripts registered. How many have implementations vs just registry entries?
   Action: Run script audit — count implemented vs stub vs broken.
   For the top 20 most useful scripts, verify they work end-to-end.
   Create SCRIPT_HEALTH_REPORT.md with: working, stub, broken counts.
   Fix or remove broken scripts. Implement top 5 stubs.

5. HOOK EFFECTIVENESS AUDIT:
   53 hooks active (62 registered). Which actually fire? Which catch real issues?
   Action: Add telemetry counters to hook system (F3 Telemetry integration).
   After 1 build cycle, report: hook_name, fire_count, block_count, false_positive_count.
   Tune thresholds for hooks with high false positive rates.
   Disable hooks that never fire (dead hooks waste registration overhead).

6. AGENT/SWARM OPTIMIZATION:
   75 agents registered. prism_orchestrate supports parallel execution.
   Current usage: minimal — most work is sequential single-agent.
   Action: Identify 5 tasks in upcoming R1-R3 work suitable for parallel agents:
     - R1-MS5/6/7 can run parallel (tool/material/machine are independent)
     - R2-MS0 50-calc matrix can batch across 10 materials in parallel
     - R3-MS4 data campaigns are inherently parallelizable
   Create PARALLEL_TASK_MAP.md mapping phase+MS to parallelizable sub-tasks.
   Test with prism_orchestrate→agent_parallel on a small batch.

7. SKILL CHAIN OPTIMIZATION:
   6 predefined skill chains exist from W2.5.
   Action: Audit which chains are used. Create 4 more chains for common workflows:
     - boot_and_resume: memory_recall → load_position → load_phase → plan
     - calc_and_validate: speed_feed → safety_check → uncertainty → report
     - registry_query: unified_search → cross_reference → format_result
     - debug_and_fix: error_diagnose → root_cause → fix → test → document
   Register new chains in SKILL_CHAIN_REGISTRY.json.
```

### v14.4 ADDITIONS TO MS2 (Wave 5-3 — Skill Phase-Loading):

```
W5-3: SKILL/DISPATCHER PHASE-LOADING (Opus designs → Haiku validates → Sonnet implements):

  Phase 1 — DESIGN PHASE-TO-SKILL MAP (Opus, ~30 min):
    Based on SKILL_RELEVANCE_MAP.json concept from step 0 above, create full mapping:
      DA skills:  session-management, context-engineering, parallel-execution
      R1 skills:  material-science, formula-registry, data-loading, tool-schema
      R2 skills:  speed-feed-calc, kienzle-force, taylor-tool-life, thread-calcs
      R3 skills:  data-campaigns, quality-validation, pfp-engine
      R4-R11: map similarly based on phase content
    Output: SKILL_PHASE_MAP.json

  Phase 2 — IMPLEMENT AUTO-LOADING (Sonnet, ~1 hr):
    In session_boot, after position recovery determines current phase:
      const phaseSkills = SKILL_PHASE_MAP[currentPhase];
      await Promise.all(phaseSkills.map(s => skillLoader.load(s)));
    Only loads skills relevant to current phase. Others stay unloaded.
    Estimated savings: 5-8 skills loaded instead of 126 = ~90% skill context reduction.

  Phase 3 — VALIDATE (Haiku, ~30 min):
    For each phase, invoke each mapped skill with a test query.
    Confirm: correct skills load, irrelevant skills don't, no errors.
    Log results to SKILL_PHASE_VALIDATION.md.

  VERIFY: Boot into R1 → only R1 skills loaded. Switch to R2 → skills swap. No errors.
```

---

## DA-MS3: MANUS / RALPH / SUPERPOWERS / AUTOMATION OPTIMIZATION
### Goal: Use advanced tools at full capability, not just basic invocations
### Source: Manus 6 Laws, Ralph validation, Superpowers methodology

```
1. MANUS 6 LAWS IMPLEMENTATION AUDIT:
   Law 1: KV-cache stability — Are we keeping system prompt stable? Audit.
   Law 2: Mask-don't-remove — Are we masking completed work or deleting? Audit.
   Law 3: Filesystem-as-context — Are we using disk as extended memory? Audit.
   Law 4: Attention via recitation — Are we reciting key state for attention? Audit.
   Law 5: Keep wrong stuff — Are we preserving errors for learning? Audit.
   Law 6: Avoid few-shot contamination — Are we avoiding bad patterns? Audit.
   For each law: score 1-5 compliance, identify specific violations, create fix.
   Write MANUS_COMPLIANCE.md with scores and action items.

2. RALPH LOOP OPTIMIZATION:
   Ralph requires API key for live validation.
   Current: ralph_loop used at phase gates only.
   Optimization: Use ralph_loop MORE FREQUENTLY:
     - After every MS completion (not just phase gate)
     - On any safety-critical code change
     - Before merging expanded phase stubs
   Create RALPH_SCHEDULE.md mapping when to run ralph at what depth:
     - Quick (1 iteration): after MS completion
     - Standard (3 iterations): before phase gate
     - Deep (5 iterations): before R6 production gate

3. SUPERPOWERS METHODOLOGY ENFORCEMENT:
   Brainstorm → Plan → Execute → Review(spec) → Review(quality) → Verify
   Current: Often skip Plan and Review steps under time pressure.
   Action: Add SUPERPOWERS_CHECKLIST.md as mandatory gate:
     Before each MS: ☐ Plan documented ☐ Approach reviewed
     After each MS: ☐ Spec review done ☐ Quality review done ☐ Evidence collected
   Wire as pre-MS and post-MS hook (NL Hook via F6).

4. AUTOPILOT OPTIMIZATION:
   AutoPilot.ts provides dynamic parsing and orchestrator-first routing.
   GSD v22.0 at data/docs/gsd/GSD_QUICK.md.
   Audit: Is AutoPilot routing optimally? Are GSD commands being used?
   Action: Test 10 common development commands through AutoPilot:
     "work on R1-MS5", "run safety check", "build and test", "check registry health",
     "plan next session", "show progress", "run ralph", "parallel batch X",
     "save and checkpoint", "resume from compaction"
   Fix any routing failures. Document working commands in GSD_COMMANDS.md.

5. NL HOOK AUTHORING (F6):
   F6 NL Hooks allow natural language hook creation.
   Action: Create 5 development-acceleration hooks via NL:
     "Before any file write, check if the file already exists and warn me"
     "After every build, report the build size and any new warnings"
     "When context pressure exceeds 70%, auto-flush staging files to disk"
     "Before phase gate, verify all companion assets are listed"
     "After compaction, read HANDOFF.md and CURRENT_POSITION.md automatically"
   These hooks protect development workflow, not just manufacturing calcs.
```

### v14.4 ADDITIONS TO MS3 (Wave 3 — prism_doc Enhancements):

```
W3-PRISM_DOC ENHANCEMENTS (~1 session, Sonnet impl, Opus review):
  Three new actions added to the doc dispatcher. Each saves significant tokens.

  W3-1: prism_doc action=hash (Content-addressed cache):
    Returns SHA-256 short hash (16 chars) of file content WITHOUT loading content.
    Usage: After compaction → hash all files → compare to remembered hashes →
      only reload files whose hash changed. Saves ~10K per file NOT reloaded.
    Implementation: crypto.createHash('sha256').update(content).digest('hex').substring(0,16)
    Returns: { name, hash, size, modified }

  W3-2: prism_doc action=diff (Change detection):
    Compare current file against baseline hash or git history.
    Mode A: diff name=X baseline_hash=abc123 → diff since that hash
    Mode B: diff name=X since=2026-02-16 → diff since date (via git log)
    Returns: list of changed anchor sections + line count delta. NOT full diff.
    Use: Verify edits didn't regress. Show what changed since last session.

  W3-3: prism_doc action=read_section (Anchor-aware partial loading):
    Read from one anchor to the next (or end of file).
    prism_doc action=read_section name=PRISM_PROTOCOLS_CORE.md section=pc_boot_protocol
    Returns: only content between that anchor and the next anchor.
    DEPENDS ON: W1 anchors being in place. Without anchors → falls back to full read.
    This is the primary token saver: 30 lines instead of 2,106.

  BUILD: npm run build after each action. Test: prism_dev action=health.
  OPUS GATE: Review diff output schema — it feeds into regression detection.
  VERIFY: All 3 actions callable. hash returns consistent results. read_section
    returns correct content boundaries. diff reports actual changes.
```

---

## DA-MS4: DETERMINISTIC HOOK CONFIGURATION (Claude Code)
### Goal: Deterministic build verification and safety checks that CANNOT be skipped
### Source: Claude Code hooks system

```
1. Add to .claude/settings.json:
   PostToolUse hooks:
   - Matcher: "Edit" → command: "npm run build 2>&1 | tail -5"
     (Every file edit triggers a build — catch breaks immediately)

   PreToolUse hooks:
   - Matcher: "Bash" → command: "node scripts/validate-safety-score.js"
     (Every bash execution checks safety score context)

2. Additional hooks to configure:
   - Pre-file-write: Anti-regression check (verify file exists, create backup)
   - Post-session: Auto-write checkpoint to CLAUDE.md

   WHY: These are DETERMINISTIC — Claude Code cannot skip, forget, or decide otherwise.
   Unlike prompt-based MCP hooks which are probabilistic, these ALWAYS fire.
   Development process hooks become guaranteed. Manufacturing calculation hooks
   still run server-side via MCP for safety.

   VERIFY: Edit any .ts file. Build should auto-run within 2 seconds.
   If build fails, the error should appear in the session immediately.
```

---

## DA-MS5: QA TOOLING + CONTEXT OPTIMIZATION (NEW in v14.4)
### Goal: Automated roadmap integrity checks + reduce context overhead from ~18K to ~6K tokens/session
### Model: Sonnet (scripts) + Opus (usage analysis for protocol split)
### Source: Wave 2 (QA tooling) + Wave 5 (context optimization)

```
QA SCRIPTS (Wave 2 — ~30 min, Sonnet):

  W2-1: TOKEN ESTIMATE UPDATER — scripts/roadmap/update-token-estimates.ps1
    For each roadmap .md: count words ÷ 0.75 = estimated tokens.
    Update PRISM_MASTER_INDEX.md Document Manifest token estimates.
    Update RECOVERY_CARD phase-file mapping with current line counts.
    Output per file: "[filename]: [lines] lines, ~[tokens] tokens (was [old])."
    VERIFY: Run script. Check MASTER_INDEX token column matches reality.

  W2-2: ROADMAP LINT — scripts/roadmap/roadmap-lint.ps1
    Checks (each is a named test that reports PASS/FAIL):
    a. Every file in MASTER_INDEX Document Manifest exists on disk
    b. Every LOADER:SKIP marker points to a valid line (not beyond EOF)
    c. Every <!-- ANCHOR: xxx --> has a matching entry in SECTION_INDEX
    d. Every phase in Phase Registry has a matching PHASE_*.md file
    e. CURRENT_POSITION.md references a valid phase and MS
    f. No file shrank >10% since last lint (regression detection)
    g. Version headers are consistent (all say v14.4+)
    h. Cross-references between files resolve (§X → §X exists in target)
    Stores baselines in scripts/.roadmap-lint-baseline.json
    Exit: 0=clean, 1=warnings, 2=errors
    VERIFY: Run lint on current roadmap. Should be 0 (clean). Intentionally break
    something (delete a file reference). Re-run. Should be 2 (error). Fix and re-run.

  W2-3: REGRESSION TEST — scripts/roadmap/roadmap-regression-test.ps1
    Wraps: lint + index rebuild + drift check + structure validation.
    Run after ANY batch of roadmap edits.
    VERIFY: Run after W5 context changes below. Should pass.

CONTEXT OPTIMIZATION (Wave 5 — ~1 session, Opus analysis + Sonnet implementation):

  W5-1: PROTOCOLS_CORE USAGE ANALYSIS (Opus, ~30 min):
    Load SECTION_INDEX (from W1). For each section in PROTOCOLS_CORE, classify:
      TIER A (every session):    Boot, env detection, position recovery, essential rules
      TIER B (phase-dependent):  Compaction, stuck, build rules, error handling
      TIER C (rare/on-demand):   Crash recovery, degradation, cadence details
      TIER D (reference only):   Error taxonomy, full schema definitions, changelogs
    Count: how many sections per tier, how many tokens per tier.
    Expected: A ~2K, B ~3K, C ~3K, D ~2K tokens.
    Output: PROTOCOLS_CORE_TIER_ANALYSIS.md

  W5-2: IMPLEMENT PROTOCOL SPLIT (Sonnet, ~1 hr):
    Create PRISM_PROTOCOLS_BOOT.md — Tier A sections only (~2K tokens).
    This is loaded EVERY session instead of full PROTOCOLS_CORE.
    Leave PROTOCOLS_CORE intact — add <!-- EXTRACTED TO PROTOCOLS_BOOT.md --> markers
    on sections that were copied to BOOT. CORE stays as the deep reference.
    Update cross-references:
      MASTER_INDEX: "Load PROTOCOLS_BOOT.md" (not CORE) in session workflow
      RECOVERY_CARD: reference BOOT for recovery, CORE "for deep reference only"
      Phase Quick Reference headers: remain self-contained (no change needed)
    VERIFY: Load BOOT only. Does it have everything needed for a standard session?
    Test: boot → position → phase doc → execute 3 steps. No missing references.

  W5-4: MASTER_INDEX SLIM-DOWN (Sonnet, ~30 min):
    Create PRISM_MASTER_INDEX_SLIM.md (~200 lines, ~1.5K tokens):
      System state condensed to 20 lines
      Phase registry table as-is (~20 lines)
      Session workflow: "Read RECOVERY_CARD" (not duplicate steps)
      Document manifest: file list only (use SECTION_INDEX for detail)
    Keep full MASTER_INDEX for phase gates. Load SLIM for normal sessions.
    VERIFY: SLIM has all critical info. Full INDEX still exists. No data lost.

TOKEN SAVINGS VERIFICATION:
  Before: MASTER_INDEX (~4K) + PROTOCOLS_CORE (~13K) + phase doc (~6K) = ~23K tokens
  After:  SLIM (~1.5K) + BOOT (~2K) + phase sections (~2K) = ~5.5K tokens
  SAVINGS: ~17K tokens per session = room for ~4x more useful work per compaction cycle.
  MEASURE: Count actual tokens loaded in a test session. Compare to baseline.
```

---

## DA-MS6: HIERARCHICAL INDEX — CODE + DATA BRANCHES (NEW in v14.4)
### Goal: Build a 4-branch hierarchical index of the entire PRISM system
### Model: Haiku (scanning) + Sonnet (extraction scripts) + Opus (schema design)
### Source: System architecture, registry structure, dispatcher wiring
### Sessions: ~2 (schema + Branch 1 in session 1, Branch 2 in session 2)

```
THE 4 BRANCHES:
  Branch 1: EXECUTION CHAIN — how code flows (dispatcher→action→engine→formula→registry)
  Branch 2: DATA HIERARCHY — how knowledge is organized (registry→group→family→grade→properties)
  Branch 3: RELATIONSHIP GRAPH — how things connect across branches (built during R2-R8)
  Branch 4: SESSION KNOWLEDGE — what Claude has learned (built by DA-MS7 knowledge system)

THIS MILESTONE BUILDS BRANCHES 1 + 2. Branch 3 is contributed by R2+ phases.
Branch 4 is built by DA-MS7 below.

STEP 1: DESIGN INDEX SCHEMA (Opus, ~30 min):
  Define the canonical format for all 4 branches:

  Branch 1 schema (execution_chain):
    {
      dispatchers: {
        [dispatcher_name]: {
          file: string,           // source file path
          actions: {
            [action_name]: {
              parameters: object,   // input schema
              engines: string[],    // which engines are instantiated
              registries: string[], // which registries are queried
              formulas: string[],   // which formulas are used
              returns: object,      // output schema
              safety: boolean       // requires S(x) check?
            }
          }
        }
      }
    }

  Branch 2 schema (data_hierarchy):
    {
      materials: {
        iso_groups: {
          [group_code]: {
            families: {
              [family_name]: {
                grades: string[],   // grade names in this family
                count: number,
                property_coverage: object  // which fields are populated, pct
              }
            }
          }
        },
        total: number,
        loading_pct: number
      },
      tools: { /* similar hierarchy: category→type→diameter→insert */ },
      machines: { /* manufacturer→model→capabilities */ },
      alarms: { /* controller→range→codes */ },
      formulas: { /* domain→formula_name→parameters */ }
    }

  Branch 3 schema (relationships — DESIGN ONLY, populated in R2+):
    {
      edges: [
        {
          from: { branch: "materials", path: "S/nickel/Inconel-718" },
          to: { branch: "tools", path: "milling/face_mill/carbide_C6" },
          type: "compatible_with",
          confidence: "verified" | "hypothesized",
          source: "R2-MS3 validation",
          constraints: { max_speed: 45, coolant_required: true }
        }
      ]
    }

  Branch 4 schema (session_knowledge — DESIGN ONLY, populated by DA-MS7):
    {
      entries: [
        {
          type: "decision" | "error_fix" | "assumption" | "performance" | "blocker" | "relationship",
          phase: "R1", milestone: "MS5",
          summary: string,
          detail: string,
          tags: string[],
          session_date: string,
          confidence: "verified" | "hypothesized" | "observed",
          promoted_to: null | { branch: number, path: string }  // null until promoted
        }
      ]
    }

  Output: HIERARCHICAL_INDEX_SPEC.md with all 4 schemas + querying protocol.
  Output: C:\PRISM\knowledge\index_schema.json (the machine-readable schema).

STEP 2: BUILD BRANCH 1 — EXECUTION CHAIN (Haiku scans, Sonnet extracts):
  Create scripts/index/build-execution-chain.ps1 (or .ts):

  Process for each dispatcher (31 total):
    1. Find the dispatcher file in src/dispatchers/
    2. Parse action names (case statements or action registry)
    3. For each action, find which engines are instantiated (new XxxEngine)
    4. For each engine, find which formulas are referenced
    5. For each formula, find which registry fields are read
    6. Record the full chain: dispatcher→action→engine→formula→registry_field

  Output: C:\PRISM\knowledge\branch1_execution_chain.json
  Output: C:\PRISM\knowledge\branch1_summary.md (human-readable summary)

  VERIFY: Pick 5 known action chains (e.g., prism_calc→speed_feed→SpeedFeedEngine).
  Compare script output to manually traced chain. If any mismatch → fix extraction.
  Coverage: should capture 31 dispatchers, 368+ actions. If <300 actions → scan missed some.

STEP 3: BUILD BRANCH 2 — DATA HIERARCHY (Haiku scans registries):
  Create scripts/index/build-data-hierarchy.ps1 (or .ts):

  Process for each registry:
    Materials (3,518 files):
      1. Scan data/materials/ directory structure
      2. Parse ISO group from filenames or content
      3. Group by group→family→grade
      4. For each grade, check which of the 127 fields are populated
      5. Record: total count, group distribution, field coverage percentages

    Tools (5,238 files):
      1. Scan data/tools/ directory structure
      2. Group by category→type→subtype
      3. Record: counts, geometry field coverage

    Machines (1,016 entries):
      1. Scan data/machines/
      2. Group by manufacturer→model
      3. Record: capability fields coverage

    Alarms (10,033 entries):
      1. Scan data/alarms/
      2. Group by controller→range

    Formulas (500):
      1. Scan formula registry
      2. Group by domain (cutting_force, tool_life, surface_finish, etc.)

  Output: C:\PRISM\knowledge\branch2_data_hierarchy.json
  Output: C:\PRISM\knowledge\branch2_summary.md

  VERIFY: Total counts match known values (3518 materials, etc.).
  Property coverage matches W5 registry loading findings.

STEP 4: CREATE INDEX QUERY PROTOCOL:
  Add to PROTOCOLS_CORE (or PROTOCOLS_BOOT):
    "To answer any question about PRISM capabilities, query the hierarchical index:
     prism_knowledge action=query_index branch=1 path=prism_calc/speed_feed
     → returns: engines, formulas, registries used by speed_feed action
     prism_knowledge action=query_index branch=2 path=materials/S/nickel
     → returns: all nickel-alloy grades, property coverage, counts"

  If prism_knowledge action doesn't exist yet → create the dispatcher action.
  If it does exist → wire it to read from C:\PRISM\knowledge\ JSON files.

STEP 5: WIRE INDEX REBUILD INTO BUILD PIPELINE:
  Add to npm run build (post-build step):
    node scripts/index/build-execution-chain.js (regenerate Branch 1)
  Branch 2 is stable (registry data doesn't change on build) — regenerate weekly or on demand.
  Branch 3 and 4 are append-only — no rebuild needed, just append new entries.

  VERIFY: npm run build completes. Branch 1 JSON updated. No build time regression >5s.
```

---

## DA-MS7: SESSION KNOWLEDGE SYSTEM (NEW in v14.4)
### Goal: Capture what Claude learns each session and make it queryable in future sessions
### Model: Sonnet (implementation) + Opus (extraction protocol design)
### Source: Branch 4 of hierarchical index, F2 Memory Graph, session handoff protocol
### Sessions: ~2 (schema + extraction in session 1, query + promotion in session 2)

```
THIS IS THE MOST IMPACTFUL NEW CAPABILITY:
  Currently: ~5% of session knowledge survives to next session (only CURRENT_POSITION.md)
  After: ~90% of actionable knowledge survives (decisions, errors, relationships, observations)
  Effect: Sessions stop re-discovering what was already learned. "Just say continue" includes
  not just WHERE to continue but WHAT WE KNOW about the work.

STEP 1: CREATE KNOWLEDGE DIRECTORY STRUCTURE:
  C:\PRISM\knowledge\            ← created in MS6 for index, reuse
  C:\PRISM\knowledge\sessions\   ← per-session extractions
  C:\PRISM\knowledge\decisions\  ← promoted decisions (permanent)
  C:\PRISM\knowledge\errors\     ← known error fixes (permanent)
  C:\PRISM\knowledge\observations\ ← performance and behavior notes
  C:\PRISM\knowledge\relationships\ ← discovered cross-registry edges (→ Branch 3)
  C:\PRISM\knowledge\SESSION_KNOWLEDGE_INDEX.json ← queryable master index

STEP 2: DESIGN EXTRACTION PROTOCOL (Opus, ~30 min):
  Define what gets extracted from each session. Six knowledge types:

  TYPE: decision
    TRIGGER: Claude chose between alternatives (A vs B, decided A)
    EXAMPLE: "Chose TypeScript enum over const for tool categories because const
              allows computed values needed for composite keys."
    WHY SAVE: Future sessions must respect this choice, not re-decide.

  TYPE: error_fix
    TRIGGER: An error was encountered and a fix was found
    EXAMPLE: "MaterialRegistry.get() returns null for materials with spaces in ISO.
              Fix: normalize with trim() before lookup."
    WHY SAVE: Prevents rediscovering the same bug. Saves 5-10 calls per occurrence.

  TYPE: assumption
    TRIGGER: Claude assumed something was true and it was validated or invalidated
    EXAMPLE: "Assumed all tool files have 'geometry' field. False — 1,247 of 5,238 lack it."
    WHY SAVE: Prevents future sessions from making the same false assumption.

  TYPE: performance
    TRIGGER: A performance characteristic was observed or benchmarked
    EXAMPLE: "Loading all 3,518 material files takes 4.2s. Batch 500 reduces to 2.8s."
    WHY SAVE: Prevents re-benchmarking. Informs optimization decisions.

  TYPE: blocker
    TRIGGER: A step was blocked and the block was resolved OR deferred with context
    EXAMPLE: "R1-MS5 step 7 blocked: ToolIndex composite key needs schema finalization.
              Deferred to MS5 step 12."
    WHY SAVE: Next session sees "DEFERRED" but also knows WHY and WHEN it'll resolve.

  TYPE: relationship
    TRIGGER: A cross-registry connection was discovered during work
    EXAMPLE: "Inconel 718 calculations require BOTH kc1.1 AND thermal conductivity.
              Kienzle extended model needs thermal for temperature compensation."
    WHY SAVE: Feeds directly into Branch 3 of hierarchical index.

  EXTRACTION RULES:
    - Extract at session end OR before handoff OR before expected compaction
    - Each entry is 1-4 sentences. Not paragraphs. Not raw conversation.
    - Tag with: phase, milestone, relevant anchors, date
    - Confidence: "verified" (tested and confirmed), "observed" (seen but not tested),
      "hypothesized" (inferred but not confirmed)
    - Maximum: 10 entries per session (quality over quantity)

  Output: KNOWLEDGE_EXTRACTION_PROTOCOL.md (the instructions for Claude to follow)

STEP 3: BUILD EXTRACTION TOOLING (Sonnet, ~1 hr):
  Option A (MCP server — preferred):
    Add prism_knowledge action=extract_session_knowledge:
      Input: array of knowledge entries (type, phase, ms, summary, detail, tags, confidence)
      Action: Write each entry to C:\PRISM\knowledge\[type]\[date]_[slug].md
      Action: Update SESSION_KNOWLEDGE_INDEX.json with new entries
      Return: count of entries saved, total index size

  Option B (DC fallback):
    Write entries directly via DC write_file to the knowledge directory.
    Update SESSION_KNOWLEDGE_INDEX.json manually.

  SESSION_KNOWLEDGE_INDEX.json format:
    {
      "version": 1,
      "entry_count": 47,
      "entries": [
        {
          "id": "2026-02-16_tool-index-composite-key",
          "type": "decision",
          "phase": "R1", "milestone": "MS5",
          "summary": "ToolIndex composite key requires [category, diameter, material_class]",
          "tags": ["tool_registry", "schema_design", "R1-MS5"],
          "date": "2026-02-16",
          "confidence": "verified",
          "file": "decisions/2026-02-16_tool-index-composite-key.md",
          "promoted_to": null
        }
      ],
      "by_phase": { "R1": [0, 1, 5, 12], "DA": [2, 3, 4] },
      "by_type": { "decision": [0, 3], "error_fix": [1, 4, 5] }
    }

  The by_phase and by_type indexes allow fast lookup without scanning all entries.

  VERIFY: Extract 3 test entries from THIS session's work. Check they appear in index.
  Read them back. Confirm content matches.

STEP 4: BUILD KNOWLEDGE QUERY ON BOOT (Sonnet, ~30 min):
  Integrate into boot sequence (PROTOCOLS_BOOT.md and RECOVERY_CARD):

  After position recovery (we know current phase + MS):
    IF SESSION_KNOWLEDGE_INDEX.json exists:
      Query: entries where phase = current_phase AND milestone = current_ms
      Also: entries where type = "error_fix" AND tags contain current_ms topic
      Load summaries into context (~50-200 tokens depending on match count)
      Log: "Loaded N knowledge entries for [phase]-[ms]"
    IF index missing: skip (knowledge is optional, not required for execution)

  Update RECOVERY_CARD §STEP 3: EXECUTE:
    Add: "Before executing, check knowledge index for current MS:
          prism_knowledge action=query phase=[phase] milestone=[ms]
          This returns decisions, known errors, and observations from prior sessions.
          Apply this knowledge: respect decisions, avoid known errors, use observations."

  VERIFY: Boot a new session. Say "continue." Knowledge entries appear in context.
  Claude doesn't rediscover previously-found errors.

STEP 5: BUILD KNOWLEDGE PROMOTION (Opus reviews, Sonnet implements):
  Some session knowledge should become PERMANENT system knowledge:

  PROMOTION RULES:
    error_fix verified in 2+ sessions → becomes a test case or code fix
    decision verified in 3+ sessions → becomes a protocol rule or code comment
    relationship verified → becomes an edge in Branch 3 (relationship graph)
    performance confirmed → becomes a benchmark in PERF_BASELINES.json
    blocker resolved → archive (but keep for reference)
    assumption invalidated → flag any code that still assumes the wrong thing

  Process:
    Every 5 sessions, Opus reviews SESSION_KNOWLEDGE_INDEX.json:
      - Which entries have been re-encountered?
      - Which are verified across multiple sessions?
      - Which should be promoted to permanent knowledge?
    For promoted entries:
      - Write to appropriate permanent location (test, code comment, Branch 3, protocol)
      - Update entry: promoted_to = { branch, path }
      - Entry stays in index (for provenance) but flagged as promoted

  VERIFY: After 5 R1 sessions, review index. At least 3 entries should be promotable.
  Promote one. Verify it appears in the target location. Verify index updated.

STEP 6: WIRE EXTRACTION INTO SESSION END PROTOCOL:
  Update PROTOCOLS_CORE §SESSION HANDOFF:
    BEFORE HANDOFF (add as step 0 of handoff):
      Review this session's work. Extract up to 10 knowledge entries.
      Call prism_knowledge action=extract_session_knowledge with entries.
      THEN proceed with normal handoff (position, tracker, state save).

  Update RECOVERY_CARD §SESSION END PROTOCOL:
    Add: "0. Extract session knowledge (decisions, errors, observations)
          prism_knowledge action=extract_session_knowledge entries=[...]"

  VERIFY: End a session. Check C:\PRISM\knowledge\sessions\ for new entries.
  Check SESSION_KNOWLEDGE_INDEX.json updated. Start new session. Knowledge loads.
```

---

## DA-MS8: PHASE GATE + END-TO-END INTEGRATION TEST + COMPANION ASSETS (was MS5)
### Gate: Development infrastructure is measurably faster. Claude Code fully operational.

```
END-TO-END INTEGRATION TEST:
Execute this exact sequence:
1. /boot → should report current position, phase, next steps
2. Pick a small R1 task (e.g., validate one material file schema)
3. Invoke registry-expert subagent for schema guidance
4. Make an edit → verify post-edit build hook fires
5. /checkpoint → should save state to all 3 files
6. Resume → /boot again → should pick up exactly where checkpoint left off
7. Spawn 3 parallel subagents on 3 independent file validation tasks
8. Verify all 3 complete and results merge correctly
9. End session. Start new session. Verify subagent memory persists.

GATE CRITERIA:
  1. PROTOCOLS_CORE split into 3 files, measured token savings documented
  2. CLAUDE.md hierarchy created, auto-loads correctly in Claude Code
  3. CURRENT_POSITION.md expanded to structured format, tested across session restart
  4. HANDOFF.md protocol tested — write at end, read at start, verified continuity
  5. SKILL_TIER_MAP.json created with all 126 skills classified
  6. At least 10/15 Claude Code skills auto-load when relevant topics arise
  7. SCRIPT_HEALTH_REPORT.md shows >80% of top 20 scripts working
  8. All 5 subagents respond correctly to domain queries
  9. All 5 slash commands execute without error
  10. At least 1 parallel agent batch tested successfully
  11. MANUS_COMPLIANCE.md shows ≥3/5 on all 6 laws
  12. Post-edit hook fires build within 2 seconds
  13. Subagent memory persists across session boundary
  14. /checkpoint → /boot cycle preserves state
  15. Ralph schedule documented and tested at MS-level
  16. 5 NL development hooks created and firing
  17. Context budget tracking active and logging
  Ω ≥ 0.75

v14.4 ADDITIONAL GATE CRITERIA (items 18-30):
  18. Section anchors placed on all 20+ files (≥220 total, verified by grep)
  19. ROADMAP_SECTION_INDEX.md exists, has all anchors, regeneration script works
  20. roadmap-lint.ps1 runs clean (exit 0) on current roadmap state
  21. roadmap-regression-test.ps1 passes all checks
  22. prism_doc action=hash works — returns consistent hashes
  23. prism_doc action=read_section works — loads anchor-bounded content
  24. prism_doc action=diff works — reports changed sections
  25. Session health_check returns valid status with correct thresholds
  26. Pre-compaction auto-dump fires at >55% pressure (test with simulated pressure)
  27. PROTOCOLS_BOOT.md created, loads in ≤2K tokens, sufficient for standard session
  28. MASTER_INDEX_SLIM.md created, loads in ≤1.5K tokens
  29. Token savings measured: normal session loads ≤6K tokens of roadmap docs
  30. Hierarchical index Branches 1+2 populated, queryable via prism_knowledge
  31. SESSION_KNOWLEDGE_INDEX.json exists with ≥5 entries from DA work
  32. Knowledge query on boot loads relevant entries for current MS
  33. Cold start test: new chat → "continue" → Claude executes without human guidance
  34. Compaction recovery test: recovers in ≤3 calls, resumes without re-reading full docs
  35. Rapid compaction test: 3 compactions → ultra-minimal mode → still makes progress
  Ω ≥ 0.80 (raised from 0.75 due to expanded scope)

MEASURABLE OUTCOME:
  Session startup time: <60 seconds from boot to productive work
  Context waste: <10% of framework tokens are unused per session
  Continuity: Zero re-discovery of previous session's work
  Compaction recovery: Resume within 30 seconds after compaction

FAILURE PROTOCOL: If any check fails, fix the specific config file and re-test
that check. Do not proceed to R1 until all checks pass.

COMPANION ASSETS (built after DA features):

  HOOKS (MCP + Claude Code):
    context_pressure_flush    — auto-flush staging files at >70% pressure
    pre_phase_gate_check      — verify companion assets listed before gate
    post_compaction_recovery   — auto-read HANDOFF + POSITION after compaction
    session_handoff_reminder   — warn if session ending without HANDOFF.md written
    build_size_monitor         — report build size and new warnings after every build
    post_edit_build (CC)       — deterministic build after every file edit
    pre_bash_safety (CC)       — safety score check before bash execution
    pre_write_antiregression (CC) — backup + size check before file overwrites

  SCRIPTS:
    session_startup           — boot + position + handoff + phase load in one command
    session_shutdown          — save + handoff + checkpoint + todo in one command
    context_audit             — measure current framework token costs
    skill_utilization_report  — show which skills fired this session
    parallel_readiness_check  — verify if current task is parallelizable

  SKILLS:
    prism-session-management  — teaches Claude optimal session start/end protocols
    prism-context-engineering — teaches Claude Manus 6 Laws + context optimization
    prism-parallel-execution  — teaches Claude when/how to use agent_parallel
    prism-ralph-validation    — teaches Claude when/how to run ralph at what depth
    + 15 Claude Code skills converted from skills-consolidated/ (DA-MS2)

  SUBAGENTS (with persistent memory):
    prism-safety-reviewer     — Opus, tracks calc failure patterns
    prism-registry-expert     — Sonnet, tracks data quality patterns
    prism-architect           — Opus, tracks design decisions
    prism-test-runner         — Sonnet, tracks test coverage/failures
    prism-data-validator      — Sonnet, tracks schema compliance

  SLASH COMMANDS:
    /boot, /gate, /checkpoint, /plan, /build
```

---

## DA PRODUCES (artifacts for downstream phases):

```
CONTEXT_AUDIT.md              — Token costs for all framework files
SKILL_TIER_MAP.json           — 126 skills classified into tiers A/B/C/D
SKILL_RELEVANCE_MAP.json      — Phase → relevant skills mapping
SCRIPT_HEALTH_REPORT.md       — Script implementation status
PARALLEL_TASK_MAP.md          — Parallelizable tasks in R1-R3 (updated with CC capabilities)
MANUS_COMPLIANCE.md           — 6 Laws audit with scores and fixes
RALPH_SCHEDULE.md             — When to run ralph and at what depth
GSD_COMMANDS.md               — Working AutoPilot commands reference
SUPERPOWERS_CHECKLIST.md      — Per-MS quality gate checklist
PRISM_PROTOCOLS_BOOT.md       — Split from CORE: boot + laws
PRISM_PROTOCOLS_SAFETY.md     — Split from CORE: structured outputs + validation
PRISM_PROTOCOLS_CODING.md     — Split from CORE: code standards + build
Expanded CURRENT_POSITION.md  — Structured multi-field position format
HANDOFF.md template           — Session handoff template
5 NL development hooks        — Context/compaction/build/gate/session hooks
4 new skill chains            — boot_resume, calc_validate, registry_query, debug_fix
4 new skills                  — session-mgmt, context-eng, parallel-exec, ralph-validation
15 Claude Code skills         — Converted from skills-consolidated/
5 subagent definitions        — safety-reviewer, registry-expert, architect, test-runner, data-validator
5 slash command definitions   — /boot, /gate, /checkpoint, /plan, /build
Hook configuration            — .claude/settings.json with deterministic hooks
CLAUDE.md (root + 2 nested)   — Project context for Claude Code auto-loading
CLAUDE_CODE_READINESS.md      — Test results + capability matrix
DA_INTEGRATION_TEST_RESULTS.md — E2E test outcomes
```
