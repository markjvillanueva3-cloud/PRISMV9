# PRISM HIERARCHICAL INDEX — SPECIFICATION v1.0
# Defines the 4-branch index architecture that accumulates intelligence across sessions
# Every roadmap phase contributes to this index as a byproduct of its normal work
# Location: C:\PRISM\mcp-server\data\docs\roadmap\HIERARCHICAL_INDEX_SPEC.md

---

## PURPOSE

PRISM has a discoverability problem. The system contains 31 dispatchers, 368 actions,
37 engines, 500 formulas, 3,518 materials, 5,238 tools, 1,016 machines, and 10,033 alarms.
Navigating this requires 8-12 calls to trace a single dependency chain. The hierarchical
index makes any concept findable in 1-2 lookups by organizing ALL system knowledge into
four interconnected branches.

## THE FOUR BRANCHES

```
BRANCH 1: EXECUTION CHAIN — how code flows (auto-generated from source)
BRANCH 2: DATA TAXONOMY   — how knowledge is organized (built from registry structure)
BRANCH 3: RELATIONSHIPS   — how things connect across registries (discovered during validation)
BRANCH 4: SESSION KNOWLEDGE — what Claude has learned (extracted from every session)
```

---

## BRANCH 1: EXECUTION CHAIN

**What it answers:** "When I call prism_calc action=speed_feed, what actually happens?"
**Generated from:** TypeScript source code (dispatchers, engines, services)
**Update trigger:** Regenerate after every `npm run build`
**Storage:** `C:\PRISM\knowledge\code-index\EXECUTION_CHAIN.json`
**Built during:** DA-MS6

### Schema
```json
{
  "dispatchers": {
    "prism_calc": {
      "file": "src/dispatchers/calcDispatcher.ts",
      "actions": {
        "speed_feed": {
          "parameters": ["material_id", "tool_id", "operation", "depth_of_cut", "width_of_cut"],
          "engines": ["SpeedFeedEngine", "SafetyEngine"],
          "registries_read": ["materials", "tools"],
          "formulas_used": ["chip_thinning_compensation", "effective_cutting_speed"],
          "returns": "SpeedFeedResult",
          "safety_critical": true
        }
      }
    }
  },
  "engines": {
    "SpeedFeedEngine": {
      "file": "src/engines/speedFeedEngine.ts",
      "called_by": ["prism_calc.speed_feed", "prism_calc.optimize_parameters"],
      "calls": ["FormulaEngine.evaluate", "MaterialRegistry.get", "ToolRegistry.get"],
      "formulas": ["chip_thinning_compensation", "effective_cutting_speed", "surface_speed_to_rpm"]
    }
  },
  "formulas": {
    "chip_thinning_compensation": {
      "file": "src/formulas/chipThinning.ts",
      "domain": "cutting_parameters",
      "inputs": ["ae", "Dc", "fz_programmed"],
      "outputs": ["fz_effective"],
      "used_by": ["SpeedFeedEngine", "ToolpathEngine"]
    }
  }
}
```

### Generation Method
```
SCRIPT: scripts/generate-code-index.ps1 (or .ts for Claude Code)
1. Parse all src/dispatchers/*.ts files
   - Extract: action names from switch/case or action maps
   - Extract: parameter interfaces from type definitions
   - Extract: engine instantiations (new XxxEngine or engine.xxx calls)
2. Parse all src/engines/*.ts files
   - Extract: which dispatchers reference them (grep for class name)
   - Extract: which formulas they call (grep for formula identifiers)
   - Extract: which registries they read (grep for registry.get/search)
3. Parse all src/formulas/*.ts files
   - Extract: input/output parameter names from function signatures
   - Extract: which engines import them
4. Build the JSON graph linking everything
5. Write EXECUTION_CHAIN.json
6. Print summary: "X dispatchers, Y actions, Z engines, W formulas indexed"
```

### Traversal Examples
```
QUESTION: "What calculates cutting force?"
LOOKUP: Search actions for "force" → prism_calc.cutting_force
TRACE DOWN: → KienzleForceEngine → kienzle_specific_force formula → needs kc1_1, mc from materials
ANSWER: prism_calc action=cutting_force → KienzleForceEngine → kienzle formula → material.kc1_1

QUESTION: "What uses the materials registry?"
LOOKUP: Search registries_read for "materials" → 12 actions across 4 dispatchers
ANSWER: List of every action that reads material data, with their parameters
```

---

## BRANCH 2: DATA TAXONOMY

**What it answers:** "What data exists for face mills?" or "How are materials organized?"
**Generated from:** Registry file structure + schema definitions
**Update trigger:** Regenerate after registry enrichment (R1 milestones)
**Storage:** `C:\PRISM\knowledge\data-index\DATA_TAXONOMY.json`
**Built during:** R1 (MS5 tools, MS6 materials, MS7 machines, MS9 quality gate)

### Schema
```json
{
  "materials": {
    "total": 3518,
    "organization": "ISO_group → family → grade",
    "groups": {
      "P": {
        "name": "Steel",
        "count": 1247,
        "families": {
          "carbon_steel": {
            "count": 312,
            "grades": ["AISI-1018", "AISI-1045", "AISI-1095"],
            "common_properties": ["tensile_strength", "hardness", "kc1_1", "mc"],
            "coverage": {
              "mechanical": "98%",
              "machinability": "87%",
              "thermal": "45%",
              "tribology": "12%"
            }
          }
        }
      }
    },
    "property_schema": {
      "mechanical": ["tensile_strength", "yield_strength", "elongation", "hardness"],
      "machinability": ["kc1_1", "mc", "machinability_rating", "chip_form"],
      "thermal": ["conductivity", "specific_heat", "max_working_temp"],
      "tribology": ["friction_coefficient", "wear_rate", "adhesion_tendency"]
    }
  },
  "tools": {
    "total": 5238,
    "organization": "category → type → diameter → insert_grade",
    "categories": {
      "milling": {
        "count": 2104,
        "types": {
          "face_mill": { "count": 487, "diameters": ["25mm-200mm"] },
          "end_mill": { "count": 891, "diameters": ["1mm-50mm"] },
          "ball_nose": { "count": 312, "diameters": ["1mm-32mm"] }
        }
      }
    }
  },
  "machines": {
    "total": 1016,
    "organization": "manufacturer → model → variant",
    "manufacturers": {
      "Okuma": {
        "count": 47,
        "models": {
          "Multus_B250II": {
            "type": "multi-tasking_lathe",
            "spindle": { "max_rpm": 5000, "max_power_kW": 22 },
            "envelope": { "x_mm": 650, "z_mm": 1100 }
          }
        }
      }
    }
  },
  "alarms": {
    "total": 10033,
    "organization": "controller_family → code_range → severity",
    "families": {
      "Fanuc": { "count": 3200, "ranges": ["0-99 program", "100-255 axis", "300-399 servo"] },
      "Okuma_OSP": { "count": 1800, "ranges": ["0-999 system", "1000-1999 axis", "2000-2999 spindle"] }
    }
  }
}
```

### Generation Method
```
SCRIPT: scripts/generate-data-taxonomy.ps1
1. Scan material registry directory structure
   - Count files per ISO group, per family
   - Sample 10 files per family: extract property coverage %
2. Scan tool registry
   - Count files per category, per type
   - Extract diameter ranges, insert grade types
3. Scan machine registry
   - Count per manufacturer, per model
   - Extract key specs (spindle, envelope, controller)
4. Scan alarm registry
   - Count per controller family, per code range
5. Build DATA_TAXONOMY.json
6. Print coverage summary
```

---

## BRANCH 3: RELATIONSHIP GRAPH

**What it answers:** "What tools work with Inconel 718?" or "What constraints apply?"
**Discovered through:** R2 calculation validation, R3 campaigns, R7 coupled physics
**Update trigger:** After each validated relationship discovery
**Storage:** `C:\PRISM\knowledge\relationships\RELATIONSHIP_GRAPH.json`
**Built during:** R2 (validated), R3 (enriched), R7 (physics-coupled)

### Schema
```json
{
  "edges": [
    {
      "from": { "type": "material", "id": "Inconel-718", "group": "S" },
      "to": { "type": "tool_grade", "id": "carbide_C6_plus" },
      "relationship": "compatible",
      "confidence": "validated_R2",
      "constraints": {
        "max_surface_speed_mpm": 45,
        "requires_coolant": true,
        "min_coolant_pressure_bar": 70
      },
      "source": "R2-MS3 calculation validation session 2026-03-01",
      "formulas_applicable": ["kienzle_extended", "taylor_nickel_alloy"]
    },
    {
      "from": { "type": "material", "id": "Inconel-718" },
      "to": { "type": "strategy", "id": "trochoidal_milling" },
      "relationship": "recommended",
      "confidence": "validated_R3",
      "reason": "Low radial engagement reduces thermal load on nickel alloys",
      "parameters": { "ae_max_pct": 10, "stepover_pct": 5 }
    },
    {
      "from": { "type": "machine", "id": "Okuma_Multus_B250II" },
      "to": { "type": "material", "id": "Inconel-718" },
      "relationship": "capable_with_constraints",
      "constraints": {
        "max_doc_mm": 2.0,
        "reason": "22kW spindle limits heavy cuts in superalloys"
      }
    }
  ],
  "traversal_index": {
    "by_material": { "Inconel-718": [0, 1, 2] },
    "by_tool": { "carbide_C6_plus": [0] },
    "by_machine": { "Okuma_Multus_B250II": [2] },
    "by_relationship": { "compatible": [0], "recommended": [1], "capable_with_constraints": [2] }
  }
}
```

### How Relationships Are Discovered
```
R2 (Safety Calculation Phase):
  - Run speed_feed calc for material+tool combination
  - If calc succeeds with valid safety score: edge = "compatible"
  - If calc fails or S(x) < 0.70: edge = "incompatible" with reason
  - If calc succeeds with constraints: edge = "compatible" with constraints
  Each R2 validation session produces 10-50 new relationship edges.

R3 (Intelligence Campaigns):
  - Cross-reference material properties with toolpath strategies
  - Discover which strategies work best for which material groups
  - Build "recommended" edges between materials and strategies
  Each R3 campaign produces 5-20 strategy recommendation edges.

R7 (Coupled Physics):
  - Discover thermal/mechanical coupling between parameters
  - E.g., "at surface speeds above X, Inconel 718 thermal softening changes kc1.1"
  - These become constraint edges with physics-based thresholds
  Each R7 session produces 2-5 physics-coupled constraint edges.
```

### Traversal Examples
```
QUESTION: "What parameters for face milling Inconel 718 with 50mm carbide?"
TRAVERSE:
  1. Find material node: Inconel-718
  2. Follow "compatible" edges to tools → filter for face_mill + carbide → get constraints
  3. Follow "recommended" edges to strategies → trochoidal_milling with ae_max=10%
  4. Follow "capable_with_constraints" edges to machines → check user's machine limits
  5. Combine: speed=45mpm max, ae=10%, coolant=70bar min, DOC=2mm max on B250II
RESULT: Complete parameter set with constraints, in 1-2 lookups instead of 8-12 calls.
```

---

## BRANCH 4: SESSION KNOWLEDGE

**What it answers:** "What did Claude learn about this MS in previous sessions?"
**Extracted from:** Every session's decisions, errors, observations
**Update trigger:** Session end protocol (mandatory) + mid-session flush (optional)
**Storage:** `C:\PRISM\knowledge\sessions\` (files) + `SESSION_KNOWLEDGE_INDEX.json` (queryable)
**Built during:** Every session, starting from DA. Accumulates forever.

### Schema
```json
{
  "nodes": [
    {
      "id": "sk_2026-02-16_001",
      "type": "error_fix",
      "phase": "R1",
      "milestone": "MS5",
      "summary": "MaterialRegistry.get() returns null for materials with spaces in ISO designation",
      "detail": "Fix: normalize with trim() before lookup. Affected 23 materials.",
      "tags": ["material_registry", "data_quality", "R1-MS5"],
      "session_date": "2026-02-16",
      "confidence": "verified",
      "promoted_to": null
    },
    {
      "id": "sk_2026-02-16_002",
      "type": "decision",
      "phase": "DA",
      "milestone": "MS0",
      "summary": "PowerShell DC protocol: always write .ps1 files, never inline $ vars",
      "detail": "DC strips $ from inline PowerShell. 3-call workaround is reliable.",
      "tags": ["desktop_commander", "powershell", "protocol"],
      "session_date": "2026-02-16",
      "confidence": "verified",
      "promoted_to": "PROTOCOLS_CORE pc_code_standards"
    }
  ],
  "index": {
    "by_phase": { "R1": ["sk_2026-02-16_001"], "DA": ["sk_2026-02-16_002"] },
    "by_milestone": { "R1-MS5": ["sk_2026-02-16_001"], "DA-MS0": ["sk_2026-02-16_002"] },
    "by_type": { "error_fix": ["sk_2026-02-16_001"], "decision": ["sk_2026-02-16_002"] },
    "by_tag": { "material_registry": ["sk_2026-02-16_001"], "powershell": ["sk_2026-02-16_002"] }
  }
}
```

### Knowledge Node Types
```
DECISION:     Architectural or design choice. WHY something was done a certain way.
              Prevents future sessions from re-deciding or choosing differently.
              Example: "Chose composite key [category,diameter,material_class] for ToolIndex"

ERROR_FIX:    Bug encountered and resolved. WHAT broke, WHY, and HOW it was fixed.
              Prevents future sessions from hitting the same bug.
              Example: "Kienzle formula NaN when mc > 0.45 — added clamping at 0.40"

ASSUMPTION:   Something believed to be true, validated or invalidated.
              Prevents future sessions from making wrong assumptions.
              Example: "Assumed all tool files have geometry field — FALSE, 1247 lack it"

OBSERVATION:  Performance data, timing, pattern noticed during work.
              Informs optimization decisions in future sessions.
              Example: "Batch loading 500 materials at a time: 2.8s. All 3518 at once: 4.2s"

RELATIONSHIP: Cross-registry connection discovered during validation.
              Feeds directly into Branch 3 (relationship graph).
              Example: "Inconel 718 requires BOTH kc1_1 AND thermal conductivity for extended Kienzle"

BLOCKER:      Issue that prevented progress, with full context.
              Gives future sessions the diagnostic head start.
              Example: "ToolIndex requires multi-field key but schema only supports single — deferred"
```

### Extraction Protocol
```
WHEN: At session end (mandatory) AND before compaction if possible (W4 auto-dump).

HOW (Claude executes this — it's a protocol, not a script):
  1. Review the session: What decisions were made? What errors hit? What was learned?
  2. For each piece of knowledge:
     a. Classify by type (decision/error_fix/assumption/observation/relationship/blocker)
     b. Tag with phase, milestone, and 2-5 topic tags
     c. Write a 1-line summary (must be useful WITHOUT reading the detail)
     d. Write detail (2-5 sentences: what, why, how, impact)
     e. Set confidence: "verified" (tested), "observed" (seen but not tested), "hypothesized"
  3. Write nodes to C:\PRISM\knowledge\sessions\[date]_session_knowledge.json
  4. Update SESSION_KNOWLEDGE_INDEX.json with new entries
  5. Check: Any nodes ready for promotion to permanent docs? (see PROMOTION below)

MINIMUM per session: At least 1 knowledge node. Most sessions produce 3-8.
If a session produced 0 knowledge nodes, something was missed — review before closing.
```

### Knowledge Promotion (Branch 4 → Branches 1-3 or documentation)
```
Some session knowledge should become PERMANENT:

error_fix (verified) → Add to error taxonomy in PROTOCOLS_CORE or as a test case
decision (verified)  → Add to architectural decisions in relevant phase doc or SYSTEM_CONTRACT
relationship (validated) → Add to RELATIONSHIP_GRAPH.json as a permanent edge
observation (confirmed across 3+ sessions) → Add to performance guidelines

PROMOTION CRITERIA:
  1. Confidence = "verified" (not just observed or hypothesized)
  2. Relevant across sessions (not a one-time workaround)
  3. Won't become stale quickly (represents stable knowledge)

PROMOTION PROCESS:
  When promoting, set promoted_to = "[destination]" on the knowledge node.
  This prevents the knowledge from being loaded redundantly (it's now in its permanent home).
  Promoted nodes stay in session knowledge as historical record but are excluded from
  boot-time loading.
```

### Boot-Time Knowledge Query
```
ON SESSION BOOT (after position recovery, before execution):
  1. Read SESSION_KNOWLEDGE_INDEX.json
  2. Filter: phase = current_phase AND milestone = current_ms AND promoted_to = null
  3. Also filter: tags matching current work context
  4. Load matching nodes (typically 3-10 entries, ~500-1000 tokens)
  5. Apply: Claude now has accumulated knowledge about this exact task

EXAMPLE:
  Position: R1-MS5 step 7
  Query: phase=R1, milestone=MS5, promoted_to=null
  Results:
    - DECISION: "Composite key design: [category, diameter, material_class]"
    - ERROR_FIX: "Null geometry handling: 1247 tools lack geometry field"
    - BLOCKER: "Multi-field key schema not yet supported — deferred to step 12"
  Claude now knows: the key design, the data quality issue, and the blocker.
  No rediscovery needed. Saves ~10 calls.
```

---

## CROSS-BRANCH INTEGRATION

```
The four branches connect:

Branch 1 (code) tells you: WHAT code exists and HOW it flows
Branch 2 (data) tells you: WHAT data exists and HOW it's organized  
Branch 3 (relationships) tells you: HOW data items RELATE to each other
Branch 4 (sessions) tells you: WHAT Claude has LEARNED about all of the above

COMBINED TRAVERSAL EXAMPLE:
  "Help me set up a turning operation for Ti-6Al-4V on the Okuma B250II"

  Branch 2: Find Ti-6Al-4V → ISO Group S, titanium family, alpha-beta alloy
  Branch 3: Find relationships → compatible tools (carbide C2, cermet, PCD),
            strategies (constant chip load, flood coolant required),
            machine constraints (B250II max RPM limits surface speed)
  Branch 1: Find actions → prism_calc.speed_feed, prism_calc.cutting_force,
            prism_safety.validate → trace engine chain for parameters needed
  Branch 4: Find session knowledge → "Ti-6Al-4V chips are stringy, use chip breaker.
            Previous session found that Taylor n=0.22 for this alloy+tool combo,
            not the default 0.25."

  Result: Complete setup with data, relationships, calculations, AND prior learnings.
```

---

## STORAGE LAYOUT

```
C:\PRISM\knowledge\
├── code-index\
│   ├── EXECUTION_CHAIN.json      (Branch 1 — auto-generated from source)
│   └── .codegen-baseline.json    (last generation hash for drift detection)
├── data-index\
│   ├── DATA_TAXONOMY.json        (Branch 2 — generated from registry structure)
│   └── .datagen-baseline.json
├── relationships\
│   ├── RELATIONSHIP_GRAPH.json   (Branch 3 — accumulated from R2/R3/R7)
│   └── .relationship-log.json    (audit trail of edge additions)
├── sessions\
│   ├── SESSION_KNOWLEDGE_INDEX.json  (Branch 4 — queryable index)
│   ├── 2026-02-16_session_knowledge.json
│   ├── 2026-02-17_session_knowledge.json
│   └── ...
└── README.md                     (this spec, condensed)
```

---

## PHASE CONTRIBUTION MAP

```
Which phases build which branches:

DA:  Branch 1 (code index generation script + first run)
     Branch 4 (knowledge extraction protocol + first captures)

R1:  Branch 2 (data taxonomy from registry enrichment)
     Branch 4 (data quality findings, schema decisions)

R2:  Branch 3 (validated calculation relationships: material↔tool↔formula)
     Branch 4 (formula validation findings, safety threshold observations)

R3:  Branch 3 (cross-registry campaign intelligence)
     Branch 4 (campaign strategy decisions)

R7:  Branch 3 (coupled physics relationships, thermal/mechanical constraints)
     Branch 4 (physics modeling decisions)

R8:  CONSUMER — uses all 4 branches to power 22 application skills
     Branch 4 (skill effectiveness observations)

ALL PHASES: Branch 4 (every session produces knowledge nodes)
```

---

## IMPLEMENTATION PRIORITY

```
1. Branch 4 (Session Knowledge) — DA-MS4
   Start capturing knowledge NOW. Every session before this is implemented
   is a session whose learnings are lost forever. Cheapest to build, highest
   immediate ROI.

2. Branch 1 (Code Index) — DA-MS6
   Auto-generated from source. One script, run after builds. Moderate effort,
   high payoff for code navigation.

3. Branch 2 (Data Taxonomy) — R1-MS9 (as part of quality gate)
   Generated from registry structure after R1 enrichment is complete.
   The data needs to exist before the taxonomy is useful.

4. Branch 3 (Relationship Graph) — R2-MS3+
   Relationships are discovered during validation. Can't build this before
   R2 because the validated connections don't exist yet.
   Schema is defined here. Population happens organically during R2/R3/R7.
```
