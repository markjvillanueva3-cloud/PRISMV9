# PRISM RECOVERY CARD — v14.3
# LOAD THIS FILE ON EVERY "continue" / "start roadmap" / post-compaction recovery.
# This is the ONLY file needed to bootstrap recovery. ~150 lines, ~1K tokens.
# Location: C:\PRISM\mcp-server\data\docs\roadmap\PRISM_RECOVERY_CARD.md

---

## STEP 0: DETECT ENVIRONMENT

```
TRY: prism_dev action=health
  → SUCCESS (status ok, dispatchers ≥ 31): MCP MODE. Use prism_ tools for everything.
  → FAIL (connection refused / tool not found): NO MCP.
    TRY: Desktop Commander available? (read_file / start_process)
      → SUCCESS: DC MODE. Read/write files via Desktop Commander.
      → FAIL: ASK human to start MCP server or enable Desktop Commander.

LOG: State your detected environment in first response:
  "Environment: MCP mode" or "Environment: DC mode (MCP unavailable)"
```

## STEP 1: FIND POSITION

```
MCP MODE:
  prism_doc action=read name=CURRENT_POSITION.md
  → Format: "CURRENT: [MS-ID] | LAST_COMPLETE: [MS-ID] [date] | PHASE: [ID] [status]"
  → OPTIONAL: prism_doc action=read name=SESSION_HANDOFF.md (richer context if available)
  → If missing: prism_doc action=read name=ROADMAP_TRACKER.md (last 5 entries)
  → If both missing: position = DA-MS0

DC MODE:
  Desktop Commander read_file C:\PRISM\mcp-server\data\docs\roadmap\CURRENT_POSITION.md
  → OPTIONAL: read SESSION_HANDOFF.md for richer context (next step, in-progress work)
  → If missing: read ROADMAP_TRACKER.md, find last COMPLETE entry, advance to next MS.
  → If both missing: position = DA-MS0

COMPACTION RECOVERY (if you suspect compaction occurred):
  1. Check /mnt/transcripts/journal.txt → read latest transcript tail
  2. Check /home/claude/ for progress files from this session
  3. Reconcile with CURRENT_POSITION.md → use LATER position
```

## STEP 1.5: LOAD SECTION INDEX (recommended — saves tokens)

```
IF ROADMAP_SECTION_INDEX.md exists (built in DA-MS5, Wave 1):
  Read ROADMAP_SECTION_INDEX.md (~200 lines, ~1.5K tokens)
  This lets you load ONLY the sections you need from any file.
  Example: Need stuck protocol? → find pc_stuck_protocol → line ~1608 → load 30 lines.
  Example: Need R1-MS5? → find r1_ms5_tool_schema → line ~253 → load that section.
  IF section index missing: Fall back to loading full phase doc (works but uses more tokens).
```

## STEP 2: LOAD PHASE DOC

```
PHASE → FILE MAPPING:
  P0  → PHASE_P0_ACTIVATION.md           (COMPLETE — skip unless re-gate)
  DA  → PHASE_DA_DEV_ACCELERATION.md      (515 lines)
  R1  → PHASE_R1_REGISTRY.md             (1482 lines — skip to MS4.5+ via LOADER:SKIP)
  R2  → PHASE_R2_SAFETY.md               (731 lines)
  R3  → PHASE_R3_CAMPAIGNS.md            (969 lines)
  R4  → PHASE_R4_ENTERPRISE.md           (204 lines)
  R5  → PHASE_R5_VISUAL.md               (248 lines)
  R6  → PHASE_R6_PRODUCTION.md           (267 lines)
  R7  → PHASE_R7_INTELLIGENCE.md         (1006 lines)
  R8  → PHASE_R8_EXPERIENCE.md           (884 lines)
  R9  → PHASE_R9_INTEGRATION.md          (570 lines)
  R10 → PHASE_R10_REVOLUTION.md          (952 lines)
  R11 → PHASE_R11_PRODUCT.md             (194 lines)

ALL DOCS AT: C:\PRISM\mcp-server\data\docs\roadmap\
MCP: prism_doc action=read name=roadmap/[filename]
DC:  Desktop Commander read_file C:\PRISM\mcp-server\data\docs\roadmap\[filename]

SKIP COMPLETED MILESTONES: Look for <!-- LOADER: SKIP TO LINE [N] --> markers.
  Read from that line forward to avoid loading completed MS content.
```

## STEP 2.5: LOAD SESSION KNOWLEDGE (if knowledge system exists)

```
IF C:\PRISM\knowledge\sessions\SESSION_KNOWLEDGE_INDEX.json exists:
  MCP: prism_doc action=read name=knowledge/sessions/SESSION_KNOWLEDGE_INDEX.json
  DC:  Desktop Commander read_file C:\PRISM\knowledge\sessions\SESSION_KNOWLEDGE_INDEX.json

  QUERY: Filter for current phase + current milestone + promoted_to = null
  LOAD matching knowledge nodes (typically 3-10 entries, ~500-1000 tokens)
  These are DECISIONS, ERROR FIXES, OBSERVATIONS from prior sessions about THIS work.
  Apply them: don't re-decide what was decided, don't re-debug what was fixed.

IF the file doesn't exist yet: Skip this step. Knowledge system is built in DA-MS4.

ALSO (optional, high value):
  IF ROADMAP_SECTION_INDEX.md exists: Load it (~200 lines, ~1.5K tokens).
  This lets you load ONLY the sections you need from any file instead of full docs.
  Find section → get line number → load just that range. Saves ~10K tokens per session.
```

## STEP 3: EXECUTE

```
1. Find your current MS in the phase doc
2. Find the current STEP within that MS (from ACTION_TRACKER.md or CURRENT_POSITION.md)
3. Execute steps sequentially
4. After each step: verify (build if code changed, check output if data)
5. Update position:
   - CURRENT_POSITION.md: every 3 calls (or after each significant step)
   - ACTION_TRACKER.md: after each step-group completion
   - ROADMAP_TRACKER.md: after each MS completion
6. Flush results to disk after each logical unit of work
```

## ESSENTIAL RULES (standalone — no other doc needed)

```
BUILD:     npm run build (NEVER standalone tsc — OOM at current scale)
SAFETY:    S(x) >= 0.70 is HARD BLOCK. Never skip safety validation.
FLUSH:     Write results to disk after each logical unit. Don't accumulate in context.
POSITION:  Update CURRENT_POSITION.md every 3 calls during execution.
ERRORS:    Fix ONE build error. Rebuild. Repeat. If >5 errors from one edit → revert.
IDEMPOTENT: Read-only calls = safe to re-run. Write calls = check if already done first.
NO PLACEHOLDERS: Every value must be real, complete, verified.
TRANSITION: When MS completes → update CURRENT_POSITION first, ROADMAP_TRACKER second.
POWERSHELL: Never inline $ vars in DC start_process. Write .ps1 file first, execute file.
```

## STUCK PROTOCOL (autonomous)

```
ATTEMPT 1-3: Try to fix the problem with different approaches.
ATTEMPT 4:   Search codebase for similar patterns (code_search / grep).
ATTEMPT 5:   Read related test files for expected behavior.
ATTEMPT 6:   Try a completely different approach (not a variation).
IF NON-BLOCKING: Skip step, mark DEFERRED in ACTION_TRACKER, continue to next step.
IF BLOCKING:     Write detailed diagnosis to ACTION_TRACKER, ask human for guidance.
  "BLOCKED on [error] after [N] attempts. Tried: [list]. Need: [specific question]."
DATA ERRORS (R1): Quarantine bad data in PHASE_FINDINGS.md, continue with remaining data.
```

## COMPACTION ADAPTATION

```
IF you detect this is a post-compaction recovery AND ROADMAP_TRACKER shows
multiple COMPACTION-RECOVERY entries in the current session:
  → RAPID-COMPACTION MODE:
    - Load only this Recovery Card (skip MASTER_INDEX and PROTOCOLS_CORE)
    - Skip skill loading and hook enabling
    - Update position every 2 calls instead of every 3
    - Flush to disk after EVERY step, not every group
    - Focus on executing the NEXT step only, don't plan ahead
```

## PHASE TRANSITION PROTOCOL

```
When the LAST MS of a phase completes:
  1. FIRST: Update CURRENT_POSITION.md → point to NEXT phase's first MS
  2. SECOND: Append to ROADMAP_TRACKER.md → "[Phase] COMPLETE [date]"
  3. Update MASTER_INDEX Phase Registry → [this-phase] status = complete
  4. Load next phase doc
  5. Continue with next phase MS0

WHY THIS ORDER: If compaction hits between step 1 and 2, CURRENT_POSITION
already points to the next milestone. Recovery finds the right place.
```

## SESSION END PROTOCOL

```
Before ending any session (or when context pressure > 75%):
  1. Write SESSION_HANDOFF.md:
     POSITION: [current MS and step]
     LAST_COMPLETED: [last finished step]
     NEXT_STEP: [what to do next]
     IN_PROGRESS: [any partial work, where it's saved]
     BLOCKING: [any issues preventing progress]
  2. Update CURRENT_POSITION.md with latest position
  3. Append to ROADMAP_TRACKER.md if any MS completed
  4. Save state: prism_session action=state_save (MCP mode only)
  5. KNOWLEDGE EXTRACTION (if knowledge system exists — built in DA-MS4):
     Review session: What decisions? What errors fixed? What learned?
     Write knowledge nodes to C:\PRISM\knowledge\sessions\[date]_session_knowledge.json
     Update SESSION_KNOWLEDGE_INDEX.json
     Types: decision, error_fix, assumption, observation, relationship, blocker
     MINIMUM: 1 node per session. Most sessions produce 3-8.
     See HIERARCHICAL_INDEX_SPEC.md §Branch 4 for full schema.

MCP:  prism_doc action=write name=SESSION_HANDOFF.md content="..."
DC:   Desktop Commander write_file C:\PRISM\mcp-server\data\docs\SESSION_HANDOFF.md
```
