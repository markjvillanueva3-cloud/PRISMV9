# Cognitive Composition Engine (CCE)

> **Purpose**: A meta-cognitive system that dynamically combines formulas, algorithms, heuristics, and mental models to synthesize optimal solutions for any problem.
>
> **Philosophy**: No single technique is optimal for all problems. The best solutions emerge from intelligent composition of multiple approaches, guided by problem structure and learned experience.

---

## Core Concept

The CCE treats problem-solving as **composition over a library of techniques**:

```
Solution = Compose(Technique₁, Technique₂, ..., Techniqueₙ)

Where Compose can be:
- Chain(A, B)      → Output of A feeds into B
- Parallel(A, B)   → Run both, merge results
- Conditional(P, A, B) → If P then A else B
- Iterate(A, P)    → Repeat A until P satisfied
- Hybrid(A, B)     → A's approach with B's validation
- Evolve(A₁...Aₙ)  → Genetic combination of techniques
```

---

## Architecture

### 1. Problem Analyzer

Decomposes any problem into a structured representation.

```typescript
interface ProblemAnalysis {
  // What kind of problem is this?
  problem_type: ProblemType;
  
  // What are the inputs?
  inputs: {
    name: string;
    type: DataType;
    constraints?: Constraint[];
    example?: any;
  }[];
  
  // What outputs are expected?
  outputs: {
    name: string;
    type: DataType;
    quality_criteria?: QualityCriterion[];
  }[];
  
  // What properties does this problem have?
  properties: ProblemProperty[];
  
  // What constraints must be satisfied?
  hard_constraints: Constraint[];
  soft_constraints: Constraint[];
  
  // How should we measure success?
  success_metrics: Metric[];
  
  // Resource budget
  budget: {
    max_tokens?: number;
    max_time_ms?: number;
    max_iterations?: number;
  };
  
  // Decomposition into sub-problems
  sub_problems?: ProblemAnalysis[];
}

type ProblemType = 
  | 'optimization'      // Find best X given constraints
  | 'search'            // Find X that satisfies condition
  | 'classification'    // Categorize X
  | 'generation'        // Create X with properties
  | 'transformation'    // Convert X to Y
  | 'diagnosis'         // Find cause of X
  | 'prediction'        // Estimate future X
  | 'planning'          // Sequence of actions to achieve X
  | 'verification'      // Prove X is correct
  | 'explanation'       // Why is X true?
  | 'composition'       // Combine X₁...Xₙ into Y

type ProblemProperty =
  | 'deterministic'     // Same input → same output
  | 'stochastic'        // Involves randomness
  | 'discrete'          // Finite choices
  | 'continuous'        // Infinite choices
  | 'sequential'        // Order matters
  | 'parallel'          // Independent sub-problems
  | 'recursive'         // Self-similar structure
  | 'adversarial'       // Against an opponent
  | 'cooperative'       // With collaborators
  | 'time_sensitive'    // Deadline pressure
  | 'resource_constrained'
  | 'uncertain'         // Incomplete information
  | 'dynamic'           // Changes over time
  | 'causal'            // Cause-effect relationships
  | 'hierarchical'      // Nested structure
```

### 2. Technique Library

A structured collection of all available problem-solving techniques.

```typescript
interface Technique {
  id: string;
  name: string;
  category: TechniqueCategory;
  
  // When is this technique applicable?
  applicable_when: {
    problem_types: ProblemType[];
    required_properties: ProblemProperty[];
    forbidden_properties: ProblemProperty[];
    input_requirements: InputRequirement[];
  };
  
  // What does this technique provide?
  provides: {
    output_type: DataType;
    guarantees: Guarantee[];
    quality_bounds?: { min: number; max: number };
  };
  
  // What resources does it consume?
  cost: {
    time_complexity: string;      // O(n), O(n²), etc.
    space_complexity: string;
    token_cost: 'zero' | 'low' | 'medium' | 'high';
    deterministic: boolean;
  };
  
  // How can it combine with others?
  composability: {
    can_chain_after: string[];    // Technique IDs
    can_chain_before: string[];
    can_parallel_with: string[];
    conflicts_with: string[];
  };
  
  // Implementation
  execute: (input: any, params: any) => Promise<TechniqueResult>;
  
  // Track record
  performance_history: {
    success_rate: number;
    avg_quality: number;
    problem_types_excelled: ProblemType[];
  };
}

type TechniqueCategory =
  | 'formula'           // Mathematical equation
  | 'algorithm'         // Step-by-step procedure
  | 'heuristic'         // Rule of thumb
  | 'pattern'           // Recognized solution shape
  | 'mental_model'      // Way of thinking about problem
  | 'search_strategy'   // How to explore solution space
  | 'decomposition'     // How to break down problem
  | 'validation'        // How to verify solution
  | 'estimation'        // How to approximate
  | 'transformation'    // How to convert representations
```

### 3. Technique Matcher

Finds applicable techniques for a given problem.

```typescript
interface TechniqueMatch {
  technique: Technique;
  fitness_score: number;         // 0-1, how well it fits
  coverage: number;              // What % of problem it addresses
  confidence: number;            // How confident in this match
  reasoning: string;             // Why this technique
  parameters: any;               // Suggested parameters
  gaps: string[];                // What it doesn't handle
}

async function matchTechniques(
  problem: ProblemAnalysis,
  library: TechniqueLibrary,
  constraints: {
    max_candidates?: number;
    min_fitness?: number;
    required_categories?: TechniqueCategory[];
    excluded_techniques?: string[];
  }
): Promise<TechniqueMatch[]> {
  
  const candidates: TechniqueMatch[] = [];
  
  for (const technique of library.all()) {
    // Check hard requirements
    if (!meetsRequirements(problem, technique)) continue;
    
    // Score fitness
    const fitness = calculateFitness(problem, technique);
    if (fitness < (constraints.min_fitness || 0.3)) continue;
    
    // Calculate coverage
    const coverage = calculateCoverage(problem, technique);
    
    // Determine parameters
    const parameters = inferParameters(problem, technique);
    
    candidates.push({
      technique,
      fitness_score: fitness,
      coverage,
      confidence: fitness * coverage,
      reasoning: explainMatch(problem, technique),
      parameters,
      gaps: findGaps(problem, technique)
    });
  }
  
  // Sort by confidence, return top N
  return candidates
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, constraints.max_candidates || 10);
}

function calculateFitness(problem: ProblemAnalysis, technique: Technique): number {
  let score = 0;
  let weights = 0;
  
  // Problem type match (weight: 3)
  if (technique.applicable_when.problem_types.includes(problem.problem_type)) {
    score += 3;
  }
  weights += 3;
  
  // Property alignment (weight: 2 per property)
  for (const prop of problem.properties) {
    if (technique.applicable_when.required_properties.includes(prop)) {
      score += 2;
    }
    if (technique.applicable_when.forbidden_properties.includes(prop)) {
      score -= 3;  // Penalty for forbidden
    }
    weights += 2;
  }
  
  // Historical performance (weight: 2)
  if (technique.performance_history.problem_types_excelled.includes(problem.problem_type)) {
    score += 2 * technique.performance_history.success_rate;
  }
  weights += 2;
  
  // Resource fit (weight: 1)
  if (fitsResourceBudget(problem.budget, technique.cost)) {
    score += 1;
  }
  weights += 1;
  
  return Math.max(0, Math.min(1, score / weights));
}
```

### 4. Composition Synthesizer

The core innovation: combines techniques into novel solutions.

```typescript
// Composition operators
type CompositionOperator =
  | { type: 'chain'; steps: Composition[] }
  | { type: 'parallel'; branches: Composition[]; merge: MergeStrategy }
  | { type: 'conditional'; condition: Condition; if_true: Composition; if_false: Composition }
  | { type: 'iterate'; body: Composition; until: Condition; max_iterations: number }
  | { type: 'hybrid'; primary: Composition; validator: Composition; fallback?: Composition }
  | { type: 'ensemble'; members: Composition[]; voting: VotingStrategy }
  | { type: 'evolve'; population: Composition[]; generations: number; fitness: FitnessFunction }
  | { type: 'leaf'; technique: Technique; parameters: any }

interface Composition {
  operator: CompositionOperator;
  expected_cost: Cost;
  expected_quality: QualityBounds;
  explanation: string;
}

interface SynthesisResult {
  composition: Composition;
  fitness_score: number;
  novelty_score: number;         // How different from known solutions
  confidence: number;
  explanation: string;
  alternatives: Composition[];   // Other viable options
}

async function synthesize(
  problem: ProblemAnalysis,
  matches: TechniqueMatch[],
  constraints: SynthesisConstraints
): Promise<SynthesisResult> {
  
  // Strategy 1: Single technique (if one technique has high coverage)
  const bestSingle = matches.find(m => m.coverage > 0.9);
  if (bestSingle) {
    return {
      composition: { 
        operator: { type: 'leaf', technique: bestSingle.technique, parameters: bestSingle.parameters },
        expected_cost: bestSingle.technique.cost,
        expected_quality: bestSingle.technique.provides.quality_bounds,
        explanation: `Direct application: ${bestSingle.reasoning}`
      },
      fitness_score: bestSingle.fitness_score,
      novelty_score: 0.1,
      confidence: bestSingle.confidence,
      explanation: `Single technique sufficient: ${bestSingle.technique.name}`,
      alternatives: []
    };
  }
  
  // Strategy 2: Chain composition (sequential problem)
  if (problem.properties.includes('sequential') || problem.sub_problems?.length > 0) {
    const chain = synthesizeChain(problem, matches);
    if (chain.fitness_score > 0.7) return chain;
  }
  
  // Strategy 3: Parallel composition (independent sub-problems)
  if (problem.properties.includes('parallel')) {
    const parallel = synthesizeParallel(problem, matches);
    if (parallel.fitness_score > 0.7) return parallel;
  }
  
  // Strategy 4: Hybrid composition (uncertain problems)
  if (problem.properties.includes('uncertain')) {
    const hybrid = synthesizeHybrid(problem, matches);
    if (hybrid.fitness_score > 0.7) return hybrid;
  }
  
  // Strategy 5: Evolutionary synthesis (novel problems)
  if (constraints.allow_evolution) {
    const evolved = await evolveComposition(problem, matches, constraints);
    if (evolved.fitness_score > 0.6) return evolved;
  }
  
  // Strategy 6: Ensemble (when no single approach dominates)
  const ensemble = synthesizeEnsemble(problem, matches);
  return ensemble;
}
```

### 5. Evolutionary Composer

Creates novel technique combinations through genetic algorithms.

```typescript
interface EvolutionConfig {
  population_size: number;       // Default: 20
  generations: number;           // Default: 10
  mutation_rate: number;         // Default: 0.1
  crossover_rate: number;        // Default: 0.7
  elitism: number;               // Keep top N unchanged
  fitness_function: (composition: Composition, problem: ProblemAnalysis) => number;
}

async function evolveComposition(
  problem: ProblemAnalysis,
  techniques: TechniqueMatch[],
  config: EvolutionConfig
): Promise<SynthesisResult> {
  
  // Initialize population with random compositions
  let population = initializePopulation(techniques, config.population_size);
  
  for (let gen = 0; gen < config.generations; gen++) {
    // Evaluate fitness
    const scored = await Promise.all(
      population.map(async (comp) => ({
        composition: comp,
        fitness: await evaluateFitness(comp, problem, config.fitness_function)
      }))
    );
    
    // Sort by fitness
    scored.sort((a, b) => b.fitness - a.fitness);
    
    // Early termination if excellent solution found
    if (scored[0].fitness > 0.95) {
      return buildResult(scored[0], gen, 'excellent_found');
    }
    
    // Selection (tournament)
    const selected = tournamentSelection(scored, config.population_size - config.elitism);
    
    // Crossover
    const offspring = crossover(selected, config.crossover_rate);
    
    // Mutation
    const mutated = mutate(offspring, config.mutation_rate, techniques);
    
    // New population = elites + offspring
    population = [
      ...scored.slice(0, config.elitism).map(s => s.composition),
      ...mutated
    ];
  }
  
  // Return best from final population
  const final = await evaluateAll(population, problem, config.fitness_function);
  return buildResult(final[0], config.generations, 'evolution_complete');
}

function crossover(parents: Composition[], rate: number): Composition[] {
  const offspring: Composition[] = [];
  
  for (let i = 0; i < parents.length - 1; i += 2) {
    if (Math.random() < rate) {
      // Swap sub-compositions
      const [child1, child2] = swapSubtrees(parents[i], parents[i + 1]);
      offspring.push(child1, child2);
    } else {
      offspring.push(parents[i], parents[i + 1]);
    }
  }
  
  return offspring;
}

function mutate(compositions: Composition[], rate: number, techniques: TechniqueMatch[]): Composition[] {
  return compositions.map(comp => {
    if (Math.random() < rate) {
      const mutation = chooseMutation();
      switch (mutation) {
        case 'swap_technique':
          return swapRandomTechnique(comp, techniques);
        case 'change_operator':
          return changeOperator(comp);
        case 'add_validation':
          return wrapWithValidation(comp, techniques);
        case 'parallelize':
          return convertToParallel(comp);
        case 'add_iteration':
          return wrapWithIteration(comp);
        default:
          return comp;
      }
    }
    return comp;
  });
}
```

---

## Technique Library Categories

### Category 1: Formulas (109 formulas)

```typescript
const FORMULA_LIBRARY = {
  // Physics & Engineering
  kienzle_cutting_force: {
    id: 'kienzle',
    formula: 'F = k_c1.1 * b * h^(1-m_c)',
    applicable_when: { problem_types: ['prediction'], domain: 'machining' },
    inputs: ['specific_cutting_force', 'width_of_cut', 'chip_thickness', 'material_exponent'],
    output: 'cutting_force_N'
  },
  
  taylor_tool_life: {
    id: 'taylor',
    formula: 'V * T^n = C',
    applicable_when: { problem_types: ['optimization', 'prediction'], domain: 'machining' },
    inputs: ['cutting_speed', 'taylor_exponent', 'taylor_constant'],
    output: 'tool_life_minutes'
  },
  
  // Information Theory
  shannon_entropy: {
    id: 'shannon_entropy',
    formula: 'H(X) = -Σ p(x) * log₂(p(x))',
    applicable_when: { problem_types: ['measurement'], properties: ['discrete'] },
    inputs: ['probability_distribution'],
    output: 'entropy_bits'
  },
  
  // Statistics
  bayes_theorem: {
    id: 'bayes',
    formula: 'P(A|B) = P(B|A) * P(A) / P(B)',
    applicable_when: { problem_types: ['prediction', 'diagnosis'], properties: ['uncertain'] },
    inputs: ['prior', 'likelihood', 'evidence'],
    output: 'posterior_probability'
  },
  
  // Optimization
  gradient_descent_step: {
    id: 'gradient_step',
    formula: 'x_new = x - α * ∇f(x)',
    applicable_when: { problem_types: ['optimization'], properties: ['continuous'] },
    inputs: ['current_value', 'learning_rate', 'gradient'],
    output: 'updated_value'
  },
  
  // Cognitive Science
  cognitive_load: {
    id: 'cognitive_load',
    formula: 'CL = intrinsic + extraneous + germane',
    applicable_when: { problem_types: ['measurement'], domain: 'code_quality' },
    inputs: ['intrinsic_load', 'extraneous_load', 'germane_load'],
    output: 'total_cognitive_load'
  },
  
  // Causal Inference
  average_treatment_effect: {
    id: 'ate',
    formula: 'ATE = E[Y(1)] - E[Y(0)]',
    applicable_when: { problem_types: ['explanation', 'prediction'], properties: ['causal'] },
    inputs: ['treated_outcomes', 'control_outcomes'],
    output: 'causal_effect'
  },
  
  // ... 102 more formulas
};
```

### Category 2: Algorithms (285 algorithms)

```typescript
const ALGORITHM_LIBRARY = {
  // Search
  binary_search: {
    id: 'binary_search',
    category: 'search',
    time_complexity: 'O(log n)',
    space_complexity: 'O(1)',
    applicable_when: { properties: ['sorted', 'discrete'] },
    guarantees: ['optimal_for_sorted']
  },
  
  a_star: {
    id: 'a_star',
    category: 'search',
    time_complexity: 'O(b^d)',
    applicable_when: { problem_types: ['search', 'planning'], properties: ['graph'] },
    guarantees: ['optimal_if_admissible_heuristic']
  },
  
  mcts: {
    id: 'monte_carlo_tree_search',
    category: 'search',
    applicable_when: { problem_types: ['planning'], properties: ['stochastic', 'sequential'] },
    guarantees: ['anytime', 'improves_with_time']
  },
  
  // Optimization
  simplex: {
    id: 'simplex',
    category: 'optimization',
    applicable_when: { problem_types: ['optimization'], properties: ['linear_constraints'] },
    guarantees: ['global_optimum_for_lp']
  },
  
  genetic_algorithm: {
    id: 'ga',
    category: 'optimization',
    applicable_when: { problem_types: ['optimization'], properties: ['discrete', 'large_search_space'] },
    guarantees: ['anytime', 'exploration_exploitation_balance']
  },
  
  simulated_annealing: {
    id: 'sa',
    category: 'optimization',
    applicable_when: { problem_types: ['optimization'], properties: ['discrete', 'many_local_optima'] },
    guarantees: ['escapes_local_optima']
  },
  
  // Graph
  dijkstra: {
    id: 'dijkstra',
    category: 'graph',
    time_complexity: 'O((V + E) log V)',
    applicable_when: { problem_types: ['search'], properties: ['graph', 'non_negative_weights'] },
    guarantees: ['shortest_path']
  },
  
  topological_sort: {
    id: 'topo_sort',
    category: 'graph',
    time_complexity: 'O(V + E)',
    applicable_when: { properties: ['dag'] },
    guarantees: ['valid_ordering']
  },
  
  // Machine Learning
  k_means: {
    id: 'kmeans',
    category: 'clustering',
    applicable_when: { problem_types: ['classification'], properties: ['continuous'] },
    guarantees: ['local_optimum']
  },
  
  random_forest: {
    id: 'rf',
    category: 'ensemble',
    applicable_when: { problem_types: ['classification', 'prediction'] },
    guarantees: ['robust_to_overfitting', 'feature_importance']
  },
  
  // Fault Localization
  spectrum_based_fl: {
    id: 'sbfl',
    category: 'diagnosis',
    applicable_when: { problem_types: ['diagnosis'], domain: 'debugging' },
    provides: { output_type: 'ranked_suspects' },
    formulas: ['tarantula', 'ochiai', 'dstar']
  },
  
  delta_debugging: {
    id: 'dd',
    category: 'diagnosis',
    applicable_when: { problem_types: ['diagnosis'], properties: ['reproducible_failure'] },
    guarantees: ['minimal_failing_input']
  },
  
  // ... 270 more algorithms
};
```

### Category 3: Heuristics (147 heuristics)

```typescript
const HEURISTIC_LIBRARY = {
  // Problem Decomposition
  divide_and_conquer: {
    id: 'dac',
    description: 'Split problem into smaller independent subproblems',
    applicable_when: { properties: ['recursive', 'divisible'] },
    anti_patterns: ['highly_coupled_subproblems']
  },
  
  greedy_choice: {
    id: 'greedy',
    description: 'Make locally optimal choice at each step',
    applicable_when: { properties: ['greedy_choice_property', 'optimal_substructure'] },
    warning: 'May not find global optimum'
  },
  
  // Estimation
  fermi_estimation: {
    id: 'fermi',
    description: 'Break into smaller estimable quantities, multiply',
    applicable_when: { problem_types: ['estimation'], properties: ['uncertain'] }
  },
  
  anchoring_adjustment: {
    id: 'anchor_adjust',
    description: 'Start from known value, adjust for differences',
    applicable_when: { problem_types: ['estimation', 'prediction'] }
  },
  
  // Code Quality
  single_responsibility: {
    id: 'srp',
    description: 'Each module should have one reason to change',
    applicable_when: { domain: 'code_design' },
    violation_signals: ['multiple_unrelated_changes', 'high_coupling']
  },
  
  premature_optimization_avoidance: {
    id: 'no_premature_opt',
    description: 'Make it work, make it right, make it fast',
    applicable_when: { domain: 'development_process' }
  },
  
  // Debugging
  wolf_fence: {
    id: 'wolf_fence',
    description: 'Binary search through code to isolate bug',
    applicable_when: { problem_types: ['diagnosis'], properties: ['reproducible'] }
  },
  
  rubber_duck: {
    id: 'rubber_duck',
    description: 'Explain problem step-by-step to find assumption errors',
    applicable_when: { problem_types: ['diagnosis', 'explanation'] }
  },
  
  // Decision Making
  two_minute_rule: {
    id: 'two_min',
    description: 'If it takes less than 2 minutes, do it now',
    applicable_when: { properties: ['time_sensitive', 'many_small_tasks'] }
  },
  
  eisenhower_matrix: {
    id: 'eisenhower',
    description: 'Prioritize by urgent vs important',
    applicable_when: { problem_types: ['planning'], properties: ['multiple_priorities'] }
  },
  
  // ... 137 more heuristics
};
```

### Category 4: Mental Models (64 models)

```typescript
const MENTAL_MODEL_LIBRARY = {
  // Systems Thinking
  feedback_loops: {
    id: 'feedback_loops',
    description: 'Identify reinforcing and balancing loops in systems',
    questions: [
      'What reinforces growth?',
      'What limits growth?',
      'What delays exist?'
    ],
    applicable_when: { properties: ['dynamic', 'interconnected'] }
  },
  
  second_order_effects: {
    id: 'second_order',
    description: 'Consider consequences of consequences',
    questions: [
      'And then what?',
      'Who else is affected?',
      'What unintended consequences?'
    ],
    applicable_when: { problem_types: ['planning', 'prediction'] }
  },
  
  // Reasoning
  inversion: {
    id: 'inversion',
    description: 'Instead of how to succeed, ask how to fail',
    questions: [
      'What would guarantee failure?',
      'What must we avoid?',
      'What are the anti-goals?'
    ],
    applicable_when: { problem_types: ['planning', 'optimization'] }
  },
  
  first_principles: {
    id: 'first_principles',
    description: 'Break down to fundamental truths, reason up',
    questions: [
      'What do we know for certain?',
      'What assumptions are we making?',
      'Can we derive from basics?'
    ],
    applicable_when: { properties: ['novel', 'conventional_wisdom_failing'] }
  },
  
  // Probability
  base_rates: {
    id: 'base_rates',
    description: 'Start with prior probability before updating',
    questions: [
      'How common is this generally?',
      'What\'s the reference class?',
      'Am I anchoring on vivid examples?'
    ],
    applicable_when: { problem_types: ['prediction'], properties: ['uncertain'] }
  },
  
  // Constraints
  theory_of_constraints: {
    id: 'toc',
    description: 'Find and elevate the bottleneck',
    questions: [
      'What\'s the constraint?',
      'How can we exploit it?',
      'How can we elevate it?'
    ],
    applicable_when: { problem_types: ['optimization'], properties: ['throughput_limited'] }
  },
  
  // ... 58 more mental models
};
```

---

## Composition Operators in Detail

### Chain Composition

Sequential execution where output of step N feeds into step N+1.

```typescript
interface ChainComposition {
  type: 'chain';
  steps: Composition[];
  data_flow: DataFlowSpec[];     // How data passes between steps
  early_exit?: Condition;        // Stop if condition met
  error_handling: 'stop' | 'skip' | 'retry';
}

function synthesizeChain(
  problem: ProblemAnalysis,
  matches: TechniqueMatch[]
): SynthesisResult {
  
  // If problem has explicit sub-problems, chain them
  if (problem.sub_problems && problem.sub_problems.length > 0) {
    const steps = problem.sub_problems.map(sub => 
      synthesize(sub, matchTechniques(sub, library))
    );
    
    return {
      composition: {
        operator: { type: 'chain', steps: steps.map(s => s.composition) },
        expected_cost: sumCosts(steps),
        expected_quality: minQuality(steps),
        explanation: 'Chain of sub-problem solutions'
      },
      fitness_score: avgFitness(steps),
      novelty_score: 0.3,
      confidence: minConfidence(steps),
      explanation: `Sequential solution: ${steps.map(s => s.composition.explanation).join(' → ')}`,
      alternatives: []
    };
  }
  
  // Otherwise, find complementary techniques to chain
  const primary = matches[0];
  const gaps = primary.gaps;
  
  // Find techniques that fill the gaps
  const fillers = matches.filter(m => 
    m.technique.id !== primary.technique.id &&
    gaps.some(gap => m.technique.provides.output_type === gap)
  );
  
  if (fillers.length > 0) {
    return buildChain([primary, ...fillers]);
  }
  
  return null;  // Chain not viable
}
```

### Parallel Composition

Execute multiple techniques simultaneously, merge results.

```typescript
interface ParallelComposition {
  type: 'parallel';
  branches: Composition[];
  merge: MergeStrategy;
  timeout_ms?: number;           // Wait max this long
  min_branches?: number;         // Need at least N to succeed
}

type MergeStrategy =
  | { type: 'vote'; method: 'majority' | 'unanimous' | 'weighted' }
  | { type: 'aggregate'; function: 'union' | 'intersection' | 'average' | 'custom' }
  | { type: 'select_best'; metric: string }
  | { type: 'combine'; combiner: (results: any[]) => any }

function synthesizeParallel(
  problem: ProblemAnalysis,
  matches: TechniqueMatch[]
): SynthesisResult {
  
  // Find techniques that address different aspects
  const diverse = selectDiverse(matches, 3);  // Top 3 most different
  
  // Determine merge strategy based on output types
  const merge = inferMergeStrategy(diverse, problem);
  
  return {
    composition: {
      operator: {
        type: 'parallel',
        branches: diverse.map(m => ({
          operator: { type: 'leaf', technique: m.technique, parameters: m.parameters },
          expected_cost: m.technique.cost,
          expected_quality: m.technique.provides.quality_bounds,
          explanation: m.reasoning
        })),
        merge
      },
      expected_cost: maxCost(diverse),  // Parallel = max time
      expected_quality: improvedQuality(diverse, merge),
      explanation: 'Parallel execution with merged results'
    },
    fitness_score: avgFitness(diverse) * 1.2,  // Bonus for diversity
    novelty_score: 0.5,
    confidence: combinedConfidence(diverse, merge),
    explanation: `Parallel approaches: ${diverse.map(d => d.technique.name).join(', ')}`,
    alternatives: []
  };
}
```

### Hybrid Composition

Primary approach with validation and fallback.

```typescript
interface HybridComposition {
  type: 'hybrid';
  primary: Composition;          // Main approach
  validator: Composition;        // Checks result
  fallback?: Composition;        // If validation fails
  max_retries?: number;
}

function synthesizeHybrid(
  problem: ProblemAnalysis,
  matches: TechniqueMatch[]
): SynthesisResult {
  
  // Find best primary technique
  const primary = matches[0];
  
  // Find a validation technique (different category)
  const validators = matches.filter(m => 
    m.technique.category === 'validation' ||
    m.technique.provides.guarantees.includes('verifies_correctness')
  );
  
  // Find a fallback (different approach than primary)
  const fallbacks = matches.filter(m =>
    m.technique.id !== primary.technique.id &&
    m.technique.category !== primary.technique.category
  );
  
  return {
    composition: {
      operator: {
        type: 'hybrid',
        primary: toLeaf(primary),
        validator: validators[0] ? toLeaf(validators[0]) : programmaticValidator(problem),
        fallback: fallbacks[0] ? toLeaf(fallbacks[0]) : undefined
      },
      expected_cost: sumCosts([primary, validators[0], fallbacks[0]].filter(Boolean)),
      expected_quality: { min: primary.technique.provides.quality_bounds.min * 1.2, max: 1.0 },
      explanation: 'Primary with validation and fallback'
    },
    fitness_score: primary.fitness_score * 1.1,  // Bonus for safety
    novelty_score: 0.4,
    confidence: primary.confidence * 1.2,
    explanation: `${primary.technique.name} → validate → ${fallbacks[0]?.technique.name || 'retry'}`,
    alternatives: []
  };
}
```

### Ensemble Composition

Multiple techniques vote or average.

```typescript
interface EnsembleComposition {
  type: 'ensemble';
  members: Composition[];
  voting: VotingStrategy;
  weights?: number[];            // For weighted voting
  min_agreement?: number;        // Confidence threshold
}

type VotingStrategy =
  | 'majority'                   // Most common answer
  | 'unanimous'                  // All must agree
  | 'weighted_majority'          // Weighted by confidence
  | 'median'                     // Middle value (for numeric)
  | 'borda_count'                // Ranked choice
  | 'stacking'                   // Meta-learner decides

function synthesizeEnsemble(
  problem: ProblemAnalysis,
  matches: TechniqueMatch[]
): SynthesisResult {
  
  // Select diverse techniques
  const members = selectDiverse(matches, 5);
  
  // Choose voting strategy based on output type
  const voting = problem.outputs[0].type === 'numeric' 
    ? 'median' 
    : 'weighted_majority';
  
  // Calculate weights from confidence scores
  const weights = members.map(m => m.confidence);
  const totalWeight = weights.reduce((a, b) => a + b, 0);
  const normalizedWeights = weights.map(w => w / totalWeight);
  
  return {
    composition: {
      operator: {
        type: 'ensemble',
        members: members.map(toLeaf),
        voting,
        weights: normalizedWeights
      },
      expected_cost: maxCost(members),
      expected_quality: { min: 0.7, max: 0.95 },  // Ensembles are robust
      explanation: `Ensemble of ${members.length} techniques`
    },
    fitness_score: avgFitness(members) * 1.3,  // Ensemble bonus
    novelty_score: 0.6,
    confidence: 1 - members.reduce((p, m) => p * (1 - m.confidence), 1),  // P(at least one right)
    explanation: `Ensemble: ${members.map(m => m.technique.name).join(', ')}`,
    alternatives: []
  };
}
```

---

## CCE Tool Interface

```typescript
// Main entry point for the Cognitive Composition Engine

interface CCEComposeParams {
  problem: string;               // Natural language problem description
  context?: {
    domain?: string;             // e.g., 'code_quality', 'debugging', 'optimization'
    constraints?: string[];      // e.g., 'must be fast', 'zero tokens', 'deterministic'
    examples?: any[];            // Example inputs/outputs
    preferences?: string[];      // e.g., 'prefer simple', 'maximize accuracy'
  };
  budget?: {
    max_tokens?: number;
    max_time_ms?: number;
    max_techniques?: number;
  };
  options?: {
    allow_evolution?: boolean;   // Allow genetic composition
    explain_reasoning?: boolean; // Verbose explanation
    return_alternatives?: number; // How many alternatives to return
  };
}

interface CCEComposeResult {
  solution: {
    composition: Composition;
    execution_plan: ExecutionStep[];
    estimated_cost: Cost;
    estimated_quality: QualityBounds;
  };
  reasoning: {
    problem_analysis: ProblemAnalysis;
    technique_matches: TechniqueMatch[];
    composition_strategy: string;
    key_decisions: string[];
  };
  confidence: number;
  novelty: number;               // How novel is this composition
  alternatives?: {
    composition: Composition;
    tradeoff: string;            // What's different about this one
  }[];
  meta: {
    techniques_considered: number;
    compositions_evaluated: number;
    synthesis_time_ms: number;
  };
}

interface CCEExecuteParams {
  composition: Composition;
  input: any;
  options?: {
    trace?: boolean;             // Return execution trace
    timeout_ms?: number;
    on_step?: (step: ExecutionStep, result: any) => void;
  };
}

interface CCEExecuteResult {
  output: any;
  success: boolean;
  quality_achieved: number;
  execution_trace?: ExecutionTrace;
  techniques_used: string[];
  total_time_ms: number;
  tokens_used: number;
}

interface CCELearnParams {
  composition: Composition;
  problem: ProblemAnalysis;
  outcome: {
    success: boolean;
    quality: number;
    user_feedback?: string;
  };
}

interface CCELearnResult {
  learned: boolean;
  updates: {
    technique_id: string;
    metric: string;
    old_value: number;
    new_value: number;
  }[];
  new_heuristics?: string[];
}
```

---

## Example: CCE Solving "Why is this test failing?"

```typescript
// User asks: "Why is test_user_auth failing?"

// Step 1: Problem Analysis
const analysis: ProblemAnalysis = {
  problem_type: 'diagnosis',
  inputs: [
    { name: 'failing_test', type: 'string', example: 'test_user_auth' },
    { name: 'error_message', type: 'string', example: 'Expected 200, got 401' }
  ],
  outputs: [
    { name: 'root_cause', type: 'explanation' },
    { name: 'fix_suggestion', type: 'code_change' }
  ],
  properties: ['causal', 'uncertain', 'reproducible'],
  hard_constraints: ['must_be_actionable'],
  success_metrics: ['finds_true_cause', 'fix_works'],
  budget: { max_tokens: 500 }
};

// Step 2: Technique Matching
const matches = [
  { technique: 'spectrum_based_fl', fitness: 0.8, coverage: 0.6 },
  { technique: 'delta_debugging', fitness: 0.7, coverage: 0.5 },
  { technique: 'causal_inference', fitness: 0.9, coverage: 0.7 },
  { technique: 'execution_trace_analysis', fitness: 0.85, coverage: 0.6 },
  { technique: 'git_blame_analysis', fitness: 0.6, coverage: 0.3 },
];

// Step 3: Composition Synthesis
// CCE decides on a Hybrid composition:
const composition: Composition = {
  operator: {
    type: 'hybrid',
    primary: {
      operator: {
        type: 'chain',
        steps: [
          // Step 1: Gather evidence (0 tokens)
          { technique: 'execution_trace_analysis', cost: 'zero' },
          // Step 2: Statistical fault localization (0 tokens)
          { technique: 'spectrum_based_fl', formula: 'ochiai', cost: 'zero' },
          // Step 3: Causal analysis of top suspects (~300 tokens)
          { technique: 'causal_inference', cost: 'medium' }
        ]
      }
    },
    validator: {
      // Validate by checking if the suggested fix actually works
      operator: { type: 'leaf', technique: 'test_execution', cost: 'zero' }
    },
    fallback: {
      // If causal analysis fails, fall back to LLM reflection
      operator: { type: 'leaf', technique: 'smart_reflection', cost: 'low' }
    }
  },
  expected_cost: { tokens: 350, time_ms: 2000 },
  expected_quality: { min: 0.7, max: 0.95 },
  explanation: 'Evidence gathering → Statistical localization → Causal analysis → Validation'
};

// Step 4: Execution
const result = await cce.execute(composition, {
  failing_test: 'test_user_auth',
  error_message: 'Expected 200, got 401'
});

// Output:
{
  root_cause: {
    file: 'src/auth/middleware.ts',
    line: 42,
    explanation: 'Token validation uses expired secret key after config change',
    causal_chain: [
      'Config reload at 14:32',
      'AUTH_SECRET not updated in memory',
      'Token signature validation fails',
      '401 returned'
    ],
    confidence: 0.87
  },
  fix_suggestion: {
    description: 'Reload AUTH_SECRET from environment after config change',
    code: 'this.secret = process.env.AUTH_SECRET; // Add after config reload',
    location: { file: 'src/auth/middleware.ts', line: 38 }
  },
  techniques_used: ['execution_trace', 'ochiai', 'causal_inference'],
  tokens_used: 285,
  quality_achieved: 0.87
}
```

---

## Learning & Evolution

The CCE improves over time by tracking which compositions work.

```typescript
// src/cce/learning.ts

interface CompositionOutcome {
  composition_hash: string;
  problem_type: ProblemType;
  success: boolean;
  quality: number;
  user_feedback?: string;
  execution_time_ms: number;
  tokens_used: number;
}

class CCELearner {
  private outcomes: CompositionOutcome[] = [];
  private techniqueStats: Map<string, TechniqueStats> = new Map();
  private compositionPatterns: Map<string, PatternStats> = new Map();
  
  async learn(outcome: CompositionOutcome): Promise<void> {
    this.outcomes.push(outcome);
    
    // Update technique statistics
    const techniques = extractTechniques(outcome.composition_hash);
    for (const tech of techniques) {
      const stats = this.techniqueStats.get(tech) || newStats();
      stats.uses++;
      if (outcome.success) stats.successes++;
      stats.avg_quality = updateAverage(stats.avg_quality, outcome.quality, stats.uses);
      this.techniqueStats.set(tech, stats);
    }
    
    // Learn composition patterns
    const pattern = abstractPattern(outcome.composition_hash);
    const patternStats = this.compositionPatterns.get(pattern) || newPatternStats();
    patternStats.uses++;
    if (outcome.success) patternStats.successes++;
    patternStats.problem_types.add(outcome.problem_type);
    this.compositionPatterns.set(pattern, patternStats);
    
    // Evolve new heuristics
    if (this.outcomes.length % 100 === 0) {
      await this.evolveHeuristics();
    }
  }
  
  async evolveHeuristics(): Promise<void> {
    // Find successful patterns
    const successfulPatterns = [...this.compositionPatterns.entries()]
      .filter(([_, stats]) => stats.successes / stats.uses > 0.8)
      .map(([pattern, _]) => pattern);
    
    // Abstract into heuristics
    for (const pattern of successfulPatterns) {
      const heuristic = abstractToHeuristic(pattern);
      await this.addHeuristic(heuristic);
    }
  }
  
  getRecommendation(problem: ProblemAnalysis): CompositionRecommendation {
    // Find patterns that worked for similar problems
    const similarOutcomes = this.outcomes.filter(o => 
      o.problem_type === problem.problem_type && o.success
    );
    
    if (similarOutcomes.length > 10) {
      // Use learned pattern
      const bestPattern = mode(similarOutcomes.map(o => abstractPattern(o.composition_hash)));
      return { pattern: bestPattern, confidence: 0.8, source: 'learned' };
    }
    
    // Fall back to technique statistics
    const bestTechniques = [...this.techniqueStats.entries()]
      .filter(([_, stats]) => stats.problem_types?.has(problem.problem_type))
      .sort((a, b) => b[1].successes / b[1].uses - a[1].successes / a[1].uses)
      .slice(0, 5)
      .map(([tech, _]) => tech);
    
    return { techniques: bestTechniques, confidence: 0.6, source: 'statistics' };
  }
}
```

---

## Integration with PRISM MCP

```typescript
// Add to src/index.ts

import { CognitiveCompositionEngine } from './cce/engine';

const cce = new CognitiveCompositionEngine({
  technique_library: loadTechniqueLibrary(),
  formula_library: loadFormulaLibrary(),
  heuristic_library: loadHeuristicLibrary(),
  mental_model_library: loadMentalModelLibrary(),
  learning_store: '.mcp-learning/cce/',
  evolution_enabled: true
});

// Register CCE tools
server.registerTool('cce_compose', {
  description: 'Synthesize optimal solution by composing techniques',
  handler: async (params: CCEComposeParams) => cce.compose(params)
});

server.registerTool('cce_execute', {
  description: 'Execute a composed solution',
  handler: async (params: CCEExecuteParams) => cce.execute(params)
});

server.registerTool('cce_explain', {
  description: 'Explain why a composition was chosen',
  handler: async (params: { composition: Composition }) => cce.explain(params.composition)
});

server.registerTool('cce_learn', {
  description: 'Learn from composition outcome',
  handler: async (params: CCELearnParams) => cce.learn(params)
});

// Auto-invocation: CCE can be called by other tools
hooks.register('problem_detected', async (problem: any) => {
  const solution = await cce.compose({ problem: JSON.stringify(problem) });
  return solution;
});
```

---

## Summary

The Cognitive Composition Engine provides:

1. **Problem Analysis**: Decomposes any problem into structured representation
2. **Technique Library**: 500+ formulas, algorithms, heuristics, and mental models
3. **Intelligent Matching**: Finds applicable techniques based on problem properties
4. **Composition Synthesis**: Combines techniques using operators (chain, parallel, hybrid, ensemble, evolve)
5. **Evolutionary Composition**: Genetic algorithms to discover novel combinations
6. **Learning**: Tracks outcomes, evolves new heuristics, improves over time

The key insight: **No single technique is optimal for all problems. The CCE finds the right combination.**

---

**END OF CCE SPECIFICATION**
