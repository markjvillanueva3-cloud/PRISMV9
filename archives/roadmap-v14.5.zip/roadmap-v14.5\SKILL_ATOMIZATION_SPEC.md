# SKILL ATOMIZATION SPECIFICATION â€” v14.5
# Status: Planned | Phase: DA-MS9, DA-MS10 | Role: Context Engineer

---

## OVERVIEW

Decompose multi-function skills into single-function skills for token efficiency,
and create new skills derived from MIT/college course content.

## SCOPE

### Existing Skill Decomposition
- 34 existing skills requiring decomposition (15 priority skills over 20KB, 19 at 10-20KB)
- Target: 300-500 single-function skills from decomposition
- Each atomic skill: <2KB, single purpose, auto-loadable by trigger

### Course-Derived Skills
- Source: 206 MIT OpenCourseWare courses + ~25 CNC/CAM resources
- Location: C:\PRISM_ARCHIVE_2026-02-01\RESOURCES\
- Target: ~3,880 skills from course material extraction
- Tier structure:
  T1 (DA parallel): Core manufacturing + materials science (50 courses)
  T2 (R1 parallel): Algorithms + optimization (40 courses)
  T3 (R3 parallel): Advanced manufacturing + controls (50 courses)
  T4 (R7 parallel): Physics + math foundations (66 courses)

## SKILL FORMAT

Each atomic skill follows:
```
SKILL.md:
  # [Skill Name]
  WHEN TO USE: [trigger conditions]
  FUNCTION: [what this skill teaches Claude to do]
  RELATED: [linked skills]
  SOURCE: [phase + MS that created it, or course ID]
  
  [Content: <2KB of focused instruction]
```

## INDEX STRUCTURE

Skills tracked in SKILL_INDEX.json and SKILL_PHASE_MAP.json.
Auto-loaded by trigger matching during session boot and on-demand.

## PARALLEL TRACK CHECKPOINTS

| Gate | Minimum Skill Count | Source |
|------|---------------------|--------|
| R1-MS9 | >= 300 | Decomposed + T1/T2 course skills |
| R3-MS5 | >= 1200 | + T3/T4 + CNC/CAM |
| R7 gate | >= 3500 | All tiers complete |

## VERIFICATION

- No duplicate skills (check by trigger + content hash)
- Each skill <2KB (token budget constraint)
- Dependency graph validates (no circular refs)
- Skill loading verified via prism_knowledge stats