# PRISM RECOVERY CARD u{2014} v14.5
# LOAD THIS FILE ON EVERY "continue" / "start roadmap" / post-compaction recovery.
# This is the ONLY file needed to bootstrap recovery. ~150 lines, ~1K tokens.
# Location: C:\PRISM\mcp-server\data\docs\roadmap\PRISM_RECOVERY_CARD.md

---

## STEP 0: DETECT ENVIRONMENT

```
TRY: prism_dev action=health
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ SUCCESS (status ok, dispatchers ÃƒÂ¢Ã¢â‚¬Â°Ã‚Â¥ 31): MCP MODE. Use prism_ tools for everything.
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ FAIL (connection refused / tool not found): NO MCP.
    TRY: Desktop Commander available? (read_file / start_process)
      ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ SUCCESS: DC MODE. Read/write files via Desktop Commander.
      ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ FAIL: ASK human to start MCP server or enable Desktop Commander.

LOG: State your detected environment in first response:
  "Environment: MCP mode" or "Environment: DC mode (MCP unavailable)"
```

## STEP 1: FIND POSITION

```
MCP MODE:
  prism_doc action=read name=CURRENT_POSITION.md
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ Format: "CURRENT: [MS-ID] | LAST_COMPLETE: [MS-ID] [date] | PHASE: [ID] [status]"
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ OPTIONAL: prism_doc action=read name=SESSION_HANDOFF.md (richer context if available)
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ If missing: prism_doc action=read name=ROADMAP_TRACKER.md (last 5 entries)
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ If both missing: position = DA-MS0

DC MODE:
  Desktop Commander read_file C:\PRISM\mcp-server\data\docs\roadmap\CURRENT_POSITION.md
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ OPTIONAL: read SESSION_HANDOFF.md for richer context (next step, in-progress work)
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ If missing: read ROADMAP_TRACKER.md, find last COMPLETE entry, advance to next MS.
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ If both missing: position = DA-MS0

COMPACTION RECOVERY (if you suspect compaction occurred):
  1. Check /mnt/transcripts/journal.txt ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ read latest transcript tail
  2. Check /home/claude/ for progress files from this session
  3. Reconcile with CURRENT_POSITION.md ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ use LATER position
```

## STEP 1.5: LOAD SECTION INDEX (recommended ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â saves tokens)

```
IF ROADMAP_SECTION_INDEX.md exists (built in DA-MS5, Wave 1):
  Read ROADMAP_SECTION_INDEX.md (~200 lines, ~1.5K tokens)
  This lets you load ONLY the sections you need from any file.
  Example: Need stuck protocol? ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ find pc_stuck_protocol ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ line ~1608 ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ load 30 lines.
  Example: Need R1-MS5? ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ find r1_ms5_tool_schema ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ line ~253 ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ load that section.
  IF section index missing: Fall back to loading full phase doc (works but uses more tokens).
```

## STEP 2: LOAD PHASE DOC

```
PHASE ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ FILE MAPPING:
  P0  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ PHASE_P0_ACTIVATION.md           (COMPLETE ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â skip unless re-gate)
  DA  u{2192} PHASE_DA_DEV_ACCELERATION.md      (1338 lines)
  R1  u{2192} PHASE_R1_REGISTRY.md             (1513 lines u{2014} skip to MS4.5+ via LOADER:SKIP))
  R2  u{2192} PHASE_R2_SAFETY.md               (778 lines)
  R3  u{2192} PHASE_R3_CAMPAIGNS.md            (1004 lines)
  R4  u{2192} PHASE_R4_ENTERPRISE.md           (243 lines)
  R5  u{2192} PHASE_R5_VISUAL.md               (289 lines)
  R6  u{2192} PHASE_R6_PRODUCTION.md           (308 lines)
  R7  u{2192} PHASE_R7_INTELLIGENCE.md         (1040 lines)
  R8  u{2192} PHASE_R8_EXPERIENCE.md           (920 lines)
  R9  u{2192} PHASE_R9_INTEGRATION.md          (604 lines)
  R10 u{2192} PHASE_R10_REVOLUTION.md          (989 lines)
  R11 u{2192} PHASE_R11_PRODUCT.md             (227 lines)

ALL DOCS AT: C:\PRISM\mcp-server\data\docs\roadmap\
MCP: prism_doc action=read name=roadmap/[filename]
DC:  Desktop Commander read_file C:\PRISM\mcp-server\data\docs\roadmap\[filename]

SKIP COMPLETED MILESTONES: Look for <!-- LOADER: SKIP TO LINE [N] --> markers.
  Read from that line forward to avoid loading completed MS content.
```

## STEP 2.5: LOAD SESSION KNOWLEDGE (if knowledge system exists)

```
IF C:\PRISM\knowledge\sessions\SESSION_KNOWLEDGE_INDEX.json exists:
  MCP: prism_doc action=read name=knowledge/sessions/SESSION_KNOWLEDGE_INDEX.json
  DC:  Desktop Commander read_file C:\PRISM\knowledge\sessions\SESSION_KNOWLEDGE_INDEX.json

  QUERY: Filter for current phase + current milestone + promoted_to = null
  LOAD matching knowledge nodes (typically 3-10 entries, ~500-1000 tokens)
  These are DECISIONS, ERROR FIXES, OBSERVATIONS from prior sessions about THIS work.
  Apply them: don't re-decide what was decided, don't re-debug what was fixed.

IF the file doesn't exist yet: Skip this step. Knowledge system is built in DA-MS4.

ALSO (optional, high value):
  IF ROADMAP_SECTION_INDEX.md exists: Load it (~200 lines, ~1.5K tokens).
  This lets you load ONLY the sections you need from any file instead of full docs.
  Find section ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ get line number ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ load just that range. Saves ~10K tokens per session.
```

## STEP 3: EXECUTE

```
1. Find your current MS in the phase doc
2. Find the current STEP within that MS (from ACTION_TRACKER.md or CURRENT_POSITION.md)
3. Execute steps sequentially
4. After each step: verify (build if code changed, check output if data)
5. Update position:
   - CURRENT_POSITION.md: every 3 calls (or after each significant step)
   - ACTION_TRACKER.md: after each step-group completion
   - ROADMAP_TRACKER.md: after each MS completion
6. Flush results to disk after each logical unit of work
```


## ROLE / MODEL ASSIGNMENT (v14.5)

```
Every milestone has a Role + Model + Effort assignment (### Role: line after ## header).
RULE: Follow the assigned model. Do NOT use Haiku for safety-critical work.
  Haiku  = Bulk ops, file scanning, grep, mechanical transforms
  Sonnet = Implementation, testing, scripts, validation, wiring
  Opus   = Architecture, safety-critical review, phase gates, schema design
CANONICAL REF: ROLE_MODEL_EFFORT_MATRIX.md (668 lines, all 95 milestones)
```

## SKILL ATOMIZATION PARALLEL TRACK (v14.5)

```
RUNS ALONGSIDE: R1+ phases (not blocking, not blocked by)
WHAT: Split 34 oversized skills + extract from 206 MIT courses + 25 CNC/CAM resources
OUTPUT: ~3,880 atomic skills, each <=5KB, indexed in SKILL_INDEX.json
DA-MS9: Build infrastructure (index schema, automation scripts)
DA-MS10: Pilot (3 skill splits + 3 course extractions to validate pattern)
BULK: Haiku extracts, Sonnet reviews quality, batches of 10-20 skills per session
SPEC: SKILL_ATOMIZATION_SPEC.md + FULL_COURSE_INVENTORY.md
COURSES AT: C:\PRISM_ARCHIVE_2026-02-01\RESOURCES\MIT COURSES\ + RESOURCE PDFS\
```

## ESSENTIAL RULES (standalone ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â no other doc needed)

```
BUILD:     npm run build (NEVER standalone tsc ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â OOM at current scale)
SAFETY:    S(x) >= 0.70 is HARD BLOCK. Never skip safety validation.
FLUSH:     Write results to disk after each logical unit. Don't accumulate in context.
POSITION:  Update CURRENT_POSITION.md every 3 calls during execution.
ERRORS:    Fix ONE build error. Rebuild. Repeat. If >5 errors from one edit ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ revert.
IDEMPOTENT: Read-only calls = safe to re-run. Write calls = check if already done first.
NO PLACEHOLDERS: Every value must be real, complete, verified.
TRANSITION: When MS completes ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ update CURRENT_POSITION first, ROADMAP_TRACKER second.
POWERSHELL: Never inline $ vars in DC start_process. Write .ps1 file first, execute file.
```

## STUCK PROTOCOL (autonomous)

```
ATTEMPT 1-3: Try to fix the problem with different approaches.
ATTEMPT 4:   Search codebase for similar patterns (code_search / grep).
ATTEMPT 5:   Read related test files for expected behavior.
ATTEMPT 6:   Try a completely different approach (not a variation).
IF NON-BLOCKING: Skip step, mark DEFERRED in ACTION_TRACKER, continue to next step.
IF BLOCKING:     Write detailed diagnosis to ACTION_TRACKER, ask human for guidance.
  "BLOCKED on [error] after [N] attempts. Tried: [list]. Need: [specific question]."
DATA ERRORS (R1): Quarantine bad data in PHASE_FINDINGS.md, continue with remaining data.
```

## COMPACTION ADAPTATION

```
IF you detect this is a post-compaction recovery AND ROADMAP_TRACKER shows
multiple COMPACTION-RECOVERY entries in the current session:
  ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ RAPID-COMPACTION MODE:
    - Load only this Recovery Card (skip MASTER_INDEX and PROTOCOLS_CORE)
    - Skip skill loading and hook enabling
    - Update position every 2 calls instead of every 3
    - Flush to disk after EVERY step, not every group
    - Focus on executing the NEXT step only, don't plan ahead
```

## PHASE TRANSITION PROTOCOL

```
When the LAST MS of a phase completes:
  1. FIRST: Update CURRENT_POSITION.md ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ point to NEXT phase's first MS
  2. SECOND: Append to ROADMAP_TRACKER.md ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ "[Phase] COMPLETE [date]"
  3. Update MASTER_INDEX Phase Registry ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ [this-phase] status = complete
  4. Load next phase doc
  5. Continue with next phase MS0

WHY THIS ORDER: If compaction hits between step 1 and 2, CURRENT_POSITION
already points to the next milestone. Recovery finds the right place.
```

## SESSION END PROTOCOL

```
Before ending any session (or when context pressure > 75%):
  1. Write SESSION_HANDOFF.md:
     POSITION: [current MS and step]
     LAST_COMPLETED: [last finished step]
     NEXT_STEP: [what to do next]
     IN_PROGRESS: [any partial work, where it's saved]
     BLOCKING: [any issues preventing progress]
  2. Update CURRENT_POSITION.md with latest position
  3. Append to ROADMAP_TRACKER.md if any MS completed
  4. Save state: prism_session action=state_save (MCP mode only)
  5. KNOWLEDGE EXTRACTION (if knowledge system exists ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â built in DA-MS4):
     Review session: What decisions? What errors fixed? What learned?
     Write knowledge nodes to C:\PRISM\knowledge\sessions\[date]_session_knowledge.json
     Update SESSION_KNOWLEDGE_INDEX.json
     Types: decision, error_fix, assumption, observation, relationship, blocker
     MINIMUM: 1 node per session. Most sessions produce 3-8.
     See HIERARCHICAL_INDEX_SPEC.md Ãƒâ€šÃ‚Â§Branch 4 for full schema.

MCP:  prism_doc action=write name=SESSION_HANDOFF.md content="..."
DC:   Desktop Commander write_file C:\PRISM\mcp-server\data\docs\SESSION_HANDOFF.md
```
