---
name: prism-high-reliability-protocols
version: 1.0.0
description: |
  Comprehensive protocols for four high-reliability domains: Formal Logic Proofs, 
  Compilable Code, Mathematical Calculations, and Verified Factual Claims.
  Integrates with: prism-reasoning-engine, prism-universal-formulas, prism-cognitive-core
---

# ═══════════════════════════════════════════════════════════════════════════════
# PRISM HIGH-RELIABILITY PROTOCOLS v1.0
# ═══════════════════════════════════════════════════════════════════════════════

## OVERVIEW

Four comprehensive protocols designed for maximum reliability in their domains:

| Protocol | Symbol | Target Reliability | Verification Method |
|----------|--------|-------------------|---------------------|
| Formal Logic Proofs | Λ(x) | 99%+ | Proof checker / rule validation |
| Compilable Code | Κ(x) | 98%+ | Execution / test suite |
| Mathematical Calculations | Μ(x) | 99%+ | Multi-path verification |
| Verified Factual Claims | Φ(x) | 95%+ | Source triangulation |

## MASTER INTEGRATION

```
PROTOCOL SELECTION:
┌─────────────────────────────────────────────────────────────────────────────┐
│  INPUT → TYPE CLASSIFICATION → PROTOCOL SELECTION → EXECUTION → VERIFY     │
├─────────────────────────────────────────────────────────────────────────────┤
│  "Prove that..." → Λ(x) FORMAL LOGIC                                        │
│  "Write code..." → Κ(x) COMPILABLE CODE                                     │
│  "Calculate..." → Μ(x) MATHEMATICAL                                         │
│  "Is it true..." → Φ(x) FACTUAL CLAIMS                                      │
│  Mixed/Compound → Apply protocols in dependency order                       │
└─────────────────────────────────────────────────────────────────────────────┘

DEPENDENCY ORDER (when compound):
  Μ(x) Mathematical → Supports → Λ(x) Logic (provides values)
  Λ(x) Logic → Validates → Κ(x) Code (correctness proofs)
  Φ(x) Facts → Grounds → All protocols (real-world constraints)
```

# ═══════════════════════════════════════════════════════════════════════════════
# PROTOCOL 1: FORMAL LOGIC PROOFS - Λ(x)
# ═══════════════════════════════════════════════════════════════════════════════

## 1.1 SCOPE

Applies to: Propositional logic, predicate logic, set theory proofs, 
mathematical proofs, validity arguments, logical derivations.

## 1.2 THE COMPLETE PROOF PROTOCOL

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    FORMAL LOGIC PROOF PROTOCOL - Λ(x)                         ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  PHASE 1: FORMALIZATION (Translate to formal language)                        ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  1.1 IDENTIFY CLAIM TYPE                                                      ║
║      □ Propositional (P → Q)                                                  ║
║      □ First-order predicate (∀x. P(x) → Q(x))                               ║
║      □ Set-theoretic (A ⊆ B)                                                  ║
║      □ Arithmetic (∀n. P(n))                                                  ║
║                                                                               ║
║  1.2 EXTRACT COMPONENTS                                                       ║
║      Premises: P₁, P₂, ... Pₙ                                                 ║
║      Conclusion: C                                                            ║
║      Goal: P₁ ∧ P₂ ∧ ... ∧ Pₙ ⊢ C                                            ║
║                                                                               ║
║  1.3 FORMALIZE EACH STATEMENT                                                 ║
║      Natural language → Formal notation                                       ║
║      VERIFY: Does formal version capture intended meaning?                    ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 2: PROOF STRATEGY SELECTION                                            ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  2.1 ANALYZE GOAL STRUCTURE                                                   ║
║                                                                               ║
║      IF goal = A → B:                                                         ║
║         → CONDITIONAL PROOF: Assume A, derive B                               ║
║                                                                               ║
║      IF goal = A ∧ B:                                                         ║
║         → CONJUNCTION: Prove A, then prove B separately                       ║
║                                                                               ║
║      IF goal = A ∨ B:                                                         ║
║         → DISJUNCTION: Prove either A or B                                    ║
║                                                                               ║
║      IF goal = ¬A:                                                            ║
║         → NEGATION: Assume A, derive contradiction                            ║
║                                                                               ║
║      IF goal = ∀x.P(x):                                                       ║
║         → UNIVERSAL: Let x be arbitrary, prove P(x)                           ║
║                                                                               ║
║      IF goal = ∃x.P(x):                                                       ║
║         → EXISTENTIAL: Find witness c, prove P(c)                             ║
║                                                                               ║
║      IF goal is equality (a = b):                                             ║
║         → SUBSTITUTION: Chain of equalities with justification                ║
║                                                                               ║
║      IF stuck or complex:                                                     ║
║         → CONTRADICTION: Assume ¬C, derive ⊥                                  ║
║         → CONTRAPOSITION: Prove ¬C → ¬(P₁∧...∧Pₙ)                            ║
║         → CASES: If premise is A∨B, prove C from A, then from B              ║
║                                                                               ║
║  2.2 LEMMA IDENTIFICATION                                                     ║
║      □ Does proof require sub-results?                                        ║
║      □ Can complex steps be broken into lemmas?                               ║
║      □ Are there known theorems applicable?                                   ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 3: PROOF CONSTRUCTION                                                  ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  3.1 LINE-BY-LINE FORMAT                                                      ║
║                                                                               ║
║      Line │ Statement │ Justification                                         ║
║      ─────┼───────────┼──────────────────────────────────────                ║
║       1   │ P₁        │ Premise                                               ║
║       2   │ P₂        │ Premise                                               ║
║       ...                                                                     ║
║       n   │ C         │ [Rule] from lines [x, y, ...]                         ║
║                                                                               ║
║  3.2 VALID INFERENCE RULES (Reference)                                        ║
║                                                                               ║
║      INTRODUCTION RULES:                                                      ║
║      ∧I:  A, B ⊢ A ∧ B                                                        ║
║      ∨I:  A ⊢ A ∨ B  or  B ⊢ A ∨ B                                           ║
║      →I:  [Assume A ... derive B] ⊢ A → B                                    ║
║      ¬I:  [Assume A ... derive ⊥] ⊢ ¬A                                       ║
║      ∀I:  P(a) for arbitrary a ⊢ ∀x.P(x)                                     ║
║      ∃I:  P(c) for some c ⊢ ∃x.P(x)                                          ║
║      =I:  ⊢ t = t (reflexivity)                                              ║
║                                                                               ║
║      ELIMINATION RULES:                                                       ║
║      ∧E:  A ∧ B ⊢ A  and  A ∧ B ⊢ B                                          ║
║      ∨E:  A ∨ B, A → C, B → C ⊢ C                                            ║
║      →E:  A → B, A ⊢ B  (Modus Ponens)                                       ║
║      ¬E:  ¬¬A ⊢ A  (Double Negation)                                         ║
║      ∀E:  ∀x.P(x) ⊢ P(t)  for any term t                                     ║
║      ∃E:  ∃x.P(x), P(c) → C ⊢ C  (c fresh)                                   ║
║      =E:  a = b, P(a) ⊢ P(b)  (substitution)                                 ║
║                                                                               ║
║      DERIVED RULES:                                                           ║
║      MT:   A → B, ¬B ⊢ ¬A  (Modus Tollens)                                   ║
║      HS:   A → B, B → C ⊢ A → C  (Hypothetical Syllogism)                    ║
║      DS:   A ∨ B, ¬A ⊢ B  (Disjunctive Syllogism)                            ║
║      Contra: A → B ⊣⊢ ¬B → ¬A                                                ║
║      DeMorgan: ¬(A∧B) ⊣⊢ ¬A∨¬B,  ¬(A∨B) ⊣⊢ ¬A∧¬B                           ║
║                                                                               ║
║  3.3 EACH STEP MUST HAVE:                                                     ║
║      □ Explicit rule citation                                                 ║
║      □ Line number references for premises used                               ║
║      □ No implicit assumptions                                                ║
║      □ No gaps in reasoning                                                   ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 4: VERIFICATION                                                        ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  4.1 SYNTACTIC CHECK (for each line n)                                        ║
║      □ Is the rule cited valid?                                               ║
║      □ Does the statement follow from cited lines by that rule?               ║
║      □ Are all free variables properly scoped?                                ║
║      □ Are assumptions discharged before conclusion?                          ║
║                                                                               ║
║  4.2 COMPLETENESS CHECK                                                       ║
║      □ Does final line match the goal C?                                      ║
║      □ Are all assumptions accounted for (either premises or discharged)?     ║
║      □ Does the proof address all cases (if case analysis used)?              ║
║                                                                               ║
║  4.3 SEMANTIC CHECK (counterexample search)                                   ║
║      □ Attempt to find interpretation where premises true, conclusion false   ║
║      □ If found: PROOF INVALID - restart                                      ║
║      □ If systematic search fails: Increases confidence                       ║
║                                                                               ║
║  4.4 ALTERNATIVE PATH (when possible)                                         ║
║      □ Construct proof via different strategy                                 ║
║      □ If same conclusion reached: HIGH CONFIDENCE                            ║
║      □ If different: INVESTIGATE discrepancy                                  ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 5: OUTPUT FORMAT                                                       ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║                                                                               ║
║  THEOREM: [Statement in natural language]                                     ║
║                                                                               ║
║  FORMAL: P₁, P₂, ..., Pₙ ⊢ C                                                 ║
║                                                                               ║
║  PROOF:                                                                       ║
║  ┌─────┬────────────────────────┬─────────────────────────────┐              ║
║  │ Line│ Statement              │ Justification               │              ║
║  ├─────┼────────────────────────┼─────────────────────────────┤              ║
║  │ 1   │ ...                    │ Premise                     │              ║
║  │ 2   │ ...                    │ Premise                     │              ║
║  │ ... │ ...                    │ [Rule] from [lines]         │              ║
║  │ n   │ C                      │ [Final rule] from [lines]   │              ║
║  └─────┴────────────────────────┴─────────────────────────────┘              ║
║                                                                               ║
║  VERIFICATION: □ Syntactic ✓  □ Completeness ✓  □ Semantic ✓               ║
║  CONFIDENCE: [X]% (based on verification depth)                              ║
║                                                                               ║
║  QED ■                                                                        ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

## 1.3 MATHEMATICAL PROOF EXTENSIONS

```
MATHEMATICAL INDUCTION (for ∀n∈ℕ. P(n)):
────────────────────────────────────────────────────────────────────────────────

STEP 1 - BASE CASE:
  Prove P(0) [or P(1) depending on domain]
  
STEP 2 - INDUCTIVE HYPOTHESIS:
  Assume P(k) for arbitrary k ≥ base
  
STEP 3 - INDUCTIVE STEP:
  Prove P(k) → P(k+1)
  Must explicitly use inductive hypothesis
  
STEP 4 - CONCLUSION:
  By principle of mathematical induction: ∀n. P(n)
  
VERIFICATION:
  □ Base case covers starting point
  □ Inductive step actually uses IH (not circular)
  □ No boundary gaps (e.g., P(0) and P(k)→P(k+1) covers all n≥0)


STRONG INDUCTION (when P(k+1) depends on multiple predecessors):
────────────────────────────────────────────────────────────────────────────────

STEP 1 - BASE CASES:
  Prove P(0), P(1), ..., P(m) for necessary base cases
  
STEP 2 - STRONG INDUCTIVE HYPOTHESIS:
  Assume ∀j < k. P(j)
  
STEP 3 - INDUCTIVE STEP:
  Prove P(k) using any P(j) where j < k
  
STEP 4 - CONCLUSION:
  By strong induction: ∀n. P(n)


STRUCTURAL INDUCTION (for recursive data structures):
────────────────────────────────────────────────────────────────────────────────

STEP 1 - BASE CASES:
  Prove P(c) for each constructor with no recursive arguments
  
STEP 2 - INDUCTIVE CASES:
  For each constructor C(x₁,...,xₙ) with recursive args:
  Assume P(xᵢ) for recursive args, prove P(C(x₁,...,xₙ))
  
STEP 3 - CONCLUSION:
  By structural induction: ∀t. P(t)
```

## 1.4 PROOF QUALITY SCORE

```
Λ(x) = (formalization × strategy × construction × verification)^(1/4)

Where:
  formalization = {
    1.0  if premises/conclusion fully formal with verified semantics
    0.8  if formal with minor ambiguity
    0.5  if partially formal
    0.2  if mostly informal
    0.0  if no formalization attempted
  }
  
  strategy = {
    1.0  if optimal strategy selected with justification
    0.8  if valid strategy, possibly suboptimal
    0.5  if strategy unclear but proof works
    0.2  if strategy mismatched to problem
    0.0  if no strategy (random steps)
  }
  
  construction = {
    1.0  if every step valid, cited, complete
    0.9  if all steps valid, minor citation gaps
    0.7  if valid but some steps combined
    0.4  if some invalid steps or gaps
    0.0  if proof fundamentally broken
  }
  
  verification = {
    1.0  if syntactic + semantic + alternative path all pass
    0.9  if syntactic + semantic pass
    0.7  if syntactic passes, semantic untested
    0.3  if verification reveals fixable issues
    0.0  if verification reveals fundamental flaw
  }
  
THRESHOLD: Λ(x) ≥ 0.9 for "HIGH RELIABILITY" claim
```

# ═══════════════════════════════════════════════════════════════════════════════
# PROTOCOL 2: COMPILABLE CODE - Κ(x)
# ═══════════════════════════════════════════════════════════════════════════════

## 2.1 SCOPE

Applies to: Any code generation task where the output must compile/run 
successfully and produce correct results.

## 2.2 THE COMPLETE CODE PROTOCOL

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    COMPILABLE CODE PROTOCOL - Κ(x)                            ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  PHASE 1: SPECIFICATION                                                       ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  1.1 EXTRACT REQUIREMENTS                                                     ║
║      INPUTS:                                                                  ║
║        □ Types: [type₁, type₂, ...]                                          ║
║        □ Constraints: [constraint₁, constraint₂, ...]                        ║
║        □ Examples: [example₁, example₂, ...]                                 ║
║                                                                               ║
║      OUTPUTS:                                                                 ║
║        □ Type: [output_type]                                                  ║
║        □ Format: [format_specification]                                       ║
║        □ Edge cases: [how to handle nulls, errors, bounds]                   ║
║                                                                               ║
║      BEHAVIOR:                                                                ║
║        □ Pure function or side effects?                                       ║
║        □ Deterministic or probabilistic?                                      ║
║        □ Performance constraints: O(?) time, O(?) space                       ║
║                                                                               ║
║  1.2 FORMALIZE AS CONTRACT                                                    ║
║      PRECONDITIONS: What must be true of inputs?                              ║
║      POSTCONDITIONS: What must be true of outputs?                            ║
║      INVARIANTS: What must remain true throughout?                            ║
║                                                                               ║
║  1.3 GENERATE TEST CASES BEFORE CODE                                          ║
║      □ Happy path (normal inputs)                                             ║
║      □ Edge cases (empty, single, max size)                                   ║
║      □ Boundary values (0, 1, -1, MAX_INT, etc.)                             ║
║      □ Error cases (null, invalid type, out of range)                        ║
║      □ Property-based: Random inputs satisfying preconditions                 ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 2: DESIGN                                                              ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  2.1 ALGORITHM SELECTION                                                      ║
║      □ Identify problem class (search, sort, graph, DP, etc.)                ║
║      □ Select appropriate algorithm (cite source)                             ║
║      □ Verify complexity meets requirements                                   ║
║      □ Consider alternatives if close to boundary                             ║
║                                                                               ║
║  2.2 DATA STRUCTURE SELECTION                                                 ║
║      □ Match operations to data structure strengths                           ║
║      □ Consider memory vs. speed tradeoffs                                    ║
║      □ Standard library vs. custom implementation                             ║
║                                                                               ║
║  2.3 DECOMPOSITION                                                            ║
║      □ Break into functions ≤ 20 lines each                                   ║
║      □ Each function: single responsibility                                   ║
║      □ Define interfaces before implementations                               ║
║      □ Identify reusable components                                           ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 3: IMPLEMENTATION                                                      ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  3.1 ENVIRONMENT CHECK                                                        ║
║      □ Target language/version: [e.g., Python 3.11]                          ║
║      □ Required imports: [list all]                                           ║
║      □ External dependencies: [list with versions]                            ║
║                                                                               ║
║  3.2 WRITE CODE IN LAYERS                                                     ║
║      LAYER 1: Type definitions and interfaces                                 ║
║      LAYER 2: Pure helper functions (easily testable)                         ║
║      LAYER 3: Core logic (composes helpers)                                   ║
║      LAYER 4: I/O and side effects (isolated)                                 ║
║      LAYER 5: Error handling wrapper                                          ║
║                                                                               ║
║  3.3 CODE STANDARDS                                                           ║
║      □ All variables typed (or type-hinted)                                   ║
║      □ No magic numbers (use named constants)                                 ║
║      □ Comments explain WHY not WHAT                                          ║
║      □ Consistent naming convention                                           ║
║      □ Error messages include context                                         ║
║                                                                               ║
║  3.4 DEFENSIVE CODING                                                         ║
║      □ Validate inputs at boundaries                                          ║
║      □ Fail fast with clear errors                                            ║
║      □ No silent failures                                                     ║
║      □ Resources properly managed (with/using/defer)                          ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 4: STATIC VERIFICATION                                                 ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  4.1 SYNTAX CHECK                                                             ║
║      □ Parse/compile without errors                                           ║
║      □ All imports resolve                                                    ║
║      □ All variables defined before use                                       ║
║                                                                               ║
║  4.2 TYPE CHECK                                                               ║
║      □ All type annotations consistent                                        ║
║      □ Function signatures match usage                                        ║
║      □ No implicit type coercions that could fail                            ║
║                                                                               ║
║  4.3 LINTING                                                                  ║
║      □ No unused variables/imports                                            ║
║      □ Consistent style                                                       ║
║      □ No deprecated patterns                                                 ║
║                                                                               ║
║  4.4 STATIC ANALYSIS                                                          ║
║      □ No obvious null dereferences                                           ║
║      □ Array bounds respected                                                 ║
║      □ No infinite loops detectable                                           ║
║      □ No race conditions (if concurrent)                                     ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 5: DYNAMIC VERIFICATION                                                ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  5.1 UNIT TESTS                                                               ║
║      □ Run all tests from Phase 1.3                                           ║
║      □ All must pass                                                          ║
║      □ Coverage ≥ 80% of branches                                             ║
║                                                                               ║
║  5.2 EXECUTION TRACE                                                          ║
║      □ Step through mentally with example input                               ║
║      □ Track variable states at each step                                     ║
║      □ Verify intermediate states match expectations                          ║
║                                                                               ║
║  5.3 BOUNDARY TESTING                                                         ║
║      □ Test with smallest valid input                                         ║
║      □ Test with largest expected input                                       ║
║      □ Test performance at scale                                              ║
║                                                                               ║
║  5.4 ERROR PATH TESTING                                                       ║
║      □ Force each error condition                                             ║
║      □ Verify appropriate error handling                                      ║
║      □ No crashes on invalid input                                            ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 6: ITERATION (if tests fail)                                           ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  6.1 DIAGNOSE FAILURE                                                         ║
║      □ Which test failed?                                                     ║
║      □ What was expected vs. actual?                                          ║
║      □ Trace execution to failure point                                       ║
║                                                                               ║
║  6.2 HYPOTHESIZE ROOT CAUSE                                                   ║
║      □ Off-by-one? Boundary? Logic? Type?                                     ║
║      □ Generate minimal reproduction                                          ║
║                                                                               ║
║  6.3 FIX AND VERIFY                                                           ║
║      □ Make minimal change                                                    ║
║      □ Re-run all tests (not just failing one)                               ║
║      □ Ensure no regression                                                   ║
║                                                                               ║
║  6.4 ITERATION LIMIT                                                          ║
║      □ Max 5 fix attempts before redesign                                     ║
║      □ If hitting limit: return to Phase 2                                    ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

## 2.3 CODE QUALITY SCORE

```
Κ(x) = min(compiles, tests_pass) × (design × implementation × verification)^(1/3)

Where:
  compiles = {1.0 if compiles/parses, 0.0 otherwise}  # HARD GATE
  tests_pass = fraction of tests passing  # HARD GATE
  
  design = {
    1.0  if algorithm optimal, well-decomposed
    0.8  if algorithm correct, reasonably decomposed
    0.5  if algorithm works but suboptimal structure
    0.2  if algorithm questionable
    0.0  if fundamental design flaw
  }
  
  implementation = {
    1.0  if all standards met, defensive, clean
    0.8  if standards mostly met, minor issues
    0.5  if functional but messy
    0.2  if significant quality issues
    0.0  if implementation fundamentally broken
  }
  
  verification = {
    1.0  if 100% tests pass + full coverage + boundary tested
    0.9  if 100% tests pass + good coverage
    0.7  if all explicit tests pass
    0.5  if most tests pass
    0.0  if compilation or critical tests fail
  }

THRESHOLD: Κ(x) ≥ 0.95 for "HIGH RELIABILITY" claim
NOTE: compiles = 0 or tests_pass < 1.0 immediately fails the protocol
```

## 2.4 LANGUAGE-SPECIFIC CHECKLISTS

```
PYTHON:
────────────────────────────────────────────────────────────────────────────────
□ Type hints on all functions
□ `if __name__ == "__main__":` guard
□ Exception handling with specific types
□ f-strings for formatting
□ Context managers for resources
□ List comprehensions where appropriate
□ No mutable default arguments


JAVASCRIPT/TYPESCRIPT:
────────────────────────────────────────────────────────────────────────────────
□ TypeScript preferred over JavaScript
□ Strict mode enabled
□ Async/await over callbacks
□ const/let, never var
□ Optional chaining (?.) for null safety
□ Array methods over loops where cleaner
□ Error boundaries for UI code


SQL:
────────────────────────────────────────────────────────────────────────────────
□ Parameterized queries (NO string concatenation)
□ Explicit column names (no SELECT *)
□ JOIN conditions clear
□ Index considerations documented
□ Transaction boundaries explicit
□ NULL handling explicit (COALESCE, etc.)


HTML/CSS/JSX:
────────────────────────────────────────────────────────────────────────────────
□ Semantic HTML elements
□ Accessibility attributes (aria-*, alt, etc.)
□ Valid nesting
□ CSS: no !important unless justified
□ Responsive considerations
□ Event handlers properly bound
```

# ═══════════════════════════════════════════════════════════════════════════════
# PROTOCOL 3: MATHEMATICAL CALCULATIONS - Μ(x)
# ═══════════════════════════════════════════════════════════════════════════════

## 3.1 SCOPE

Applies to: Arithmetic, algebra, calculus, statistics, numerical methods,
any computation producing a numerical result.

## 3.2 THE COMPLETE CALCULATION PROTOCOL

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    MATHEMATICAL CALCULATION PROTOCOL - Μ(x)                   ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  PHASE 1: PROBLEM SETUP                                                       ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  1.1 IDENTIFY KNOWNS AND UNKNOWNS                                             ║
║      GIVEN:                                                                   ║
║        □ Variable₁ = value₁ [units₁]                                         ║
║        □ Variable₂ = value₂ [units₂]                                         ║
║        □ ...                                                                  ║
║                                                                               ║
║      FIND:                                                                    ║
║        □ Target variable [expected units]                                     ║
║                                                                               ║
║  1.2 UNIT ANALYSIS                                                            ║
║      □ All inputs have explicit units                                         ║
║      □ Target units identified                                                ║
║      □ Conversion factors listed if needed                                    ║
║      □ DIMENSIONAL ANALYSIS: Do units work out?                               ║
║                                                                               ║
║  1.3 SELECT FORMULA/METHOD                                                    ║
║      □ Cite formula source (textbook, PRISM-universal-formulas, etc.)        ║
║      □ Verify formula applies to this problem type                            ║
║      □ Note any assumptions/constraints of formula                            ║
║                                                                               ║
║  1.4 ESTIMATE BEFORE CALCULATING                                              ║
║      □ Order of magnitude estimate                                            ║
║      □ Expected range: [low_bound, high_bound]                                ║
║      □ If final answer outside range: INVESTIGATE                             ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 2: PRIMARY CALCULATION PATH                                            ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  2.1 WRITE FORMULA WITH SUBSTITUTIONS                                         ║
║      Formula: [symbolic formula]                                              ║
║      Substituting: [formula with values inserted]                             ║
║                                                                               ║
║  2.2 SHOW ALL INTERMEDIATE STEPS                                              ║
║      Step 1: [calculation] = [result]                                         ║
║      Step 2: [calculation] = [result]                                         ║
║      ...                                                                      ║
║      Final: [result] [units]                                                  ║
║                                                                               ║
║  2.3 STEP RULES                                                               ║
║      □ One operation per line maximum                                         ║
║      □ Carry full precision through intermediates                             ║
║      □ Round only at final answer                                             ║
║      □ Units tracked at every step                                            ║
║                                                                               ║
║  2.4 COMMON OPERATIONS CHECK                                                  ║
║      ADDITION/SUBTRACTION:                                                    ║
║        □ Same units? (convert if not)                                         ║
║        □ Signs correct?                                                       ║
║                                                                               ║
║      MULTIPLICATION/DIVISION:                                                 ║
║        □ Units multiply/divide correctly?                                     ║
║        □ Division by zero possible?                                           ║
║                                                                               ║
║      EXPONENTS/ROOTS:                                                         ║
║        □ Base positive if even root?                                          ║
║        □ Units raised to power correctly?                                     ║
║                                                                               ║
║      LOGARITHMS:                                                              ║
║        □ Argument positive?                                                   ║
║        □ Units dimensionless? (log of dimensional quantity is invalid)        ║
║                                                                               ║
║      TRIGONOMETRY:                                                            ║
║        □ Angle in correct units (radians vs degrees)?                         ║
║        □ Domain restrictions satisfied?                                       ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 3: VERIFICATION (MANDATORY)                                            ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  3.1 DIMENSIONAL VERIFICATION                                                 ║
║      □ Final units match expected units? ✓/✗                                  ║
║      □ If ✗: Error in calculation - trace back                               ║
║                                                                               ║
║  3.2 MAGNITUDE VERIFICATION                                                   ║
║      □ Answer within estimated range? ✓/✗                                     ║
║      □ If ✗: Either estimate wrong OR calculation wrong - investigate both   ║
║                                                                               ║
║  3.3 ALTERNATIVE PATH (at least one of):                                      ║
║                                                                               ║
║      OPTION A - DIFFERENT METHOD:                                             ║
║        □ Solve using alternative formula/approach                             ║
║        □ Compare results (should match within precision)                      ║
║                                                                               ║
║      OPTION B - INVERSE CHECK:                                                ║
║        □ Use result to compute back to given                                  ║
║        □ Example: If found x from y=f(x), verify y = f(calculated_x)          ║
║                                                                               ║
║      OPTION C - SPECIAL CASE:                                                 ║
║        □ Substitute simple values where answer is known                       ║
║        □ Verify formula gives correct known result                            ║
║                                                                               ║
║      OPTION D - LIMITING BEHAVIOR:                                            ║
║        □ Check behavior as variable → 0 or → ∞                               ║
║        □ Should match physical/mathematical intuition                         ║
║                                                                               ║
║  3.4 COMPUTATIONAL VERIFICATION (if numerical)                                ║
║      □ Compute using independent tool/method                                  ║
║      □ Compare to hand calculation                                            ║
║      □ Agreement within expected precision?                                   ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 4: UNCERTAINTY QUANTIFICATION                                          ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  4.1 INPUT UNCERTAINTY                                                        ║
║      For each input with uncertainty:                                         ║
║        xᵢ = value ± δxᵢ                                                       ║
║                                                                               ║
║  4.2 PROPAGATION                                                              ║
║      For f(x₁, x₂, ...):                                                     ║
║        δf = √[Σᵢ (∂f/∂xᵢ)² × (δxᵢ)²]   (independent errors)                 ║
║                                                                               ║
║      OR Monte Carlo:                                                          ║
║        Sample inputs N times → compute distribution of f                      ║
║                                                                               ║
║  4.3 REPORT FORMAT                                                            ║
║      Result: value ± uncertainty [units] (confidence level)                   ║
║      Example: 42.3 ± 0.5 m/s (95% CI)                                         ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 5: OUTPUT FORMAT                                                       ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║                                                                               ║
║  PROBLEM: [Restate problem]                                                   ║
║                                                                               ║
║  GIVEN:                                                                       ║
║    • x₁ = value₁ [units₁]                                                    ║
║    • x₂ = value₂ [units₂]                                                    ║
║                                                                               ║
║  FIND: [target] [units]                                                       ║
║                                                                               ║
║  ESTIMATE: ~[order of magnitude] [units]                                      ║
║                                                                               ║
║  SOLUTION:                                                                    ║
║    Formula: [formula]  (Source: [citation])                                   ║
║    Substituting: [with values]                                                ║
║    Step 1: ... = ...                                                          ║
║    Step 2: ... = ...                                                          ║
║    ...                                                                        ║
║    Result: [value] [units]                                                    ║
║                                                                               ║
║  VERIFICATION:                                                                ║
║    □ Units: ✓                                                                ║
║    □ Magnitude: ✓ (within estimate)                                         ║
║    □ Alternative path: [method] → [same result] ✓                           ║
║                                                                               ║
║  FINAL ANSWER: value ± uncertainty [units]                                    ║
║  CONFIDENCE: [X]% (based on verification depth)                               ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

## 3.3 CALCULATION QUALITY SCORE

```
Μ(x) = (setup × execution × verification × uncertainty)^(1/4)

Where:
  setup = {
    1.0  if all knowns explicit, units clear, formula cited, estimate made
    0.8  if setup mostly complete, minor gaps
    0.5  if some setup present
    0.2  if minimal setup
    0.0  if no setup (jumped to calculation)
  }
  
  execution = {
    1.0  if all steps shown, units tracked, precision maintained
    0.8  if most steps shown, minor gaps
    0.5  if result correct but steps unclear
    0.2  if steps shown but errors present
    0.0  if execution fundamentally wrong
  }
  
  verification = {
    1.0  if dimension + magnitude + alternative path all check
    0.9  if dimension + magnitude check, no alternative
    0.7  if dimension check only
    0.3  if no verification attempted
    0.0  if verification reveals error
  }
  
  uncertainty = {
    1.0  if full propagation with CI
    0.8  if uncertainty estimated reasonably
    0.5  if uncertainty mentioned but not quantified
    0.2  if point estimate only with awareness of limits
    0.0  if false precision claimed
  }

THRESHOLD: Μ(x) ≥ 0.9 for "HIGH RELIABILITY" claim
```

## 3.4 COMMON ERROR PATTERNS

```
ERROR CATALOG FOR CALCULATIONS:
────────────────────────────────────────────────────────────────────────────────

E-CALC-001: Unit mismatch
  SYMPTOM: Nonsensical units in result
  PREVENTION: Track units at every step
  DETECTION: Dimensional analysis

E-CALC-002: Sign error
  SYMPTOM: Result has wrong sign
  PREVENTION: Explicit sign tracking
  DETECTION: Physical reasonableness check

E-CALC-003: Off-by-factor error (×10, ×2π, etc.)
  SYMPTOM: Correct form, wrong magnitude
  PREVENTION: Order-of-magnitude estimate
  DETECTION: Compare to estimate

E-CALC-004: Transcription error
  SYMPTOM: Random wrong digit
  PREVENTION: Double-check substitutions
  DETECTION: Alternative calculation path

E-CALC-005: Order of operations
  SYMPTOM: Subtle wrong value
  PREVENTION: Explicit parentheses
  DETECTION: Step-by-step verification

E-CALC-006: Rounding too early
  SYMPTOM: Accumulated error
  PREVENTION: Carry full precision
  DETECTION: Compare to high-precision calculation

E-CALC-007: Domain violation
  SYMPTOM: undefined/NaN/error
  PREVENTION: Check domains before operations
  DETECTION: Range checking

E-CALC-008: Formula misapplication
  SYMPTOM: Wrong formula for context
  PREVENTION: Verify assumptions
  DETECTION: Special case testing
```

# ═══════════════════════════════════════════════════════════════════════════════
# PROTOCOL 4: VERIFIED FACTUAL CLAIMS - Φ(x)
# ═══════════════════════════════════════════════════════════════════════════════

## 4.1 SCOPE

Applies to: Any assertion about the real world, historical facts, scientific 
consensus, statistics, current events, or anything verifiable.

## 4.2 THE COMPLETE VERIFICATION PROTOCOL

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    VERIFIED FACTUAL CLAIMS PROTOCOL - Φ(x)                    ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  PHASE 1: CLAIM CLASSIFICATION                                                ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  1.1 IDENTIFY CLAIM TYPE                                                      ║
║      □ EMPIRICAL: Observable/measurable (e.g., "Water boils at 100°C")       ║
║      □ HISTORICAL: Past events (e.g., "WWII ended in 1945")                  ║
║      □ STATISTICAL: Data-based (e.g., "30% of X do Y")                       ║
║      □ DEFINITIONAL: By definition (e.g., "A prime has exactly 2 factors")   ║
║      □ CONSENSUS: Expert agreement (e.g., "Climate change is human-caused")  ║
║      □ CURRENT: Present state (e.g., "Biden is president")                   ║
║                                                                               ║
║  1.2 DETERMINE VERIFIABILITY                                                  ║
║      VERIFIABLE:                                                              ║
║        □ Specific enough to check                                             ║
║        □ Has objective truth value                                            ║
║        □ Sources exist to confirm/deny                                        ║
║                                                                               ║
║      NOT DIRECTLY VERIFIABLE:                                                 ║
║        □ Opinions presented as facts                                          ║
║        □ Predictions about future                                             ║
║        □ Vague claims ("many people say...")                                 ║
║        → REFRAME or QUALIFY before proceeding                                ║
║                                                                               ║
║  1.3 ASSESS PRIOR CONFIDENCE                                                  ║
║      Before searching, estimate:                                              ║
║        P(claim is true) = [0-100%]                                           ║
║        Basis: [training data / common knowledge / no idea]                    ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 2: SOURCE GATHERING                                                    ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  2.1 SOURCE HIERARCHY (prefer higher)                                         ║
║                                                                               ║
║      TIER 1 - PRIMARY SOURCES:                                                ║
║        □ Original research papers (peer-reviewed)                             ║
║        □ Official government data/statistics                                  ║
║        □ Primary documents (laws, treaties, speeches)                         ║
║        □ Direct observation/measurement data                                  ║
║                                                                               ║
║      TIER 2 - AUTHORITATIVE SECONDARY:                                        ║
║        □ Systematic reviews / meta-analyses                                   ║
║        □ Reputable encyclopedias (Britannica, Stanford Encyclopedia)          ║
║        □ Major news organizations (for current events)                        ║
║        □ Textbooks from recognized publishers                                 ║
║                                                                               ║
║      TIER 3 - GENERAL SECONDARY:                                              ║
║        □ Wikipedia (check citations)                                          ║
║        □ News aggregators                                                     ║
║        □ Industry publications                                                ║
║                                                                               ║
║      TIER 4 - USE WITH CAUTION:                                               ║
║        □ Blogs, opinion pieces                                                ║
║        □ Social media                                                         ║
║        □ Partisan sources                                                     ║
║        □ Self-published material                                              ║
║                                                                               ║
║  2.2 TRIANGULATION REQUIREMENT                                                ║
║      MINIMUM for high confidence:                                             ║
║        □ 3+ independent sources                                               ║
║        □ At least 2 from Tier 1-2                                            ║
║        □ Sources don't cite each other circularly                             ║
║                                                                               ║
║  2.3 SOURCE DOCUMENTATION                                                     ║
║      For each source, record:                                                 ║
║        □ Citation (author, date, title, URL)                                  ║
║        □ Source tier                                                          ║
║        □ What claim does it support/contradict?                               ║
║        □ Any potential bias?                                                  ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 3: EVIDENCE EVALUATION                                                 ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  3.1 CONSISTENCY CHECK                                                        ║
║      □ Do sources agree on core claim?                                        ║
║      □ If disagreement: What's the nature? (error, nuance, controversy)       ║
║      □ Weigh by source quality                                                ║
║                                                                               ║
║  3.2 RECENCY CHECK                                                            ║
║      □ Is information current enough?                                         ║
║      □ For fast-changing topics: Require recent sources                       ║
║      □ For historical: Older authoritative may be better                      ║
║                                                                               ║
║  3.3 BIAS CHECK                                                               ║
║      For each source ask:                                                     ║
║        □ Who created this? What's their interest?                             ║
║        □ Who funded the research?                                             ║
║        □ Is language neutral or loaded?                                       ║
║        □ Are contrary views acknowledged?                                     ║
║                                                                               ║
║  3.4 METHODOLOGY CHECK (for studies/statistics)                               ║
║      □ Sample size adequate?                                                  ║
║      □ Methodology appropriate?                                               ║
║      □ Results replicated?                                                    ║
║      □ Statistical significance vs. practical significance?                   ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 4: CONFIDENCE CALIBRATION                                              ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║  4.1 UPDATE BELIEF (Bayesian)                                                 ║
║      P(true | evidence) = P(evidence | true) × P(true) / P(evidence)         ║
║                                                                               ║
║      Practical calibration:                                                   ║
║      ┌─────────────────────────────────────────────────────────────────────┐ ║
║      │ Evidence Pattern                              │ Confidence Range    │ ║
║      ├─────────────────────────────────────────────────────────────────────┤ ║
║      │ 3+ Tier 1 sources agree                       │ 95-99%              │ ║
║      │ 2 Tier 1 + 1 Tier 2 agree                     │ 90-95%              │ ║
║      │ Multiple Tier 2 sources agree                 │ 80-90%              │ ║
║      │ Mixed agreement with some dissent             │ 60-80%              │ ║
║      │ Conflicting sources, unclear                  │ 40-60%              │ ║
║      │ Mostly contrary evidence                      │ 10-40%              │ ║
║      │ Strong contrary evidence                      │ 1-10%               │ ║
║      └─────────────────────────────────────────────────────────────────────┘ ║
║                                                                               ║
║  4.2 CONFIDENCE ADJUSTMENTS                                                   ║
║      DECREASE confidence if:                                                  ║
║        □ Claim is extraordinary                                               ║
║        □ Sources might share common bias                                      ║
║        □ Topic is highly politicized                                          ║
║        □ Information is very recent (may change)                              ║
║        □ No primary sources available                                         ║
║                                                                               ║
║      INCREASE confidence if:                                                  ║
║        □ Claim matches physical laws                                          ║
║        □ Multiple independent methodologies agree                             ║
║        □ Long-standing consensus                                              ║
║        □ Prediction has been validated                                        ║
║                                                                               ║
║  ═════════════════════════════════════════════════════════════════════════    ║
║                                                                               ║
║  PHASE 5: OUTPUT FORMAT                                                       ║
║  ─────────────────────────────────────────────────────────────────────────    ║
║                                                                               ║
║  CLAIM: [Precise statement of claim]                                          ║
║                                                                               ║
║  VERDICT: TRUE / FALSE / PARTIALLY TRUE / UNCERTAIN / UNVERIFIABLE           ║
║                                                                               ║
║  CONFIDENCE: [X]%                                                             ║
║                                                                               ║
║  EVIDENCE SUMMARY:                                                            ║
║    SUPPORTING:                                                                ║
║      • [Source 1] - [What it says] (Tier X)                                  ║
║      • [Source 2] - [What it says] (Tier X)                                  ║
║    CONTRADICTING:                                                             ║
║      • [Source 3] - [What it says] (Tier X)                                  ║
║    NUANCING:                                                                  ║
║      • [Context that affects interpretation]                                  ║
║                                                                               ║
║  CAVEATS:                                                                     ║
║    • [Any important qualifications]                                           ║
║    • [Conditions under which claim may not hold]                              ║
║                                                                               ║
║  SOURCES:                                                                     ║
║    [1] Full citation                                                          ║
║    [2] Full citation                                                          ║
║    ...                                                                        ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

## 4.3 FACTUAL CLAIM QUALITY SCORE

```
Φ(x) = (classification × sourcing × evaluation × calibration)^(1/4)

Where:
  classification = {
    1.0  if claim type identified, verifiability assessed, prior stated
    0.8  if claim type identified, some assessment
    0.5  if minimal classification
    0.2  if jumped to verification without setup
    0.0  if unverifiable claim treated as verifiable
  }
  
  sourcing = {
    1.0  if 3+ independent sources, 2+ Tier 1-2, documented
    0.8  if 2-3 sources, at least 1 Tier 1-2
    0.5  if sources found but quality issues
    0.2  if single source or all Tier 3-4
    0.0  if no sources or circular sourcing
  }
  
  evaluation = {
    1.0  if consistency, recency, bias, methodology all checked
    0.8  if most checks performed
    0.5  if basic consistency check only
    0.2  if sources listed but not evaluated
    0.0  if no evaluation
  }
  
  calibration = {
    1.0  if confidence matches evidence strength, adjustments applied
    0.8  if reasonable confidence estimate
    0.5  if confidence stated but potentially miscalibrated
    0.2  if overconfident or underconfident
    0.0  if false certainty claimed
  }

THRESHOLD: Φ(x) ≥ 0.85 for "HIGH RELIABILITY" claim
NOTE: Inherently lower than other protocols due to real-world uncertainty
```

## 4.4 SPECIAL CASES

```
RAPIDLY CHANGING INFORMATION:
────────────────────────────────────────────────────────────────────────────────
□ Use web_search for anything current
□ Note timestamp of verification
□ Qualify with "As of [date]"
□ Flag that information may have changed


CONTROVERSIAL TOPICS:
────────────────────────────────────────────────────────────────────────────────
□ Present range of credible views
□ Identify where consensus exists (if any)
□ Distinguish empirical claims from value judgments
□ Higher sourcing requirements (4+ independent)
□ Explicitly note political/ideological dimensions


STATISTICAL CLAIMS:
────────────────────────────────────────────────────────────────────────────────
□ Require primary data source
□ Check methodology and sample
□ Note confidence intervals
□ Distinguish correlation from causation
□ Check for cherry-picking or p-hacking


CLAIMS ABOUT LIVING PERSONS:
────────────────────────────────────────────────────────────────────────────────
□ Higher verification standard
□ Recent sources required
□ Consider defamation implications
□ Stick to verifiable public facts
```

# ═══════════════════════════════════════════════════════════════════════════════
# INTEGRATION WITH EXISTING PRISM SKILLS
# ═══════════════════════════════════════════════════════════════════════════════

## SKILL INTEGRATION MAP

```
THIS SKILL (prism-high-reliability-protocols)
    │
    ├── USES → prism-reasoning-engine
    │          • R(x) metrics for quality assessment
    │          • Confidence calibration framework
    │          • Evidence level standards (L1-L5)
    │
    ├── USES → prism-universal-formulas
    │          • Domain 14 (Formal Logic) for Λ(x)
    │          • Domain 2 (Probability) for Bayesian updates in Φ(x)
    │          • Uncertainty propagation for Μ(x)
    │
    ├── USES → prism-cognitive-core
    │          • BAYES-001/002/003 hooks for belief updates
    │          • OPT-001/002/003 for solution optimization
    │          • REFL-001/002/003 for quality assessment
    │
    ├── USES → prism-sp-verification
    │          • Evidence level framework for all protocols
    │          • Verification checklist patterns
    │
    └── USES → prism-code-perfection (for Κ(x) only)
             • C(x) metrics for code quality
             • 11 code quality dimensions
```

## HOOK INTEGRATION

```
HOOKS ACTIVATED BY THIS SKILL:
────────────────────────────────────────────────────────────────────────────────

ON PROTOCOL START:
  → BAYES-001 (initialize priors based on problem type)
  → OPT-001 (set objective: maximize protocol quality score)

ON EVIDENCE RECEIVED:
  → BAYES-002 (update beliefs with new evidence)
  → ANOM-002 (flag if evidence contradicts expectations)

ON VERIFICATION STEP:
  → REFL-001 (assess quality of completed work)
  → CAUSAL-003 (trace errors to root causes if verification fails)

ON PROTOCOL COMPLETE:
  → BAYES-003 (compute final posterior confidence)
  → RL-002 (record outcome for learning)
```

## COMBINED QUALITY EQUATION

```
For tasks involving multiple protocols, compute combined quality:

Ω_combined = min(Ω_safety) × Π(protocol_scores)^(1/n)

Where:
  Ω_safety = Safety constraint from prism-safety-framework (HARD GATE)
  protocol_scores = {Λ(x), Κ(x), Μ(x), Φ(x)} as applicable
  n = number of protocols used

Example: Code that includes calculations from verified data
  Ω_combined = S(x) × (Κ(x) × Μ(x) × Φ(x))^(1/3)
```

# ═══════════════════════════════════════════════════════════════════════════════
# VERSION HISTORY
# ═══════════════════════════════════════════════════════════════════════════════

v1.0.0 (2026-02-04)
  • Initial creation
  • Four protocols: Λ(x), Κ(x), Μ(x), Φ(x)
  • Integration with existing PRISM skills
  • Quality scores for each protocol

# END OF SKILL
