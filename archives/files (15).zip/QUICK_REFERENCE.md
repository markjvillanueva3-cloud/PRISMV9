# HIGH-RELIABILITY PROTOCOLS - QUICK REFERENCE CARD

## When to Use Each Protocol

| See this pattern? | Use Protocol |
|-------------------|--------------|
| "Prove that...", "Show logically...", "Derive..." | **Λ(x) FORMAL LOGIC** |
| "Write code...", "Build a function...", "Script to..." | **Κ(x) COMPILABLE CODE** |
| "Calculate...", "What is the value of...", "Solve for..." | **Μ(x) MATHEMATICAL** |
| "Is it true that...", "What's the status of...", "Verify..." | **Φ(x) FACTUAL CLAIMS** |

---

## Λ(x) FORMAL LOGIC PROOFS - The 5 Phases

```
┌────────────────────────────────────────────────────────────────┐
│ 1. FORMALIZE      → Translate to formal notation               │
│ 2. SELECT STRATEGY → Match goal structure to proof technique   │
│ 3. CONSTRUCT      → Line-by-line with rule citations           │
│ 4. VERIFY         → Syntactic + Semantic + Alternative path    │
│ 5. OUTPUT         → Table format with QED                      │
└────────────────────────────────────────────────────────────────┘

KEY RULE: Every step needs explicit justification + line references

GOAL STRUCTURE → STRATEGY:
  A → B     → Conditional Proof (assume A, derive B)
  A ∧ B     → Prove A and B separately
  A ∨ B     → Prove either A or B
  ¬A        → Assume A, derive contradiction
  ∀x.P(x)  → Let x be arbitrary, prove P(x)
  ∃x.P(x)  → Find witness c, prove P(c)
```

---

## Κ(x) COMPILABLE CODE - The 6 Phases

```
┌────────────────────────────────────────────────────────────────┐
│ 1. SPECIFICATION  → Extract requirements, write tests FIRST   │
│ 2. DESIGN         → Algorithm + data structure + decomposition │
│ 3. IMPLEMENTATION → Write in layers, follow standards          │
│ 4. STATIC VERIFY  → Syntax + Types + Lint + Analysis           │
│ 5. DYNAMIC VERIFY → Run tests, trace execution, boundary test  │
│ 6. ITERATE        → Fix failures, max 5 attempts before redesign│
└────────────────────────────────────────────────────────────────┘

HARD GATES (must pass):
  □ Code compiles/parses
  □ All tests pass
  
WRITE TESTS BEFORE CODE covering:
  □ Happy path
  □ Edge cases (empty, single, max)
  □ Boundary values (0, 1, -1, MAX_INT)
  □ Error cases (null, invalid)
```

---

## Μ(x) MATHEMATICAL CALCULATIONS - The 5 Phases

```
┌────────────────────────────────────────────────────────────────┐
│ 1. SETUP          → List knowns/unknowns, units, estimate first│
│ 2. PRIMARY PATH   → Show all steps, track units, cite formula  │
│ 3. VERIFICATION   → Dimension + Magnitude + Alternative path   │
│ 4. UNCERTAINTY    → Propagate errors, report with CI           │
│ 5. OUTPUT         → Given → Find → Solution → Verified Answer │
└────────────────────────────────────────────────────────────────┘

MANDATORY VERIFICATION (at least one):
  □ Different method → same answer
  □ Inverse check (plug result back)
  □ Special case (known answer)
  □ Limiting behavior (0 or ∞)

ESTIMATE FIRST: If answer outside estimate range → INVESTIGATE

FINAL ANSWER FORMAT: value ± uncertainty [units] (confidence)
```

---

## Φ(x) FACTUAL CLAIMS - The 5 Phases

```
┌────────────────────────────────────────────────────────────────┐
│ 1. CLASSIFY       → Claim type + verifiability + prior belief  │
│ 2. SOURCE         → 3+ independent, 2+ Tier 1-2, triangulate   │
│ 3. EVALUATE       → Consistency + Recency + Bias + Methodology │
│ 4. CALIBRATE      → Update belief Bayesian-style               │
│ 5. OUTPUT         → Verdict + Confidence + Evidence + Caveats  │
└────────────────────────────────────────────────────────────────┘

SOURCE TIER HIERARCHY:
  Tier 1: Primary (peer-reviewed, official data, original docs)
  Tier 2: Authoritative secondary (reviews, encyclopedias, major news)
  Tier 3: General secondary (Wikipedia, aggregators)
  Tier 4: Use with caution (blogs, social media, partisan)

MINIMUM FOR HIGH CONFIDENCE:
  □ 3+ independent sources
  □ At least 2 from Tier 1-2
  □ No circular citing
```

---

## Quality Score Thresholds

| Protocol | Formula | Threshold for "High Reliability" |
|----------|---------|----------------------------------|
| Λ(x) Logic | (formalization × strategy × construction × verification)^(1/4) | ≥ 0.90 |
| Κ(x) Code | min(compiles, tests_pass) × (design × implementation × verification)^(1/3) | ≥ 0.95 |
| Μ(x) Math | (setup × execution × verification × uncertainty)^(1/4) | ≥ 0.90 |
| Φ(x) Facts | (classification × sourcing × evaluation × calibration)^(1/4) | ≥ 0.85 |

---

## Integration with Existing PRISM Skills

```
This skill (high-reliability-protocols)
    ├── USES → prism-reasoning-engine (R(x) metrics, confidence)
    ├── USES → prism-universal-formulas (logic, probability, uncertainty)
    ├── USES → prism-cognitive-core (Bayesian hooks, reflection)
    ├── USES → prism-sp-verification (evidence levels L1-L5)
    └── USES → prism-code-perfection (C(x) metrics for code)
```

---

## Universal Principles Across All Protocols

1. **NEVER skip verification** — Every protocol has mandatory verification
2. **Quantify uncertainty** — Point estimates without bounds are incomplete
3. **Show your work** — Every step traceable and justified
4. **Multiple paths** — Cross-check via alternative methods
5. **Fail fast** — Catch errors early, don't propagate

---

*v1.0.0 | Integrates with PRISM Cognitive Framework*
