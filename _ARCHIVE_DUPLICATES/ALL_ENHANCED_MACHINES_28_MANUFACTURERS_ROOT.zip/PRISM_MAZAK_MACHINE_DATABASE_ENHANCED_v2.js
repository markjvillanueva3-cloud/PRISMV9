/**
 * PRISM_MAZAK_MACHINE_DATABASE_ENHANCED_v2.js
 * LEVEL 4 ENHANCED - Full Kinematics + Collision Ready
 * 
 * Mazak (Yamazaki Mazak Corporation) is one of the world's largest machine tool
 * builders, headquartered in Japan with major production in Japan, USA, UK, Singapore.
 * Famous for Integrex mill-turn, Variaxis 5-axis, and SMOOTH CNC control.
 * 
 * @version 2.0.0
 * @created 2026-01-20
 * @session 0.EXT.2f.9
 */

const PRISM_MAZAK_MACHINE_DATABASE_ENHANCED = {
    metadata: {
        manufacturer: "Mazak",
        full_name: "Yamazaki Mazak Corporation",
        country: "Japan",
        founded: 1919,
        headquarters: "Oguchi, Aichi, Japan",
        facilities: ["Japan", "USA (Kentucky)", "UK", "Singapore", "China"],
        specialty: "Multi-tasking, 5-axis, turning centers, horizontal machining",
        controller: "MAZATROL SmoothAi / SmoothG / SmoothX",
        website: "https://www.mazak.com",
        version: "2.0.0-LEVEL4-ENHANCED",
        last_updated: "2026-01-20",
        machine_count: 16,
        enhancement_level: 4
    },

    machines: [
        // ============================================
        // INTEGREX MULTI-TASKING SERIES
        // ============================================
        {
            id: "MAZAK_INTEGREX_I_200S",
            manufacturer: "Mazak",
            model: "INTEGREX i-200S",
            type: "mill_turn_center",
            subtype: "5_axis_mill_turn",
            description: "Multi-tasking machine with milling spindle and B-axis",
            series: "INTEGREX i",
            
            work_envelope: {
                max_turning_diameter: 660,
                max_turning_length: 1519,
                max_bar_capacity: 80,
                milling_spindle_travel_x: 630,
                milling_spindle_travel_y: { min: -160, max: 160 },
                milling_spindle_travel_z: 1569,
                unit: "mm"
            },
            
            main_spindle: {
                type: "built_in_motor",
                chuck_size: 10,
                chuck_size_unit: "inch",
                bore_diameter: 91,
                max_rpm: 4000,
                power_rating: 30,
                power_unit: "kW",
                torque_max: 795,
                torque_unit: "Nm",
                c_axis: true,
                c_axis_resolution: 0.0001,
                spindle_nose: "A2-8"
            },
            
            sub_spindle: {
                type: "built_in_motor",
                chuck_size: 8,
                chuck_size_unit: "inch",
                max_rpm: 5000,
                power_rating: 22,
                power_unit: "kW",
                c_axis: true,
                travel_w2: 1569
            },
            
            milling_spindle: {
                type: "built_in_motor",
                taper: "Capto_C6",
                alternate_taper: "HSK-A63",
                max_rpm: 12000,
                power_rating: 22,
                power_unit: "kW",
                torque_max: 119,
                torque_unit: "Nm",
                b_axis: true,
                b_axis_travel: { min: -30, max: 210 },
                b_axis_indexing: 0.0001
            },
            
            axis_specs: {
                x: {
                    travel: 630,
                    rapid_rate: 40000,
                    max_feed: 40000,
                    acceleration: 0.6,
                    acceleration_unit: "g",
                    guideway_type: "linear_roller",
                    guideway_size: 45,
                    ballscrew_diameter: 50,
                    encoder_type: "absolute",
                    positioning_accuracy: 0.004,
                    repeatability: 0.002
                },
                y: {
                    travel: { min: -160, max: 160 },
                    total_travel: 320,
                    rapid_rate: 40000,
                    max_feed: 40000,
                    acceleration: 0.6,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.004,
                    repeatability: 0.002
                },
                z: {
                    travel: 1569,
                    rapid_rate: 40000,
                    max_feed: 40000,
                    acceleration: 0.5,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.006,
                    repeatability: 0.003
                },
                b: {
                    type: "milling_spindle_tilt",
                    travel: { min: -30, max: 210 },
                    rapid_rate: 100,
                    rapid_rate_unit: "rpm",
                    max_torque: 350,
                    clamping_torque: 700,
                    drive_type: "direct_drive",
                    indexing: 0.0001,
                    positioning_accuracy: 0.001
                },
                c1: {
                    type: "main_spindle_c",
                    continuous: true,
                    indexing: 0.0001,
                    max_rpm_positioning: 100,
                    clamping_torque: 450
                },
                c2: {
                    type: "sub_spindle_c",
                    continuous: true,
                    indexing: 0.0001,
                    max_rpm_positioning: 100
                },
                w2: {
                    type: "sub_spindle_travel",
                    travel: 1569,
                    rapid_rate: 40000
                }
            },
            
            turret: {
                lower_turret: {
                    type: "drum_turret",
                    stations: 12,
                    tool_size: "25mm_square",
                    live_tooling: true,
                    live_tool_rpm: 6000,
                    live_tool_power: 5.5,
                    indexing_time: 0.3
                }
            },
            
            atc: {
                type: "chain_magazine",
                capacity: 36,
                capacity_options: [36, 72, 110],
                max_tool_diameter: 100,
                max_tool_length: 400,
                max_tool_weight: 12,
                tool_change_time: 1.6
            },
            
            controller: {
                brand: "MAZAK",
                model: "MAZATROL SmoothAi",
                type: "conversational_and_EIA",
                axes_count: 9,
                simultaneous_axes: 5,
                
                ai_features: {
                    ai_thermal_shield: true,
                    ai_spindle_monitor: true,
                    cutting_advisor: true,
                    voice_advisor: true
                },
                
                multi_tasking: {
                    done_in_one: true,
                    turning_milling_sync: true,
                    superimposed_machining: true,
                    balance_cutting: true
                },
                
                tcpc: true,
                rtcp: true
            },
            
            machine_dimensions: {
                length: 6465,
                width: 2770,
                height: 3010,
                weight: 19500,
                weight_unit: "kg"
            },
            
            kinematic_chain: {
                type: "mill_turn_dual_spindle",
                structure: "integrex_B_axis_milling",
                chain: [
                    "bed",
                    "main_headstock_C1",
                    "cross_slide_X",
                    "y_slide_Y",
                    "milling_carriage_Z",
                    "b_axis_head_B",
                    "milling_spindle",
                    "lower_turret",
                    "sub_headstock_C2_W2"
                ],
                
                moving_masses: {
                    x_assembly: { mass: 1200, cog: [0, 0, 200] },
                    y_assembly: { mass: 800, cog: [0, 0, 150] },
                    z_assembly: { mass: 1500, cog: [0, 0, 300] },
                    b_head: { mass: 350, cog: [0, 100, 0] },
                    sub_spindle: { mass: 900, cog: [0, 0, 100] }
                }
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "cross_slide" },
                y: { type: "translation", vector: [0, 1, 0], component: "y_slide" },
                z: { type: "translation", vector: [0, 0, 1], component: "milling_carriage" },
                b: { type: "rotation", axis: [0, 1, 0], center: [0, 0, 0], component: "b_axis_head" },
                c1: { type: "rotation", axis: [0, 0, 1], component: "main_spindle" },
                c2: { type: "rotation", axis: [0, 0, 1], component: "sub_spindle" },
                w2: { type: "translation", vector: [0, 0, 1], component: "sub_headstock" }
            },
            
            geometry_reference: {
                base_path: "MAZAK/INTEGREX_I_200S",
                assembly: { file: "ASSEMBLY/INTEGREX_I_200S_COMPLETE.step" },
                components: {
                    bed: { step_file: "COMPONENTS/BED.step", is_fixed: true, mass: 12000 },
                    main_headstock: { step_file: "COMPONENTS/MAIN_HEADSTOCK.step", parent: "bed", joint_type: "fixed" },
                    cross_slide: { step_file: "COMPONENTS/CROSS_SLIDE.step", parent: "bed", joint_type: "prismatic", joint_axis: "X" },
                    y_slide: { step_file: "COMPONENTS/Y_SLIDE.step", parent: "cross_slide", joint_type: "prismatic", joint_axis: "Y" },
                    milling_carriage: { step_file: "COMPONENTS/MILLING_CARRIAGE.step", parent: "y_slide", joint_type: "prismatic", joint_axis: "Z" },
                    b_axis_head: { step_file: "COMPONENTS/B_AXIS_HEAD.step", parent: "milling_carriage", joint_type: "revolute", joint_axis: "B" },
                    milling_spindle: { step_file: "COMPONENTS/MILLING_SPINDLE.step", parent: "b_axis_head", joint_type: "revolute" },
                    sub_headstock: { step_file: "COMPONENTS/SUB_HEADSTOCK.step", parent: "bed", joint_type: "prismatic", joint_axis: "W2" }
                },
                collision_config: {
                    check_pairs: [
                        ["milling_spindle", "main_headstock"],
                        ["milling_spindle", "sub_headstock"],
                        ["b_axis_head", "workpiece"],
                        ["tool", "chuck"]
                    ],
                    safety_margin: 3.0
                }
            }
        },
        
        {
            id: "MAZAK_INTEGREX_I_400S",
            manufacturer: "Mazak",
            model: "INTEGREX i-400S",
            type: "mill_turn_center",
            subtype: "5_axis_mill_turn_large",
            description: "Large multi-tasking machine for heavy-duty work",
            series: "INTEGREX i",
            
            work_envelope: {
                max_turning_diameter: 730,
                max_turning_length: 2060,
                max_bar_capacity: 102,
                unit: "mm"
            },
            
            main_spindle: {
                type: "built_in_motor",
                chuck_size: 15,
                chuck_size_unit: "inch",
                bore_diameter: 112,
                max_rpm: 3300,
                power_rating: 37,
                power_unit: "kW",
                torque_max: 1493,
                torque_unit: "Nm",
                c_axis: true
            },
            
            milling_spindle: {
                type: "built_in_motor",
                taper: "Capto_C6",
                max_rpm: 12000,
                power_rating: 30,
                power_unit: "kW",
                torque_max: 191,
                b_axis: true,
                b_axis_travel: { min: -30, max: 210 }
            },
            
            axis_specs: {
                x: { travel: 755, rapid_rate: 36000, positioning_accuracy: 0.005 },
                y: { travel: { min: -180, max: 180 }, rapid_rate: 36000, positioning_accuracy: 0.005 },
                z: { travel: 2110, rapid_rate: 36000, positioning_accuracy: 0.006 },
                b: { travel: { min: -30, max: 210 }, drive_type: "direct_drive", positioning_accuracy: 0.001 },
                c1: { continuous: true, indexing: 0.0001 },
                c2: { continuous: true, indexing: 0.0001 }
            },
            
            controller: {
                brand: "MAZAK",
                model: "MAZATROL SmoothAi",
                axes_count: 9,
                tcpc: true
            },
            
            machine_dimensions: {
                length: 7675,
                width: 3310,
                height: 3350,
                weight: 28000,
                weight_unit: "kg"
            },
            
            kinematic_chain: {
                type: "mill_turn_dual_spindle",
                structure: "integrex_large_format",
                chain: ["bed", "main_headstock_C1", "cross_slide_X", "y_slide_Y", "milling_carriage_Z", "b_axis_head_B", "sub_headstock_C2_W2"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "cross_slide" },
                y: { type: "translation", vector: [0, 1, 0], component: "y_slide" },
                z: { type: "translation", vector: [0, 0, 1], component: "milling_carriage" },
                b: { type: "rotation", axis: [0, 1, 0], component: "b_axis_head" },
                c1: { type: "rotation", axis: [0, 0, 1], component: "main_spindle" },
                c2: { type: "rotation", axis: [0, 0, 1], component: "sub_spindle" }
            }
        },

        // ============================================
        // VARIAXIS 5-AXIS SERIES
        // ============================================
        {
            id: "MAZAK_VARIAXIS_I_700",
            manufacturer: "Mazak",
            model: "VARIAXIS i-700",
            type: "vertical_machining_center",
            subtype: "5_axis_trunnion",
            description: "5-axis VMC with tilting rotary table",
            series: "VARIAXIS i",
            
            work_envelope: {
                x: { min: 0, max: 730, unit: "mm" },
                y: { min: 0, max: 750, unit: "mm" },
                z: { min: 0, max: 660, unit: "mm" },
                a_axis: { min: -120, max: 30, unit: "deg" },
                c_axis: { min: -360, max: 360, continuous: true, unit: "deg" },
                table_diameter: 630,
                max_workpiece_diameter: 730,
                max_workpiece_height: 500,
                table_load_capacity: 500,
                table_load_unit: "kg"
            },
            
            spindle: {
                type: "built_in_motor",
                taper: "HSK-A63",
                max_rpm: 12000,
                power_rating: 30,
                power_unit: "kW",
                torque_max: 286,
                torque_unit: "Nm",
                cooling: "jacket_cooling",
                bearing_lubrication: "oil_air"
            },
            
            spindle_options: [
                { name: "Standard", rpm: 12000, power: 30, torque: 286 },
                { name: "High-speed", rpm: 18000, power: 30, torque: 143 }
            ],
            
            axis_specs: {
                x: {
                    travel: 730,
                    rapid_rate: 42000,
                    max_feed: 42000,
                    acceleration: 0.5,
                    acceleration_unit: "g",
                    guideway_type: "linear_roller",
                    guideway_size: 45,
                    positioning_accuracy: 0.005,
                    repeatability: 0.002
                },
                y: {
                    travel: 750,
                    rapid_rate: 42000,
                    max_feed: 42000,
                    acceleration: 0.5,
                    guideway_type: "linear_roller",
                    guideway_size: 55,
                    positioning_accuracy: 0.005,
                    repeatability: 0.002
                },
                z: {
                    travel: 660,
                    rapid_rate: 42000,
                    max_feed: 42000,
                    acceleration: 0.4,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.005,
                    repeatability: 0.002
                },
                a: {
                    type: "tilting_trunnion",
                    travel: { min: -120, max: 30 },
                    rapid_rate: 25,
                    rapid_rate_unit: "rpm",
                    max_torque: 2500,
                    clamping_torque: 5000,
                    drive_type: "roller_gear_cam",
                    drive_brand: "Mazak",
                    positioning_accuracy: 0.001,
                    repeatability: 0.0005,
                    rotation_center_height: 250
                },
                c: {
                    type: "rotary_table",
                    continuous: true,
                    rapid_rate: 90,
                    rapid_rate_unit: "rpm",
                    max_torque: 1200,
                    clamping_torque: 2400,
                    drive_type: "roller_gear_cam",
                    positioning_accuracy: 0.001,
                    repeatability: 0.0005
                }
            },
            
            atc: {
                type: "chain_magazine",
                capacity: 30,
                capacity_options: [30, 60, 90, 120],
                max_tool_diameter: 100,
                max_tool_diameter_adjacent_empty: 200,
                max_tool_length: 400,
                max_tool_weight: 12,
                tool_change_time: 2.5,
                chip_to_chip_time: 4.5
            },
            
            controller: {
                brand: "MAZAK",
                model: "MAZATROL SmoothX",
                axes_count: 5,
                simultaneous_axes: 5,
                tcpc: true,
                tcpc_name: "Tilt-Tool-Center-Point",
                rtcp: true,
                
                smooth_features: {
                    smooth_corner: true,
                    smooth_ai: true,
                    smooth_machining_configuration: true,
                    servo_optimizer: true
                }
            },
            
            coolant: {
                tank_capacity: 500,
                through_spindle: true,
                tsc_pressure: 70,
                tsc_pressure_unit: "bar",
                flood_coolant: true,
                chip_conveyor: "hinged_belt"
            },
            
            machine_dimensions: {
                length: 3900,
                width: 3630,
                height: 3875,
                weight: 17000,
                weight_unit: "kg"
            },
            
            kinematic_chain: {
                type: "table_table",
                structure: "variaxis_AC_trunnion",
                chain: [
                    "base",
                    "column",
                    "y_saddle",
                    "z_ram",
                    "spindle",
                    "x_table_base",
                    "a_trunnion",
                    "c_table"
                ],
                
                dh_parameters: {
                    y: { a: 0, alpha: 0, d: "variable", theta: 0, type: "P" },
                    z: { a: 0, alpha: 90, d: "variable", theta: 0, type: "P" },
                    x: { a: 0, alpha: 0, d: "variable", theta: 0, type: "P" },
                    a: { a: 0, alpha: 0, d: 250, theta: "variable", type: "R" },
                    c: { a: 0, alpha: 0, d: 0, theta: "variable", type: "R" }
                },
                
                moving_masses: {
                    y_saddle: { mass: 1800, cog: [0, 200, 500] },
                    z_ram: { mass: 1200, cog: [0, 0, 330] },
                    x_table: { mass: 2500, cog: [0, 0, 150] },
                    a_trunnion: { mass: 800, cog: [0, 0, 125] },
                    c_table: { mass: 400, cog: [0, 0, 50] }
                }
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "x_table_base" },
                y: { type: "translation", vector: [0, 1, 0], component: "y_saddle" },
                z: { type: "translation", vector: [0, 0, 1], component: "z_ram" },
                a: { type: "rotation", axis: [1, 0, 0], center: [0, 0, 250], component: "a_trunnion" },
                c: { type: "rotation", axis: [0, 0, 1], center: [0, 0, 0], component: "c_table" }
            },
            
            geometry_reference: {
                base_path: "MAZAK/VARIAXIS_I_700",
                assembly: { file: "ASSEMBLY/VARIAXIS_I_700_COMPLETE.step" },
                components: {
                    base: { step_file: "COMPONENTS/BASE.step", is_fixed: true },
                    column: { step_file: "COMPONENTS/COLUMN.step", parent: "base", joint_type: "fixed" },
                    y_saddle: { step_file: "COMPONENTS/Y_SADDLE.step", parent: "column", joint_type: "prismatic", joint_axis: "Y" },
                    z_ram: { step_file: "COMPONENTS/Z_RAM.step", parent: "y_saddle", joint_type: "prismatic", joint_axis: "Z" },
                    spindle: { step_file: "COMPONENTS/SPINDLE.step", parent: "z_ram", tool_interface: "HSK-A63" },
                    x_table_base: { step_file: "COMPONENTS/X_TABLE_BASE.step", parent: "base", joint_type: "prismatic", joint_axis: "X" },
                    a_trunnion: { step_file: "COMPONENTS/A_TRUNNION.step", parent: "x_table_base", joint_type: "revolute", joint_axis: "A" },
                    c_table: { step_file: "COMPONENTS/C_TABLE.step", parent: "a_trunnion", joint_type: "revolute", joint_axis: "C" }
                },
                collision_config: {
                    check_pairs: [
                        ["spindle", "c_table"], ["spindle", "a_trunnion"],
                        ["z_ram", "c_table"], ["z_ram", "a_trunnion"],
                        ["tool", "workpiece"], ["tool", "fixture"]
                    ],
                    safety_margin: 2.0
                }
            }
        },
        
        {
            id: "MAZAK_VARIAXIS_I_500",
            manufacturer: "Mazak",
            model: "VARIAXIS i-500",
            type: "vertical_machining_center",
            subtype: "5_axis_trunnion",
            description: "Compact 5-axis VMC for precision parts",
            series: "VARIAXIS i",
            
            work_envelope: {
                x: { min: 0, max: 510, unit: "mm" },
                y: { min: 0, max: 510, unit: "mm" },
                z: { min: 0, max: 510, unit: "mm" },
                a_axis: { min: -120, max: 30, unit: "deg" },
                c_axis: { min: -360, max: 360, continuous: true },
                table_diameter: 500,
                table_load_capacity: 300,
                table_load_unit: "kg"
            },
            
            spindle: {
                type: "built_in_motor",
                taper: "HSK-A63",
                max_rpm: 12000,
                power_rating: 25,
                power_unit: "kW",
                torque_max: 200,
                torque_unit: "Nm"
            },
            
            axis_specs: {
                x: { travel: 510, rapid_rate: 42000, positioning_accuracy: 0.005 },
                y: { travel: 510, rapid_rate: 42000, positioning_accuracy: 0.005 },
                z: { travel: 510, rapid_rate: 42000, positioning_accuracy: 0.005 },
                a: { travel: { min: -120, max: 30 }, rapid_rate: 25, drive_type: "roller_gear_cam", positioning_accuracy: 0.001 },
                c: { continuous: true, rapid_rate: 90, drive_type: "roller_gear_cam", positioning_accuracy: 0.001 }
            },
            
            atc: { type: "chain_magazine", capacity: 30, tool_change_time: 2.5 },
            
            controller: { brand: "MAZAK", model: "MAZATROL SmoothX", axes_count: 5, tcpc: true },
            
            machine_dimensions: { length: 3300, width: 3100, height: 3500, weight: 12000, weight_unit: "kg" },
            
            kinematic_chain: {
                type: "table_table",
                structure: "variaxis_AC_trunnion",
                chain: ["base", "column", "y_saddle", "z_ram", "spindle", "x_table_base", "a_trunnion", "c_table"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "x_table_base" },
                y: { type: "translation", vector: [0, 1, 0], component: "y_saddle" },
                z: { type: "translation", vector: [0, 0, 1], component: "z_ram" },
                a: { type: "rotation", axis: [1, 0, 0], center: [0, 0, 200], component: "a_trunnion" },
                c: { type: "rotation", axis: [0, 0, 1], center: [0, 0, 0], component: "c_table" }
            }
        },

        // ============================================
        // VERTICAL CENTER - VCN SERIES
        // ============================================
        {
            id: "MAZAK_VCN_530C",
            manufacturer: "Mazak",
            model: "VCN-530C",
            type: "vertical_machining_center",
            subtype: "3_axis_vmc",
            description: "High-performance 3-axis VMC with thermal shield",
            series: "VCN",
            
            work_envelope: {
                x: { min: 0, max: 1050, unit: "mm" },
                y: { min: 0, max: 530, unit: "mm" },
                z: { min: 0, max: 510, unit: "mm" },
                table_length: 1300,
                table_width: 530,
                table_load_capacity: 900,
                table_load_unit: "kg"
            },
            
            spindle: {
                type: "built_in_motor",
                taper: "BT40",
                max_rpm: 12000,
                power_rating: 18.5,
                power_unit: "kW",
                torque_max: 119,
                torque_unit: "Nm",
                bearing_type: "angular_contact",
                cooling: "jacket_cooling"
            },
            
            axis_specs: {
                x: {
                    travel: 1050,
                    rapid_rate: 42000,
                    acceleration: 0.5,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.005,
                    repeatability: 0.002
                },
                y: {
                    travel: 530,
                    rapid_rate: 42000,
                    acceleration: 0.5,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.005,
                    repeatability: 0.002
                },
                z: {
                    travel: 510,
                    rapid_rate: 42000,
                    acceleration: 0.5,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.005,
                    repeatability: 0.002
                }
            },
            
            atc: {
                type: "arm_type",
                capacity: 30,
                max_tool_diameter: 80,
                max_tool_length: 300,
                max_tool_weight: 8,
                tool_change_time: 1.6
            },
            
            controller: {
                brand: "MAZAK",
                model: "MAZATROL SmoothG",
                axes_count: 3,
                ai_thermal_shield: true
            },
            
            machine_dimensions: {
                length: 3200,
                width: 2650,
                height: 3100,
                weight: 8500,
                weight_unit: "kg"
            },
            
            kinematic_chain: {
                type: "serial_C_prime",
                structure: "moving_column",
                chain: ["base", "table_fixed", "column_X", "saddle_Y", "spindle_Z"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "column" },
                y: { type: "translation", vector: [0, 1, 0], component: "saddle" },
                z: { type: "translation", vector: [0, 0, 1], component: "spindle_head" }
            }
        },

        // ============================================
        // HORIZONTAL CENTER - HCN SERIES
        // ============================================
        {
            id: "MAZAK_HCN_5000",
            manufacturer: "Mazak",
            model: "HCN-5000",
            type: "horizontal_machining_center",
            subtype: "4_axis_hmc",
            description: "Production horizontal machining center",
            series: "HCN",
            
            work_envelope: {
                x: { min: 0, max: 730, unit: "mm" },
                y: { min: 0, max: 730, unit: "mm" },
                z: { min: 0, max: 880, unit: "mm" },
                b_axis: { min: 0, max: 360, indexing: 0.001 },
                pallet_size: 500,
                max_workpiece_diameter: 800,
                max_workpiece_height: 1000,
                table_load_capacity: 700,
                table_load_unit: "kg"
            },
            
            spindle: {
                type: "built_in_motor",
                taper: "HSK-A63",
                max_rpm: 14000,
                power_rating: 30,
                power_unit: "kW",
                torque_max: 303,
                torque_unit: "Nm",
                orientation: "horizontal"
            },
            
            axis_specs: {
                x: { travel: 730, rapid_rate: 60000, guideway_type: "linear_roller", positioning_accuracy: 0.004 },
                y: { travel: 730, rapid_rate: 60000, guideway_type: "linear_roller", positioning_accuracy: 0.004 },
                z: { travel: 880, rapid_rate: 60000, guideway_type: "linear_roller", positioning_accuracy: 0.005 },
                b: { indexing: 0.001, full_contouring: true, max_torque: 2000, clamping_torque: 4000, drive_type: "roller_gear_cam" }
            },
            
            pallet_changer: {
                type: "dual_pallet",
                pallet_count: 2,
                pallet_size: 500,
                pallet_change_time: 6.5,
                automation_ready: true,
                palletech_compatible: true
            },
            
            atc: {
                type: "chain_magazine",
                capacity: 40,
                capacity_options: [40, 60, 90, 120],
                max_tool_diameter: 100,
                max_tool_length: 450,
                max_tool_weight: 15,
                tool_change_time: 1.5
            },
            
            controller: {
                brand: "MAZAK",
                model: "MAZATROL SmoothG",
                axes_count: 4,
                tcpc: true
            },
            
            machine_dimensions: {
                length: 4400,
                width: 3300,
                height: 3200,
                weight: 16000,
                weight_unit: "kg"
            },
            
            kinematic_chain: {
                type: "T_configuration",
                structure: "traveling_column_HMC",
                chain: ["base", "pallet_B", "column_Z", "saddle_Y", "spindle_X"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "spindle_head" },
                y: { type: "translation", vector: [0, 1, 0], component: "saddle" },
                z: { type: "translation", vector: [0, 0, 1], component: "column" },
                b: { type: "rotation", axis: [0, 1, 0], center: [0, 0, 0], component: "pallet" }
            }
        },

        // ============================================
        // TURNING CENTER - QTN SERIES
        // ============================================
        {
            id: "MAZAK_QTN_250MY",
            manufacturer: "Mazak",
            model: "QT-NEXUS 250-II MY",
            type: "turning_center",
            subtype: "y_axis_lathe",
            description: "High-performance turning center with Y-axis and milling",
            series: "QUICK TURN NEXUS",
            
            work_envelope: {
                swing_over_bed: 700,
                swing_over_cross_slide: 450,
                max_turning_diameter: 366,
                max_turning_length: 500,
                bar_capacity: 65,
                unit: "mm"
            },
            
            spindle: {
                type: "built_in_motor",
                chuck_size: 10,
                chuck_size_unit: "inch",
                bore_diameter: 76,
                max_rpm: 4000,
                power_rating: 22,
                power_unit: "kW",
                torque_max: 536,
                torque_unit: "Nm",
                c_axis: true,
                c_axis_indexing: 0.0001,
                spindle_nose: "A2-8"
            },
            
            axis_specs: {
                x: {
                    travel: 235,
                    rapid_rate: 30000,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.004,
                    repeatability: 0.002
                },
                y: {
                    travel: { min: -50, max: 50 },
                    total_travel: 100,
                    rapid_rate: 15000,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.004,
                    repeatability: 0.002
                },
                z: {
                    travel: 570,
                    rapid_rate: 30000,
                    guideway_type: "linear_roller",
                    positioning_accuracy: 0.006,
                    repeatability: 0.003
                },
                c: {
                    type: "main_spindle_positioning",
                    indexing: 0.0001,
                    max_rpm_positioning: 50,
                    clamping_torque: 220
                }
            },
            
            turret: {
                type: "milling_turret",
                stations: 12,
                tool_size: "25mm_square",
                boring_bar_capacity: 50,
                live_tooling: true,
                live_stations: 12,
                live_tool_rpm: 6000,
                live_tool_power: 5.5,
                indexing_time: 0.2,
                y_axis_milling: true
            },
            
            tailstock: {
                quill_diameter: 80,
                quill_travel: 100,
                taper: "MT4",
                thrust_force: 10000,
                programmable: true
            },
            
            controller: {
                brand: "MAZAK",
                model: "MAZATROL SmoothG",
                axes_count: 4,
                c_axis: true,
                y_axis: true,
                rigid_tapping: true
            },
            
            machine_dimensions: {
                length: 3500,
                width: 1900,
                height: 1900,
                weight: 6500,
                weight_unit: "kg"
            },
            
            kinematic_chain: {
                type: "lathe_Y_axis",
                structure: "slant_bed_with_Y",
                chain: ["bed", "headstock_spindle_C", "cross_slide_X", "y_slide_Y", "turret_Z"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "cross_slide" },
                y: { type: "translation", vector: [0, 1, 0], component: "y_slide" },
                z: { type: "translation", vector: [0, 0, 1], component: "turret" },
                c: { type: "rotation", axis: [0, 0, 1], component: "spindle" }
            }
        },
        
        {
            id: "MAZAK_QTN_350M",
            manufacturer: "Mazak",
            model: "QUICK TURN NEXUS 350M",
            type: "turning_center",
            subtype: "mill_turn_lathe",
            description: "Large turning center with milling capability",
            series: "QUICK TURN NEXUS",
            
            work_envelope: {
                swing_over_bed: 810,
                max_turning_diameter: 500,
                max_turning_length: 1016,
                bar_capacity: 102,
                unit: "mm"
            },
            
            spindle: {
                type: "built_in_motor",
                chuck_size: 12,
                chuck_size_unit: "inch",
                bore_diameter: 112,
                max_rpm: 3000,
                power_rating: 30,
                power_unit: "kW",
                torque_max: 955,
                c_axis: true
            },
            
            axis_specs: {
                x: { travel: 300, rapid_rate: 30000, positioning_accuracy: 0.005 },
                z: { travel: 1100, rapid_rate: 30000, positioning_accuracy: 0.006 },
                c: { indexing: 0.0001, clamping_torque: 350 }
            },
            
            turret: {
                type: "VDI_50",
                stations: 12,
                live_tooling: true,
                live_tool_rpm: 4500,
                live_tool_power: 7.5
            },
            
            controller: { brand: "MAZAK", model: "MAZATROL SmoothG", axes_count: 3 },
            
            machine_dimensions: { length: 4200, width: 2100, height: 2100, weight: 9500, weight_unit: "kg" },
            
            kinematic_chain: {
                type: "lathe_standard",
                structure: "slant_bed_mill_turn",
                chain: ["bed", "headstock_spindle_C", "cross_slide_X", "turret_Z"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "cross_slide" },
                z: { type: "translation", vector: [0, 0, 1], component: "turret" },
                c: { type: "rotation", axis: [0, 0, 1], component: "spindle" }
            }
        },

        // ============================================
        // COMPACT - VCE SERIES
        // ============================================
        {
            id: "MAZAK_VCE_500",
            manufacturer: "Mazak",
            model: "VCE-500",
            type: "vertical_machining_center",
            subtype: "compact_vmc",
            description: "Compact entry-level VMC",
            series: "VCE",
            
            work_envelope: {
                x: { min: 0, max: 500, unit: "mm" },
                y: { min: 0, max: 400, unit: "mm" },
                z: { min: 0, max: 460, unit: "mm" },
                table_length: 600,
                table_width: 400,
                table_load_capacity: 400,
                table_load_unit: "kg"
            },
            
            spindle: {
                type: "belt_driven",
                taper: "BT40",
                max_rpm: 10000,
                power_rating: 11,
                power_unit: "kW",
                torque_max: 65,
                torque_unit: "Nm"
            },
            
            axis_specs: {
                x: { travel: 500, rapid_rate: 36000, positioning_accuracy: 0.008 },
                y: { travel: 400, rapid_rate: 36000, positioning_accuracy: 0.008 },
                z: { travel: 460, rapid_rate: 30000, positioning_accuracy: 0.008 }
            },
            
            atc: { type: "arm_type", capacity: 20, tool_change_time: 2.2 },
            
            controller: { brand: "MAZAK", model: "MAZATROL SmoothEz", axes_count: 3 },
            
            machine_dimensions: { length: 2400, width: 2100, height: 2700, weight: 4500, weight_unit: "kg" },
            
            kinematic_chain: {
                type: "serial_C_prime",
                structure: "fixed_column",
                chain: ["base", "column", "table_X", "saddle_Y", "spindle_Z"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "table" },
                y: { type: "translation", vector: [0, 1, 0], component: "saddle" },
                z: { type: "translation", vector: [0, 0, 1], component: "spindle_head" }
            }
        },

        // ============================================
        // HIGH-SPEED - CV5-500 SERIES
        // ============================================
        {
            id: "MAZAK_CV5_500",
            manufacturer: "Mazak",
            model: "CV5-500",
            type: "vertical_machining_center",
            subtype: "5_axis_simultaneous",
            description: "Compact 5-axis simultaneous machining center",
            series: "CV5",
            
            work_envelope: {
                x: { min: 0, max: 500, unit: "mm" },
                y: { min: 0, max: 350, unit: "mm" },
                z: { min: 0, max: 510, unit: "mm" },
                a_axis: { min: -40, max: 110, unit: "deg" },
                c_axis: { min: -360, max: 360, continuous: true },
                table_diameter: 400,
                table_load_capacity: 120,
                table_load_unit: "kg"
            },
            
            spindle: {
                type: "built_in_motor",
                taper: "HSK-A63",
                max_rpm: 12000,
                power_rating: 15,
                power_unit: "kW",
                torque_max: 120,
                torque_unit: "Nm"
            },
            
            axis_specs: {
                x: { travel: 500, rapid_rate: 50000, acceleration: 0.8, positioning_accuracy: 0.004 },
                y: { travel: 350, rapid_rate: 50000, acceleration: 0.8, positioning_accuracy: 0.004 },
                z: { travel: 510, rapid_rate: 50000, acceleration: 0.8, positioning_accuracy: 0.004 },
                a: { travel: { min: -40, max: 110 }, rapid_rate: 40, drive_type: "direct_drive", positioning_accuracy: 0.001 },
                c: { continuous: true, rapid_rate: 150, drive_type: "direct_drive", positioning_accuracy: 0.001 }
            },
            
            atc: { type: "disc_magazine", capacity: 30, tool_change_time: 1.8 },
            
            controller: {
                brand: "MAZAK",
                model: "MAZATROL SmoothX",
                axes_count: 5,
                simultaneous_axes: 5,
                tcpc: true
            },
            
            machine_dimensions: { length: 2300, width: 2600, height: 3200, weight: 7000, weight_unit: "kg" },
            
            kinematic_chain: {
                type: "table_table",
                structure: "compact_AC_trunnion",
                chain: ["base", "column", "y_saddle", "z_ram", "spindle", "table_X", "a_trunnion", "c_table"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "table" },
                y: { type: "translation", vector: [0, 1, 0], component: "y_saddle" },
                z: { type: "translation", vector: [0, 0, 1], component: "z_ram" },
                a: { type: "rotation", axis: [1, 0, 0], center: [0, 0, 150], component: "a_trunnion" },
                c: { type: "rotation", axis: [0, 0, 1], center: [0, 0, 0], component: "c_table" }
            }
        },

        // ============================================
        // DOUBLE COLUMN - FJV SERIES
        // ============================================
        {
            id: "MAZAK_FJV_250",
            manufacturer: "Mazak",
            model: "FJV-250",
            type: "double_column_machining_center",
            subtype: "bridge_type",
            description: "Double-column 5-face machining center",
            series: "FJV",
            
            work_envelope: {
                x: { min: 0, max: 1500, unit: "mm" },
                y: { min: 0, max: 1200, unit: "mm" },
                z: { min: 0, max: 700, unit: "mm" },
                table_length: 1800,
                table_width: 1200,
                table_load_capacity: 3000,
                table_load_unit: "kg"
            },
            
            spindle: {
                type: "built_in_motor",
                taper: "BT50",
                max_rpm: 6000,
                power_rating: 30,
                power_unit: "kW",
                torque_max: 420,
                torque_unit: "Nm"
            },
            
            axis_specs: {
                x: { travel: 1500, rapid_rate: 24000, guideway_type: "linear_roller", positioning_accuracy: 0.010 },
                y: { travel: 1200, rapid_rate: 24000, guideway_type: "linear_roller", positioning_accuracy: 0.010 },
                z: { travel: 700, rapid_rate: 18000, guideway_type: "linear_roller", positioning_accuracy: 0.010 }
            },
            
            atc: { type: "arm_type", capacity: 30, tool_change_time: 5 },
            
            controller: { brand: "MAZAK", model: "MAZATROL SmoothG", axes_count: 3 },
            
            machine_dimensions: { length: 5000, width: 3500, height: 3500, weight: 20000, weight_unit: "kg" },
            
            kinematic_chain: {
                type: "bridge_type",
                structure: "fixed_table_moving_bridge",
                chain: ["base", "table_fixed", "bridge_X", "crossrail", "saddle_Y", "ram_Z"]
            },
            
            transformations: {
                x: { type: "translation", vector: [1, 0, 0], component: "bridge" },
                y: { type: "translation", vector: [0, 1, 0], component: "saddle" },
                z: { type: "translation", vector: [0, 0, 1], component: "ram" }
            }
        }
    ],

    // Helper functions
    getMachineById: function(id) { return this.machines.find(m => m.id === id); },
    getMachinesByType: function(type) { return this.machines.filter(m => m.type === type); },
    getMachinesBySeries: function(series) { return this.machines.filter(m => m.series === series); },
    get5AxisMachines: function() { return this.machines.filter(m => m.subtype && m.subtype.includes("5_axis")); },
    getMillTurnMachines: function() { return this.machines.filter(m => m.type === "mill_turn_center"); },
    getIntegrexMachines: function() { return this.machines.filter(m => m.series === "INTEGREX i"); },
    getVariaxisMachines: function() { return this.machines.filter(m => m.series === "VARIAXIS i"); },
    
    exportForSimulation: function(machineId) {
        const machine = this.getMachineById(machineId);
        if (!machine) return null;
        return {
            id: machine.id,
            name: `${machine.manufacturer} ${machine.model}`,
            kinematic_chain: machine.kinematic_chain,
            transformations: machine.transformations,
            axis_specs: machine.axis_specs,
            work_envelope: machine.work_envelope,
            geometry_reference: machine.geometry_reference
        };
    }
};

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PRISM_MAZAK_MACHINE_DATABASE_ENHANCED;
}
if (typeof window !== 'undefined') {
    window.PRISM_MAZAK_MACHINE_DATABASE_ENHANCED = PRISM_MAZAK_MACHINE_DATABASE_ENHANCED;
}
