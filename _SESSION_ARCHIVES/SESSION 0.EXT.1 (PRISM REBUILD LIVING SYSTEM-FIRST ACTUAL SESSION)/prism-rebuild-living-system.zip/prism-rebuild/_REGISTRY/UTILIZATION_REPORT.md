# PRISM REBUILD - UTILIZATION REPORT
## Database → Consumer Wiring Status

**Last Updated:** 2026-01-20
**Last Session:** 0.SETUP.1

---

# DATABASE UTILIZATION

## Materials Databases (6)

| Database | Min Consumers | Actual | Status |
|----------|---------------|--------|--------|
| PRISM_MATERIALS_MASTER | 15 | 0 | ⬜ Not Imported |
| PRISM_MATERIAL_KC_DATABASE | 8 | 0 | ⬜ Not Imported |
| PRISM_ENHANCED_MATERIAL_DATABASE | 8 | 0 | ⬜ Not Imported |
| PRISM_EXTENDED_MATERIAL_CUTTING_DB | 8 | 0 | ⬜ Not Imported |
| PRISM_JOHNSON_COOK_DATABASE | 8 | 0 | ⬜ Not Imported |
| PRISM_CONSOLIDATED_MATERIALS | 8 | 0 | ⬜ Not Imported |

## Machine Databases (7)

| Database | Min Consumers | Actual | Status |
|----------|---------------|--------|--------|
| PRISM_MACHINES_DATABASE | 12 | 0 | ⬜ Not Imported |
| (6 more) | 8 | 0 | ⬜ Not Imported |

## Tool Databases (7)

| Database | Min Consumers | Actual | Status |
|----------|---------------|--------|--------|
| PRISM_TOOL_DATABASE_V7 | 10 | 0 | ⬜ Not Imported |
| (6 more) | 8 | 0 | ⬜ Not Imported |

---

# ENGINE UTILIZATION

## AI/ML Engines (74)

| Engine | Min Uses | Actual | Status |
|--------|----------|--------|--------|
| PRISM_PSO_OPTIMIZER | 5 | 0 | ⬜ Not Imported |
| PRISM_BAYESIAN_ENGINE | 5 | 0 | ⬜ Not Imported |
| PRISM_NEURAL_NETWORK | 5 | 0 | ⬜ Not Imported |
| (71 more) | 5 | 0 | ⬜ Not Imported |

## Physics Engines (42)

| Engine | Min Uses | Actual | Status |
|--------|----------|--------|--------|
| PRISM_TAYLOR_TOOL_LIFE | 6 | 0 | ⬜ Not Imported |
| PRISM_KIENZLE_FORCE | 6 | 0 | ⬜ Not Imported |
| PRISM_MERCHANT_FORCE | 6 | 0 | ⬜ Not Imported |
| (39 more) | 6 | 0 | ⬜ Not Imported |

---

# CALCULATION SOURCE TRACKING

| Calculation Type | Required Sources | Implemented | Status |
|------------------|------------------|-------------|--------|
| Speed Calculation | 6 | 0 | ⬜ Not Implemented |
| Feed Calculation | 6 | 0 | ⬜ Not Implemented |
| Force Calculation | 6 | 0 | ⬜ Not Implemented |
| Tool Life Calculation | 6 | 0 | ⬜ Not Implemented |
| Surface Finish Calculation | 6 | 0 | ⬜ Not Implemented |

---

**OVERALL UTILIZATION: 0%**

