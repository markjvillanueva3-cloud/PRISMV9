---
name: prism-state-manager
description: PRISM Manufacturing Intelligence session state management. Use when starting/ending PRISM development sessions, updating CURRENT_STATE.json, managing session logs, or recovering from context compaction. Handles the state-driven development workflow required by PRISM v5.0.
---

# PRISM State Manager

Manages session state for PRISM Manufacturing Intelligence v9.0 rebuild.

## Critical Paths

```
STATE FILE: C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)\CURRENT_STATE.json
SESSION LOGS: C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)\SESSION_LOGS\
LOCAL ROOT: C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)\
```

## Session Start Protocol

1. Read CURRENT_STATE.json
2. Verify folder access with list_directory
3. Read latest session log (if exists)
4. Announce: `STARTING SESSION [ID]: [NAME]`
5. Update state to IN_PROGRESS

```python
python scripts/session_start.py
```

## During Session

Update state every 3-5 tool calls:
- After completing significant tasks
- Before risky operations
- When making architectural decisions

```python
python scripts/update_state.py --task "Extracted PRISM_MATERIALS_MASTER" --progress 15
```

## Session End Protocol

1. Update CURRENT_STATE.json (status, progress, nextSteps)
2. Write session log
3. Announce completion with next steps
4. Remind about Box sync

```python
python scripts/session_end.py --completed "task1,task2" --next "1.A.2"
```

## Recovery After Compaction

If context compacted:
1. Read transcript file from compaction summary
2. Read CURRENT_STATE.json
3. Read latest session log
4. Continue from currentWork.nextSteps

```python
python scripts/recover_state.py
```

## State File Schema

See `references/state_schema.md` for CURRENT_STATE.json structure.

## Session ID Format

```
STAGE.CATEGORY.NUMBER
│      │        │
│      │        └── Sequential number
│      └────────── Category (A=DBs, B=Engines, etc.)
└─────────────────── Stage (0=Prep, 1=Extract, 2=Arch, 3=Migrate)
```
