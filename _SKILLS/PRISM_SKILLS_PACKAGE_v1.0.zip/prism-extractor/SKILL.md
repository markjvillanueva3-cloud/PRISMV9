---
name: prism-extractor
description: Extract modules from PRISM v8.89.002 monolith (986,621 lines). Use when extracting databases, engines, knowledge bases, or any module from the source HTML file. Handles module boundary detection, dependency documentation, and output generation.
---

# PRISM Module Extractor

Extracts modules from the monolith into categorized files.

## Source & Output Paths

```
SOURCE: C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)\_BUILD\PRISM_v8_89_002_TRUE_100_PERCENT.html
OUTPUT: C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)\EXTRACTED\[category]\
```

## Quick Extraction

```python
# Extract single module by name
python scripts/extract_module.py --name PRISM_MATERIALS_MASTER --output materials/

# Extract category batch
python scripts/extract_batch.py --category databases.materials --output materials/
```

## Module Categories

| Category | Count | Output Folder |
|----------|-------|---------------|
| Materials DBs | 6 | `EXTRACTED/databases/materials/` |
| Machine DBs | 7 | `EXTRACTED/databases/machines/CORE/` |
| Tool DBs | 7 | `EXTRACTED/databases/tools/` |
| Workholding DBs | 10 | `EXTRACTED/databases/workholding/` |
| Post DBs | 7 | `EXTRACTED/databases/post/` |
| Process DBs | 6 | `EXTRACTED/databases/process/` |
| Business DBs | 4 | `EXTRACTED/databases/business/` |
| CAD Engines | 25 | `EXTRACTED/engines/cad/` |
| CAM Engines | 20 | `EXTRACTED/engines/cam/` |
| Physics Engines | 42 | `EXTRACTED/engines/physics/` |
| AI/ML Engines | 74 | `EXTRACTED/engines/ai_ml/` |
| Optimization | 44 | `EXTRACTED/engines/optimization/` |

## Extraction Rules

1. **COMPLETE modules only** - No partial extractions
2. **Preserve ALL comments** - Documentation is critical
3. **Document dependencies** - Add header listing what module NEEDS
4. **Document outputs** - Add header listing what module PRODUCES
5. **Create index file** - Each category gets an index.js

## Output File Template

```javascript
/**
 * PRISM MODULE: [NAME]
 * Extracted: [DATE]
 * Source: PRISM_v8_89_002 line [START]-[END]
 * 
 * DEPENDENCIES (what this module needs):
 * - PRISM_CONSTANTS
 * - PRISM_UNITS
 * - [etc.]
 * 
 * OUTPUTS (what this module produces):
 * - getMaterial(id) → MaterialData
 * - calculateKc(params) → CuttingCoefficient
 * - [etc.]
 * 
 * CONSUMERS (who uses this module):
 * - PRISM_SPEED_FEED_CALCULATOR
 * - PRISM_FORCE_CALCULATOR
 * - [etc.]
 */

// Original module code below...
```

## Known Line Numbers (Key Modules)

See `references/module_locations.md` for complete line number mapping.

## Verification

After extraction, verify:
- All functions present (compare function count)
- All data present (compare object keys)
- No syntax errors (parse with Node.js)
- Dependencies documented
- Outputs documented
