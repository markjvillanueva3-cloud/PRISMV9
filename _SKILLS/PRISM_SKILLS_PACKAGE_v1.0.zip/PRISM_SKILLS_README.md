# PRISM Manufacturing Intelligence - Custom Skills Package
## Version 1.0 | January 21, 2026

---

## Overview

This package contains **8 custom skills** designed specifically for PRISM v9.0 development:

| # | Skill | Purpose | Priority |
|---|-------|---------|----------|
| 1 | **prism-state-manager** | Session state, CURRENT_STATE.json management | CRITICAL |
| 2 | **prism-extractor** | Extract modules from 986K-line monolith | CRITICAL |
| 3 | **prism-python-tools** | Python automation, batch processing | CRITICAL |
| 4 | **prism-auditor** | Verify extraction completeness | CRITICAL |
| 5 | **prism-utilization** | Enforce 100% utilization requirements | CRITICAL |
| 6 | **prism-swarm-orchestrator** | Multi-agent parallel extraction (NEW) | HIGH |
| 7 | **prism-hierarchy-manager** | 4-layer database architecture (NEW) | HIGH |
| 8 | **prism-consumer-mapper** | Auto-generate consumer wiring (NEW) | HIGH |

---

## Installation

### Option 1: Copy to Claude Project
Copy each skill folder to your Claude Project's custom skills location.

### Option 2: Reference from Local
Point Claude to read skills from:
```
C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)\_SKILLS\
```

---

## Skill Summaries

### 1. prism-state-manager (Priority #1)
**Triggers:** Session start/end, state updates, compaction recovery

**Key Scripts:**
- `session_start.py` - Initialize session, read state
- `session_end.py` - Complete session, write log
- `update_state.py` - Incremental state updates

**Usage:**
```python
python scripts/session_start.py
# During work...
python scripts/update_state.py --task "Extracted materials" --progress 15
# At end...
python scripts/session_end.py --completed "task1,task2" --next "1.A.2"
```

### 2. prism-extractor (Priority #2)
**Triggers:** Extract modules, find module locations, batch extraction

**Key Scripts:**
- `extract_module.py` - Extract single module with header
- `module_locations.md` - Known line numbers for key modules

**Usage:**
```python
python scripts/extract_module.py --name PRISM_MATERIALS_MASTER --output databases/materials/
```

### 3. prism-python-tools (Priority #3)
**Triggers:** Large file processing, batch operations, path management

**Key Scripts:**
- `prism_paths.py` - All PRISM path constants
- `large_file_search.py` - Efficient 1M+ line searching

**Usage:**
```python
from prism_paths import LOCAL_ROOT, EXTRACTED, RESOURCES
python scripts/large_file_search.py --file monolith.html --pattern "PRISM_MATERIALS"
```

### 4. prism-auditor (Priority #4)
**Triggers:** Verify extraction, check completeness, audit categories

**Key Scripts:**
- `audit_module.py` - Full module completeness check

**Usage:**
```python
python scripts/audit_module.py --module PRISM_MATERIALS_MASTER --path extracted/materials/
```

### 5. prism-utilization (Priority #5)
**Triggers:** Migration verification, consumer wiring, 6-source checks

**Key Scripts:**
- `verify_before_import.py` - BLOCKS incomplete imports

**Usage:**
```python
python scripts/verify_before_import.py --module PRISM_MATERIALS_MASTER --consumers 15
# Will BLOCK if <15 consumers or missing required consumers
```

### 6. prism-swarm-orchestrator (Priority #6 - NEW)
**Triggers:** Parallel extraction, multi-agent coordination, swarm deployment

**Key Scripts:**
- `spawn_extraction_swarm.py` - Deploy extraction agents

**Usage:**
```python
python scripts/spawn_extraction_swarm.py --category databases --agents 4
# Creates MULTI_AGENT_PLAN.md for coordination
```

**ROI:** 5x faster extraction (15-25 sessions → 3-5 sessions)

### 7. prism-hierarchy-manager (Priority #7 - NEW)
**Triggers:** Layer management, inheritance resolution, propagation

**Key Scripts:**
- `resolve_inheritance.py` - Resolve property through 4 layers

**Usage:**
```python
python scripts/resolve_inheritance.py --machine "HAAS VF-2" --property maxRpm
# Returns: Resolved from ENHANCED layer
```

### 8. prism-consumer-mapper (Priority #8 - NEW)
**Triggers:** Consumer mapping, wiring generation, utilization planning

**Key Scripts:**
- `map_consumers.py` - Generate consumer specifications

**Usage:**
```python
python scripts/map_consumers.py --module PRISM_MATERIALS_MASTER --output wiring.js
# Generates wiring code for all 15 required consumers
```

---

## Integration with PRISM v5.0

These skills directly support the v5.0 development protocol:

1. **State Management** → `prism-state-manager`
2. **Stage 1 Extraction** → `prism-extractor` + `prism-swarm-orchestrator`
3. **Extraction Verification** → `prism-auditor`
4. **Stage 3 Migration** → `prism-utilization` + `prism-consumer-mapper`
5. **4-Layer Architecture** → `prism-hierarchy-manager`
6. **Python Automation** → `prism-python-tools`

---

## File Structure

```
prism-skills/
├── prism-state-manager/
│   ├── SKILL.md
│   ├── scripts/
│   │   ├── session_start.py
│   │   ├── session_end.py
│   │   └── update_state.py
│   └── references/
│       └── state_schema.md
├── prism-extractor/
│   ├── SKILL.md
│   ├── scripts/
│   │   └── extract_module.py
│   └── references/
│       └── module_locations.md
├── prism-python-tools/
│   ├── SKILL.md
│   └── scripts/
│       ├── prism_paths.py
│       └── large_file_search.py
├── prism-auditor/
│   ├── SKILL.md
│   └── scripts/
│       └── audit_module.py
├── prism-utilization/
│   ├── SKILL.md
│   └── scripts/
│       └── verify_before_import.py
├── prism-swarm-orchestrator/
│   ├── SKILL.md
│   └── scripts/
│       └── spawn_extraction_swarm.py
├── prism-hierarchy-manager/
│   ├── SKILL.md
│   └── scripts/
│       └── resolve_inheritance.py
└── prism-consumer-mapper/
    ├── SKILL.md
    └── scripts/
        └── map_consumers.py
```

---

## Next Steps

1. **Install skills** to Claude Project or local reference
2. **Start Session 1.A.1** with `prism-state-manager`
3. **Extract materials databases** with `prism-extractor`
4. **Verify extraction** with `prism-auditor`
5. **Consider swarm** for parallel acceleration

---

*Generated for PRISM Manufacturing Intelligence v9.0 rebuild*
*Based on PRISM_ULTIMATE_DEVELOPMENT_MASTER_v5.0.md specifications*
