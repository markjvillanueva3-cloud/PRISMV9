# PRISM Material Lookup Skill
## Pre-Compiled Data Tables from ASM/Machining Data Handbook
**Time Savings: 40% lookup reduction**

---

## PURPOSE
Instant lookup of mechanical properties, compositions, and cutting data for common materials. Eliminates need to search external references during material creation.

---

## CARBON STEEL QUICK REFERENCE (AISI 10XX Series)

### Composition Ranges
| Grade | C% | Mn% | P max | S max | Notes |
|-------|-----|-----|-------|-------|-------|
| 1005 | 0.06 max | 0.35 max | 0.040 | 0.050 | Ultra-low carbon |
| 1006 | 0.08 max | 0.25-0.40 | 0.040 | 0.050 | Low carbon |
| 1008 | 0.10 max | 0.30-0.50 | 0.040 | 0.050 | Low carbon |
| 1010 | 0.08-0.13 | 0.30-0.60 | 0.040 | 0.050 | Low carbon |
| 1015 | 0.13-0.18 | 0.30-0.60 | 0.040 | 0.050 | Low carbon |
| 1018 | 0.15-0.20 | 0.60-0.90 | 0.040 | 0.050 | Low carbon, common |
| 1020 | 0.18-0.23 | 0.30-0.60 | 0.040 | 0.050 | Low carbon |
| 1022 | 0.18-0.23 | 0.70-1.00 | 0.040 | 0.050 | Low carbon, high Mn |
| 1025 | 0.22-0.28 | 0.30-0.60 | 0.040 | 0.050 | Low/medium carbon |
| 1030 | 0.28-0.34 | 0.60-0.90 | 0.040 | 0.050 | Medium carbon |
| 1035 | 0.32-0.38 | 0.60-0.90 | 0.040 | 0.050 | Medium carbon |
| 1040 | 0.37-0.44 | 0.60-0.90 | 0.040 | 0.050 | Medium carbon |
| 1045 | 0.43-0.50 | 0.60-0.90 | 0.040 | 0.050 | Medium carbon |
| 1050 | 0.48-0.55 | 0.60-0.90 | 0.040 | 0.050 | Medium/high carbon |
| 1055 | 0.50-0.60 | 0.60-0.90 | 0.040 | 0.050 | High carbon |
| 1060 | 0.55-0.65 | 0.60-0.90 | 0.040 | 0.050 | High carbon |
| 1070 | 0.65-0.75 | 0.60-0.90 | 0.040 | 0.050 | High carbon |
| 1080 | 0.75-0.88 | 0.60-0.90 | 0.040 | 0.050 | High carbon |
| 1095 | 0.90-1.03 | 0.30-0.50 | 0.040 | 0.050 | Very high carbon |

### Mechanical Properties by Condition

#### ANNEALED Condition
| Grade | UTS (MPa) | Yield (MPa) | Elong % | RA % | HB | Machinability % |
|-------|-----------|-------------|---------|------|-----|-----------------|
| 1010 | 325 | 180 | 28 | 50 | 95 | 55 |
| 1015 | 340 | 190 | 27 | 50 | 101 | 60 |
| 1018 | 400 | 220 | 25 | 50 | 116 | 70 |
| 1020 | 380 | 210 | 25 | 50 | 111 | 65 |
| 1025 | 400 | 220 | 25 | 50 | 116 | 60 |
| 1030 | 460 | 250 | 20 | 42 | 137 | 55 |
| 1035 | 500 | 270 | 18 | 40 | 149 | 55 |
| 1040 | 520 | 290 | 18 | 40 | 149 | 50 |
| 1045 | 565 | 310 | 16 | 40 | 163 | 50 |
| 1050 | 635 | 345 | 15 | 35 | 187 | 45 |
| 1060 | 680 | 370 | 12 | 30 | 201 | 40 |
| 1080 | 770 | 420 | 10 | 25 | 229 | 35 |
| 1095 | 830 | 455 | 10 | 25 | 248 | 30 |

#### HOT ROLLED Condition
| Grade | UTS (MPa) | Yield (MPa) | Elong % | RA % | HB | Machinability % |
|-------|-----------|-------------|---------|------|-----|-----------------|
| 1010 | 365 | 200 | 28 | 50 | 105 | 55 |
| 1015 | 385 | 210 | 27 | 50 | 111 | 60 |
| 1018 | 440 | 240 | 25 | 50 | 126 | 70 |
| 1020 | 420 | 230 | 25 | 50 | 121 | 65 |
| 1025 | 440 | 240 | 25 | 50 | 126 | 60 |
| 1030 | 500 | 275 | 20 | 42 | 149 | 55 |
| 1035 | 550 | 300 | 18 | 40 | 163 | 55 |
| 1040 | 590 | 325 | 18 | 40 | 170 | 50 |
| 1045 | 625 | 345 | 16 | 40 | 179 | 50 |
| 1050 | 725 | 400 | 12 | 30 | 217 | 45 |
| 1060 | 815 | 485 | 10 | 25 | 241 | 40 |

#### COLD DRAWN Condition
| Grade | UTS (MPa) | Yield (MPa) | Elong % | RA % | HB | Machinability % |
|-------|-----------|-------------|---------|------|-----|-----------------|
| 1010 | 415 | 350 | 20 | 45 | 121 | 55 |
| 1015 | 440 | 370 | 18 | 45 | 126 | 60 |
| 1018 | 485 | 415 | 15 | 40 | 143 | 70 |
| 1020 | 470 | 395 | 15 | 40 | 131 | 65 |
| 1025 | 505 | 425 | 15 | 40 | 149 | 60 |
| 1030 | 550 | 460 | 12 | 35 | 163 | 55 |
| 1035 | 585 | 490 | 12 | 35 | 170 | 55 |
| 1040 | 620 | 515 | 12 | 35 | 179 | 50 |
| 1045 | 655 | 550 | 12 | 35 | 187 | 50 |
| 1050 | 690 | 580 | 10 | 30 | 197 | 45 |

#### NORMALIZED Condition
| Grade | UTS (MPa) | Yield (MPa) | Elong % | RA % | HB | Machinability % |
|-------|-----------|-------------|---------|------|-----|-----------------|
| 1020 | 440 | 275 | 35 | 60 | 131 | 65 |
| 1030 | 520 | 345 | 32 | 60 | 149 | 55 |
| 1035 | 565 | 365 | 28 | 55 | 163 | 55 |
| 1040 | 590 | 375 | 28 | 55 | 170 | 50 |
| 1045 | 625 | 395 | 25 | 50 | 179 | 50 |
| 1050 | 745 | 425 | 20 | 40 | 217 | 45 |

---

## ALLOY STEEL QUICK REFERENCE (AISI 41XX, 43XX, 86XX)

### 4140 Chrome-Moly Steel
| Condition | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability % |
|-----------|-----------|-------------|---------|-----|-----------------|
| Annealed | 655 | 415 | 25 | 197 | 65 |
| Normalized | 1020 | 655 | 18 | 302 | 50 |
| Q&T 205°C | 1770 | 1640 | 8 | 495 | 25 |
| Q&T 315°C | 1550 | 1430 | 9 | 445 | 30 |
| Q&T 425°C | 1250 | 1140 | 13 | 375 | 40 |
| Q&T 540°C | 1000 | 860 | 17 | 295 | 50 |
| Q&T 650°C | 860 | 655 | 22 | 262 | 55 |

### 4340 Nickel-Chrome-Moly Steel
| Condition | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability % |
|-----------|-----------|-------------|---------|-----|-----------------|
| Annealed | 745 | 470 | 22 | 217 | 50 |
| Normalized | 1280 | 860 | 12 | 363 | 40 |
| Q&T 205°C | 1875 | 1675 | 10 | 530 | 20 |
| Q&T 315°C | 1725 | 1585 | 10 | 490 | 25 |
| Q&T 425°C | 1470 | 1365 | 10 | 430 | 30 |
| Q&T 540°C | 1170 | 1005 | 13 | 350 | 40 |
| Q&T 650°C | 965 | 830 | 19 | 290 | 50 |

### 8620 Nickel-Chrome-Moly (Carburizing)
| Condition | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability % |
|-----------|-----------|-------------|---------|-----|-----------------|
| Annealed | 540 | 360 | 26 | 149 | 65 |
| Normalized | 635 | 360 | 26 | 183 | 60 |
| Carburized | Case: 60 HRC, Core: 30 HRC | - | - | - | 35 |

---

## STAINLESS STEEL QUICK REFERENCE

### Austenitic (300 Series)
| Grade | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability % | Notes |
|-------|-----------|-------------|---------|-----|-----------------|-------|
| 304 | 515 | 205 | 40 | 160 | 45 | Most common |
| 304L | 485 | 170 | 40 | 150 | 45 | Low carbon |
| 316 | 515 | 205 | 40 | 160 | 40 | Molybdenum added |
| 316L | 485 | 170 | 40 | 150 | 40 | Low carbon |
| 321 | 515 | 205 | 40 | 160 | 45 | Titanium stabilized |
| 347 | 515 | 205 | 40 | 160 | 45 | Columbium stabilized |

### Martensitic (400 Series)
| Grade | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability % | Notes |
|-------|-----------|-------------|---------|-----|-----------------|-------|
| 410 Ann | 485 | 275 | 30 | 155 | 55 | General purpose |
| 410 HT | 1310 | 1000 | 15 | 388 | 30 | Hardened |
| 420 Ann | 655 | 345 | 25 | 195 | 50 | Cutlery grade |
| 440C Ann | 760 | 450 | 14 | 223 | 40 | High carbon |
| 440C HT | 1965 | 1895 | 2 | 580 | 15 | Hardened |

### Ferritic (400 Series)
| Grade | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability % | Notes |
|-------|-----------|-------------|---------|-----|-----------------|-------|
| 430 | 515 | 310 | 30 | 155 | 55 | General purpose |
| 446 | 515 | 310 | 25 | 160 | 50 | High chromium |

---

## ALUMINUM ALLOY QUICK REFERENCE

### Wrought Alloys
| Alloy | Temper | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability |
|-------|--------|-----------|-------------|---------|-----|---------------|
| 2024 | O | 185 | 75 | 20 | 47 | Good |
| 2024 | T3 | 485 | 345 | 18 | 120 | Fair |
| 2024 | T4 | 470 | 325 | 20 | 120 | Fair |
| 6061 | O | 125 | 55 | 25 | 30 | Excellent |
| 6061 | T4 | 240 | 145 | 22 | 65 | Excellent |
| 6061 | T6 | 310 | 275 | 12 | 95 | Excellent |
| 7075 | O | 230 | 105 | 17 | 60 | Good |
| 7075 | T6 | 570 | 505 | 11 | 150 | Fair |
| 7075 | T73 | 505 | 435 | 13 | 135 | Fair |

### Cast Alloys
| Alloy | Temper | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability |
|-------|--------|-----------|-------------|---------|-----|---------------|
| A356 | T6 | 230 | 165 | 3 | 80 | Excellent |
| A380 | F | 315 | 160 | 3 | 80 | Excellent |

---

## TITANIUM ALLOY QUICK REFERENCE

| Alloy | Condition | UTS (MPa) | Yield (MPa) | Elong % | HB | Machinability % |
|-------|-----------|-----------|-------------|---------|-----|-----------------|
| CP Ti Gr 1 | Annealed | 240 | 170 | 24 | 120 | 30 |
| CP Ti Gr 2 | Annealed | 345 | 275 | 20 | 160 | 25 |
| CP Ti Gr 4 | Annealed | 550 | 480 | 15 | 250 | 20 |
| Ti-6Al-4V | Annealed | 895 | 825 | 10 | 334 | 20 |
| Ti-6Al-4V | STA | 1100 | 1035 | 10 | 375 | 15 |
| Ti-6Al-2Sn-4Zr-2Mo | Annealed | 900 | 830 | 10 | 340 | 18 |

---

## PHYSICAL PROPERTIES CONSTANTS

### Density (kg/m³)
| Material | Density |
|----------|---------|
| Carbon Steel | 7850 |
| Alloy Steel | 7850 |
| Stainless 300 series | 8000 |
| Stainless 400 series | 7750 |
| Aluminum 2xxx | 2780 |
| Aluminum 6xxx | 2700 |
| Aluminum 7xxx | 2810 |
| Titanium CP | 4510 |
| Ti-6Al-4V | 4430 |
| Inconel 718 | 8190 |
| Gray Cast Iron | 7150 |
| Ductile Iron | 7100 |

### Thermal Conductivity (W/(m·K))
| Material | k Value |
|----------|---------|
| Carbon Steel (low C) | 51.9 |
| Carbon Steel (med C) | 49.8 |
| Carbon Steel (high C) | 48.5 |
| Alloy Steel 4140 | 42.7 |
| Stainless 304/316 | 16.2 |
| Stainless 410 | 24.9 |
| Aluminum 6061 | 167 |
| Aluminum 7075 | 130 |
| Titanium CP | 16.4 |
| Ti-6Al-4V | 7.2 |
| Inconel 718 | 11.4 |

### Melting Points (°C)
| Material | Solidus | Liquidus |
|----------|---------|----------|
| Low Carbon Steel | 1500 | 1530 |
| Medium Carbon Steel | 1480 | 1520 |
| High Carbon Steel | 1460 | 1495 |
| 4140 | 1430 | 1500 |
| 304 Stainless | 1400 | 1450 |
| 316 Stainless | 1370 | 1400 |
| 6061 Aluminum | 580 | 650 |
| 7075 Aluminum | 475 | 635 |
| Ti-6Al-4V | 1604 | 1660 |

---

## KIENZLE Kc1.1 QUICK LOOKUP (N/mm²)

| Material | HB Range | Kc1.1 | mc |
|----------|----------|-------|-----|
| Low C Steel (ann) | 90-130 | 1400-1600 | 0.20-0.24 |
| Low C Steel (CD) | 120-160 | 1500-1800 | 0.22-0.26 |
| Med C Steel (ann) | 140-180 | 1700-1950 | 0.23-0.27 |
| Med C Steel (norm) | 150-200 | 1800-2100 | 0.24-0.28 |
| High C Steel (sph) | 170-220 | 2000-2300 | 0.26-0.30 |
| 4140 Annealed | 180-220 | 1900-2200 | 0.24-0.28 |
| 4140 Q&T | 280-350 | 2400-2800 | 0.28-0.32 |
| 304 Stainless | 150-200 | 2200-2600 | 0.26-0.30 |
| 316 Stainless | 150-200 | 2300-2700 | 0.26-0.30 |
| 6061-T6 | 90-110 | 700-900 | 0.16-0.20 |
| 7075-T6 | 140-160 | 900-1100 | 0.18-0.22 |
| Ti-6Al-4V | 320-380 | 2100-2500 | 0.22-0.26 |
| Gray Cast Iron | 180-260 | 1100-1400 | 0.28-0.34 |
| Ductile Iron | 170-280 | 1300-1700 | 0.26-0.32 |

---

## TAYLOR TOOL LIFE COEFFICIENTS

### HSS Tools
| Material | C (m/min) | n |
|----------|-----------|-----|
| Low C Steel | 35-50 | 0.10-0.14 |
| Medium C Steel | 28-40 | 0.10-0.13 |
| High C Steel | 20-30 | 0.09-0.12 |
| 4140 Annealed | 25-35 | 0.10-0.13 |
| 304 Stainless | 15-22 | 0.08-0.11 |
| 6061-T6 | 150-200 | 0.15-0.20 |
| Ti-6Al-4V | 6-10 | 0.06-0.09 |

### Carbide Coated Tools
| Material | C (m/min) | n |
|----------|-----------|-----|
| Low C Steel | 280-380 | 0.25-0.32 |
| Medium C Steel | 240-320 | 0.24-0.30 |
| High C Steel | 200-280 | 0.23-0.28 |
| 4140 Annealed | 220-300 | 0.24-0.29 |
| 304 Stainless | 150-200 | 0.20-0.26 |
| 6061-T6 | 600-900 | 0.30-0.38 |
| Ti-6Al-4V | 50-80 | 0.15-0.22 |

---

## JOHNSON-COOK PARAMETER REFERENCE

| Material | A (MPa) | B (MPa) | n | C | m |
|----------|---------|---------|------|-------|-----|
| AISI 1006 | 350 | 275 | 0.36 | 0.022 | 1.0 |
| AISI 1018 | 310 | 530 | 0.26 | 0.016 | 1.0 |
| AISI 1045 | 553 | 600 | 0.23 | 0.013 | 1.0 |
| AISI 4140 Ann | 595 | 580 | 0.13 | 0.023 | 1.0 |
| AISI 4340 | 792 | 510 | 0.26 | 0.014 | 1.03 |
| 304 Stainless | 310 | 1000 | 0.65 | 0.070 | 1.0 |
| 316L Stainless | 305 | 1161 | 0.61 | 0.010 | 1.0 |
| 6061-T6 | 324 | 114 | 0.42 | 0.002 | 1.34 |
| 7075-T6 | 520 | 477 | 0.52 | 0.001 | 1.61 |
| Ti-6Al-4V | 1098 | 1092 | 0.93 | 0.014 | 1.1 |

---

## USAGE

1. Find material grade in appropriate table
2. Note condition (annealed, normalized, Q&T, etc.)
3. Copy UTS, yield, elongation, hardness
4. Use Kc1.1 lookup for cutting parameters
5. Use Taylor coefficients for tool life
6. Use J-C parameters for constitutive model

**Sources:** ASM Metals Handbook Vol 1, Machining Data Handbook 3rd Ed, MMPDS-17, Tool manufacturer catalogs
