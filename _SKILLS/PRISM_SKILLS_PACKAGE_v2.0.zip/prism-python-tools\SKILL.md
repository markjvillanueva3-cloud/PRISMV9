---
name: prism-python-tools
description: Python automation utilities for PRISM development. Use when processing large files, batch operations, file manipulation, data transformation, or any task requiring Python scripting. Includes PDF catalog processing, STEP file analysis, and batch file operations.
---

# PRISM Python Tools

Python utilities for PRISM manufacturing intelligence development.

## Available Scripts

### File Operations

```python
# Batch file operations
python scripts/batch_file_ops.py --operation move --source dir1 --dest dir2 --pattern "*.js"

# Large file search (faster than grep for 1M+ lines)
python scripts/large_file_search.py --file monolith.html --pattern "PRISM_MATERIALS" --context 10
```

### Data Processing

```python
# Convert extracted JS to JSON for analysis
python scripts/js_to_json.py --input module.js --output module.json

# Merge multiple extracted modules
python scripts/merge_modules.py --inputs "db1.js,db2.js" --output merged.js
```

### Manufacturing-Specific

```python
# Extract data from manufacturer PDF catalogs
python scripts/pdf_catalog_extract.py --input catalog.pdf --output catalog.json

# Parse STEP files for machine geometry
python scripts/step_parser.py --input machine.step --output geometry.json
```

## Path Constants

All scripts use these paths:

```python
LOCAL_ROOT = r"C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)"
BOX_ROOT = r"C:\Users\Mark Villanueva\Box\PRISM REBUILD"
EXTRACTED = os.path.join(LOCAL_ROOT, "EXTRACTED")
RESOURCES = os.path.join(BOX_ROOT, "RESOURCES")
CATALOGS = os.path.join(RESOURCES, "MANUFACTURER CATALOGS")
CAD_FILES = os.path.join(RESOURCES, "CAD FILES")
```

## Dependencies

Required packages:
- `pdfplumber` - PDF text extraction
- `json5` - Lenient JSON parsing
- `tqdm` - Progress bars

Install: `pip install pdfplumber json5 tqdm --break-system-packages`

## Usage Pattern

```python
# Import the PRISM paths
from prism_paths import LOCAL_ROOT, EXTRACTED, RESOURCES

# Use in scripts
output_path = os.path.join(EXTRACTED, "databases", "materials")
```

## Tips

- Always use `encoding='utf-8', errors='ignore'` for large files
- Use generators for 1M+ line files to avoid memory issues
- Batch operations should update state every 100 items
- All output goes to LOCAL_ROOT, never container filesystem
