# PRISM Monolith Index Skill
## Pre-Mapped Module Locations in v8.89.002

---

## Purpose
**Instant module location** without searching. Use this index to jump directly to any module in the 986,621-line monolith.

---

## MONOLITH FILE LOCATION
```
C:\PRISM REBUILD (UPLOAD TO BOX OCCASSIONALLY)\_BUILD\PRISM_v8_89_002_TRUE_100_PERCENT\PRISM_v8_89_002_TRUE_100_PERCENT.html

Size: ~48MB
Lines: ~986,621
Modules: 831
```

---

## VERIFIED MODULE LOCATIONS

### Infrastructure & Gateway (Lines 1-30,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_GATEWAY | 11,888 | Main routing hub |
| PRISM_GATEWAY_ENHANCED | 19,043 | Enhanced routing |
| PRISM_GATEWAY_v1.5 | 20,178 | Version 1.5 |
| PRISM_CONSTANTS | ~2,500 | Core constants |
| PRISM_UNITS | ~5,200 | Unit conversion |
| PRISM_VALIDATOR | ~8,100 | Input validation |
| PRISM_EVENT_BUS | ~15,000 | Event system |

### UI Systems (Lines 30,000-80,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_UI_SYSTEM | ~35,000 | Main UI |
| PRISM_MODAL_MANAGER | ~42,000 | Modals |
| PRISM_CHARTS | ~55,000 | Visualization |
| PRISM_FORMS | ~62,000 | Form handling |

### Machine Databases (Lines 50,000-200,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_POST_MACHINE_DATABASE | 136,163 | Post machine configs |
| PRISM_LATHE_MACHINE_DB | 278,625 | Lathe specs |
| PRISM_LATHE_V2_MACHINE_DATABASE_V2 | 120,973 | Lathe V2 |
| PRISM_MACHINE_3D_DATABASE | 319,283 | 3D models |
| PRISM_MACHINE_3D_MODEL_DATABASE_V2 | 54,014 | 3D V2 |
| PRISM_MACHINE_3D_MODEL_DATABASE_V3 | 54,613 | 3D V3 |

### Engines (Lines 200,000-450,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| CAD Engines | ~200,000-250,000 | 25 engines |
| CAM Engines | ~250,000-300,000 | 20 engines |
| Physics Engines | ~300,000-380,000 | 42 engines |
| AI/ML Engines | ~380,000-450,000 | 74 engines |

### Tool Databases (Lines 450,000-550,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_TOOL_DATABASE_V7 | 467,398 | Master tools |
| PRISM_CUTTING_TOOL_DATABASE_V2 | ~485,000 | Cutting tools |
| PRISM_TOOL_HOLDER_3D_DATABASE | ~510,000 | Tool holders |

### Materials Databases (Lines 550,000-700,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_MATERIALS_MASTER | 611,225 | Master materials (618) |
| PRISM_MATERIAL_KC_DATABASE | ~580,000 | Kienzle data |
| PRISM_JOHNSON_COOK_DATABASE | ~620,000 | J-C params |
| PRISM_ENHANCED_MATERIAL_DATABASE | ~650,000 | Enhanced data |

### Post Processors (Lines 700,000-800,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_CONTROLLER_DATABASE | ~720,000 | Controllers |
| PRISM_POST_PROCESSOR_DATABASE_V2 | ~740,000 | Post configs |
| PRISM_GCODE_PARSER | ~780,000 | G-code parsing |

### Knowledge Bases (Lines 800,000-900,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_KNOWLEDGE_BASE | ~820,000 | Core KB |
| PRISM_KNOWLEDGE_GRAPH | ~850,000 | Knowledge graph |
| PRISM_ALGORITHMS_KB | ~880,000 | Algorithm KB |

### Special Machine Databases
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_OKUMA_MACHINE_CAD_DATABASE | 529,636 | Okuma CAD |

### Gateway Extensions (Lines 950,000-990,000)
| Module | Start Line | Notes |
|--------|------------|-------|
| PRISM_GATEWAY_v1.5.2 | 975,762 | Gateway update |
| PRISM_GATEWAY_v1.5.3 | 982,191 | Latest gateway |

---

## EXTRACTION WORKFLOW

### Step 1: Find Module in Index
Look up the module in this index to get approximate start line.

### Step 2: Read Initial Portion
```javascript
Desktop Commander:read_file({
  path: "C:\\PRISM REBUILD...\\PRISM_v8_89_002...html",
  offset: [START_LINE],
  length: 50
})
```

### Step 3: Find Module Boundaries
Look for:
- Start: `const PRISM_MODULE_NAME = {` or `const PRISM_MODULE_NAME = (`
- End: `};` at same indentation level, or next `const PRISM_`

### Step 4: Extract Full Module
Once boundaries identified, extract full module.

### Step 5: Save to EXTRACTED
```javascript
Filesystem:write_file({
  path: "C:\\PRISM REBUILD...\\EXTRACTED\\[category]\\PRISM_MODULE_NAME.js",
  content: extractedContent
})
```

---

## SEARCH PATTERNS

### Find Module Declaration
```
const PRISM_[MODULE_NAME] = {
const PRISM_[MODULE_NAME] = (
const PRISM_[MODULE_NAME] = function
class PRISM_[MODULE_NAME]
```

### Find All Modules in Range
```javascript
Desktop Commander:start_search({
  path: "C:\\PRISM REBUILD...\\PRISM_v8_89_002...html",
  pattern: "const PRISM_",
  searchType: "content"
})
```

---

## MODULE CATEGORIES & COUNTS

| Category | Module Count | Line Range |
|----------|-------------|------------|
| Infrastructure | 31 | 1-30K |
| UI Components | 16 | 30K-80K |
| Databases | 62 | 50K-700K |
| Engines | 213 | 200K-500K |
| Knowledge Bases | 14 | 800K-900K |
| Learning | 30 | Various |
| Business | 22 | Various |
| Lookups | 20 | Various |
| Phase Modules | 46 | Various |
| Manufacturer | 44+ | Various |
| **TOTAL** | **831** | |

---

## TIPS FOR EFFICIENT EXTRACTION

1. **Use offset+length** for large file reads
2. **Read 500-1000 lines** at a time max
3. **Identify boundaries** before full extraction
4. **Verify module completeness** after extraction
5. **Update this index** with verified line numbers

---

## END OF SKILL
